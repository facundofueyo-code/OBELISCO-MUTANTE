// Prueba 7: capturas (y llamadas de dibujo / triángulos que suman los soldados).
const H=require('../../harness.js'),fs=require('fs'),path=require('path');
const INST=require('./inst.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
const DIR=process.argv[3]||path.join(__dirname,'..','capturas');
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F,{width:640,height:360});lg('abierto');const R={};const ev=c=>h.ev(c);
  /* dibuja un cuadro con la cámara donde está (o donde se la ponga en `cam`), y saca la captura */
  const foto=async(nombre,cam)=>{await ev(`(()=>{renderer.render=window.__render;let t=window.__simT+16;frame(t);window.__simT=t;
      ${cam||''}
      renderer.render=()=>{};return 1;})()`);await h.page.screenshot({path:path.join(DIR,nombre)});lg('foto',nombre);};
  /* cámara a mano: posición y punto al que mira; vuelve a dibujar con esa cámara */
  const camA=(x,y,z,lx,ly,lz,fov)=>`camera.position.set(${x},${y},${z});camera.lookAt(${lx},${ly},${lz});${fov?`camera.fov=${fov};camera.updateProjectionMatrix();`:''}camera.updateMatrixWorld(true);lightsPre();window.__render(scene,camera);lightsPost();`;
  try{
    fs.mkdirSync(DIR,{recursive:true});
    await h.start();await ev("RETEN.ir({bichos:false});1");await ev(INST);await h.step(1);await ev("SECG.A.visible=false;1");
    /* 1. el retén en guardia desde 40 m (el jugador parado en la avenida mirando al oeste) */
    await ev("P.pos.set(-398,floorAt(-398,607.5),607.5);P.vel.set(0,0,0);P.yaw=Math.PI/2;P.pitch=.02;1");
    await foto('c1_reten_40m.png');
    /* llamadas de dibujo: con y sin soldados (mismo cuadro, misma cámara) */
    R.dibujo=await ev(`(()=>{const m=()=>{lightsPre();window.__render(scene,camera);lightsPost();return {calls:renderer.info.render.calls,tris:renderer.info.render.triangles};};
      const a=m();for(const v of UEG.modelos)v.root.visible=false;const b=m();for(const v of UEG.modelos)v.root.visible=v.vis;return {con:a,sin:b,soldados:UEG.modelos.length,visibles:UEG.modelos.filter(v=>v.vis).length};})()`);
    lg('dibujo',JSON.stringify(R.dibujo));
    /* 2. un soldado de cerca (el jefe), con la cámara a la altura de los ojos, de noche y con su linterna */
    const j=await ev("(()=>{const s=UE.soldados.find(q=>q.rol==='jefe');s.luz=true;return [s.x,s.y,s.z,s.rumbo]})()");
    await foto('c2_soldado_cerca.png',camA(j[0]+Math.sin(j[3])*3.2+Math.cos(j[3])*1.2,j[1]+1.55,j[2]+Math.cos(j[3])*3.2-Math.sin(j[3])*1.2,j[0],j[1]+1.1,j[2],50));
    R.jefe={x:j[0],y:j[1],z:j[2],piso:await ev(`floorAt(${j[0]},${j[2]})`)};
    /* 3. combate: el jugador parado en la luz a 30 m, inmortal; foto cuando hay trazadoras en el aire */
    await ev("window.__inmortal=true;P.pos.set(-408,floorAt(-408,606),606);P.vel.set(0,0,0);P.yaw=Math.PI/2;P.pitch=.03;switchTo(2);1");
    for(let k=0;k<30;k++){await h.step(.5,1/60,'__fich()');if(await ev("__L.bala.n>6&&UE.estado().combate"))break;}
    for(let k=0;k<40;k++){await h.step(1/30);if(await ev("UEFX.vivos>12"))break;}
    await foto('c3_combate_hud.png');
    R.combate=await ev("({balas:__L.bala.n,vivos:UEFX.vivos,est:UE.estado(),hp:P.hp,radio:__L.radio.slice(-4).map(r=>r[1]+': '+r[3])})");lg('combate',JSON.stringify(R.combate));
    /* 4. vista táctica en combate (F2 grande) */
    await ev("UEDBG.poner(2);1");await h.step(.3);await foto('c4_tactica.png');await ev("UEDBG.poner(1);1");await h.step(.3);await foto('c4b_tactica_chica.png');await ev("UEDBG.poner(0);1");
    /* 5. el tirador en el techo con el láser: cámara de costado, desde la vereda norte */
    for(let k=0;k<40;k++){await h.step(.25,1/60,'__fich()');if(await ev("!!UE.soldados.find(s=>s.rol==='tirador'&&s.vivo&&s.laser)"))break;}
    const t=await ev("(()=>{const s=UE.soldados.find(q=>q.rol==='tirador');return [s.x,s.y,s.z,!!s.laser,s.vivo]})()");
    R.tirador=t;lg('tirador',JSON.stringify(t));
    await foto('c5_tirador_laser.png',camA(t[0]+9,t[1]+1.6,t[2]-7.5,t[0]+1,t[1]+.3,t[2]+1,55));
    /* 6. de lejos, desde donde llega el jugador (110 m) */
    await ev("UEDBG.poner(0);P.pos.set(-326,floorAt(-326,606),606);P.vel.set(0,0,0);P.yaw=Math.PI/2;P.pitch=0;1");
    await foto('c6_llegada_110m.png');
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(path.join(__dirname,'t7.json'),JSON.stringify(R));
  await h.close();lg('cerrado');
})();
