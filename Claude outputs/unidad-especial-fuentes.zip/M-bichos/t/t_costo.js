/* Costo de updateEnemies con 20 bichos en Av. de Mayo: sin objetivos, con 8 soldados de mentira lejos (a más de 24 m: los bichos
   hacen exactamente lo mismo que sin soldados, así que la diferencia es el costo puro de elegir blanco) y con 8 soldados entre
   los bichos (la pelea de verdad: otro trabajo, no es comparable cuadro a cuadro). Los soldados no mueren.
   Además, microcostos de bchBlanco (forzando una elección por llamada), bchCamino (con y sin camino), rayoBichos y bichosVivos.
   Uso: node t_costo.js [copia_det.html]   (con base_det.html mide solo «sin»: sirve de referencia del juego sin parche)
   Mide con el reloj real (__realNow del preludio). Alterna sin/con varias veces con la misma semilla y la misma tanda de bichos. */
const H=require('../../harness.js');const path=require('path');
const file=process.argv[2]||path.join(__dirname,'mod_det.html');
const t0=Date.now();const log=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(1)+'s',...a);
const AYUDA=String.raw`(()=>{
  const TIPOS=['rata','rata','rata','rata','rata','bagayo','bagayo','bagayo','bagayo','baboso','baboso','baboso','baboso','baboso','escupidor','escupidor','escupidor','mole','mole','mole'];
  const SOLD=[[-440,604],[-444,606],[-437.5,612.5],[-446.5,610.5],[-428,606],[-432,611],[-450,603],[-424,609]];
  const limpiar=()=>{enemies.slice().forEach(e=>{scene.remove(e.obj);if(e.rig)scene.remove(e.rig.group);});enemies.length=0;projs.forEach(p=>scene.remove(p.m));projs.length=0;pickups.forEach(p=>scene.remove(p.g));pickups.length=0;bossAlive=null;};
  const hayM=typeof bchBlanco!=='undefined';
  /* corrida: 20 bichos entre los soldados y el jugador; seg segundos; devuelve ms por llamada de updateEnemies */
  const LEJOS=SOLD.map(p=>[p[0]-90,p[1]]);
  window.__corrida=(con,seg)=>{limpiar();__rng.seed(777);P.pos.set(-380,0,608);P.vel.set(0,0,0);P.yaw=Math.PI/2;P.hp=100;
    const L=(con==='lejos'?LEJOS:SOLD).map(p=>({x:p[0],z:p[1],y:floorAt(p[0],p[1]),r:.4,vivo:true,hp:1e9,n:0,herir(d,e){this.n++;}}));
    UEB.objetivos=con?()=>L:()=>[];
    TIPOS.forEach((t,i)=>{const e=spawnEnemy(t,[-445+(i%5)*6,601+Math.floor(i/5)*3.5]);e.state='chase';e.rise=1;e.obj.position.y=0;});
    let acc=0,n=0,mx=0;const ms=[];const _u=updateEnemies;
    updateEnemies=function(dt){const a=__realNow();_u(dt);const b=__realNow()-a;acc+=b;n++;ms.push(b);};
    let cA=0,nA=0;let _c=null;if(hayM){_c=bchCamino;bchCamino=function(x,z,s,cls,out){cA++;return _c(x,z,s,cls,out);};}
    const F=1000/60;let t=window.__simT;const nF=Math.round(seg*60);
    try{for(let i=0;i<nF;i++){t+=F;__timers.adv(F);P.hp=100;P.pos.x=-380;P.pos.z=608;frame(t);}}finally{window.__simT=t;updateEnemies=_u;if(_c)bchCamino=_c;}
    ms.sort((a,b)=>a-b);const tg=hayM?enemies.filter(e=>e.tg).length:0;con=con||'sin';
    return {con,cuadros:n,msMedia:+(acc/n).toFixed(4),msMediana:+ms[n>>1].toFixed(4),ms90:+ms[Math.floor(n*.9)].toFixed(4),vivos:enemies.length,conBlancoSoldado:tg,golpesASoldados:L.reduce((a,s)=>a+s.n,0),caminosCortos:cA};};
  /* microcostos (µs por llamada), con el reloj real; cada uno en un bucle largo porque el reloj tiene 0,1 ms de resolución */
  window.__micro=()=>{const r={};const rel=__realNow;
    __corrida(true,1);                                        // 20 bichos con blanco, 8 soldados cerca
    const E=enemies.slice(),N=400;let a=rel();
    for(let k=0;k<N;k++)for(const e of E){e.tgT=0;bchBlanco(e,0);}r.blancoEligiendo=+((rel()-a)*1000/(N*E.length)).toFixed(2);
    a=rel();for(let k=0;k<N;k++)for(const e of E)bchBlanco(e,0);r.blancoSinElegir=+((rel()-a)*1000/(N*E.length)).toFixed(2);
    const cam=(bx,bz,sx,sz)=>{const s={x:sx,z:sz},out={x:0,z:0};let ok=false;const a=rel();for(let k=0;k<2000;k++)ok=bchCamino(bx,bz,s,0,out);return [ok,+((rel()-a)*1000/2000).toFixed(1)];};
    r.caminoTaxi=cam(-394.5,604.4,-406,604.4);                // rodear el taxi 784
    r.caminoEdificio=cam(-420,600,-420,587);                  // soldado adentro de un edificio: no hay
    r.caminoLejos=cam(-430,606,-470,612);                     // 40 m: fuera de la ventana de 64 casilleros o del tope de costo
    const o=new V3(),d=new V3();a=rel();let n=0;for(let k=0;k<20000;k++){const e=E[k%E.length];o.set(-380,1.2,608);d.set(e.obj.position.x+380,0,e.obj.position.z-608).normalize();if(rayoBichos(o,d,140))n++;}
    r.rayoBichos=+((rel()-a)*1000/20000).toFixed(2);r.rayosQuePegan=n;
    a=rel();for(let k=0;k<20000;k++)bichosVivos();r.bichosVivos=+((rel()-a)*1000/20000).toFixed(2);
    UEB.objetivos=()=>[];BCH.t=-1;a=rel();for(let k=0;k<N;k++){BCH.t=-1;for(const e of E)bchBlanco(e,0);}r.blancoSinSoldados=+((rel()-a)*1000/(N*E.length)).toFixed(3);
    return r;};
  return hayM;})()`;
(async()=>{
  const h=await H.open(file);log('abierto',file);
  try{
    await h.ev("SHJ.init();__rng.seed(4242);window.__simT=1e6;T=500;1");
    log('start',JSON.stringify(await h.start()));
    log('reten',JSON.stringify(await h.alReten(-380,608)));
    const hayM=await h.ev(AYUDA);
    await h.ev("__corrida(false,2)");                      // calentar (JIT)
    const R={sin:[],lejos:[],cerca:[]};
    for(let k=0;k<3;k++){
      const a=await h.ev("__corrida(false,8)");R.sin.push(a);console.log(JSON.stringify(a));
      if(hayM){const b=await h.ev("__corrida('lejos',8)");R.lejos.push(b);console.log(JSON.stringify(b));
        const c=await h.ev("__corrida(true,8)");R.cerca.push(c);console.log(JSON.stringify(c));}
    }
    const med=L=>{const v=L.map(x=>x.msMedia).sort((a,b)=>a-b);return v[v.length>>1];};
    console.log('RESUMEN ms por llamada de updateEnemies (media de cada corrida de 480 cuadros; mediana de las 3): sin',med(R.sin),hayM?'· 8 soldados lejos '+med(R.lejos)+' · 8 soldados entre los bichos '+med(R.cerca):'');
    if(hayM)console.log('MICRO µs por llamada',JSON.stringify(await h.ev("__micro()")));
    log('errores',h.errors.length,h.errors.slice(0,4).join(' | '));
  }finally{await h.close();}
})().catch(e=>{console.error('FAIL',e.stack||e.message);process.exit(1);});
