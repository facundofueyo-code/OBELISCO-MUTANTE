/* =====================================================================================================
   UNIDAD ESPECIAL — IA de escuadrón (módulo UE)                                  Obelisco Mutante v1.15
   -----------------------------------------------------------------------------------------------------
   JavaScript puro: no usa Three.js ni DOM. Todo lo que la IA sabe del mundo entra por ENV (SPEC 4.7).

   La idea rectora: un escuadrón parece inteligente y a la vez justo no por tener muchas reglas, sino
   porque SE COORDINA y AVISA lo que va a hacer. Las reglas de juego limpio (SPEC 1.3) están escritas
   acá como mecanismos, no como buenas intenciones:

     1. Un cerebro por escuadrón reparte tareas (base de fuego, flanqueo, tirador) y permisos de moverse.
     2. Nadie lee la posición real del jugador para decidir: `percibir()` es el ÚNICO lugar que mira a
        ENV.jugador() para saber algo. Todo lo demás trabaja con el «último lugar conocido» (uc).
        (La otra lectura de ENV.jugador() está en `resolverBala()`: es física —si la bala lo toca o no—
        y nunca vuelve como conocimiento.)
     3. Granada: grito + gesto antes de soltarla. Tirador: láser continuo antes del tiro.
     4. Fichas de ataque: como mucho TUNE.fichas tiran a pegar; los demás suprimen (erran a propósito).
        La primera ráfaga de cada soldado es de aviso.
     5. Tiempos humanos: reacción, recarga, posturas, supresión.
     6. Cada bala se resuelve con un rayo real (ENV.rayo): nunca atraviesa nada.
     7. Tope de daño por segundo de fusil y escopeta.
     8. Corren más lento que el jugador.

   Cómo está armado (de arriba hacia abajo):
     UE_TUNE ........ todos los números, comentados
     FRASES ......... lo que dicen por radio (SPEC 9)
     crearUE() ...... grilla y línea de visión · A* · coberturas · soldado · percepción · armas ·
                      estados del soldado · cerebro del escuadrón · API pública
   ===================================================================================================== */

const UE_TUNE = {
  /* ---------- las tres perillas simples (para Facu) ---------- */
  fichas: 2,            // cuántos soldados pueden «tirar a pegar» al mismo tiempo (el tirador va aparte). 1 = fácil, 3 = brutal
  punteria: 1,          // multiplica la dispersión de todas sus armas: 1.5 = tiran peor, 0.7 = tiran mejor
  dano: 1,              // multiplica el daño que le hacen al jugador (también se acepta escrito `daño`)

  /* ---------- cuerpo ---------- */
  vida: 100,            // salud de cada soldado
  multCabeza: 2.2,      // un tiro en la cabeza saca 2,2 veces
  multTorso: 0.85,      // el chaleco para algo
  multMiembro: 0.7,     // brazo o pierna
  velRonda: 1.6,        // m/s caminando la ronda
  velAgach: 3.2,        // m/s avanzando agachado (flanqueo, búsqueda)
  velCorrer: 5.6,       // m/s corriendo de cobertura a cobertura (el jugador corre a 9,6: siempre se les escapa)
  velEscapar: 6.6,      // m/s escapando de una granada
  acel: 14,             // m/s²: no cambian de dirección de golpe
  tAgach: 0.25,         // s de pie ↔ agachado
  tATierra: 0.6,        // s agachado → cuerpo a tierra
  tDeTierra: 0.9,       // s cuerpo a tierra → agachado (mientras se levanta no puede tirar ni correr)
  ojoPie: 1.62, ojoAgach: 1.05, ojoTierra: 0.30,   // altura de los ojos en cada postura (m)
  giro: 4,              // rad/s que gira el cuerpo
  reaccion: 0.45,       // s desde que lo ve hasta que puede tirar
  heridoBajo: 0.35,     // por debajo de esta fracción de vida se repliega y dice «herido»
  aturdeDano: 34,       // un golpe de este daño o más (escopeta de cerca) lo deja aturdido
  aturdeT: 0.5,         // s aturdido

  /* ---------- vista y oído ---------- */
  conoGuardia: 110,     // grados del cono de visión en guardia
  conoSospecha: 150,    // cuando ya sospechan o buscan
  conoCombate: 200,     // en combate
  vistaDist: 45,        // m que ven de noche
  vistaLuz: 1.5,        // × si el jugador está en zona iluminada o con la linterna prendida
  vistaQuieto: 0.6,     // × si el jugador está agachado, quieto y a oscuras
  vistaTope: 80,        // m: nunca más lejos que esto
  detectar: [8, 0.35, 15, 0.9, 30, 2, 45, 4],   // pares (distancia m, segundos para detectarlo en guardia)
  detLuz: 1.6,          // la sospecha sube × esto si está iluminado o con linterna
  detAgach: 0.6,        // × si está agachado
  detQuieto: 0.7,       // × si está quieto
  detMedio: 0.5,        // × si solo se le ve la cabeza
  detCorre: 1.3,        // × si corre
  detBorde: 0.6,        // × si lo ve con el rabillo del ojo (fuera del 60 % central del cono)
  detAlerta: 2.2,       // × cuando el escuadrón ya sospecha, busca o volvió de un combate
  sospechaBaja: 0.25,   // la sospecha baja esto por segundo si deja de verlo
  sospechaMira: 0.4,    // a partir de acá gira, alumbra y avisa «sospecha»
  oidoDisparo: 120,     // m a los que oyen un disparo del jugador
  oidoPasos: 14,        // m a los que oyen pasos corriendo
  oidoImpacto: 3,       // m a los que notan un impacto de bala
  oidoExplosion: 150,   // m a los que oyen una explosión
  vistaBicho: 30,       // m a los que ven mutantes
  aviso: 0.5,           // s desde que uno lo ve hasta que lo sabe el escuadrón (lo dice por radio)
  tPercibir: 0.12,      // cada cuánto mira cada soldado (s)
  tPensar: 0.125,       // cada cuánto decide cada soldado (s): 8 veces por segundo
  tCerebro: 0.4,        // cada cuánto decide el escuadrón (s)
  lejos: 160,           // si el jugador está más lejos que esto y están en guardia, casi no gastan

  /* ---------- fichas de ataque y puntería ---------- */
  fichaMin: 1.6,        // s mínimos que un soldado conserva la ficha
  fichaMax: 5.5,        // s tras los cuales la cede si otro la está esperando
  asientoT: 1.0,        // s que tarda en asentar la puntería viéndolo sin parar
  miraAtraso: 0.18,     // s de atraso del punto de mira respecto del jugador
  miraAdelanto: 0.5,    // cuánto del atraso compensa adelantando (0.5 = la mitad: de costado y corriendo, erra)
  supOffMin: 0.9, supOffMax: 1.5,   // tirar a suprimir: a cuántos metros del jugador apuntan a propósito
  topeDano: 32,         // salud por segundo como máximo con balas de fusil y escopeta

  /* ---------- armas ---------- */
  fusil: {
    rafMin: 3, rafMax: 5,     // balas por ráfaga
    cadencia: 0.095,          // s entre balas
    pausaMin: 0.6, pausaMax: 1.2,   // s entre ráfagas
    dano: 7,                  // por bala
    disp: 0.011,              // rad de dispersión con la puntería asentada
    suelto: 3.2,              // × sin asentar
    cargador: 30, recarga: 2.4,
    alcance: 110
  },
  escopeta: {
    perdigones: 8, dano: 5,   // 8 perdigones de 5
    disp: 0.05,
    cadencia: 0.95,           // s entre tiros
    lleno: 10,                // hasta acá el perdigón pega entero
    util: 16,                 // a esta distancia todavía sirve (pega ~2/3)
    nada: 28,                 // de acá en más no hace nada
    cargador: 6, recargaCartucho: 0.55,
    alcance: 40
  },
  tirador: {
    dano: 48,
    laser: 1.3,               // s de láser continuo sobre el jugador antes del destello
    destello: 0.25,           // s de destello antes del tiro
    ciclo: 3.2,               // s mínimos entre tiros
    atraso: 0.22,             // s de atraso del punto rojo
    adelanto: 0.6,            // adelanta el 60 %: corriendo de costado te erra
    disp: 0.0018,
    cerca: 12,                // a menos de esto tira rápido y mal, sin láser
    cercaDano: 24, cercaDisp: 0.05, cercaCadencia: 1.2,
    cargador: 5, recarga: 3.0,
    distMin: 28, distMax: 75, // a qué distancia del jugador busca puesto
    alcance: 140
  },
  culata: { dano: 15, dist: 1.8, aviso: 0.35, cada: 2.5 },

  /* ---------- supresión sobre el soldado ---------- */
  suprCerca: 1.2,       // m: una bala del jugador que pasa a menos de esto lo suprime
  suprSuma: 0.35,       // cuánto suma cada bala
  suprBaja: 0.5,        // cuánto baja por segundo
  suprEsconde: 0.6,     // por encima de esto se esconde y pierde la puntería
  suprTMin: 0.8, suprTMax: 1.5,   // s que se queda escondido

  /* ---------- granadas ---------- */
  granada: {
    mecha: 3,             // s desde que sale de la mano
    aviso: 0.65,          // s entre el grito y soltarla (mínimo)
    gesto: 1.3,           // s que dura el gesto de lanzar (la suelta en el 55 %)
    radio: 7, dano: 80,   // m y daño en el centro (el daño real lo aplica el sistema de granadas del juego)
    cobertura: 0.3,       // × detrás de cobertura
    cada: 11,             // s entre granadas del escuadrón
    distMin: 8, distMax: 30,
    quieto: 3.5,          // s que el jugador lleva quieto o cubierto…
    quietoRadio: 2.5,     // …en este radio, para que se la tiren
    amigos: 8,            // m: ningún compañero más cerca que esto del blanco
    bichos: 3,            // cuántos bichos juntos justifican una
    bichosRadio: 4.5
  },

  /* ---------- escuadrón ---------- */
  flancoCada: 14,       // s mínimos entre órdenes de flanqueo
  flancoMinVivos: 3,    // con menos, no se flanquea: aguantan
  flancoDist: 12,       // m del jugador a los que busca quedar el que flanquea
  perdidoT: 2.5,        // s sin verlo: «lo perdí» y fuego sobre el último lugar
  perdidoAccion: 7,     // s: granada o avance
  perdidoBarrido: 12,   // s: empieza el barrido
  barridoT: 30,         // s que dura el barrido
  jefeCaidoT: 7,        // s de desorden al caer el jefe
  refuerzoVivos: 2,     // con esta cantidad o menos piden refuerzo
  refuerzoCombate: 45,  // o a los tantos segundos de combate
  refuerzoPedir: 3,     // s que tarda en pedirlo por radio
  refuerzoLlega: 25,    // s que tarda en llegar
  radioCada: 1.2,       // s mínimos entre frases de un mismo escuadrón (las de peligro pasan siempre)
  separacion: 3,        // m: no comparten cobertura (a menos de esto son blanco de una sola granada)
  moverSinVer: 2,       // s sin que nadie vea al jugador para moverse sin pedir fuego de cobertura
  ventanaMin: 1.2, ventanaMax: 2.5,   // s que se queda asomado tirando
  cubiertoMin: 0.5, cubiertoMax: 1.4, // s que se queda cubierto entre asomadas
  distJefe: 30, distGranadero: 22, distAsalto: 12,   // m del jugador que prefiere cada rol

  /* ---------- bichos ---------- */
  bichoManda: 7,        // m: un bicho más cerca que esto pasa a ser el blanco sí o sí
  bichoRetro: 4.5,      // m: si se le viene encima, retrocede tirando
  bichoDano: 1,         // multiplica el daño de sus balas a los bichos

  /* ---------- camino ---------- */
  costoExpo: 2.6,       // un casillero que el jugador ve cuesta (1 + esto) veces: salen solos los flanqueos tapados
  costoSalto: 3,        // costo extra de saltar una valla (≈ medio segundo)
  saltoMax: 12,         // dm: hasta 1,2 m se salta; lo más alto se rodea
  saltoT: 0.5           // s que tarda en pasar una valla
};

/* Frases de radio (SPEC 9). Una entrada puede ser un diálogo [«pregunta», «respuesta»]: la segunda la dice otro. */
const UE_FRASES = {
  ocioso: ['Central, retén Mayo sin novedad.', ['¿Cuántos van?', 'Once.'], 'Media hora para el relevo.', 'Nadie sale de la zona. Nadie.'],
  sospecha: ['Vi algo. Voy a mirar.', '¿Escucharon eso?', 'Movimiento al este.'],
  nada: ['Nada. Falsa alarma.', 'Sin novedad.'],
  contacto: ['Contacto. Testigo al frente.', 'Lo veo. Detrás del auto.', 'Testigo a la vista.'],
  fijar: ['Fuego de cobertura.', 'Lo tengo fijado.'],
  muevo: ['Me muevo.', 'Cambio de posición.', 'Cubrime.'],
  tecubro: ['Te cubro.', 'Dale, andá.'],
  orden_flanco: ['Ceniza {N}, rodealo.'],
  flanco_izq: ['Voy por izquierda.'],
  flanco_der: ['Voy por derecha.'],
  granada: ['¡Granada va!'],
  granada_enemiga: ['¡Granada! ¡Al piso!'],
  recarga: ['Recargando.', 'Cambio cargador.'],
  recarga_jugador: ['Está recargando. ¡Voy!'],
  herido: ['Me dieron.', 'Estoy herido.'],
  suprimido: ['¡Me tiene clavado!'],
  flanqueado: ['¡Nos rodeó!', '¡Por el costado!'],
  baja: ['Hombre caído.', 'Cayó Ceniza {N}.'],
  jefe_caido: ['Cayó el jefe. Tomo el mando.'],
  perdido: ['Lo perdí.', 'Sin visual.'],
  tirador_listo: ['Tirador en posición.'],
  tirador_mira: ['Lo tengo en la mira.'],
  tirador_fallo: ['Se me movió.'],
  bichos: ['¡Bichos!', 'Bichos por atrás.', 'Contacto hostil, no humano.'],
  auto_fuego: ['¡Ese auto va a volar! ¡Salgan!'],
  busqueda: ['Barriendo el sector.', 'Revisen los autos.'],
  limpio: ['Sector limpio. Volvemos al retén.'],
  refuerzo_pide: ['Central, contacto en el retén Mayo. Pedimos apoyo.'],
  refuerzo_va: ['Tizón en camino. Treinta segundos.'],
  refuerzo_llega: ['Tizón en posición.'],
  muerto_jugador: ['Testigo eliminado.', 'Central, uno menos.']
};
/* frases de peligro: pasan siempre, aunque el escuadrón haya hablado recién */
const UE_URGENTES = { granada: 1, granada_enemiga: 1, auto_fuego: 1, contacto: 1, jefe_caido: 1 };

