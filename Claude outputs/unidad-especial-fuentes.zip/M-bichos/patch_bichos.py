#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UE · M — parche «los bichos contra la unidad especial».

Uso:  python3 patch_bichos.py entrada.html salida.html

Inserta mod_bichos.js delante de /*UE:modulos*/ y engancha el código viejo con ediciones chicas, todas marcadas
con UE:M. Cada ancla tiene que aparecer exactamente las veces esperadas: si no, falla sin escribir nada.
Sin soldados (UEB.objetivos() vacío) el juego parcheado se comporta igual que el original, cuadro por cuadro.
"""
import sys, os

src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()
AQUI = os.path.dirname(os.path.abspath(__file__))


def rep(viejo, nuevo, n=1):
    global s
    c = s.count(viejo)
    assert c == n, f'ancla: esperaba {n}, hay {c}: {viejo[:80]!r}'
    s = s.replace(viejo, nuevo)


def antes(marca, codigo):            # inserta delante de un marcador y lo deja
    rep(marca, codigo + marca)


def delante(ancla, codigo):          # inserta delante de un ancla propia y la deja igual
    rep(ancla, codigo + ancla)


def detras(ancla, codigo):           # inserta detrás de un ancla propia y la deja igual
    rep(ancla, ancla + codigo)


# ---------------------------------------------------------------- módulo nuevo
antes('/*UE:modulos*/', open(os.path.join(AQUI, 'mod_bichos.js'), encoding='utf-8').read() + '\n')

# ---------------------------------------------------------------- updateEnemies
# 1. Variables de blanco al principio del cuerpo del bucle. tg = null es el jugador: tgx,tgz,tgy valen P.pos y
#    distP (distancia al jugador, para los sonidos) vale lo mismo que dist.
rep('const dx=P.pos.x-o.position.x,dz=P.pos.z-o.position.z,dist=Math.hypot(dx,dz)||1e-3;',
    'const tg=bchBlanco(e,dt),tgx=tg?tg.x:P.pos.x,tgz=tg?tg.z:P.pos.z,tgy=tg?tg.y:P.pos.y;/*UE:M blanco del bicho: null = el jugador*/\n'
    '    const dx=tgx-o.position.x,dz=tgz-o.position.z,dist=Math.hypot(dx,dz)||1e-3,distP=tg?Math.hypot(P.pos.x-o.position.x,P.pos.z-o.position.z)||1e-3:dist;')
# 2. Caída del salto del bagayo: si el blanco es un soldado, le pega a él.
delante('if(Math.hypot(P.pos.x-o.position.x,P.pos.z-o.position.z)<c.r+1.3&&P.pos.y<1.2)',
        'if(tg){/*UE:M*/if(bchPega(e,tg,c.r+1.3,1.2,c.dmg*2)){e.bite=1;e.atk=1;}}else ')
# 3. Empezar a pegar: la altura que cuenta es la del blanco.
rep('P.pos.y-e.gy<c.height+1&&e.gy-P.pos.y<1.2', 'tgy-e.gy<c.height+1&&e.gy-tgy<1.2/*UE:M*/')
# 4. Los gemidos y gruñidos de acecho dependen de la distancia al jugador, no al blanco.
rep('if(dist<26&&e.moanCd<=0', 'if(distP/*UE:M*/<26&&e.moanCd<=0')
rep("else if((dist<30||e.type==='boss')&&growlCd<=0", "else if((distP/*UE:M*/<30||e.type==='boss')&&growlCd<=0")

# ---------------------------------------------------------------- navegación
# Con blanco soldado el bicho no sigue el campo del jugador: va derecho o por un camino corto propio (bchSteer).
detras('function enSteer(e,x,z,out){const cls=isBig(e)?1:0;',
       'if(e.tg){/*UE:M*/const r=bchSteer(e,x,z,out,cls);if(r)return r;}')

# ---------------------------------------------------------------- el golpe (atkTick)
detras('function atkTick(e,dt,dist){const A=e.atkS,T=A.A,o=e.obj.position,c=e.c;', 'const g=e.tg;/*UE:M blanco: null = el jugador*/')
delante('A.tgt.set(P.pos.x,P.pos.y+1.1-.5*P.ch,P.pos.z);if(A.t>=T.wind)A.frozen=true;', 'if(g)A.tgt.set(g.x,g.y+1.1,g.z);else ')
rep('_w.set(P.pos.x-o.x,0,P.pos.z-o.z).normalize();e.kb.addScaledVector(_w,T.lunge);',
    '_w.set((g?g.x:P.pos.x)-o.x,0,(g?g.z:P.pos.z)-o.z).normalize();e.kb.addScaledVector(_w,T.lunge);')
# el golpe le llega al soldado (herir) en vez de al jugador; el pisotón del Engendro además agarra a los soldados que tenga cerca
rep('if(d<c.r+1.45&&P.pos.y<c.height+1&&e.hp>0){hurtPlayer(c.dmg*e.dmgMul);e.bite=Math.max(e.bite,.5);}}',
    'if(g){if(e.hp>0&&bchPega(e,g,c.r+1.45,c.height+1,c.dmg*e.dmgMul))e.bite=Math.max(e.bite,.5);}else '
    'if(d<c.r+1.45&&P.pos.y<c.height+1&&e.hp>0){hurtPlayer(c.dmg*e.dmgMul);e.bite=Math.max(e.bite,.5);}\n'
    "    if(e.type==='boss'&&e.hp>0)bchArea(o.x,o.z,c.r+1.45,e.gy+c.height+1,c.dmg*e.dmgMul,e);/*UE:M*/}")

# ---------------------------------------------------------------- escupitajos
# apunta al blanco (un soldado no tiene velocidad conocida: sin adelanto) y anota quién escupió
rep('const tgt=_v.set(P.pos.x+P.vel.x*.4+',
    'const g=e.tg/*UE:M*/,tgt=g?_v.set(g.x+rand(-1,1)*spread,g.y+1.1,g.z+rand(-1,1)*spread):_v.set(P.pos.x+P.vel.x*.4+')
rep("projs.push({m,v:vel,dmg:e.type==='boss'?16:10}", "projs.push({m,v:vel,dmg:e.type==='boss'?16:10,de:e}")
# en vuelo, después de probar contra el jugador (y antes del piso, que desde la 1.15 es PISO.y), prueba contra los soldados.
# El ancla es la línea del jugador, que no cambió entre versiones (la del piso sí cambió en la 1.15).
detras('if(dx*dx+dy*dy+dz*dz<1.1*p.m.scale.x){hurtPlayer(p.dmg,true);hit=true;}', '\n  else if(bchProy(p))hit=true;/*UE:M*/')

# ---------------------------------------------------------------- daño y muerte por soldado
# cuarto parámetro opcional: de==='soldado' → sin puntos, combo, bajas ni frase para el jugador (la caja la puede dejar igual)
rep('function damageEnemy(e,dm,dir){', "function damageEnemy(e,dm,dir,de){/*UE:M de==='soldado': la bala es de la unidad especial*/")
rep('if(e.hp<=0)killEnemy(e);else painSound(e);}', 'if(e.hp<=0)killEnemy(e,de);else painSound(e);}')
rep('function killEnemy(e){', 'function killEnemy(e,de){')
delante('kills++;if(comboT>0)combo=Math.min(5,combo+1);else combo=1;comboT=3;', "if(de==='soldado')hudWave();else{/*UE:M*/")
detras('feed(`<b>${pick(QUIPS)}</b> · ${e.c.name} +${e.c.score*combo}`);', '}')
rep("announce('¡Lo reventaste!',", "announce(de==='soldado'?'Lo reventaron ellos':'¡Lo reventaste!',")

# ---------------------------------------------------------------- autos
# toda explosión de auto le avisa a la IA de los soldados, con el radio y el daño que recibe el jugador
detras('if(dp<8)hurtPlayer(Math.round(70*Math.pow(1-dp/8,1.3)),false);',
       "UEB.explosion(W0,8,70,'auto');/*UE:M mismo radio y daño que recibe el jugador*/")
# el auto que barre el Engendro (o empuja el mole) también golpea a los soldados
detras('P.vel.x+=dx*sp*.9;P.vel.z+=dz*sp*.9;p.hitP=.7;break;}}', '\n  bchAuto(c,sp);/*UE:M*/')

open(dst, 'w', encoding='utf-8').write(s)
