/* LA RADIO: las frases salen de UE_FRASES (las mismas que usa la IA), agrupadas por momento. {N} es el número del soldado. */
(function () {
'use strict';
const caja = document.getElementById('frases');
if (!caja || typeof UE_FRASES === 'undefined') return;
const GRUPOS = [
  ['En guardia', ['ocioso']], ['Algo raro', ['sospecha', 'nada']], ['Te ven', ['contacto', 'fijar']],
  ['Se mueven', ['muevo', 'tecubro', 'orden_flanco', 'flanco_izq', 'flanco_der']],
  ['Te apuntan', ['tirador_listo', 'tirador_mira', 'tirador_fallo', 'granada', 'recarga_jugador']],
  ['Les va mal', ['recarga', 'herido', 'suprimido', 'flanqueado', 'granada_enemiga', 'baja', 'jefe_caido']],
  ['Te pierden', ['perdido', 'busqueda', 'limpio']], ['Bichos y autos', ['bichos', 'auto_fuego']],
  ['Refuerzo', ['refuerzo_pide', 'refuerzo_va', 'refuerzo_llega']], ['Al final', ['muerto_jugador']]
];
const usadas = new Set();
function fila(titulo, claves) {
  const frases = [];
  for (const k of claves) { const v = UE_FRASES[k]; if (!v) continue; usadas.add(k); for (const f of v) frases.push(Array.isArray(f) ? f.join('» / «') : f); }
  if (!frases.length) return;
  const d = document.createElement('div'), m = document.createElement('span'), q = document.createElement('span');
  m.className = 'm'; m.textContent = titulo; q.className = 'q';
  frases.forEach((f, i) => {
    if (i) q.append(' · ');
    const partes = ('«' + f + '»').split('{N}');
    partes.forEach((p, j) => { if (j) { const n = document.createElement('i'); n.textContent = 'N'; q.append(n); } q.append(p); });
  });
  d.append(m, q); caja.append(d);
}
for (const [t, c] of GRUPOS) fila(t, c);
const otras = Object.keys(UE_FRASES).filter(k => !usadas.has(k));
if (otras.length) fila('Otras', otras);
})();
