/* Prueba 7: 400 px con navegador de escritorio, y la página publicada sin red (Three.js no carga: el tablero tiene que andar igual). */
const path = require('path');
const H = require(path.join(__dirname, '../../harness.js'));
const ok = (c, m) => console.log((c ? 'OK   ' : 'FALLA') + ' ' + m);
(async () => {
  let h = await H.openPage(path.join(__dirname, '../prueba.html'), { width: 400, height: 800 });
  try {
    await h.page.waitForTimeout(800);
    const r = await h.page.evaluate(() => { UEPAG.empezar('mirar'); UEPAG.congelar(true); const i = UEPAG.avanzar(20); return { sw: document.documentElement.scrollWidth, iw: innerWidth, jugar: !document.getElementById('bJugar').hidden, t: i.t, radio: i.cuentas.radio }; });
    ok(r.sw <= r.iw && r.jugar, '400 px (escritorio): ' + JSON.stringify(r));
    console.log('errores:', h.errors.length ? h.errors.slice(0, 3).join('\n') : 0);
  } finally { await h.close(); }
  h = await H.openPage(path.join(__dirname, '../unidad-especial-concepto.html'), { width: 1280, height: 800 });
  try {
    await h.page.waitForTimeout(800);
    await h.page.evaluate(() => document.getElementById('vStage').scrollIntoView({ block: 'center' })); await h.page.waitForTimeout(800);
    const r = await h.page.evaluate(() => { const av = document.getElementById('vAviso'); UEPAG.empezar('mirar'); UEPAG.congelar(true); const i = UEPAG.avanzar(30); return { three: typeof THREE, aviso: av.hidden ? null : av.textContent, t: i.t, radio: i.cuentas.radio, balas: i.cuentas.balasSold, errores: i.cuentas.errores }; });
    ok(r.three === 'undefined' && r.aviso && r.radio > 0 && r.errores === 0, 'publicada sin red: tablero anda y el visor avisa: ' + JSON.stringify(r));
    console.log('errores esperables (sin Three.js):', h.errors.map(e => e.split('\n')[0].slice(0, 90)).join(' | '));
  } finally { await h.close(); }
})();
