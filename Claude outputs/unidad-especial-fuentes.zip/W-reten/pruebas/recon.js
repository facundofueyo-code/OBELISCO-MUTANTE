/* reconocimiento de la zona del retén sobre la base sin tocar: datos y capturas */
const fs=require('fs'),path=require('path');
const {H,log,libre,parado,info}=require('./lib.js');
const OUT=path.join(__dirname,'..','recon');
(async()=>{
  const h=await H.open(path.join(__dirname,'base-copia.html'),{width:960,height:540});log('abierto');
  try{
    log('start',JSON.stringify(await h.start()));
    await h.alReten(-326,606);
    const d=await h.ev(`(()=>{
      const X0=-475,X1=-365,Z0=585,Z1=632,inW=(x,z)=>x>X0&&x<X1&&z>Z0&&z<Z1,r2=v=>+v.toFixed(2);
      const walls=WALLS.filter(w=>(inW(w[0],w[1])||inW(w[2],w[3]))).map(w=>w.map(r2));
      const circ=circles.filter(c=>inW(c.x,c.z)).map(c=>({x:r2(c.x),z:r2(c.z),r:r2(c.r),h:c.h,k:c.brk?c.brk.k:null,dead:!!c.dead,low:!!c.low}));
      const trees=TREES.filter(t=>inW(t.x,t.z)).map(t=>({x:r2(t.x),z:r2(t.z),k:t.k,s:r2(t.s)}));
      const lamps=LAMPS.filter(l=>l.x>-520&&l.x<-300&&l.z>585&&l.z<632).map(l=>({x:r2(l.x),z:r2(l.z),h:l.h,hx:r2(l.hx),hz:r2(l.hz),col:l.col}));
      const roads=ROADS.filter(r=>/de Mayo|San Jos|Santiago del Estero|Yrigoyen|Rivadavia|Peña/.test(r.name)).map(r=>({n:r.name,t:r.t,w:r2(r.w),lanes:r.lanes,pts:r.pts.filter(p=>p[0]>-700&&p[0]<-250&&p[1]>450&&p[1]<750).map(p=>p.map(r2))})).filter(r=>r.pts.length);
      const cars=VCARS.filter(c=>c.x>-520&&c.x<-300&&c.z>585&&c.z<632).map(c=>({id:c.S.id,mi:c.mi,x:r2(c.x),z:r2(c.z),a:+c.a.toFixed(4),L:c.L,W:c.W,H:c.H,lit:c.lit,rust:c.rust,col:c.col.toString(16),grp:!!c.grp,dy:r2(c.res.pose.dy),rx:+c.res.pose.rx.toFixed(4),rz:+c.res.pose.rz.toFixed(4),keys:Object.keys(c.res.geo).join(' '),tris:c.res.tris}));
      const bags=BAGS.filter(b=>inW(b.x,b.z)).map(b=>({x:r2(b.x),z:r2(b.z)}));
      const obs=obstacles.filter(b=>b.x1>X0&&b.x0<X1&&b.z1>Z0&&b.z0<Z1).map(b=>({x0:r2(b.x0),x1:r2(b.x1),z0:r2(b.z0),z1:r2(b.z1),y0:b.y0,y1:b.y1,g:!!b.glass,brk:!!b.brk}));
      const sub=SUBTE.filter(s=>s.x>-560&&s.x<-300&&s.z>560&&s.z<680).map(s=>({x:r2(s.x),z:r2(s.z),ux:r2(s.ux),uz:r2(s.uz),path:s.path}));
      const mh=MH.filter(s=>s.x>-560&&s.x<-300&&s.z>560&&s.z<680).map(s=>({x:r2(s.x),z:r2(s.z)}));
      const groups={near:VLOD.near.length,mid:VLOD.mid.length,far:VLOD.far.length,vcars:VCARS.length,
        nearKeys:VLOD.near.map(g=>g.S.id+'/'+g.rust+'/'+g.cars.length+'/'+g.meshes.length).join(' ')};
      const tri={};CARS.forEach((S,i)=>{const a=vModel(i,'full',null),b=vModel(i,'light',null);tri[S.id]=[a.tris,b.tris,Object.keys(a.geo).length,Object.keys(b.geo).length];});
      return {walls,circ,trees,lamps,roads,cars,bags,obs,sub,mh,groups,tri,secms:SECG.ms,stage:STAGE,wave,fog:scene.fog.density};})()`);
    fs.writeFileSync(path.join(OUT,'zona.json'),JSON.stringify(d,null,1));
    log('datos',d.walls.length,'paredes',d.circ.length,'círculos',d.cars.length,'autos',JSON.stringify(d.groups),JSON.stringify(d.tri));
    const shots=[
      ['a-arranque-oeste',-326,606,Math.PI/2,0],
      ['b-380-oeste',-380,607,Math.PI/2,0],
      ['c-420-oeste',-420,607,Math.PI/2,0],
      ['d-438-sur',-436,607,Math.PI,.05],
      ['e-438-norte',-436,607,0,.05],
      ['f-vereda-sur-oeste',-424,618.4,Math.PI/2,0],
      ['g-barolo',-409.5,606,Math.PI,.12],
      ['i-detras-este',-452,607,-Math.PI/2,0],
      ['j-vereda-norte-oeste',-428,596,Math.PI/2,0],
      ['k-esquina-so',-436,612,Math.PI*.75,.02],
    ];
    for(const [n,x,z,yaw,pit] of shots){await parado(h,x,z,yaw,pit);await h.shot(path.join(OUT,n+'.png'));log('captura',n,JSON.stringify(await info(h)));}
    await parado(h,-415,607,Math.PI/2,0);
    await libre(h,[-415,70,607.01],[-415,0,607],path.join(OUT,'h-arriba.png'),{fog:.0006});log('captura arriba');
    await libre(h,[-438,26,640],[-438,0,607],path.join(OUT,'h2-oblicua-sur.png'),{fog:.0015});log('captura oblicua');
    log('errores',h.errors.length,h.errors.slice(0,5).join(' | '));
  }finally{await h.close();}
})().catch(e=>{console.error('FAIL',e.stack||e.message);process.exit(1);});
