const H=require('../harness.js');const t0=Date.now();const log=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(1)+'s',...a);
(async()=>{const h=await H.open('obelisco-mutante.html');log('abierto');
  log('start',JSON.stringify(await h.start()));
  await h.ev("intermission=.1;1");
  log('normal 30s',JSON.stringify(await h.step(30,1/60,"P.hp=100")),JSON.stringify(await h.ev("({wave,en:enemies.length,ver:GAME_VERSION,sold:(typeof UEG!=='undefined')})")));
  log('ir al retén',JSON.stringify(await h.ev("(()=>{RETEN.ir({bichos:false});return {stage:STAGE,x:Math.round(P.pos.x),z:Math.round(P.pos.z)};})()")));
  await h.step(2,1/60,"P.hp=100");
  log('soldados',JSON.stringify(await h.ev("(()=>{const d=UEB.debug();return d?d.soldados.map(s=>[s.nombre,s.rol,Math.round(s.x),Math.round(s.z),s.estado]):null;})()")));
  // caminar hacia el retén 25 s y ver qué pasa
  log('avanza 25s',JSON.stringify(await h.step(25,1/60,"P.hp=100;keys.KeyW=true")));
  log('estado',JSON.stringify(await h.ev("(()=>{const e=UEB.estado(),d=UEB.debug();return {x:Math.round(P.pos.x),est:e,esc:d&&d.escuadrones.map(q=>[q.nombre,q.estado,q.orden]),vivos:d&&d.soldados.filter(s=>s.hp>0).length};})()")));
  log('pelea 20s',JSON.stringify(await h.step(20,1/60,"keys.KeyW=false")),JSON.stringify(await h.ev("({hp:Math.round(P.hp),running,over})")));
  log('errores',h.errors.length,h.errors.slice(0,4).join(' | ').slice(0,600));
  await h.close();})().catch(e=>{console.error('FAIL',e.message);process.exit(1);});
