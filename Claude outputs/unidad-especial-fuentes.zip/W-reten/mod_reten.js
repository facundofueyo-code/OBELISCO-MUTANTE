/* ================= RETÉN de la unidad especial (W) =================
   Una unidad sin insignias corta Av. de Mayo a la altura del Palacio Barolo y no deja pasar a nadie.
   Se arma una sola vez, con la sección B (RETEN.armar() al final de buildSectionB): todo queda adentro de SECG.B y se
   oculta solo de lejos. Deja en RETEN.datos lo que necesita la IA (puestos, ronda, nido, reunión, refuerzo, luz).
   Costo: lo nuevo va unido en pocas mallas (menos de 25 llamadas de dibujo). Sin luces reales: haces, manchas de luz,
   balizas, destellos y fuego son mallas y puntos aditivos.
   La fila de autos detenidos son autos del juego (instanciados) que se corren de lugar al armar: frenan balas, se
   dañan, se prenden, explotan y al reiniciar vuelven a donde los dejó el retén (el UNDO guarda el estado al tocarlos). */
const RETEN=(()=>{
  const PI=Math.PI;
  const sst=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};
  /* azar con semilla: el retén sale igual en todas las partidas */
  let sem=91173;const rn=()=>{sem=(sem*1664525+1013904223)>>>0;return sem/4294967296;},rr=(a,b)=>a+(b-a)*rn();
  const r2=v=>Math.round(v*100)/100;

  /* ---------- disposición, medida sobre el mapa de la 1.16.0 ----------
     calzada a −0,15 · a la altura de la barricada los cordones están en z≈597,9 y ≈617,2 · la avenida gira ~2° (hacia el oeste se corre al sur) */
  const BX=-438;                                    // eje de la barricada
  const FUR=[{z:602.45,a:0},{z:611.55,a:PI}];       // furgones atravesados: el norte con la trompa al norte, el sur al sur; las colas dan al paso del medio
  const PASO=[605.4,608.6];                         // paso del medio entre los furgones, cerrado con vallas
  const TRIP=[{x:-440,z:598.6,ap:[-405,606.5]},{x:-440,z:616.1,ap:[-405,609]}];   // reflectores en las puntas y el punto del piso adonde apuntan
  const CAM={x:-446.6,z:609.6};                     // camioneta de mando: trompa al oeste, la caja abierta hacia la barricada
  const GEN={x:-447,z:604.6};                       // grupo electrógeno que alimenta los reflectores
  const TACHO={x:-443.4,z:619};                     // tacho donde queman documentos y ropa (vereda sur, detrás de la barricada)
  const A0=PI/2+.033;                               // rumbo de un auto mirando al oeste, a lo largo de la avenida
  /* la fila de autos detenidos: autos que ya pone el generador en la cuadra (VCARS 779–788 en la 1.16.0), buscados por dónde
     están y por modelo. Quedan cada 8–12 m alternando carriles; 786 y 787 ya estaban bien. lado de puerta: −1 izquierda (conductor), 1 derecha */
  const FILA=[
    {de:[-436.23,599.35],id:'hatch3',x:-428.0,z:603.3,da:-.05,puertas:[-1],balas:1},   // estaba adentro de la barricada
    {de:[-416.87,615.02],id:'sedan',puertas:[-1,1],sangre:1},                          // queda donde está
    {de:[-407.19,601.69],id:'furgon',x:-408.6,z:601.9,da:.02,balas:1},
    {de:[-400.14,604.38],id:'taxi',x:-399.0,z:611.4,da:.12,puertas:[-1],balas:1},
    {de:[-380.38,603.71],id:'taxi',x:-390.2,z:603.8,da:-.32,puertas:[1],sangre:1},    // quiso pegar la vuelta
    {de:[-381.73,614.02],id:'hatch3',balas:1},                                         // queda donde está
    {de:[-412.47,601.37],id:'furgon',x:-372.0,z:600.4,da:.04},
    {de:[-402.70,598.14],id:'sedan',x:-355.5,z:605.0,da:.22,puertas:[-1]}];

  let G=null,armado=false,t=0,modo=null,chk=0;
  const OBS=[],CIR=[],LAMP=[],AUTOS=[],CERCA=[],avisos=[];
  const HA={mesh:null},HD={mesh:null};             // mallas unidas donde van las puertas y las calcomanías de cada auto (c.rg las esconde si explota)
  let BEAM=null,POOL=null,LENS=null,GLOW=null,HUMO=null;const BAL={};
  const I=[1,1];                                    // intensidad de cada reflector (el sur titila)
  let fk={t:7,on:0};
  const datos={centro:{x:BX,z:607},frente:{x:1,z:0},puestos:[],ronda:[],nido:null,reunion:null,refuerzo:null,luz:[],cuerpos:[]};

  /* ---------- geometría unida con color por vértice (una sola llamada de dibujo) ---------- */
  function Lote(){const P=[],N=[],C=[],c=new THREE.Color();
    return{get n(){return P.length/3;},
      add(geo,m,col){const g=geo.index?geo.toNonIndexed():geo.clone();if(m)g.applyMatrix4(m);if(!g.attributes.normal)g.computeVertexNormals();
        const p=g.attributes.position.array,q=g.attributes.normal.array;c.set(col);
        for(let i=0;i<p.length;i++){P.push(p[i]);N.push(q[i]);}for(let i=0;i<p.length/3;i++)C.push(c.r,c.g,c.b);g.dispose();},
      geo(){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(P,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(N,3));
        g.setAttribute('color',new THREE.Float32BufferAttribute(C,3));return g;}};}
  const BOX1=new THREE.BoxGeometry(1,1,1),CYL1=new THREE.CylinderGeometry(1,1,1,8),SPH1=new THREE.SphereGeometry(1,12,8);
  const M4=(x,y,z,ry=0,sx=1,sy=1,sz=1,rx=0,rz=0)=>mtx(x,y,z,ry,sx,sy,sz,rx,rz);
  const _q=new THREE.Quaternion(),_up=new THREE.Vector3(0,1,0),_z=new THREE.Vector3(0,0,1),_a=new THREE.Vector3(),_b=new THREE.Vector3(),_s=new THREE.Vector3();
  /* caño entre dos puntos */
  function seg(L,a,b,r,col,geo=CYL1){_a.set(b[0]-a[0],b[1]-a[1],b[2]-a[2]);const len=_a.length();_q.setFromUnitVectors(_up,_a.normalize());
    L.add(geo,new THREE.Matrix4().compose(_b.set((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2),_q,_s.set(r,len,r)),col);}
  /* caja con su eje z hacia d (vector unitario) */
  function cajaHacia(L,p,d,sx,sy,sz,col,geo=BOX1){_q.setFromUnitVectors(_z,d);L.add(geo,new THREE.Matrix4().compose(p,_q,_s.set(sx,sy,sz)),col);}

  /* ---------- vehículos negros mate, sin ploteo, sin patente ---------- */
  const KEYC={paint:0x15171a,paint2:0x15171a,glass:0x06080a,bglass:0x050607,bhole:0x020202,chrome:0x1c1d1f,trim:0x111214,grille:0x0b0c0d,under:0x060606,
    tire:0x0b0b0b,rim:0x1d1e20,rimSteel:0x25272a,light:0x76808a,tail:0x380707,amber:0x5a3308,int:0x16171a,char:0x0e0c0b,seam:0x040404,roofw:0x141516,
    lensB:0x14295f,lensR:0x5c3606,bellows:0x1a1a1a,rust:0x3a2416};
  function vehiculo(L,mi,x,z,a){const S={...CARS[mi],col:KEYC.paint,met:.2,d:{rust:0,decals:[]}},res=VEH.car(S,true),by=PISO.y(x,z);
    const B=mtx(x,by,z,a).multiply(new THREE.Matrix4().makeTranslation(0,res.pose.dy,0));let top=-9;
    for(const k in res.geo){const col=KEYC[k];if(col===undefined)continue;L.add(res.geo[k],B,col);
      if(k==='paint'){res.geo[k].computeBoundingBox();top=Math.max(top,res.geo[k].boundingBox.max.y);}}
    return{S,res,by,B,top:top+res.pose.dy,tris:res.tris};}
  /* defensa de caños al frente (local: el frente mira a −z) */
  function defensa(L,B,S,col){const hl=S.L/2,w=S.W*.42;const m=(x,y,z,sx,sy,sz)=>B.clone().multiply(M4(x,y,z,0,sx,sy,sz));
    for(const s of [-1,1])L.add(BOX1,m(s*w,.62,-hl-.16,.07,.62,.07),col);
    L.add(BOX1,m(0,.88,-hl-.18,w*2+.07,.07,.07),col);L.add(BOX1,m(0,.45,-hl-.18,w*2+.07,.07,.07),col);
    for(const s of [-1,1])L.add(BOX1,m(s*w,.66,-hl-.06,.06,.06,.22),col);}

  /* valla de contención de 1,1 m: caños, barrotes y patas planas (en el eje x = cte, de z0 a z1) */
  function valla(L,x,z0,z1,by,col){const len=z1-z0,zc=(z0+z1)/2,H=1.1;
    for(const z of [z0+.035,z1-.035])L.add(CYL1,M4(x,by+H/2,z,0,.024,H,.024),col);
    for(const y of [.13,H-.03])L.add(CYL1,M4(x,by+y,zc,0,.022,len-.07,.022,PI/2),col);
    for(let z=z0+.14;z<z1-.1;z+=.115)L.add(BOX1,M4(x,by+.13+(H-.16)/2,z,0,.016,H-.16,.016),col);
    for(const z of [z0+.08,z1-.08]){L.add(BOX1,M4(x,by+.015,z,0,.64,.03,.07),col);}}
  /* trípode de reflector: tres patas, mástil, horquilla y cabezal apuntando a d */
  function tripode(L,x,z,by,lamp,d,col){const hub=by+1.35,ry=Math.atan2(d.x,d.z),cr=Math.cos(ry),sr=Math.sin(ry);
    for(let i=0;i<3;i++){const an=i*2*PI/3+.35;seg(L,[x+Math.cos(an)*.62,by,z+Math.sin(an)*.62],[x,hub,z],.021,col);}
    seg(L,[x,hub-.15,z],[x,lamp.y-.24,z],.03,col);                                         // mástil
    L.add(BOX1,M4(x,lamp.y-.24,z,ry,.58,.05,.06),col);                                     // horquilla
    for(const s of [-1,1])L.add(BOX1,M4(x+cr*s*.28,lamp.y-.12,z-sr*s*.28,ry,.035,.25,.07),col);
    _b.set(lamp.x-d.x*.2,lamp.y-d.y*.2,lamp.z-d.z*.2);cajaHacia(L,_b,d,.44,.38,.36,0x17181a);    // cabezal
    _b.set(lamp.x-d.x*.02,lamp.y-d.y*.02,lamp.z-d.z*.02);cajaHacia(L,_b,d,.5,.44,.05,0x0c0c0d); // aro
    _b.set(lamp.x+d.x*.06,lamp.y+.21,lamp.z+d.z*.06);cajaHacia(L,_b,d,.46,.02,.2,0x111213);}     // visera

  /* ---------- reflectores: intensidad en un punto, con sombras de autos y cajas ---------- */
  /* corte de un segmento contra la caja de un auto (en su marco, como rayCars) */
  function segAuto(c,ax,ay,az,bx,by,bz){const ca=Math.cos(c.a),sa=Math.sin(c.a);
    const lx=(ax-c.x)*ca-(az-c.z)*sa,lz=(ax-c.x)*sa+(az-c.z)*ca,ly=ay-c.by,dx0=bx-ax,dz0=bz-az,dx=dx0*ca-dz0*sa,dz=dx0*sa+dz0*ca,dy=by-ay;
    let t0=0,t1=1;const sl=(p,v,a,b)=>{if(Math.abs(v)<1e-9)return p>=a&&p<=b;let u0=(a-p)/v,u1=(b-p)/v;if(u0>u1){const w=u0;u0=u1;u1=w;}t0=Math.max(t0,u0);t1=Math.min(t1,u1);return t0<=t1;};
    return sl(lx,dx,-c.W/2,c.W/2)&&sl(ly,dy,.12,c.H*.97)&&sl(lz,dz,-c.L/2,c.L/2);}
  function segCaja(b,ax,ay,az,bx,by,bz){let t0=0,t1=1;const sl=(p,v,a,c)=>{if(Math.abs(v)<1e-9)return p>=a&&p<=c;let u0=(a-p)/v,u1=(c-p)/v;if(u0>u1){const w=u0;u0=u1;u1=w;}t0=Math.max(t0,u0);t1=Math.min(t1,u1);return t0<=t1;};
    return sl(ax,bx-ax,b.x0,b.x1)&&sl(ay,by-ay,b.y0,b.y1)&&sl(az,bz-az,b.z0,b.z1);}
  function tapado(L,x,y,z){for(const c of CERCA){if(c.st>=3||c.crushed)continue;if(segAuto(c,L.x,L.y,L.z,x,y,z))return true;}
    for(const b of OBS)if(segCaja(b,L.x,L.y,L.z,x,y,z))return true;return false;}
  /* qué tanto alumbra el reflector L al punto (x,z) a la altura «alto» sobre el piso: 1 de lleno en el haz, cae en los bordes */
  function luzL(L,x,z,alto,sombra){const y=floorAt(x,z)+alto,dx=x-L.x,dy=y-L.y,dz=z-L.z,d=Math.hypot(dx,dy,dz);if(d<.8||d>L.R)return 0;
    const c=(dx*L.d.x+dy*L.d.y+dz*L.d.z)/d;if(c<=L.c1)return 0;
    let f=sst(L.c1,L.c0,c)*Math.min(1,(L.R-d)/(L.R*.25));if(f>0&&sombra&&tapado(L,x,y,z))f*=.08;return f;}
  /* para la IA: a la altura del pecho, con sombras (agachado detrás de un auto no se lo ve) */
  function luz(x,z){if(!armado)return 0;let b=0;for(const L of LAMP){if(!L.on)continue;const f=luzL(L,x,z,1,true);if(f>b)b=f;}return b;}

  /* mancha de luz sobre el asfalto: se hornea en una textura (rojo = reflector norte, verde = sur) con las sombras de los autos */
  function hornear(){if(!POOL)return;const P=POOL,im=P.ctx.createImageData(P.W,P.H),dd=im.data;
    for(let j=0;j<P.H;j++){const z=P.z0+(j+.5)/P.H*(P.z1-P.z0);for(let i=0;i<P.W;i++){const x=P.x0+(i+.5)/P.W*(P.x1-P.x0),k=(j*P.W+i)*4;
      for(let n=0;n<2;n++){const L=LAMP[n];let f=luzL(L,x,z,.02,true);if(f>0){const d=Math.hypot(x-L.x,z-L.z);f*=Math.min(1,Math.pow(13/d,1.05));}dd[k+n]=Math.round(255*clamp(f,0,1));}
      dd[k+2]=0;dd[k+3]=255;}}
    P.ctx.putImageData(im,0,0);P.tex.needsUpdate=true;}

  /* ---------- mueve un auto del juego (instanciado) a otro lugar ---------- */
  function moverAuto(c,x,z,a){const by=PISO.y(x,z),ps=c.res.pose;
    for(const q of c.cs)enDirty(q.x-q.r,q.z-q.r,q.x+q.r,q.z+q.r);
    c.x=x;c.z=z;c.a=a;c.by=by;c.tx=0;c.tz=0;
    const Mx=mtx(x,by,z,a).multiply(new THREE.Matrix4().makeTranslation(0,ps.dy,0)).multiply(new THREE.Matrix4().makeRotationX(ps.rx)).multiply(new THREE.Matrix4().makeRotationZ(ps.rz));
    c.M.copy(Mx);c.Mc.copy(Mx).multiply(new THREE.Matrix4().makeScale(1,.4,1));
    const sa=Math.sin(a),ca=Math.cos(a);c.cs.forEach((q,i)=>{const o=[-.31,0,.31][i]??0;circMove(q,x+sa*o*c.L,z+ca*o*c.L);q.h=c.H+by;enDirty(q.x-q.r,q.z-q.r,q.x+q.r,q.z+q.r);});
    if(c.grp){c.grp.matrix.copy(Mx);carLamps(c);}VLOD.t=0;}

  /* ---------- puertas abiertas y balazos de los autos de la fila ---------- */
  function geomAuto(S){const hl=S.L/2,xA=hl-S.hood,xA2=xA-S.ws,yT=(S.Hc||S.H)-.02,bR=S.hR+(S.bRise??.04),st=S.st;let xC2,xC;
    if(st==='sedan'||st==='classic'){xC2=xA2-S.roof;xC=xC2-S.rw;}else if(st==='pickup'||st==='amb'){xC2=xA2-S.cab;xC=xC2-.08;}else{xC2=-hl+(S.rs||.2);xC=-hl+.1;}
    return{hl,xA,xA2,xC,xC2,yT,bR};}
  function puerta(L,c,s){const S=c.S,g=geomAuto(S),W=c.W,y0=(S.yb||.3)+.1,y1=g.yT-.07,Ld=S.id==='hatch3'?1.22:1.02,th=rr(.85,1.15);
    const zf=-(g.xA+.06),hx=s*W/2,dir=[s*Math.sin(th),Math.cos(th)],ry=Math.atan2(dir[0],dir[1]),col=c.colC.clone().multiplyScalar(.8);
    const m=(x,y,z,r,sx,sy,sz)=>c.M.clone().multiply(M4(x,y,z,r,sx,sy,sz));
    /* hueco oscuro donde estaba la puerta */
    L.add(BOX1,m(hx+s*.012,(y0+y1)/2,zf+Ld/2,0,.012,y1-y0,Ld),0x050505);
    /* la puerta abierta (chapa hasta la cintura y el marco de la ventanilla, sin vidrio) */
    const cx=hx+dir[0]*Ld/2+s*.05,cz=zf+dir[1]*Ld/2;
    L.add(BOX1,m(cx,(y0+S.hR)/2,cz,ry,.07,S.hR-y0,Ld),col);
    L.add(BOX1,m(cx,y1-.03,cz-dir[1]*.04,ry,.045,.045,Ld*.86),col);
    L.add(BOX1,m(hx+dir[0]*(Ld-.05)+s*.05,(S.hR+y1)/2,zf+dir[1]*(Ld-.05),ry,.045,y1-S.hR,.045),col);
    return{x:c.x+Math.cos(c.a)*(hx+dir[0]*Ld*1.1)+Math.sin(c.a)*(cz),z:c.z-Math.sin(c.a)*(hx+dir[0]*Ld*1.1)+Math.cos(c.a)*(cz)};}

  /* ---------- calcomanías (sangre, casquillos, papeles, hollín, balazos, la pintada) en un solo atlas ---------- */
  const AT={W:1024,H:1024,c:256};
  function atlas(){const cv=document.createElement('canvas');cv.width=AT.W;cv.height=AT.H;const g=cv.getContext('2d');let s2=4242;const R=()=>{s2=(s2*1664525+1013904223)>>>0;return s2/4294967296;};
    const cell=(i,fn)=>{const x=(i%4)*AT.c,y=Math.floor(i/4)*AT.c;g.save();g.translate(x,y);g.beginPath();g.rect(0,0,AT.c,AT.c);g.clip();fn(g,AT.c);g.restore();};
    const blob=(g,x,y,r,col)=>{g.fillStyle=col;g.beginPath();for(let k=0;k<=24;k++){const a=k/24*PI*2,rr2=r*(.75+.35*R());g.lineTo(x+Math.cos(a)*rr2,y+Math.sin(a)*rr2);}g.fill();};
    /* 0 charco de sangre */
    cell(0,(g,S)=>{for(let k=0;k<5;k++)blob(g,S/2+(R()-.5)*50,S/2+(R()-.5)*50,40+R()*30,'rgba(52,4,4,.82)');blob(g,S/2,S/2,48,'rgba(30,2,2,.9)');
      for(let k=0;k<26;k++){const a=R()*PI*2,d=70+R()*50;g.fillStyle='rgba(50,4,4,.8)';g.beginPath();g.arc(S/2+Math.cos(a)*d,S/2+Math.sin(a)*d,2+R()*5,0,7);g.fill();}});
    /* 1 arrastre */
    cell(1,(g,S)=>{for(let k=0;k<60;k++){const y=10+k*4,w=26+12*Math.sin(k*.4)+R()*10;g.fillStyle=`rgba(${40+R()*20|0},3,3,${.35+.4*R()})`;g.fillRect(S/2-w/2+(R()-.5)*8,y,w,5);}
      for(let k=0;k<14;k++){g.fillStyle='rgba(30,2,2,.85)';g.fillRect(S/2-22+R()*44,R()*S,2,14+R()*30);}});
    /* 2 y 3 casquillos */
    for(const n of [2,3])cell(n,(g,S)=>{for(let k=0;k<(n===2?26:16);k++){const x=20+R()*(S-40),y=20+R()*(S-40),a=R()*PI;g.save();g.translate(x,y);g.rotate(a);
      g.fillStyle='#8a6a2a';g.fillRect(-7,-2.6,14,5.2);g.fillStyle='#e8c870';g.fillRect(-6,-2.6,11,1.6);g.fillStyle='#3a2a10';g.fillRect(6,-2.2,2,4.4);g.restore();}});
    /* 4 papeles y documentos */
    cell(4,(g,S)=>{for(let k=0;k<9;k++){const x=30+R()*(S-60),y=30+R()*(S-60),a=R()*PI,doc=k%3===0;g.save();g.translate(x,y);g.rotate(a);
      if(doc){g.fillStyle='#9fb3c4';g.fillRect(-17,-11,34,22);g.fillStyle='#5c6a74';g.fillRect(-14,-7,10,13);g.fillStyle='#404a52';for(let l=0;l<3;l++)g.fillRect(-1,-6+l*5,14,1.6);}
      else{g.fillStyle=`rgba(${200+R()*30|0},${196+R()*30|0},${180+R()*30|0},.95)`;g.fillRect(-22,-29,44,58);g.fillStyle='rgba(60,60,70,.55)';for(let l=0;l<9;l++)g.fillRect(-17,-23+l*5.5,30-R()*12,1.4);
        if(R()<.5){g.fillStyle='rgba(60,6,6,.6)';g.beginPath();g.arc(R()*20-10,R()*30-15,6+R()*8,0,7);g.fill();}}g.restore();}});
    /* 5 hollín y ceniza */
    cell(5,(g,S)=>{const gr=g.createRadialGradient(S/2,S/2,10,S/2,S/2,S/2);gr.addColorStop(0,'rgba(8,6,5,.95)');gr.addColorStop(.6,'rgba(14,12,10,.6)');gr.addColorStop(1,'rgba(14,12,10,0)');g.fillStyle=gr;g.fillRect(0,0,S,S);
      for(let k=0;k<40;k++){g.fillStyle=`rgba(${90+R()*60|0},${85+R()*55|0},${80+R()*50|0},${.3+R()*.4})`;g.fillRect(S/2+(R()-.5)*120,S/2+(R()-.5)*120,2+R()*6,2+R()*6);}});
    /* 6 balazos (para vidrios y chapa) */
    cell(6,(g,S)=>{for(let k=0;k<9;k++){const x=30+R()*(S-60),y=30+R()*(S-60);g.strokeStyle='rgba(220,230,235,.55)';g.lineWidth=1;
      for(let l=0;l<7;l++){const a=R()*PI*2,d=10+R()*26;g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(a)*d,y+Math.sin(a)*d);g.stroke();}
      g.fillStyle='rgba(200,210,215,.35)';g.beginPath();g.arc(x,y,8,0,7);g.fill();g.fillStyle='#050505';g.beginPath();g.arc(x,y,3.4,0,7);g.fill();}});
    /* 7 manos y chorreado de sangre (chapa) */
    cell(7,(g,S)=>{g.fillStyle='rgba(70,6,6,.8)';for(let k=0;k<3;k++){const x=50+k*70,y=60+R()*40;g.beginPath();g.ellipse(x,y,16,20,0,0,7);g.fill();for(let f=0;f<4;f++)g.fillRect(x-14+f*8,y-44,5,26);
      g.fillRect(x-3,y+12,3+R()*3,60+R()*60);}});
    /* 8–11: la pintada (1024×256, en y 512–768): aerosol claro, letras chorreadas */
    {g.save();g.translate(512,640);g.rotate(-.025);g.font='800 132px "Chakra Petch",Impact,"Arial Black",sans-serif';g.textAlign='center';g.textBaseline='middle';
      const tw=g.measureText('NO SON RESCATE').width;if(tw>940)g.scale(940/tw,1);   // que entre entera en la fila del atlas
      g.fillStyle='rgba(226,218,200,.94)';g.shadowColor='rgba(226,218,200,.5)';g.shadowBlur=6;g.fillText('NO SON RESCATE',0,0);g.shadowBlur=0;
      for(let k=0;k<44;k++){const x=-tw/2+12+R()*(tw-24);g.fillRect(x,30+R()*12,2+R()*3,18+R()*60);}g.restore();}
    /* 12–15: persiana metálica baja (1024×256, en y 768–1024): acanalada, con óxido, mugre abajo y restos de afiches */
    {const y0=768;g.fillStyle='#2a2e32';g.fillRect(0,y0,1024,256);
      for(let y=0;y<250;y+=7){g.fillStyle='rgba(255,255,255,.07)';g.fillRect(0,y0+y,1024,2);g.fillStyle='rgba(0,0,0,.3)';g.fillRect(0,y0+y+3,1024,2);}
      for(let k=0;k<40;k++){g.fillStyle=`rgba(${90+R()*40|0},${50+R()*20|0},30,${.08+R()*.12})`;g.fillRect(R()*1024,y0+R()*60,3+R()*6,40+R()*190);}
      for(let k=0;k<3;k++){g.fillStyle=`rgba(${180+R()*50|0},${170+R()*40|0},${150+R()*40|0},.3)`;g.fillRect(80+R()*800,y0+30+R()*100,60+R()*50,70+R()*40);}
      const gr=g.createLinearGradient(0,y0+150,0,y0+256);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(10,8,6,.55)');g.fillStyle=gr;g.fillRect(0,y0,1024,256);
      g.fillStyle='#1a1d20';g.fillRect(0,y0+246,1024,10);}
    const tex=new THREE.CanvasTexture(cv);tex.anisotropy=MAXANI;return tex;}
  /* coordenadas de textura de una celda del atlas */
  const UVC=i=>{const x=(i%4)*AT.c,y=Math.floor(i/4)*AT.c;return[x/AT.W,1-(y+AT.c)/AT.H,(x+AT.c)/AT.W,1-y/AT.H];};
  const UVPINT=[0,1-768/AT.H,1,1-512/AT.H],UVPERS=[0,0,1,1-768/AT.H];
  function Calcos(){const P=[],N=[],U=[];
    return{get n(){return P.length/3;},
      /* rectángulo con centro c, ejes u y v (unitarios), medidas w × h; la normal es u × v */
      quad(c,u,v,w,h,uv){const n=_a.copy(u).cross(v).normalize();const pts=[[-1,-1],[1,-1],[1,1],[-1,1]].map(([a,b])=>[c.x+u.x*a*w/2+v.x*b*h/2,c.y+u.y*a*w/2+v.y*b*h/2,c.z+u.z*a*w/2+v.z*b*h/2]);
        const uvs=[[uv[0],uv[1]],[uv[2],uv[1]],[uv[2],uv[3]],[uv[0],uv[3]]];for(const i of [0,1,2,0,2,3]){P.push(...pts[i]);N.push(n.x,n.y,n.z);U.push(...uvs[i]);}},
      piso(x,z,w,h,rot,cell){const y=floorAt(x,z)+.012,ca=Math.cos(rot),sa=Math.sin(rot);this.quad(new THREE.Vector3(x,y,z),new THREE.Vector3(ca,0,-sa),new THREE.Vector3(-sa,0,-ca),w,h,UVC(cell));},
      geo(){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(P,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(N,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(U,2));return g;}};}

  /* ---------- sombreadores: haz en la niebla, mancha de luz, brillos (balizas y fuego) y humo ---------- */
  const SH_BEAM={vertexShader:'attribute float aL;uniform float uI0,uI1,uFD;varying vec3 vN;varying vec3 vV;varying float vT;varying float vI;varying float vF;'+
      'void main(){vec4 mv=modelViewMatrix*vec4(position,1.);vN=normalize(normalMatrix*normal);vV=normalize(-mv.xyz);vT=uv.y;vI=mix(uI0,uI1,aL);float d=length(mv.xyz);vF=exp(-uFD*uFD*d*d);gl_Position=projectionMatrix*mv;}',
    fragmentShader:'uniform float uOp;uniform vec3 uCol;varying vec3 vN;varying vec3 vV;varying float vT;varying float vI;varying float vF;'+
      'void main(){float f=pow(abs(dot(normalize(vN),normalize(vV))),2.2);float a=f*uOp*vI*(.16+.84*pow(1.-vT,2.))*smoothstep(1.,.7,vT)*smoothstep(0.,.04,vT);gl_FragColor=vec4(uCol*a*(.4+.6*vF),1.);}'};
  const SH_POOL={vertexShader:'uniform float uFD;varying vec2 vUv;varying float vF;void main(){vUv=uv;vec4 mv=modelViewMatrix*vec4(position,1.);float d=length(mv.xyz);vF=exp(-uFD*uFD*d*d);gl_Position=projectionMatrix*mv;}',
    fragmentShader:'uniform sampler2D uTex;uniform float uI0,uI1;uniform vec3 uCol;varying vec2 vUv;varying float vF;void main(){vec4 t=texture2D(uTex,vUv);float a=t.r*uI0+t.g*uI1;gl_FragColor=vec4(uCol*a*vF,1.);}'};
  const SH_GLOW={vertexShader:'attribute float aS;attribute vec3 aC;uniform float uScale,uMin,uFD;varying vec3 vC;'+
      'void main(){vec4 mv=modelViewMatrix*vec4(position,1.);float d=max(-mv.z,.1);float f=exp(-uFD*uFD*d*d);vC=aC*(.3+.7*f);float on=step(.003,aC.r+aC.g+aC.b);'+
      'gl_PointSize=on*clamp(aS*uScale/d,uMin,300.);gl_Position=projectionMatrix*mv;}',
    fragmentShader:'varying vec3 vC;void main(){vec2 p=gl_PointCoord*2.-1.;float r=dot(p,p);if(r>1.)discard;float a=1.-r;gl_FragColor=vec4(vC*a*a,1.);}'};
  const SH_HUMO={vertexShader:'attribute float aS;attribute vec4 aC;uniform float uScale,uFD;varying vec4 vC;'+
      'void main(){vec4 mv=modelViewMatrix*vec4(position,1.);float d=max(-mv.z,.1);float f=exp(-uFD*uFD*d*d);vC=vec4(aC.rgb,aC.a*f);gl_PointSize=clamp(aS*uScale/d,0.,360.);gl_Position=projectionMatrix*mv;}',
    fragmentShader:'varying vec4 vC;void main(){vec2 p=gl_PointCoord*2.-1.;float r=dot(p,p);if(r>1.)discard;float a=1.-r;gl_FragColor=vec4(vC.rgb,vC.a*a*a);}'};
  /* puntos con tamaño y color propios (se actualizan cada cuadro) */
  function Puntos(n,sh,blend,col4){const g=new THREE.BufferGeometry(),P=new Float32Array(n*3),S=new Float32Array(n),C=new Float32Array(n*(col4?4:3));
    g.setAttribute('position',new THREE.BufferAttribute(P,3).setUsage(THREE.DynamicDrawUsage));g.setAttribute('aS',new THREE.BufferAttribute(S,1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aC',new THREE.BufferAttribute(C,col4?4:3).setUsage(THREE.DynamicDrawUsage));
    const m=new THREE.ShaderMaterial({uniforms:{uScale:{value:400},uMin:{value:2.5},uFD:{value:.005}},vertexShader:sh.vertexShader,fragmentShader:sh.fragmentShader,transparent:true,depthWrite:false,blending:blend});
    const o=new THREE.Points(g,m);o.frustumCulled=false;o.renderOrder=7;return{o,P,S,C,g,m,dirty(){for(const k of ['position','aS','aC'])g.attributes[k].needsUpdate=true;}};}

  /* ================= armar ================= */
  function armar(){if(armado)return datos;armado=true;sem=91173;
    G=new THREE.Group();G.name='reten';SECG.B.add(G);
    const L=new THREE.Group();G.add(L);
    const A=Lote();
    /* --- furgones --- */
    const fur=FUR.map(f=>{const v=vehiculo(A,10,BX,f.z,f.a);defensa(A,v.B,v.S,0x141517);return v;});
    fur.forEach((v,i)=>{const S=v.S,g=geomAuto(S),f=FUR[i],sg=f.a===0?1:-1,x0=BX-S.W/2-.06,x1=BX+S.W/2+.06;
      /* dos cajas por furgón: la cabina (más baja) y la caja; frenan balas y no se trepan */
      const zc0=f.z-sg*S.L/2,zc1=f.z-sg*g.xC,zb1=f.z+sg*S.L/2;
      OBS.push({x0,x1,z0:Math.min(zc0,zc1),z1:Math.max(zc0,zc1),y0:v.by,y1:v.by+(S.Hc||S.H),k:'furgon'});
      OBS.push({x0,x1,z0:Math.min(zc1,zb1),z1:Math.max(zc1,zb1),y0:v.by,y1:v.by+v.top,k:'furgon'});});
    /* el nido del tirador: techo de la caja del furgón norte, entre el borde y el equipo de aire */
    {const v=fur[0];datos.nido={x:BX+.2,z:r2(FUR[0].z+.35),y:r2(v.by+v.top),rumbo:r2(PI/2),r:.8};}
    /* --- vallas: el paso del medio y las puntas hasta el cordón --- */
    const zc=x=>{let a=null,b=null;for(let z=590;z<=625;z+=.05)if(PISO.calzada(x,z)){if(a===null)a=z;b=z;}return[a,b];};
    const [cN,cS]=zc(BX);const by0=PISO.y(BX,607);const gal=0x5d6164;
    const VA=[[cN+.02,FUR[0].z-2.95],[PASO[0],PASO[0]+1.62],[PASO[0]+1.58,PASO[1]],[FUR[1].z+2.95,cS-.02]];
    VA.forEach(([z0,z1],i)=>valla(A,BX+(i===1?.12:i===2?-.12:0),z0,z1,by0,gal));
    for(const [z0,z1] of [[cN+.02,FUR[0].z-2.95],[PASO[0],PASO[1]],[FUR[1].z+2.95,cS-.02]])OBS.push({x0:BX-.3,x1:BX+.3,z0,z1,y0:by0,y1:by0+1.1,k:'valla'});
    /* --- camioneta de mando --- */
    const cam=vehiculo(A,4,CAM.x,CAM.z,PI/2);defensa(A,cam.B,cam.S,0x141517);
    {const S=cam.S,hl=S.L/2,m=(x,y,z,sx,sy,sz,ry=0)=>cam.B.clone().multiply(M4(x,y,z,ry,sx,sy,sz));
      OBS.push({x0:CAM.x-hl,x1:CAM.x+hl,z0:CAM.z-S.W/2-.05,z1:CAM.z+S.W/2+.05,y0:cam.by,y1:cam.by+1.72,k:'camioneta'});
      /* la caja abierta: cajones, un estuche y la antena (local: la cola es +z) */
      const fy=(S.bedY||.95)-.12;A.add(BOX1,m(-.3,fy+.24,1.55,.85,.48,.62),0x23261f);A.add(BOX1,m(-.3,fy+.5,1.55,.88,.04,.65),0x2e3229);
      A.add(BOX1,m(.42,fy+.18,2.15,.55,.36,.5),0x1b1d1a);A.add(BOX1,m(-.25,fy+.6,1.5,.62,.2,.42,.3),0x0f1011);
      A.add(BOX1,m(.35,fy+.08,1.25,.6,.16,.3),0x2a2416);
      A.add(CYL1,m(-.72,fy+1.55,1.12,.028,3.1,.028),0x202124);A.add(CYL1,m(-.72,fy+3.55,1.12,.008,.9,.008),0x101010);
      A.add(BOX1,m(-.72,fy+.12,1.12,.14,.24,.14),0x151618);
      BAL.ant=new THREE.Vector3(-.72,fy+3.98,1.12).applyMatrix4(cam.B);}
    /* --- reflectores en trípode y grupo electrógeno con los cables --- */
    TRIP.forEach((tp,i)=>{const by=floorAt(tp.x,tp.z),lamp=new THREE.Vector3(tp.x,by+2.75,tp.z),ap=new THREE.Vector3(tp.ap[0],PISO.y(tp.ap[0],tp.ap[1]),tp.ap[1]);
      const d=ap.clone().sub(lamp).normalize();tripode(A,tp.x,tp.z,by,lamp,d,0x1a1b1d);
      const a1=11*PI/180,a0=6*PI/180;LAMP.push({x:lamp.x,y:lamp.y,z:lamp.z,d,R:58,c1:Math.cos(a1),c0:Math.cos(a0),ang:a1,on:true,i});
      CIR.push(Object.assign(addCircle(tp.x,tp.z,.42),{h:by+2.6}));});
    {const by=floorAt(GEN.x,GEN.z);A.add(BOX1,M4(GEN.x,by+.31,GEN.z,.2,.95,.56,.6),0x262a20);A.add(BOX1,M4(GEN.x,by+.62,GEN.z,.2,.9,.06,.55),0x14160f);
      for(const s of [-1,1])A.add(CYL1,M4(GEN.x+Math.cos(.2)*s*.5,by+.45,GEN.z-Math.sin(.2)*s*.5,0,.02,.9,.02),0x111111);
      CIR.push(Object.assign(addCircle(GEN.x,GEN.z,.55),{h:by+.66}));
      /* cables por el piso hasta cada trípode */
      for(const tp of TRIP){let px=GEN.x+.3,pz=GEN.z;const n=9;for(let k=1;k<=n;k++){const u=k/n,x=GEN.x+.3+(tp.x-GEN.x-.3)*u+Math.sin(u*PI)*.9,z=GEN.z+(tp.z-GEN.z)*u;
        seg(A,[px,floorAt(px,pz)+.02,pz],[x,floorAt(x,z)+.02,z],.018,0x080808);px=x;pz=z;}}}
    /* --- tacho con fuego y la pila de ropa quemada al lado --- */
    {const by=floorAt(TACHO.x,TACHO.z);A.add(new THREE.CylinderGeometry(.3,.28,.86,14,1,true),M4(TACHO.x,by+.43,TACHO.z),0x3a281c);
      A.add(new THREE.CylinderGeometry(.31,.31,.04,14),M4(TACHO.x,by+.86,TACHO.z),0x22170f);A.add(new THREE.CircleGeometry(.29,14),M4(TACHO.x,by+.8,TACHO.z,0,1,1,1,-PI/2),0x1a0c06);
      for(let k=0;k<7;k++)A.add(BOX1,M4(TACHO.x+.55+rr(-.3,.3),by+.05,TACHO.z+rr(-.35,.35),rr(0,3),rr(.25,.5),rr(.04,.12),rr(.2,.45)),k%2?0x1a1714:0x2b2620);
      CIR.push(Object.assign(addCircle(TACHO.x,TACHO.z,.34),{h:by+.88}));}
    /* --- bolsas negras con cuerpos, en fila contra la pared de la vereda sur --- */
    const bolsas=[];{/* x, separación de la pared y giro: una quedó corrida, como si la hubieran arrastrado después */
      for(const [x,sep,rot] of [[-433.4,0,0],[-431.45,0,.04],[-429.5,0,-.05],[-427.75,.6,.45],[-425.95,0,.03]]){const h=wallHit(x,618.2,0,1,8),zf=h?h.z:620.8;bolsas.push({x,z:zf-.5-sep,rot});}
      for(const b of bolsas){const by=floorAt(b.x,b.z),ca=Math.cos(b.rot),sa=Math.sin(b.rot),P=(lx,lz)=>[b.x+lx*ca+lz*sa,b.z-lx*sa+lz*ca];
        /* a lo largo de x: cuerpo, cabeza y pies se marcan */
        A.add(SPH1,M4(b.x,by+.13,b.z,b.rot+PI/2,.31,.14,.9),0x14171d);
        {const [hx,hz]=P(.82,0);A.add(SPH1,M4(hx,by+.12,hz,b.rot,.17,.13,.17),0x14171d);}
        {const [fx,fz]=P(-.8,0);A.add(SPH1,M4(fx,by+.11,fz,b.rot+PI/2,.19,.11,.14),0x14171d);}
        A.add(BOX1,M4(b.x,by+.275,b.z,b.rot,1.5,.012,.02),0x6a6d72);}
      const xs=bolsas.map(b=>b.x),zs=bolsas.map(b=>b.z);
      OBS.push({x0:Math.min(...xs)-1,x1:Math.max(...xs)+1,z0:Math.min(...zs)-.35,z1:Math.max(...zs)+.35,y0:0,y1:.28,k:'bolsas'});}

    /* --- la fila de autos detenidos --- */
    const fila=[];for(const f of FILA){let c=null,bd=1.5;for(const o of VCARS){if(o.S.id!==f.id)continue;const d=Math.hypot(o.x-f.de[0],o.z-f.de[1]);if(d<bd){bd=d;c=o;}}
      if(!c){avisos.push('no encontré el auto '+f.id+' en '+f.de.join(';'));continue;}fila.push([f,c]);}
    for(const [f,c] of fila){if(f.x!==undefined)moverAuto(c,f.x,f.z,A0+f.da);AUTOS.push({c,f,hid:false,a0:0,a1:0,b0:0,b1:0});}
    /* puertas abiertas (en la malla unida: si el auto explota, carBoom las esconde con c.rg) */
    const sangreP=[];for(const e of AUTOS){const f=e.f;e.a0=A.n;for(const s of f.puertas||[]){const p=puerta(A,e.c,s);if(s<0||f.sangre)sangreP.push(p);}e.a1=A.n;}
    /* malla unida */
    const mA=new THREE.Mesh(A.geo(),new THREE.MeshStandardMaterial({vertexColors:true,roughness:.52,metalness:.32}));mA.castShadow=true;mA.receiveShadow=true;L.add(mA);HA.mesh=mA;
    for(const e of AUTOS)if(e.a1>e.a0)e.c.rg.push([HA,e.a0,e.a1]);

    /* --- choques: cajas y círculos nuevos; la grilla de los bichos toma todo --- */
    for(const b of OBS)obstacles.push(b);
    enDirty(-452,594,-424,624);
    /* autos que pueden tapar la luz de los reflectores */
    for(const c of VCARS)if(c.x>-445&&c.x<-370&&c.z>593&&c.z<621)CERCA.push(c);

    /* --- reflectores: haces, lentes, destellos y mancha de luz --- */
    {const pos=[],nor=[],uv=[],al=[];for(const Lm of LAMP){const len=54,rf=len*Math.tan(Lm.ang)*.9,g=new THREE.CylinderGeometry(rf,.2,len,22,1,true).toNonIndexed();g.translate(0,len/2,0);
        _q.setFromUnitVectors(_up,Lm.d);g.applyMatrix4(new THREE.Matrix4().compose(_b.set(Lm.x,Lm.y,Lm.z),_q,_s.set(1,1,1)));
        pos.push(...g.attributes.position.array);nor.push(...g.attributes.normal.array);uv.push(...g.attributes.uv.array);for(let k=0;k<g.attributes.position.count;k++)al.push(Lm.i);g.dispose();}
      const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(nor,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setAttribute('aL',new THREE.Float32BufferAttribute(al,1));
      const m=new THREE.ShaderMaterial({uniforms:{uOp:{value:.24},uCol:{value:new THREE.Color(0xfff1d8)},uI0:{value:1},uI1:{value:1},uFD:{value:.005}},vertexShader:SH_BEAM.vertexShader,fragmentShader:SH_BEAM.fragmentShader,
        transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide});
      BEAM=new THREE.Mesh(g,m);BEAM.renderOrder=6;BEAM.frustumCulled=false;L.add(BEAM);}
    {const lb=Lote();for(const Lm of LAMP){_b.set(Lm.x+Lm.d.x*.035,Lm.y+Lm.d.y*.035,Lm.z+Lm.d.z*.035);_q.setFromUnitVectors(_z,Lm.d);lb.add(new THREE.CircleGeometry(.19,18),new THREE.Matrix4().compose(_b,_q,_s.set(1,1,1)),0xfff3dc);}
      LENS=new THREE.Mesh(lb.geo(),new THREE.MeshBasicMaterial({vertexColors:true,fog:false}));L.add(LENS);LENS.userData.C0=LENS.geometry.attributes.color.array.slice();
      for(const Lm of LAMP){const s=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex,color:0xfff0d2,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,fog:false}));
        s.position.set(Lm.x+Lm.d.x*.12,Lm.y+Lm.d.y*.12,Lm.z+Lm.d.z*.12);s.renderOrder=8;L.add(s);Lm.spr=s;}}
    {const P={x0:-437,x1:-381,z0:595.6,z1:619.6,W:224,H:96};const cv=document.createElement('canvas');cv.width=P.W;cv.height=P.H;P.ctx=cv.getContext('2d');P.tex=new THREE.CanvasTexture(cv);
      const g=new THREE.PlaneGeometry(P.x1-P.x0,P.z1-P.z0);g.rotateX(-PI/2);
      const m=new THREE.ShaderMaterial({uniforms:{uTex:{value:P.tex},uI0:{value:1},uI1:{value:1},uCol:{value:new THREE.Color(.44,.41,.35)},uFD:{value:.005}},vertexShader:SH_POOL.vertexShader,fragmentShader:SH_POOL.fragmentShader,
        transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3});
      P.mesh=new THREE.Mesh(g,m);P.mesh.position.set((P.x0+P.x1)/2,by0+.02,(P.z0+P.z1)/2);P.mesh.renderOrder=5;L.add(P.mesh);POOL=P;hornear();}

    /* --- brillos: balizas, antena, fuego (un solo objeto de puntos) y humo --- */
    {const lst=[];const add=(p,s,c,k,ph)=>{lst.push({p:p.clone(),s,c:new THREE.Color(c),k,ph});};
      fur.forEach((v,i)=>{const S=v.S,g=geomAuto(S),zc=-(g.xA2+(g.xC2-g.xA2)*.45),y=(S.Hc||S.H)+.12;
        [-.48,-.16,.16,.48].forEach((x,j)=>add(new THREE.Vector3(x,y,zc).applyMatrix4(v.B),1.7,0x4a7cff,'azul',(j<2?0:.45)+i*.21));
        const bx0=-S.L/2-.02,bx1=g.xC-.02;for(const [x,z] of [[-(S.W/2-.08),-bx0+.02],[S.W/2-.08,-bx0+.02]])add(new THREE.Vector3(x,S.H+.06,z).applyMatrix4(v.B),1.8,0xffa21e,'ambar',rn());
        add(new THREE.Vector3(0,y+.3,zc).applyMatrix4(v.B),10,0x2a5cff,'halo',i*.21);});
      add(BAL.ant,.55,0xff2418,'antena',0);
      const tb=new THREE.Vector3(TACHO.x,floorAt(TACHO.x,TACHO.z)+.9,TACHO.z);add(tb.clone().setY(tb.y+.55),3.6,0xff7a26,'hogar',0);
      for(let k=0;k<14;k++)add(tb,.5,0xffb050,'llama',k/14);for(let k=0;k<6;k++)add(tb,.06,0xffc070,'chispa',k/6);
      BAL.lst=lst;GLOW=Puntos(lst.length,SH_GLOW,THREE.AdditiveBlending,false);G.add(GLOW.o);
      HUMO=Puntos(8,SH_HUMO,THREE.NormalBlending,true);HUMO.o.renderOrder=4;G.add(HUMO.o);HUMO.base=tb;}

    /* --- calcomanías: sangre, casquillos, papeles, hollín, balazos y la pintada --- */
    {const D=Calcos();const V=(x,y,z)=>new THREE.Vector3(x,y,z);
      /* detrás de la barricada: donde se paran a tirar */
      D.piso(-441.2,602.6,1.1,1.1,rr(0,6),2);D.piso(-441.4,611.2,1.1,1.1,rr(0,6),3);D.piso(-443.5,607.2,1,1,rr(0,6),2);
      /* el paso del medio: acá revisaban a la gente */
      D.piso(-435.6,606.9,1.9,1.9,.3,0);D.piso(-434,607.6,1.5,1.5,1.2,4);D.piso(-436.2,608.4,1.1,1.1,2,3);D.piso(-432.4,605.6,1.3,1.3,2.5,4);
      /* arrastre desde el paso hasta las bolsas */
      D.piso(-434.6,612.6,1.1,4.6,.62,1);D.piso(-433.1,616.4,1,2.6,.35,1);
      /* sangre junto a las puertas abiertas, papeles y casquillos a lo largo de la fila */
      for(const p of sangreP)D.piso(p.x,p.z,1.6,1.6,rr(0,6),0);
      for(const [x,z,c,s] of [[-424,606.8,4,1.4],[-412,609.5,4,1.2],[-396,607.2,4,1.3],[-419,600.4,3,1],[-403,606,2,1],[-386,609,3,1],[-430,611.8,4,1.1],[-401.5,614.6,2,1]])D.piso(x,z,s,s,rr(0,6),c);
      /* hollín bajo el tacho y la ropa quemada */
      D.piso(TACHO.x+.2,TACHO.z,2.2,2.2,0,5);D.piso(TACHO.x+.7,TACHO.z+.1,1.4,1.4,1,5);
      /* la pintada «NO SON RESCATE», en la pared norte del lado este */
      /* la pintada «NO SON RESCATE»: en una persiana baja de la vereda norte, 40 m antes de la barricada (un aviso para el que
         viene del este). La persiana es nuestra: los frentes de los locales (FRENTES) no salen iguales en todas las partidas.
         Se apoya en el plano del frente que haya ahí (o en la pared, si no hay frente) */
      const DP=Calcos();{let x=-397.5,z=590.7,ry=0,ok=false;try{for(const ch of FRENTES._ch.values())for(const q of ch.specs)if(q.z>585&&q.z<596&&Math.abs(q.x-x)<q.w/2+.01){z=q.z;ry=q.ry;ok=true;}}catch(e){}
        if(!ok){const h=wallHit(x,600,0,-1,20);if(h)z=h.z;else avisos.push('no encontré la pared para la pintada');}
        const nx=Math.sin(ry),nz=Math.cos(ry),fy=floorAt(x+nx*.8,z+nz*.8),u=V(Math.cos(ry),0,-Math.sin(ry)),up=V(0,1,0);
        D.quad(V(x+nx*.1,fy+1.3,z+nz*.1),u,up,6.8,2.6,UVPERS);
        DP.quad(V(x+nx*.115,fy+1.42,z+nz*.115),u,up,6.4,1.6,UVPINT);datos.pintada={x:r2(x+nx*.1),z:r2(z+nz*.1)};}
      /* balazos y sangre en los autos (en el marco de cada auto; carBoom los esconde con c.rg) */
      for(const e of AUTOS){const c=e.c,S=c.S,g=geomAuto(S);e.b0=D.n;
        if(e.f.balas){const pa=V(0,g.bR+.03,-g.xA).applyMatrix4(c.M),pb=V(0,g.yT,-g.xA2).applyMatrix4(c.M),vv=pb.clone().sub(pa),hgt=vv.length();vv.normalize();
          const uu=V(-1,0,0).transformDirection(c.M),nn=uu.clone().cross(vv).normalize(),cc=pa.clone().add(pb).multiplyScalar(.5).addScaledVector(nn,.03);D.quad(cc,uu,vv,c.W*.62,hgt*.9,UVC(6));
          const ra=V(0,g.yT-.02,-g.xC2).applyMatrix4(c.M),rb=V(0,g.bR+.08,-g.xC).applyMatrix4(c.M),v2=rb.clone().sub(ra),h2=v2.length();v2.normalize();
          const n2=uu.clone().cross(v2).normalize(),c2=ra.clone().add(rb).multiplyScalar(.5).addScaledVector(n2,.03);D.quad(c2,uu,v2,c.W*.6,h2*.9,UVC(6));}
        if(e.f.sangre){const s=-1,p=V(s*(c.W/2+.03),(S.hR+(S.yb||.3))/2+.15,-(g.xA-1.45)).applyMatrix4(c.M);D.quad(p,V(0,0,1).transformDirection(c.M).multiplyScalar(-s),V(0,1,0),.9,.75,UVC(7));}
        e.b1=D.n;}
      const AT_TEX=atlas();
      if(DP.n){const mP=new THREE.Mesh(DP.geo(),new THREE.MeshStandardMaterial({map:AT_TEX,emissiveMap:AT_TEX,emissive:0xffffff,emissiveIntensity:.55,transparent:true,depthWrite:false,roughness:.9,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));mP.renderOrder=4;/* después de la persiana */L.add(mP);}
      const mD=new THREE.Mesh(D.geo(),new THREE.MeshStandardMaterial({map:AT_TEX,transparent:true,depthWrite:false,roughness:.85,metalness:0,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));
      mD.renderOrder=3;mD.receiveShadow=true;L.add(mD);HD.mesh=mD;for(const e of AUTOS)if(e.b1>e.b0)e.c.rg.push([HD,e.b0,e.b1]);}

    /* ================= datos para la IA ================= */
    const PT=(x,z)=>({x:r2(x),z:r2(z)});
    datos.puestos=[{...PT(-441,602.8),rumbo:r2(PI/2),rol:'jefe'},{...PT(-433,607),rumbo:r2(PI/2),rol:'asalto'},{...PT(-441,611.2),rumbo:r2(PI/2),rol:'granadero'},
      {x:datos.nido.x,z:datos.nido.z,rumbo:datos.nido.rumbo,rol:'tirador'}];
    datos.ronda=[PT(-433,607),PT(-424.5,606.6),PT(-412.5,605.2),PT(-394.5,607.4),PT(-403.5,608.6),PT(-416.9,611.9),PT(-429,611.2)];
    datos.reunion=PT(-447.5,613.3);
    datos.refuerzo={sale:PT(-540,605.5),camino:[PT(-540,605.5),PT(-505,605.5),PT(-470,606.5),PT(-452,609),PT(-447.5,613.3)]};
    /* zonas de luz: en franjas de 6 m, un rectángulo por cada tramo de z donde algún reflector da de lleno (luz > 0,5 a la altura
       del pecho, sin contar sombras de autos). Cerca de la barricada quedan dos (uno por haz) con la franja oscura del medio afuera */
    datos.luz=[];for(let x=-436;x<-380;x+=6){let a=null;for(let z=595;z<=620.5;z+=.5){let on=false;
        if(z<=620)for(let xx=x+.5;xx<x+6&&!on;xx+=1)for(const Lm of LAMP)if(luzL(Lm,xx,z,1,false)>.5){on=true;break;}
        if(on){if(a===null)a=z;}else if(a!==null){datos.luz.push({x0:x,z0:r2(a-.25),x1:x+6,z1:r2(z-.25)});a=null;}}}
    datos.cuerpos=[...bolsas.map(b=>PT(b.x,b.z)),...AUTOS.filter(e=>e.f.balas||e.f.sangre||e.f.puertas).map(e=>PT(e.c.x,e.c.z))];
    {let tt=0;G.traverse(o=>{if(o.isMesh){const g=o.geometry;tt+=(g.index?g.index.count:g.attributes.position.count)/3;}});datos.tris=Math.round(tt);}
    return datos;}

  /* ================= cada cuadro: balizas, reflectores, fuego, humo ================= */
  const _cp=new THREE.Vector3();
  function fx(dt){if(!G||!SECG.B.visible)return;t+=dt;
    /* el reflector sur titila de a ratos */
    fk.t-=dt;if(fk.on>0){fk.on-=dt;if(Math.random()<.35)I[1]=Math.random()<.45?rr(.05,.35):rr(.7,1);}else{I[1]=Math.min(1,I[1]+dt*6);if(fk.t<=0){fk.on=.35+Math.random()*.9;fk.t=6+Math.random()*9;}}
    if(!LAMP[1].on)I[1]=0;if(!LAMP[0].on)I[0]=0;
    const fd=scene.fog?scene.fog.density:.005,cp=camera.position,sc=renderer.domElement.height/(2*Math.tan(camera.fov*PI/360));
    BEAM.material.uniforms.uI0.value=I[0];BEAM.material.uniforms.uI1.value=I[1];BEAM.material.uniforms.uFD.value=fd;
    POOL.mesh.material.uniforms.uI0.value=I[0];POOL.mesh.material.uniforms.uI1.value=I[1];POOL.mesh.material.uniforms.uFD.value=fd;
    {const ca=LENS.geometry.attributes.color,C0=LENS.userData.C0,n=ca.count/2;for(let k=0;k<ca.count;k++){const f=I[k<n?0:1]*.85+.15;ca.array[k*3]=C0[k*3]*f;ca.array[k*3+1]=C0[k*3+1]*f;ca.array[k*3+2]=C0[k*3+2]*f;}ca.needsUpdate=true;}
    /* destello: de frente al haz encandila (como la lente del faro) */
    for(const Lm of LAMP){_cp.set(cp.x-Lm.x,cp.y-Lm.y,cp.z-Lm.z);const dist=_cp.length()||1,al=(_cp.x*Lm.d.x+_cp.y*Lm.d.y+_cp.z*Lm.d.z)/dist,fl=Math.pow(Math.max(0,al),14);
      const s=1.6+dist*.02+fl*(3+dist*.12),k=(.3+2.6*fl)*I[Lm.i];Lm.spr.scale.set(s,s,1);Lm.spr.material.color.setRGB(k,k*.95,k*.84);}
    /* balizas y fuego */
    const g=GLOW,lst=BAL.lst;g.m.uniforms.uScale.value=sc;g.m.uniforms.uFD.value=fd;const fire=.8+.2*Math.sin(t*13)+.1*Math.sin(t*31);
    for(let k=0;k<lst.length;k++){const b=lst[k];let f=0,s=b.s,x=b.p.x,y=b.p.y,z=b.p.z,r=b.c.r,gg=b.c.g,bb=b.c.b;
      if(b.k==='azul'){const u=((t+b.ph)%.9)/.9;f=(u<.07||(u>.13&&u<.2))?1.8:0;}
      else if(b.k==='halo'){const u=((t+b.ph)%.9)/.9,v=((t+b.ph+.45)%.9)/.9;f=.5*((u<.07||(u>.13&&u<.2)||v<.07||(v>.13&&v<.2))?1:0);}
      else if(b.k==='ambar')f=Math.pow(Math.max(0,Math.cos((t*1.15+b.ph)*2*PI)),6)*1.4;
      else if(b.k==='antena')f=((t+.3)%2.2)<.12?.9:.05;
      else if(b.k==='hogar')f=.32*fire;
      else if(b.k==='llama'){const u=(t*1.35+b.ph)%1;f=(1-u)*(.75+.25*Math.sin(t*20+k));y+=u*1.05;x+=Math.sin(t*3+k*2.1)*.12*u;z+=Math.cos(t*2.6+k*1.3)*.1*u;s=b.s*(1-u*.7);gg=b.c.g*(1-u*.6);bb=b.c.b*(1-u);}
      else if(b.k==='chispa'){const u=(t*.6+b.ph)%1;f=u<.85?1-u:0;y+=u*2.6;x+=Math.sin(k*7+t)*u*.6+u*.5;z+=Math.cos(k*5)*u*.5;}
      g.P[k*3]=x;g.P[k*3+1]=y;g.P[k*3+2]=z;g.S[k]=s;g.C[k*3]=r*f;g.C[k*3+1]=gg*f;g.C[k*3+2]=bb*f;}
    g.dirty();
    {const h=HUMO;h.m.uniforms.uScale.value=sc;h.m.uniforms.uFD.value=fd;for(let k=0;k<8;k++){const u=(t*.16+k/8)%1;h.P[k*3]=h.base.x+u*2.2+Math.sin(k*3+t*.3)*.3;h.P[k*3+1]=h.base.y+.7+u*6;h.P[k*3+2]=h.base.z+Math.cos(k*2)*.4*u;
      h.S[k]=.7+u*3.2;h.C[k*4]=.075;h.C[k*4+1]=.07;h.C[k*4+2]=.066;h.C[k*4+3]=.42*Math.min(1,u*6)*(1-u);}h.dirty();}
    /* autos de la fila que empujó un bicho grande: sus puertas y calcomanías se van con ellos */
    if((chk-=dt)<=0){chk=.3;for(const e of AUTOS){const c=e.c;if(!e.hid&&c.dyn){e.hid=true;if(e.a1>e.a0)hideRange(HA.mesh,e.a0,e.a1);if(e.b1>e.b0)hideRange(HD.mesh,e.b0,e.b1);UNDO.push(()=>{e.hid=false;});}}}}

  /* al reiniciar la partida: los autos ya volvieron (UNDO); se vuelve a hornear la luz con ellos en su lugar */
  function reset(){if(!armado)return;t=0;fk={t:7,on:0};I[0]=I[1]=1;for(const Lm of LAMP)Lm.on=true;hornear();}

  /* ================= ir directo al retén (botones de la pantalla de inicio) ================= */
  function ir(opt){modo={bichos:!(opt&&opt.bichos===false)};startGame();}
  /* se llama desde startGame (después de resetGame): si la partida es de retén, deja todo como para probarlo */
  function alEmpezar(){if(modo)aplicar(modo);}
  function aplicar(m){GATE.open=true;STAGE='B';
    const x=-326,z=606;P.pos.set(x,floorAt(x,z),z);P.vel.set(0,0,0);P.yaw=PI/2;P.pitch=0;
    wave=5;bossCount=1;toSpawn=0;intermission=m.bichos?7:1e9;
    W[1].res=20;W[2].res=128;hudAmmo();hudWave();if(!m.bichos)$('#left').textContent='sin bichos (prueba)';
    setTimeout(()=>{if(running&&modo)announce('Av. de Mayo y Santiago del Estero',m.bichos?'Prueba del retén. Los bichos siguen saliendo.':'Prueba del retén, sin bichos.',false,3600);},30);}
  {const bR=$('#btnReten'),bS=$('#btnRetenSB');if(bR)bR.addEventListener('click',()=>ir({bichos:true}));if(bS)bS.addEventListener('click',()=>ir({bichos:false}));
    /* el botón normal vuelve a la partida de siempre (este va antes que startGame: captura en el documento) */
    document.addEventListener('click',e=>{if(e.target&&e.target.id==='btnStart')modo=null;},true);}

  /* ================= verificación de los datos contra la grilla de los bichos (enB) ================= */
  function verificar(){const D=datos,pts=[];D.puestos.forEach(p=>{if(p.rol!=='tirador')pts.push(['puesto '+p.rol,p]);});D.ronda.forEach((p,i)=>pts.push(['ronda '+i,p]));
    pts.push(['reunion',D.reunion]);D.refuerzo.camino.forEach((p,i)=>pts.push(['camino '+i,p]));
    const I0=Math.floor(-600-EX0),I1=Math.floor(-300-EX0),J0=Math.floor(560-EZ0),J1=Math.floor(660-EZ0),Wd=I1-I0+1,seen=new Uint8Array(Wd*(J1-J0+1));
    const libre=k=>k>=0&&enB[k]===0,k0=eCell(pts[0][1].x,pts[0][1].z),q=[k0];if(libre(k0))seen[((k0/EW|0)-J0)*Wd+(k0%EW-I0)]=1;
    while(q.length){const k=q.pop(),i=k%EW,j=k/EW|0;for(const [di,dj] of EN8){const ii=i+di,jj=j+dj;if(ii<I0||ii>I1||jj<J0||jj>J1)continue;const n=jj*EW+ii;
      if(!libre(n)||(di&&dj&&(!libre(j*EW+ii)||!libre(jj*EW+i))))continue;const s=(jj-J0)*Wd+(ii-I0);if(seen[s])continue;seen[s]=1;q.push(n);}}
    const out=pts.map(([n,p])=>{const k=eCell(p.x,p.z);return{n,x:p.x,z:p.z,libre:libre(k),conectado:libre(k)&&!!seen[((k/EW|0)-J0)*Wd+(k%EW-I0)]};});
    const nd=D.nido,enFur=OBS.some(b=>b.k==='furgon'&&nd.x>b.x0&&nd.x<b.x1&&nd.z>b.z0&&nd.z<b.z1&&Math.abs(b.y1-nd.y)<.05);
    return{ok:out.every(o=>o.libre&&o.conectado)&&enFur,puntos:out,nidoSobreFurgon:enFur};}

  return{armar,luz,reset,ir,alEmpezar,fx,verificar,get datos(){return datos;},get grupo(){return G;},get autos(){return AUTOS.map(e=>e.c);},get obs(){return OBS;},avisos,
    get lamparas(){return LAMP;},hornear,get piezas(){return{GLOW,HUMO,BEAM,POOL,LENS,HA,HD};}};
})();
