const v=(rol,az,el,txt,o={})=>Object.assign({rol,pose:'Apunta',t:1.6,az,el,dist:3.2,obj:[0,1.0,0],txt},o);
module.exports={cols:4,vistas:[
  v('jefe',.7,.08,'jefe 3/4'),v('jefe',1.57,.05,'jefe perfil'),v('jefe',3.3,.1,'jefe espalda'),v('asalto',.6,.08,'asalto 3/4'),
  v('granadero',.6,.08,'granadero 3/4'),v('tirador',.6,.08,'tirador 3/4'),v('jefe',.35,.05,'cabeza',{dist:.75,obj:[0,1.66,0]}),v('jefe',0,.05,'jefe luz plena',{plena:true})]};
