/* Pruebas con soldados de mentira sobre la copia parcheada y determinista (t/mod_det.html).
   Uso: node t_sold.js [archivo.html]   → imprime cada resultado en JSON y un resumen OK/FALLA. */
const H=require('../../harness.js');const fs=require('fs');const path=require('path');
const file=process.argv[2]||path.join(__dirname,'mod_det.html');
const t0=Date.now();const log=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(1)+'s',...a);
const res=[];const ok=(nombre,cond,det)=>{res.push([nombre,!!cond]);console.log((cond?'  OK    ':'  FALLA ')+nombre+(det!==undefined?'  · '+(typeof det==='string'?det:JSON.stringify(det)):''));};

/* la cuenta de «rayo contra bichos» copiada textual de fire() en base.html: es la referencia para rayoBichos */
const base=fs.readFileSync(path.join(__dirname,'..','..','v116','base.html'),'utf8');   // base 1.16.0
const a0=base.indexOf('let best=Infinity,hitE=null,hitP=null;'),a1=base.indexOf('let wall=Infinity,glB=null',a0);
if(a0<0||a1<0)throw new Error('no encuentro la cuenta de fire()');
const CUENTA=base.slice(a0,a1);

const AYUDA=String.raw`(()=>{
  let L=[];
  const sold=(x,z,hp=1000,y=floorAt(x,z))=>({x,z,y,r:.4,vivo:true,hp,g:[],herir(d,e){this.hp-=d;this.g.push({t:+T.toFixed(2),d:+(+d).toFixed(2),de:e?e.type:null,dist:e?+Math.hypot(e.obj.position.x-this.x,e.obj.position.z-this.z).toFixed(2):null});if(this.hp<=0)this.vivo=false;}});
  const poner=(l,filtrar)=>{L=l;UEB.objetivos=filtrar?()=>L.filter(s=>s.vivo):()=>L;};
  const limpiar=()=>{enemies.slice().forEach(e=>{scene.remove(e.obj);if(e.rig)scene.remove(e.rig.group);});enemies.length=0;projs.forEach(p=>scene.remove(p.m));projs.length=0;pickups.forEach(p=>scene.remove(p.g));pickups.length=0;bossAlive=null;};
  const bicho=(tipo,x,z,listo=true)=>{const e=spawnEnemy(tipo,[x,z]);if(listo){e.state='chase';e.rise=1;e.obj.position.y=0;}return e;};
  const jug=(x,z,yaw=Math.PI/2)=>{P.pos.set(x,0,z);P.vel.set(0,0,0);P.yaw=yaw;P.pitch=0;P.hp=100;};
  const paso=(seg,fn)=>{const n=Math.round(seg*60),F=1000/60;let t=window.__simT;for(let i=0;i<n;i++){t+=F;__timers.adv(F);if(fn)fn(i);frame(t);}window.__simT=t;};
  const idx=g=>g?L.indexOf(g):-1;
  const d2=(e,s)=>Math.hypot(s.x-e.obj.position.x,s.z-e.obj.position.z);
  window.__S={sold,poner,limpiar,bicho,jug,paso,idx,d2,get L(){return L;}};

  /* A · un bicho de un tipo cerca de 4 soldados, con el jugador lejos: a quién elige, si llega y cuánto daño hace */
  window.__tA=(tipo,bx,bz,seg,sol)=>{const S=__S;S.limpiar();S.jug(-340,608);
    const Ls=(sol||[[-440,604],[-444,606],[-437.5,612.5],[-446.5,610.5]]).map(p=>S.sold(p[0],p[1]));S.poner(Ls);
    const e=S.bicho(tipo,bx,bz);const r={tipo,tg0:null,tTg:null,minD:1e9,nav2:0,saltos:0,cambios:0,trabado:0,golpesIni:0};let prev=null,sal=false;const T0=T;
    S.paso(seg,i=>{P.hp=100;const g=e.tg||null;if(g!==prev){r.cambios++;if(g&&r.tTg===null){r.tTg=+(T-T0).toFixed(2);r.tg0=S.idx(g);}prev=g;}
      if(g){r.minD=Math.min(r.minD,S.d2(e,g));if(e.nav===2)r.nav2++;}
      if(e.leapT>0&&!sal){sal=true;r.saltos++;}else if(!(e.leapT>0))sal=false;if(e.stk>0)r.trabado++;if(e.atkS&&e.atkS.t===0)r.golpesIni++;});
    r.minD=+r.minD.toFixed(2);r.golpes=Ls.map(s=>s.g);r.hp=Ls.map(s=>+s.hp.toFixed(1));r.tgFin=S.idx(e.tg);r.pos=[+e.obj.position.x.toFixed(1),+e.obj.position.z.toFixed(1)];r.vivo=enemies.includes(e);r.hpJ=P.hp;return r;};

  /* A2 · el salto del bagayo: arranca a 8 m de su blanco con el salto listo a los 0,5 s (en A llega antes de que se le cargue
     el salto y, pegado al blanco, ya no salta: lo mismo pasa con un jugador quieto, ver el control).
     conSold=true: un soldado en (-440,604) y el jugador lejos. conSold=false (control): sin soldados y el jugador clavado ahí. */
  window.__tA2=(conSold,lc)=>{const S=__S;S.limpiar();const X=-440,Z=604;S.jug(conSold?-380:X,conSold?608:Z);
    const A=S.sold(X,Z);S.poner(conSold?[A]:[]);const e=S.bicho('bagayo',X+8,Z);e.leapCd=lc;
    const r={saltos:0,dSalto:[],golpes:[],hpJ:[]};let sal=false;
    S.paso(lc+2.5,()=>{if(e.leapT>0&&!sal){sal=true;r.saltos++;r.dSalto.push(+Math.hypot((conSold?A.x:P.pos.x)-e.obj.position.x,(conSold?A.z:P.pos.z)-e.obj.position.z).toFixed(2));}else if(!(e.leapT>0))sal=false;
      if(conSold)P.hp=100;else{if(P.hp<100)r.hpJ.push(100-P.hp);P.hp=100;P.pos.x=X;P.pos.z=Z;P.vel.set(0,0,0);}});
    r.golpes=A.g.map(x=>x.d);return r;};

  /* C · cuando muere su soldado pasa a otro blanco */
  /* modo 0: la lista conserva al muerto con vivo=false · 1: la lista se filtra y además vivo=false · 2: el muerto solo desaparece de la lista (vivo queda en true) */
  window.__tC=(modo)=>{const S=__S;S.limpiar();S.jug(-380,608);const A=S.sold(-440,604,20),B=S.sold(-444,606,1000);const Ls=[A,B];S.poner(Ls,modo===1);
    if(modo===2){A.herir=function(d,e){this.hp-=d;this.g.push({t:+T.toFixed(2),d,de:e?e.type:null});};UEB.objetivos=()=>Ls.filter(s=>s.hp>0);}
    const e=S.bicho('baboso',-434,603);const r={sec:[],tMuerte:null,tCambio:null};let prev='x';const T0=T;
    S.paso(14,i=>{P.hp=100;const k=e.tg===A?'A':e.tg===B?'B':'J';if(k!==prev){r.sec.push([+(T-T0).toFixed(2),k]);prev=k;}
      if(A.hp<=0&&r.tMuerte===null)r.tMuerte=+(T-T0).toFixed(2);if(A.hp<=0&&e.tg===B&&r.tCambio===null)r.tCambio=+(T-T0).toFixed(2);});
    r.gA=A.g.length;r.gB=B.g.length;r.hpB=B.hp;return r;};

  /* D · con el jugador más cerca, va al jugador; con el soldado más cerca, al soldado */
  window.__tD=(jx,bx)=>{const S=__S;S.limpiar();S.jug(jx,603);const Ls=[S.sold(-440,604),S.sold(-444,606)];S.poner(Ls);
    const e=S.bicho('rata',bx,603);let hpMin=100;const r={tg:[]};let prev='x';const T0=T;
    S.paso(5,i=>{if(P.hp<60){hpMin=Math.min(hpMin,P.hp);P.hp=100;}const k=S.idx(e.tg);if(k!==prev){r.tg.push([+(T-T0).toFixed(2),k]);prev=k;}});
    r.dJ=+Math.hypot(P.pos.x-e.obj.position.x,P.pos.z-e.obj.position.z).toFixed(2);r.golpesSold=Ls.map(s=>s.g.length);r.jugadorHerido=hpMin<100||P.hp<100;r.hpJ=P.hp;return r;};

  /* E · histéresis y sesgo, con el bicho clavado en su lugar (e.slow=0) para que las distancias no cambien */
  window.__tE=()=>{const S=__S;S.limpiar();S.jug(-300,608);const BX=-425,BZ=607;const A=S.sold(BX-15,BZ),Ls=[A];S.poner(Ls);   // z=607 de x=-441 a -411: sin autos (1.16)
    const e=S.bicho('baboso',BX,BZ);e.slow=0;const r={};const paso=s=>S.paso(s,()=>{P.hp=100;});const bx=e.obj.position.x,bz=e.obj.position.z;
    A.x=bx-15;A.z=bz;A.y=floorAt(A.x,A.z);paso(1.2);r.inicial=S.idx(e.tg);                          // A a 15 m (17,25 con el sesgo): único candidato
    const B=S.sold(bx,bz+13);Ls.push(B);paso(1.2);r.conB13=S.idx(e.tg);          // B a 13 m: 14,95 no baja de 17,25×0,75=12,9 → sigue con A
    const C=S.sold(bx,bz+8);Ls.push(C);paso(1.2);r.conC8=S.idx(e.tg);            // C a 8 m: 9,2 < 12,9 → cambia a C
    S.jug(bx+5,bz);paso(1.2);r.jug5=S.idx(e.tg);                                 // jugador a 5 m: 5 < 9,2×0,75=6,9 → va al jugador
    S.jug(bx+8.5,bz);e.tg=C;e.tgT=0;paso(1.2);r.jug8_5=S.idx(e.tg);              // con C de blanco y el jugador a 8,5 m (no baja de 6,9) → sigue con C
    r.quieto=+Math.hypot(e.obj.position.x-bx,e.obj.position.z-bz).toFixed(3);
    /* sesgo: bicho nuevo, jugador a 9 m y soldado a 8 m (8×1,15=9,2 > 9) → elige al jugador */
    S.limpiar();const D=S.sold(BX-8,BZ);S.poner([D]);const f=S.bicho('baboso',BX,BZ);f.slow=0;const fx=f.obj.position.x,fz=f.obj.position.z;S.jug(fx+9,fz);
    D.x=fx-8;D.z=fz;D.y=floorAt(D.x,D.z);paso(1.2);r.sesgoJ9S8=S.idx(f.tg);
    D.x=fx-7;paso(1.2);r.sesgoJ9S7=S.idx(f.tg);                                  // soldado a 7 m: 8,05 no baja de 9×0,75=6,75 → sigue con el jugador (histéresis)
    D.x=fx-5;paso(1.2);r.sesgoJ9S5=S.idx(f.tg);                                  // soldado a 5 m: 5,75 < 6,75 → cambia al soldado
    return r;};

  /* F · soldados a los que no se puede llegar: adentro de un edificio y arriba de un techo */
  window.__tF=()=>{const S=__S;S.limpiar();S.jug(-300,608);const r={};
    const X=S.sold(-420,587);S.poner([X]);const e=S.bicho('rata',-420,600);e.slow=0;S.paso(1.5,()=>{P.hp=100;});
    r.celdaEdificio=enB[eCell(X.x,X.z)];r.edificio=S.idx(e.tg);
    S.limpiar();const Y=S.sold(-440,604,1000,2.6);S.poner([Y]);const ra=S.bicho('rata',-434,604),mo=S.bicho('mole',-434,600);ra.slow=0;mo.slow=0;S.paso(1.5,()=>{P.hp=100;});
    r.techoRata=S.idx(ra.tg);r.techoMole=S.idx(mo.tg);return r;};

  /* G · lo suelta si se aleja más de 30 m */
  window.__tG=()=>{const S=__S;S.limpiar();S.jug(-300,608);const A=S.sold(-450,603);S.poner([A]);const e=S.bicho('baboso',-430,603);e.slow=0;const r={};
    S.paso(1.2,()=>{P.hp=100;});r.a20=S.idx(e.tg);A.x=-458;S.paso(1.2,()=>{P.hp=100;});r.a28=S.idx(e.tg);A.x=-461;S.paso(1.2,()=>{P.hp=100;});r.a31=S.idx(e.tg);return r;};

  /* H · escupidor contra un soldado quieto: cuántos escupitajos salen y cuántos le pegan */
  window.__tH=(d)=>{const S=__S;S.limpiar();S.jug(-300,608);const A=S.sold(-440,604);S.poner([A]);const e=S.bicho('escupidor',-440+d,604);
    const r={d,escupidas:0,distMin:1e9,distMax:0,sec:[],stk:0};const _sp=spit;spit=function(a,b){if(a===e)r.escupidas++;return _sp(a,b);};let prev='x';const T0=T;
    S.paso(20,()=>{P.hp=100;const q=S.d2(e,A);r.distMin=Math.min(r.distMin,q);r.distMax=Math.max(r.distMax,q);const k=S.idx(e.tg);if(k!==prev){r.sec.push([+(T-T0).toFixed(2),k]);prev=k;}if(e.stk>0)r.stk++;});spit=_sp;
    r.distMin=+r.distMin.toFixed(1);r.distMax=+r.distMax.toFixed(1);r.golpes=A.g;r.aciertos=A.g.filter(h=>h.d===10&&h.dist>4).length;r.tg=S.idx(e.tg);return r;};

  /* L · el Engendro: no elige soldados, pero el pisotón les pega a los que tiene cerca */
  window.__tL=()=>{const S=__S;S.limpiar();S.jug(-414.6,606);
    const Ls=[S.sold(-420,612.1),S.sold(-420,599.9),S.sold(-425.9,607.5),S.sold(-420,620)];S.poner(Ls);
    const e=S.bicho('boss',-420,606);e.thrCd=99;e.summon=99;e.spitCd=99;const r={tgNoNulo:0,pisotones:0};let hpJ=0;
    S.paso(8,()=>{if(P.hp<100){hpJ+=100-P.hp;P.hp=100;}P.pos.set(-414.6,0,606);if(e.tg)r.tgNoNulo++;e.spitCd=99;e.summon=99;if(e.atkS&&e.atkS.hit&&!e.atkS._c){e.atkS._c=1;r.pisotones++;}});
    r.danoJugador=hpJ;r.golpes=Ls.map(s=>s.g.map(h=>h.d+'/'+h.de));r.dist=Ls.map(s=>+S.d2(e,s).toFixed(2));S.limpiar();return r;};

  /* M · el Engendro arroja un auto: al caer explota y avisa UEB.explosion */
  window.__tM=()=>{const S=__S;S.limpiar();const JX=-320,JZ=606;S.jug(JX,JZ);S.poner([S.sold(JX-2,JZ-3)]);const ex=[];const _ex=UEB.explosion;UEB.explosion=(p,r,d,de)=>{ex.push([+p.x.toFixed(1),+p.y.toFixed(1),+p.z.toFixed(1),r,d,de,+T.toFixed(2)]);};
    const e=S.bicho('boss',-346,607);e.thrCd=.2;e.summon=99;const r={levanto:false,volo:false};   // a 7,6 m del clásico 783 (-346,1;599,4)
    S.paso(9,()=>{P.hp=100;P.pos.x=JX;P.pos.z=JZ;P.vel.set(0,0,0);e.summon=99;e.spitCd=99;if(e.thr)r.levanto=true;for(const c of VDYN)if(c.ph&&c.ph.fly)r.volo=true;});
    UEB.explosion=_ex;r.explosiones=ex;S.limpiar();return r;};

  /* N · un auto empujado (lo que hace el barrido del Engendro) le pega a un soldado */
  window.__tN=()=>{const S=__S;S.limpiar();S.jug(-300,608);let c=null,cd=1e9;for(const v of VCARS){if(v.st>=3)continue;const d=Math.hypot(v.x+366.05,v.z-613.19);if(d<cd){cd=d;c=v;}}
    const A=S.sold(c.x,c.z-c.W/2-1.2);S.poner([A]);const r={auto:[+c.x.toFixed(1),+c.z.toFixed(1),c.S.id],z0:c.z};
    carShove(c,0,-1,9,c.x,c.z+1,0);S.paso(2.5,()=>{P.hp=100;});r.z1=+c.z.toFixed(2);r.golpes=A.g;return r;};

  /* O · muerte por soldado: sin puntos, combo, bajas ni frase */
  window.__tO=()=>{const S=__S;S.limpiar();S.jug(-380,608);S.poner([]);const r={};const dir=new V3(1,0,0);const feedN=()=>$('#feed').textContent;
    let e=S.bicho('baboso',-390,608);score=1000;kills=5;combo=2;comboT=2;let f0=feedN(),p0=pickups.length;
    damageEnemy(e,999,dir,'soldado');r.soldado={score,kills,combo,comboT,feed:feedN()===f0?0:1,vivo:enemies.includes(e),izq:$('#left').textContent};
    e=S.bicho('baboso',-390,608);f0=feedN();damageEnemy(e,999,dir);r.jugador={score,kills,combo,comboT,feed:feedN()!==f0&&/baboso \+300/.test(feedN())?1:0,vivo:enemies.includes(e)};
    e=S.bicho('baboso',-390,608);damageEnemy(e,10,dir,'soldado');r.herido={hp:e.hp,max:e.maxHp,vivo:enemies.includes(e),score};
    /* cajas: 300 muertes por soldado, ¿alguna deja caja? (13 % empanada, 40 % munición) */
    let n0=pickups.length;for(let k=0;k<300;k++){const q=S.bicho('rata',-390+k%5,612);damageEnemy(q,999,dir,'soldado');}r.cajasEn300=pickups.length-n0;r.scoreTras300=score;r.killsTras300=kills;
    /* el Engendro muerto por soldados: la partida sigue bien */
    const b=S.bicho('boss',-360,608);bossAlive=b;$('#bossbar').hidden=false;const sc=score;damageEnemy(b,1e6,dir,'soldado');r.boss={bossAlive:bossAlive===null,barra:$('#bossbar').hidden,score:score-sc,titulo:$('#announce').textContent.slice(0,40)};
    S.limpiar();return r;};

  /* P · rayoBichos contra la cuenta textual de fire() */
  window.__ref=function(o,d,maxT){ray.o.copy(o);/*CUENTA*/
    return hitE&&best<maxT?{e:hitE,t:best,p:hitP,ojo:!!hitP&&hitP.kind==='eye'}:null;};
  window.__tP=(N)=>{const S=__S;S.limpiar();S.jug(-380,608);S.poner([]);
    const tipos=['rata','bagayo','baboso','escupidor','mole','rata','baboso','escupidor','bagayo','mole','boss'];const es=tipos.map((t,i)=>S.bicho(t,-400-(i%4)*7-(t==='boss'?30:0),600+Math.floor(i/4)*6));
    S.paso(1.5,()=>{P.hp=100;P.pos.set(-380,0,608);});updatePartSpheres();BCH.esf=T;
    const r={N,cuerpo:0,parte:0,ojo:0,nada:0,dif:0,ej:[],tNeg:0};const o=new V3(),d=new V3(),c=new V3();
    for(let k=0;k<N;k++){const e=enemies[k%enemies.length];enemyCenter(e,c);const a=Math.random()*6.283,rr=4+Math.random()*30;o.set(c.x+Math.cos(a)*rr,.3+Math.random()*2.2,c.z+Math.sin(a)*rr);
      const pp=e.parts[(Math.random()*e.parts.length)|0];if(k%3===0&&pp&&pp.alive&&pp.rad)c.copy(pp.c);const j=k%5===0?3:e.c.r*1.3;
      d.set(c.x+(Math.random()-.5)*j-o.x,c.y+(Math.random()-.5)*j-o.y,c.z+(Math.random()-.5)*j-o.z).normalize();const maxT=k%7===0?rr*.8:140;
      const A=__ref(o,d,maxT),B=rayoBichos(o,d,maxT);
      const igual=(!A&&!B)||(A&&B&&A.e===B.e&&A.p===B.p&&A.t===B.t&&A.ojo===B.ojo);if(!igual){r.dif++;if(r.ej.length<3)r.ej.push([A&&[A.e.type,A.t,A.p&&A.p.kind],B&&[B.e.type,B.t,B.p&&B.p.kind]]);}
      if(!A)r.nada++;else if(A.ojo)r.ojo++;else if(A.p)r.parte++;else r.cuerpo++;if(A&&A.t<0)r.tNeg++;}
    /* después de un cuadro (los bichos se movieron) rayoBichos actualiza las esferas solo */
    S.paso(.5,()=>{P.hp=100;});let dif2=0;const e=enemies[2];enemyCenter(e,c);o.set(c.x+9,1.2,c.z+2);d.subVectors(c,o).normalize();const B=rayoBichos(o,d,100);updatePartSpheres();const A=__ref(o,d,100);
    r.trasMoverse=!!(A&&B&&A.e===B.e&&A.p===B.p&&A.t===B.t);r.mismoObjeto=rayoBichos(o,d,100)===rayoBichos(o,d,100);S.limpiar();return r;};

  /* Q · carBoom directo: UEB.explosion con el centro del auto, radio 8, daño 70, 'auto' */
  window.__tQ=()=>{const S=__S;S.limpiar();S.jug(-380,608);S.poner([]);let c=null,cd=1e9;for(const v of VCARS){if(v.st>=3)continue;const d=Math.hypot(v.x+432.6,v.z-608.7);if(d<cd){cd=d;c=v;}}
    const ex=[];const _ex=UEB.explosion;UEB.explosion=(p,r,d,de)=>{ex.push([p.isVector3===true,+p.x.toFixed(2),+p.y.toFixed(2),+p.z.toFixed(2),r,d,de]);};
    const r={auto:[+c.x.toFixed(2),+c.z.toFixed(2)],y:+(c.by+.8).toFixed(2)};carDamage(c,25);r.st=c.st;S.paso(7.5,()=>{P.hp=100;});r.stFin=c.st;UEB.explosion=_ex;r.todas=ex.length;r.todasBien=ex.every(x=>x[0]===true&&x[4]===8&&x[5]===70&&x[6]==='auto');r.explosiones=ex.filter(x=>x[1]===r.auto[0]&&x[3]===r.auto[1]);return r;};

  /* R · bichosVivos */
  window.__tR=()=>{const S=__S;S.limpiar();S.jug(-380,608);const A=S.sold(-440,604);S.poner([A]);const a=S.bicho('rata',-436,604),b=S.bicho('mole',-390,608),c=S.bicho('baboso',-395,612,false);
    S.paso(.6,()=>{P.hp=100;});const L1=bichosVivos();const r={n:L1.length,items:L1.map(q=>({tipo:q.tipo,x:+q.x.toFixed(1),y:+q.y.toFixed(2),z:+q.z.toFixed(1),r:q.r,hp:q.hp,ref:q.ref===a?'a':q.ref===b?'b':q.ref===c?'c':'?',tg:q.tg===A?'A':q.tg,est:q.est}))};
    const o0=L1[0];damageEnemy(b,1e5,new V3(1,0,0),'soldado');const L2=bichosVivos();r.mismoArreglo=L1===L2;r.mismoItem=L2[0]===o0;r.n2=L2.length;r.centro=+(a.obj.position.y+a.m.bodyY).toFixed(2);S.limpiar();r.n3=bichosVivos().length;return r;};
  return 1;})()`.replace('/*CUENTA*/',()=>CUENTA);

(async()=>{
  const h=await H.open(file);log('abierto',file);
  try{
    await h.ev("SHJ.init();__rng.seed(4242);window.__simT=1e6;T=500;1");
    log('start',JSON.stringify(await h.start()));
    log('reten',JSON.stringify(await h.alReten(-380,608)));
    await h.ev(AYUDA);
    await h.ev("__S.paso(1);1");
    const J=x=>JSON.stringify(x);
    const run=async(code)=>{const r=await h.ev(code);return r;};

    console.log('\n== A · elección, llegada y daño por tipo (bicho en (-430,601), soldados en (-440,604) (-444,606) (-437.5,612.5) (-446.5,610.5), jugador a 90 m)');
    const dano={rata:[7],bagayo:[6,12],baboso:[14],escupidor:[10],mole:[28]};
    for(const tipo of ['rata','bagayo','baboso','escupidor','mole']){
      const r=await run(`__tA('${tipo}',-430,601,${tipo==='mole'||tipo==='baboso'||tipo==='escupidor'?16:10})`);
      const g=r.golpes.flat();console.log(J({...r,golpes:undefined,nGolpes:g.length,danos:[...new Set(g.map(x=>x.d))],de:[...new Set(g.map(x=>x.de))],primero:g[0]}));
      ok(`A ${tipo}: elige a un soldado`,r.tg0!==null&&r.tg0>=0,`soldado ${r.tg0} a los ${r.tTg} s`);
      ok(`A ${tipo}: elige al más cercano (soldado 0)`,r.tg0===0);
      ok(`A ${tipo}: lo daña`,g.length>0,`${g.length} golpes`);
      ok(`A ${tipo}: el daño es el de TYPES`,g.length>0&&g.every(x=>dano[tipo].includes(x.d)&&x.de===tipo),[...new Set(g.map(x=>x.d))]);
      ok(`A ${tipo}: no daña al jugador`,r.hpJ===100);
      if(tipo==='escupidor')ok('A escupidor: pega de lejos (escupitajo a más de 5 m)',g.some(x=>x.dist>5),g.filter(x=>x.dist>5).length+' de lejos');
      if(tipo!=='escupidor')ok(`A ${tipo}: llega hasta el soldado`,r.minD<({rata:.55,bagayo:.32,baboso:.95,mole:1.7})[tipo]+1.5,`mínima ${r.minD} m`);
    }

    console.log('\n== A2 · el salto del bagayo (8 m, salto listo a los 0,5 s) y el control con el jugador quieto');
    {const r=await run("__tA2(true,.5)");console.log(J(r));const c=await run("__tA2(false,.5)");console.log('control',J(c));
      ok('A2 bagayo: salta sobre el soldado',r.saltos>0,`${r.saltos} saltos a ${r.dSalto} m`);ok('A2 bagayo: la caída pega doble (12)',r.golpes.includes(12),r.golpes);
      ok('A2 control: contra el jugador salta y pega lo mismo',c.saltos===r.saltos&&c.hpJ.includes(12),`saltos ${c.saltos}, daños ${c.hpJ}`);}
    {const r=await run("__tA2(true,3)");const c=await run("__tA2(false,3)");console.log('salto a los 3 s:',J({sold:[r.saltos,r.golpes],jug:[c.saltos,c.hpJ]}));
      ok('A2: con el salto lento, ni contra el soldado ni contra el jugador quieto salta (por eso en A no saltaba)',r.saltos===0&&c.saltos===0);}

    console.log('\n== B · camino corto: rata al este del auto (taxi 784 en -400.1,604.4), soldado al oeste, sin línea recta');
    {const r=await run("__tA('rata',-394.5,604.4,8,[[-406,604.4]])");const g=r.golpes.flat();console.log(J({...r,golpes:undefined,nGolpes:g.length}));
      ok('B: lo elige aunque no hay línea recta',r.tg0===0);ok('B: usa el camino corto (nav 2)',r.nav2>0,`${r.nav2} cuadros`);ok('B: llega y pega',g.length>0&&g.every(x=>x.d===7),`${g.length} golpes`);ok('B: no se traba',r.trabado===0);}
    {const r=await run("__tA('mole',-394.5,604.4,14,[[-406,604.4]])");const g=r.golpes.flat();console.log(J({...r,golpes:undefined,nGolpes:g.length}));
      ok('B mole: llega y pega',g.length>0&&g.every(x=>x.d===28),`${g.length} golpes, tg0=${r.tg0}, nav2=${r.nav2}`);}
    {const r=await run("__tA('baboso',-410.5,615,12,[[-423,615]])");const g=r.golpes.flat();console.log(J({...r,golpes:undefined,nGolpes:g.length}));
      ok('B baboso con un auto en el medio (sedán 786): llega y pega',g.length>0&&g.every(x=>x.d===14),`${g.length} golpes, nav2=${r.nav2}, trabado=${r.trabado}`);}

    console.log('\n== C · muere su soldado y pasa a otro');
    for(const m of [0,1,2]){const r=await run(`__tC(${m})`);console.log(J(r));const nom=['lista con el muerto en vivo=false','lista filtrada y vivo=false','el muerto solo desaparece de la lista'][m];
      ok(`C (${nom}): mata a A y pasa a B`,r.tMuerte!==null&&r.tCambio!==null&&r.gB>0,`A muere a los ${r.tMuerte} s, pasa a B a los ${r.tCambio} s, ${r.gB} golpes a B, ${r.gA} a A`);
      ok(`C (${nom}): cambia enseguida`,r.tCambio!==null&&r.tCambio-r.tMuerte<=(m===2?1.9:.6),`${(r.tCambio-r.tMuerte).toFixed(2)} s`);}

    console.log('\n== D · jugador más cerca / soldado más cerca');
    {const r=await run("__tD(-425,-431)");console.log(J(r));ok('D: jugador a 6 m y soldado a 9 m → va al jugador',r.tg.every(x=>x[1]===-1)&&r.jugadorHerido&&r.golpesSold.every(n=>n===0));}
    {const r=await run("__tD(-425,-436)");console.log(J(r));ok('D: jugador a 11 m y soldado a 4 m → va al soldado',r.tg.some(x=>x[1]===0)&&r.golpesSold[0]>0&&!r.jugadorHerido);}

    console.log('\n== E · histéresis y sesgo');
    {const r=await run("__tE()");console.log(J(r));
      ok('E: solo A a 15 m → A',r.inicial===0);ok('E: aparece B a 13 m → sigue con A',r.conB13===0);ok('E: aparece C a 8 m → cambia a C',r.conC8===2);
      ok('E: jugador a 5 m → va al jugador',r.jug5===-1);ok('E: con C de blanco, jugador a 8,5 m → sigue con C',r.jug8_5===2);
      ok('E sesgo: jugador a 9 m y soldado a 8 m → jugador',r.sesgoJ9S8===-1);ok('E: soldado a 7 m → sigue con el jugador',r.sesgoJ9S7===-1);ok('E: soldado a 5 m → cambia al soldado',r.sesgoJ9S5===0);}

    console.log('\n== F · inalcanzables · G · se aleja');
    {const r=await run("__tF()");console.log(J(r));ok('F: soldado adentro de un edificio → no lo elige',r.edificio===-1&&r.celdaEdificio===2);ok('F: soldado en un techo a 2,6 m → la rata no lo elige',r.techoRata===-1);ok('F: … y el mole sí (le llega con el golpe)',r.techoMole===0);}
    {const r=await run("__tG()");console.log(J(r));ok('G: a 20 m lo elige, a 28 m lo conserva, a 31 m lo suelta',r.a20===0&&r.a28===0&&r.a31===-1);}

    console.log('\n== H · escupidor contra un soldado quieto');
    for(const d of [8,16,23]){const r=await run(`__tH(${d})`);console.log(J({...r,golpes:undefined}));
      ok(`H (arranca a ${d} m): le acierta y no lo suelta`,r.aciertos>=4&&r.aciertos>=r.escupidas-1&&r.tg===0,`${r.aciertos} aciertos de ${r.escupidas} escupitajos; se mantiene entre ${r.distMin} y ${r.distMax} m`);}

    console.log('\n== L · Engendro: pisotón en área · M · auto arrojado · N · auto barrido');
    {const r=await run("__tL()");console.log(J(r));
      ok('L: el Engendro nunca elige a un soldado',r.tgNoNulo===0);ok('L: pisa al jugador',r.pisotones>0&&r.danoJugador>0,`${r.pisotones} pisotones, ${r.danoJugador} de daño al jugador`);
      ok('L: los 3 soldados a menos de 6,45 m reciben 38 por pisotón',[0,1,2].every(i=>r.golpes[i].length===r.pisotones&&r.golpes[i].every(x=>x==='38/boss')),r.golpes.map(g=>g.length));
      ok('L: el soldado a 14 m no recibe nada',r.golpes[3].length===0);}
    {const r=await run("__tM()");console.log(J(r));ok('M: levanta y arroja un auto',r.levanto&&r.volo);ok("M: al caer avisa UEB.explosion(pos,8,70,'auto')",r.explosiones.length>=1&&r.explosiones.every(x=>x[3]===8&&x[4]===70&&x[5]==='auto'),r.explosiones);}
    {const r=await run("__tN()");console.log(J(r));ok('N: el auto empujado le pega al soldado (herir con bicho null)',r.golpes.length>=1&&r.golpes.every(x=>x.de===null&&x.d>=12&&x.d<=33),r.golpes);}

    console.log('\n== O · muerte por soldado');
    {const r=await run("__tO()");console.log(J(r));
      ok("O: 'soldado' no suma puntos, bajas ni combo, ni dice frase",r.soldado.score===1000&&r.soldado.kills===5&&r.soldado.combo===2&&r.soldado.comboT===2&&r.soldado.feed===0&&!r.soldado.vivo,r.soldado);
      ok('O: sin cuarto parámetro sigue sumando como siempre',r.jugador.score===1000+100*3&&r.jugador.kills===6&&r.jugador.combo===3&&r.jugador.feed===1,r.jugador);
      ok('O: herido por soldado sin morir: baja la vida y no suma',r.herido.hp===r.herido.max-10&&r.herido.vivo);
      ok('O: los muertos por soldado pueden dejar caja',r.cajasEn300>0&&r.scoreTras300===r.jugador.score&&r.killsTras300===6,`${r.cajasEn300} cajas en 300 muertes`);
      ok('O: Engendro muerto por soldados: sin puntos, se cierra la barra',r.boss.bossAlive&&r.boss.barra&&r.boss.score===0,r.boss);}

    console.log('\n== P · rayoBichos contra la cuenta de fire()');
    {const r=await run("__tP(6000)");console.log(J(r));ok('P: 6000 rayos, mismo resultado que fire() (bicho, parte, distancia exacta)',r.dif===0,`cuerpo ${r.cuerpo}, parte ${r.parte}, ojo ${r.ojo}, nada ${r.nada}`);
      ok('P: hay casos de las cuatro clases',r.cuerpo>50&&r.parte>50&&r.ojo>20&&r.nada>50);ok('P: tras moverse los bichos, actualiza las esferas solo',r.trasMoverse);}

    console.log('\n== Q · explosión de auto · R · bichosVivos');
    {const r=await run("__tQ()");console.log(J(r));ok("Q: todas las explosiones de auto avisan con radio 8, daño 70 y 'auto'",r.todas>=1&&r.todasBien,`${r.todas} explosiones`);
      ok("Q: el auto que explota → una llamada UEB.explosion(Vector3 centro del auto (c.by+0,8), 8, 70, 'auto')",r.stFin===3&&r.explosiones.length===1&&r.explosiones[0][0]===true&&r.explosiones[0][1]===r.auto[0]&&r.explosiones[0][2]===r.y&&r.explosiones[0][3]===r.auto[1]&&r.explosiones[0][4]===8&&r.explosiones[0][5]===70&&r.explosiones[0][6]==='auto',r.explosiones);}
    {const r=await run("__tR()");console.log(J(r));ok('R: bichosVivos devuelve los 3 con centro del cuerpo, radio, tipo, vida, tg y est',r.n===3&&r.items[0].ref==='a'&&r.items[0].tg==='A'&&r.items[0].y===r.centro&&r.items[2].est==='rise');
      ok('R: reutiliza el arreglo y los objetos; sin bichos devuelve vacío',r.mismoArreglo&&r.mismoItem&&r.n2===2&&r.n3===0);}

    log('errores de página',h.errors.length,h.errors.slice(0,6).join(' | '));ok('sin errores de página ni de consola',h.errors.length===0);
    const mal=res.filter(x=>!x[1]);console.log(`\nRESUMEN: ${res.length-mal.length} OK, ${mal.length} FALLA`);mal.forEach(x=>console.log('  FALLA: '+x[0]));
  }finally{await h.close();}
})().catch(e=>{console.error('FAIL',e.stack||e.message);process.exit(1);});
