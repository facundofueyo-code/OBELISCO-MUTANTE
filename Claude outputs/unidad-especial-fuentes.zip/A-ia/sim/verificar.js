/* =====================================================================================================
   sim/verificar.js — las 10 verificaciones de juego limpio de la TAREA, sobre un mundo de sim/mundo.js.
   JS puro (sirve también en el navegador).

     const V = crearVerificador(M, UE);
     cada cuadro, DESPUÉS de M.paso(dt):   V.paso(M.sacarEventos())   (devuelve los mismos eventos)
     V.fallas → ['[3] t=12.40 …', …]     V.cuenta → {1:0, 2:0, …}    V.resumen() → texto corto

   Cada verificación mira el mundo «de verdad» (posición real del jugador, rayos reales del simulador) y lo
   compara con lo que hizo la IA. No confía en las banderas internas de la IA salvo donde se dice.
   ===================================================================================================== */
function crearVerificador(M, UE, op) {
  op = op || {};
  const T = UE.T, J = M.jugador, G = M.grilla, hyp = Math.hypot;
  const fallas = [], cuenta = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0, 10: 0 };
  const chequeos = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0, 10: 0 };
  const NOMBRE = {
    1: 'nunca más de TUNE.fichas tirando a pegar (más el tirador)',
    2: 'granada: aviso por radio ≥0,6 s antes de soltarla y ≥3 s hasta la explosión',
    3: 'tirador: láser continuo sobre el jugador ≥1,2 s antes de cada tiro',
    4: 'el último lugar conocido solo se mueve con una señal real; granadas y supresión van ahí',
    5: 'la primera ráfaga de cada soldado tras el contacto no pega',
    6: 'daño de fusil y escopeta ≤ tope por segundo',
    7: 'nadie tira antes de 0,35 s de haberse enterado',
    8: 'ninguna bala le pega al jugador con algo en el medio',
    9: 'ningún soldado con orden de moverse queda >3 s sin avanzar',
    10: 'sin NaN ni excepciones; nadie dentro de un casillero bloqueado'
  };
  function falla(n, txt) { cuenta[n]++; if (fallas.length < 60) fallas.push('[' + n + '] t=' + M.t.toFixed(2) + ' ' + txt); }

  /* historia del jugador (posición y señales) para juzgar el último lugar conocido */
  const hist = [];                     // {t,x,z,ve,corre,tiro}
  let tTiroJ = -99;
  const S = new Map();                 // estado por soldado
  const est = s => { let o = S.get(s); if (!o) { o = { aware: null, primeraRaf: null, laserDesde: null, mov: [], grito: -99, granadas: [], escAntes: null, ultUC: null }; S.set(s, o); } return o; };
  let ucAntes = null;
  const danoV = [];                    // [t, daño] de fusil y escopeta
  const ojo = s => s.y + (s.tierra > 0 ? T.ojoAgach + (T.ojoTierra - T.ojoAgach) * s.tierra : T.ojoPie + (T.ojoAgach - T.ojoPie) * s.agach);   // la misma mezcla que usa la IA
  /* ¿s tiene línea real al jugador? Ni el ojo ni el cuerpo son puntos, y la grilla entra inflada 0,3 m: se acepta la línea
     si pasa con el ojo corrido hasta 0,25 m (o 0,1 m más alto) y apuntando a cualquier parte de la cápsula (centro o
     costados del pecho y de la cabeza). Es más estricto que el mundo real del juego, no menos. */
  function loVe(s, oy) {
    const d = hyp(J.x - s.x, J.z - s.z) || 1, ux = -(J.z - s.z) / d, uz = (J.x - s.x) / d, yp = J.y + J.alto * 0.62, yc = J.y + J.alto - 0.12;
    for (const eh of [0, 0.1]) for (const eo of [0, 0.25, -0.25]) for (const po of [0, 0.3, -0.3]) for (const y of [yp, yc])
      if (M.lv(s.x + ux * eo, oy + eh, s.z + uz * eo, J.x + ux * po, y, J.z + uz * po)) return true;
    /* como pide la TAREA para la línea de visión rápida, los primeros 0,6 m desde el ojo no cuentan (la cabeza se asoma) */
    const fx = (J.x - s.x) / d * 0.6, fz = (J.z - s.z) / d * 0.6;
    for (const y of [yp, yc]) { const fy = (y - oy) / d * 0.6; if (M.lv(s.x + fx, oy + fy, s.z + fz, J.x, y, J.z)) return true; }
    return false;
  }
  function alguienLoVe() {
    if (!J.vivo) return false;
    for (const s of UE.soldados) if (s.vivo && s.activo && hyp(J.x - s.x, J.z - s.z) < 85 && loVe(s, ojo(s))) return true;
    return false;
  }
  function posJugadorEn(t) { let m = null; for (let i = hist.length - 1; i >= 0; i--) { m = hist[i]; if (hist[i].t <= t + 1e-6) break; } return m; }
  function huboSenal(t0, t1, tipo) {
    for (let i = hist.length - 1; i >= 0; i--) {
      const h = hist[i]; if (h.t < t0) break; if (h.t > t1) continue;
      if (tipo === 'vista' ? h.ve : (h.tiro || h.corre)) return true;
    }
    return false;
  }
  const quiereMover = s => s.vivo && (s.camino || s.esperaCamino) && s.dest && hyp(s.dest.x - s.x, s.dest.z - s.z) > 1.0 && s.salto < 0 && !s.elev &&
    s.aturdido <= 0 && s.retro <= 0 && s.tierra < 0.3 && s.estado !== 'lanzar' && s.estado !== 'radio' && s.estado !== 'culata' && s.estado !== 'tierra' && s.estado !== 'bicho';

  function paso(evs) {
    const t = M.t;
    /* ---- señales del jugador en este cuadro ---- */
    const ve = alguienLoVe();
    let corre = false; if (J.corriendo) for (const s of UE.soldados) if (s.vivo && hyp(J.x - s.x, J.z - s.z) < T.oidoPasos + 1) corre = true;
    for (const e of evs) if (e.tipo === 'bala' && e.de === 'jugador') tTiroJ = t;
    hist.push({ t, x: J.x, z: J.z, ve, corre, tiro: tTiroJ === t });
    while (hist.length && hist[0].t < t - 8) hist.shift();

    /* ---- eventos ---- */
    for (const e of evs) {
      if (e.tipo === 'radio' && e.clave === 'granada' && e.s) est(e.s).grito = e.t;
      if (e.tipo === 'evento' && e.nombre === 'granada_orden' && e.datos.motivo !== 'bichos') {
        chequeos[4]++; const u = UE.red.uc;
        if (!u || hyp(u.x - e.datos.x, u.z - e.datos.z) > 2.0) falla(4, e.datos.s.nombre + ': granada ordenada a (' + e.datos.x.toFixed(1) + ',' + e.datos.z.toFixed(1) + ') que no es el último lugar conocido');   // hasta 1,8 m más allá, para pasar por arriba de su cobertura
      }
      if (e.tipo === 'granada' && e.de && e.de !== 'jugador') {
        chequeos[2]++; const o = est(e.de), dt = e.t - o.grito;
        if (dt < 0.6 - 1e-6 || dt > 6) falla(2, e.de.nombre + ': soltó la granada ' + dt.toFixed(2) + ' s después del grito');
        if (e.mecha < 3 - 1e-6) falla(2, e.de.nombre + ': mecha de ' + e.mecha + ' s');
        o.granadas.push({ grito: o.grito });
      }
      if (e.tipo === 'explosion' && e.de && e.de !== 'jugador') {
        const o = est(e.de), g = o.granadas.shift();
        if (g && e.t - g.grito < 3 - 1e-6) falla(2, e.de.nombre + ': explotó ' + (e.t - g.grito).toFixed(2) + ' s después del grito');
      }
      if (e.tipo === 'herida' && e.a === 'jugador' && (e.fuente === 'fusil' || e.fuente === 'escopeta')) {
        chequeos[6]++; danoV.push([e.t, e.dano]);
        let n = 0; for (const d of danoV) if (d[0] > e.t - 1 + 1e-9) n += d[1];
        if (n > T.topeDano + 1e-6) falla(6, 'fusil+escopeta: ' + n.toFixed(1) + ' en el último segundo');
        while (danoV.length && danoV[0][0] <= e.t - 1) danoV.shift();
      }
      if (e.tipo !== 'bala' || e.de !== 'soldado') continue;
      const s = e.s, o = est(s);
      if (e.modo === 'bicho') continue;
      /* 1. fichas */
      if (e.modo === 'pegar' && e.arma !== 'tirador') { chequeos[1]++; if (!e.ficha) falla(1, s.nombre + ' tiró a pegar sin ficha'); }   // el tirador va aparte (1 tiro en curso)
      /* 7. reacción */
      chequeos[7]++;
      if (o.aware === null || e.t - o.aware < 0.35 - 1e-6) falla(7, s.nombre + ' tiró ' + (o.aware === null ? 'sin haberse enterado' : (e.t - o.aware).toFixed(2) + ' s después de enterarse'));
      /* 5. primera ráfaga */
      if (o.primeraRaf === null) o.primeraRaf = e.raf;
      if (e.raf === o.primeraRaf) { chequeos[5]++; if (e.pega === 'jugador') falla(5, s.nombre + ': la primera ráfaga pegó'); }
      /* 3. tirador */
      if (e.arma === 'tirador' && (e.modo === 'laser' || e.modo === 'aviso') && hyp(s.x - J.x, s.z - J.z) > T.tirador.cerca + 0.5) {
        chequeos[3]++;
        if (o.laserDesde === null || e.t - o.laserDesde < 1.2 - 1e-6) falla(3, s.nombre + ': tiró con ' + (o.laserDesde === null ? 'el láser apagado o fuera del jugador' : (e.t - o.laserDesde).toFixed(2) + ' s de láser'));
      }
      /* 4. supresión sin verlo: al último lugar conocido (o a lo último que vio él) */
      if ((e.modo === 'suprimir' || e.modo === 'aviso') && !s.ve && e.arma !== 'tirador') {
        chequeos[4]++; const u = UE.red.uc, h = s.hist[(s.hI + 9) % 10], d = hyp(e.px - s.x, e.pz - s.z), tol = T.supOffMax + 0.06 * d + 1.2;
        const ok = (u && hyp(e.px - u.x, e.pz - u.z) < tol) || (ucAntes && hyp(e.px - ucAntes.x, e.pz - ucAntes.z) < tol) || (h && h.t > -90 && hyp(e.px - h.x, e.pz - h.z) < tol);
        if (!ok) falla(4, s.nombre + ' suprimió a (' + e.px.toFixed(1) + ',' + e.pz.toFixed(1) + ') lejos del último lugar conocido');
      }
      /* 8. nada en el medio */
      if (e.pega === 'jugador') {
        chequeos[8]++;
        const dx = e.hx - e.ox, dy = e.hy - e.oy, dz = e.hz - e.oz, L = Math.sqrt(dx * dx + dy * dy + dz * dz), n = Math.ceil(L / 0.05);
        for (let q = 1; q < n - 3; q++) {
          const x = e.ox + dx * q / n, y = e.oy + dy * q / n, z = e.oz + dz * q / n, k = M.celda(x, z);
          if (y < 0 || (k >= 0 && G.HR[k] > y)) { falla(8, s.nombre + ': bala que pegó atravesando algo en (' + x.toFixed(1) + ',' + z.toFixed(1) + ')'); break; }
        }
      }
    }

    /* ---- conciencia por soldado (para 5 y 7): después de los eventos, que son de este mismo cuadro ---- */
    for (const s of UE.soldados) {
      const o = est(s);
      const fuera = s.esc.estado !== 'combate' && s.alerta < 2;                      // fuera de combate (guardia, sospecha, búsqueda): el reloj de reacción vuelve a contar
      if (fuera) o.aware = null;
      if (fuera && (s.esc.estado === 'guardia' || s.esc.estado === 'sospecha')) o.primeraRaf = null;   // contacto nuevo: otra ráfaga de aviso
      else if (o.aware === null && (s.ve || s.esc.estado === 'combate' || s.alerta >= 2)) o.aware = t;
    }
    /* ---- 1 (cantidad) · 3 (láser) · 9 (avance) · 10 (NaN, adentro de algo) por soldado ---- */
    let nF = 0, nL = 0;
    for (const s of UE.soldados) {
      if (!s.activo) continue;
      const o = est(s);
      if (!Number.isFinite(s.x) || !Number.isFinite(s.z) || !Number.isFinite(s.y) || !Number.isFinite(s.hp)) { falla(10, s.nombre + ' tiene NaN'); continue; }
      if (!s.vivo) continue;
      chequeos[10]++;
      const k = M.celda(s.x, s.z);
      if (!s.elev && s.salto < 0 && (k < 0 || G.B[k] !== 0)) { if (!o.adentro) falla(10, s.nombre + ' dentro de un casillero bloqueado (' + s.x.toFixed(1) + ',' + s.z.toFixed(1) + ')'); o.adentro = true; } else o.adentro = false;
      if (s.ficha) nF++;
      if (s.laser) nL++;
      /* láser sobre el jugador: el punto cerca del cuerpo y línea real del tirador al jugador */
      if (s.rol === 'tirador') {
        let sobre = false;
        if (s.laser && J.vivo) {
          const p0 = posJugadorEn(M.t - 0.25), oy = ojo(s);                            // el punto rojo sigue al jugador con atraso
          const dl = Math.min(hyp(s.laser.x - J.x, s.laser.z - J.z), p0 ? hyp(s.laser.x - p0.x, s.laser.z - p0.z) : 1e9);
          sobre = dl < 2.5 && loVe(s, oy);
        }
        if (sobre) { if (o.laserDesde === null) o.laserDesde = M.t; } else o.laserDesde = null;
      }
      /* 9. avance */
      if (quiereMover(s)) {
        const ul = o.mov.length ? o.mov[o.mov.length - 1] : null;
        o.mov.push([M.t, s.x, s.z, (ul ? ul[3] + hyp(s.x - ul[1], s.z - ul[2]) : 0)]);          // [t, x, z, recorrido acumulado]
        while (o.mov.length > 1 && o.mov[0][0] < M.t - 3.05) o.mov.shift();
        if (o.mov.length > 2 && M.t - o.mov[0][0] >= 3) {
          chequeos[9]++;
          if (o.mov[o.mov.length - 1][3] - o.mov[0][3] < 0.4) { falla(9, s.nombre + ' (' + s.estado + ') 3 s sin avanzar en (' + s.x.toFixed(1) + ',' + s.z.toFixed(1) + ')'); o.mov.length = 0; }
        }
      } else o.mov.length = 0;
    }
    chequeos[1]++;
    if (nF > T.fichas) falla(1, nF + ' soldados con ficha a la vez');
    if (nL > 1) falla(1, nL + ' láseres de tirador a la vez');

    /* ---- 4. el último lugar conocido solo cambia con una señal real ---- */
    const u = UE.red.uc;
    if (u && (!ucAntes || ucAntes.t !== u.t || hyp(ucAntes.x - u.x, ucAntes.z - u.z) > 0.05)) {
      chequeos[4]++;
      const p = posJugadorEn(u.t);
      if (u.t > M.t + 1e-6 || u.t < M.t - 2) falla(4, 'lugar conocido con hora rara (' + u.t.toFixed(2) + ')');
      else if (u.tipo === 'vista') {
        if (!huboSenal(u.t - 0.13, u.t + 0.08, 'vista')) falla(4, 'lugar conocido «por vista» sin que nadie tuviera línea al jugador');
        else if (p && hyp(p.x - u.x, p.z - u.z) > 0.8) falla(4, 'lugar conocido «por vista» a ' + hyp(p.x - u.x, p.z - u.z).toFixed(1) + ' m de donde estaba el jugador');
      } else {
        if (!huboSenal(u.t - 0.13, u.t + 0.08, 'oido')) falla(4, 'lugar conocido «por oído» sin disparo ni pasos del jugador');
        else if (p && hyp(p.x - u.x, p.z - u.z) > 2 * u.err + 2) falla(4, 'lugar conocido «por oído» demasiado preciso o lejos');
      }
      ucAntes = { x: u.x, z: u.z, t: u.t };
    } else if (!u) ucAntes = null;
    return evs;
  }
  function excepcion(err) { falla(10, 'excepción: ' + (err && err.stack ? err.stack.split('\n').slice(0, 3).join(' | ') : err)); }
  function resumen() { return Object.keys(cuenta).map(n => n + ':' + (cuenta[n] ? 'FALLA×' + cuenta[n] : 'ok') + '(' + chequeos[n] + ')').join(' '); }
  return { paso, excepcion, fallas, cuenta, chequeos, resumen, NOMBRE };
}
if (typeof module !== 'undefined') module.exports = { crearVerificador };
