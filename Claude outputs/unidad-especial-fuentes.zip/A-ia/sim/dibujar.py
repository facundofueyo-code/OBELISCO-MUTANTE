#!/usr/bin/env python3
"""sim/dibujar.py — láminas vistas desde arriba de una corrida del simulador (trazas/<esc>.json → trazas/<esc>.png).

  python3 sim/dibujar.py trazas/f0.json [--desde 10] [--cada 4] [--n 8] [--caja x0,x1,z0,z1]

Cada panel es un instante (uno cada 2 s de juego en el .json; --cada elige uno de cada tantos).
Norte arriba, este a la derecha. Referencias:
  soldados: J jefe (rojo) · A asalto (naranja) · G granadero (violeta) · T tirador (celeste); borde negro = Tizón
            raya = hacia dónde mira · texto chico = estado · ✕ fino = cobertura elegida · línea fina = camino
            anillo amarillo = tiene ficha (tira a pegar) · gris = muerto
  jugador:  círculo verde (chico = agachado) · cruz roja = último lugar conocido del escuadrón
  balas del último medio segundo: naranja = a pegar · gris = supresión/aviso · verde = del jugador
  láser: línea roja · granadas: punto negro con la mecha · bichos: puntos marrones · zona amarilla = reflectores
"""
import json, sys, os
from PIL import Image, ImageDraw, ImageFont

AQUI = os.path.dirname(os.path.abspath(__file__))
MAPA = os.path.join(AQUI, '..', '..', 'mapa-reten.json')


def arg(n, d=None):
    if '--' + n in sys.argv:
        i = sys.argv.index('--' + n)
        return sys.argv[i + 1]
    return d


def main():
    src = sys.argv[1]
    tr = json.load(open(src))
    mapa = json.load(open(MAPA))
    X0, Z0, W = mapa['X0'], mapa['Z0'], mapa['W']
    B, Hh = mapa['B'], mapa['Hh']
    frames = tr['frames']
    desde = float(arg('desde', 0))
    cada = int(arg('cada', 2))
    n = int(arg('n', 8))
    fr = [f for f in frames if f['t'] >= desde][::cada][:n]
    caja = arg('caja')
    if caja:
        x0, x1, z0, z1 = [float(v) for v in caja.split(',')]
    else:
        xs = [f['jugador']['x'] for f in fr] + [s['x'] for f in fr for s in f['soldados']]
        zs = [f['jugador']['z'] for f in fr] + [s['z'] for f in fr for s in f['soldados']]
        x0, x1 = max(min(xs) - 6, X0), min(max(xs) + 6, X0 + W)
        z0, z1 = max(min(zs) - 6, Z0), min(max(zs) + 6, Z0 + mapa['H'])
        if x1 - x0 < 60:
            c = (x0 + x1) / 2; x0, x1 = c - 30, c + 30
        if z1 - z0 < 30:
            c = (z0 + z1) / 2; z0, z1 = c - 15, c + 15
    cols = 2
    pw = 350
    esc = pw / (x1 - x0)
    ph = int((z1 - z0) * esc) + 14
    rows = (len(fr) + cols - 1) // cols
    img = Image.new('RGB', (cols * pw, rows * ph + 16), (250, 250, 247))
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 9)
        fontb = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 9)
    except Exception:
        font = fontb = ImageFont.load_default()
    d.text((4, 2), '%s · %s · semilla %s' % (tr['esc'], tr['nombre'], tr['semilla']), fill=(0, 0, 0), font=fontb)
    # fondo (una vez) con la grilla del juego + el retén
    reten = tr.get('reten', [])
    fondo = Image.new('RGB', (pw, ph - 14), (236, 236, 230))
    fd = ImageDraw.Draw(fondo)
    L = tr.get('luz')
    if L:
        fd.rectangle([(L['x0'] - x0) * esc, (L['z0'] - z0) * esc, (L['x1'] - x0) * esc, (L['z1'] - z0) * esc], fill=(250, 244, 205))
    for zz in range(int(z0), int(z1) + 1):
        for xx in range(int(x0), int(x1) + 1):
            i, j = xx - X0, zz - Z0
            if i < 0 or j < 0 or i >= W or j >= mapa['H']:
                continue
            k = j * W + i
            b = B[k]
            col = None
            if b == 2:
                col = (120, 120, 120)
            elif b == 1:
                h = Hh[k]
                col = (165, 165, 175) if h >= 13 else (200, 200, 190)
            if col:
                fd.rectangle([(xx - x0) * esc, (zz - z0) * esc, (xx + 1 - x0) * esc - 1, (zz + 1 - z0) * esc - 1], fill=col)
    for r in reten:
        c = {'furgon': (60, 60, 70), 'mando': (60, 60, 70), 'auto': (130, 130, 150), 'valla': (140, 100, 60)}.get(r['tipo'], (90, 90, 90))
        fd.rectangle([(r['x0'] - x0) * esc, (r['z0'] - z0) * esc, (r['x1'] - x0) * esc, (r['z1'] - z0) * esc], outline=c)
    ROL = {'jefe': (210, 40, 40), 'asalto': (240, 140, 20), 'granadero': (140, 60, 190), 'tirador': (40, 170, 220)}
    for idx, f in enumerate(fr):
        ox, oy = (idx % cols) * pw, (idx // cols) * ph + 16
        img.paste(fondo, (ox, oy + 14))
        P = lambda x, z: (ox + (min(max(x, x0), x1) - x0) * esc, oy + 14 + (min(max(z, z0), z1) - z0) * esc)
        dentro = lambda x, z: x0 <= x <= x1 and z0 <= z <= z1
        e = f.get('escuadrones', [])
        txt = 't=%.0f  hp %d  ' % (f['t'], f['jugador']['hp']) + ' · '.join('%s:%s%s' % (q['nombre'][:3], q['estado'][:4], (' ' + q['orden'][:18]) if q.get('orden') else '') for q in e)
        d.text((ox + 3, oy + 1), txt, fill=(0, 0, 0), font=font)
        for b in f.get('balas', []):
            c = (0, 150, 0) if b['de'] == 'jugador' else ((235, 120, 0) if b['modo'] == 'pegar' or b['modo'] == 'laser' else (150, 150, 150))
            d.line([P(b['ox'], b['oz']), P(b['hx'], b['hz'])], fill=c, width=1)
        for l in f.get('laseres', []):
            d.line([P(l['ox'], l['oz']), P(l['x'], l['z'])], fill=(255, 0, 0), width=1)
        for s in f['soldados']:
            if not dentro(s['x'], s['z']):
                continue
            if s.get('camino') and s['vivo']:
                pts = [P(s['x'], s['z'])] + [P(p['x'], p['z']) for p in s['camino']]
                d.line(pts, fill=(90, 90, 200), width=1)
            if s.get('cob') and s['vivo']:
                cx, cz = P(s['cob']['x'], s['cob']['z'])
                d.line([cx - 3, cz - 3, cx + 3, cz + 3], fill=(40, 40, 160)); d.line([cx - 3, cz + 3, cx + 3, cz - 3], fill=(40, 40, 160))
        u = f.get('uc')
        if u:
            ux, uz = P(u['x'], u['z'])
            d.line([ux - 5, uz - 5, ux + 5, uz + 5], fill=(220, 0, 0), width=2); d.line([ux - 5, uz + 5, ux + 5, uz - 5], fill=(220, 0, 0), width=2)
        for bi in f.get('bichos', []):
            if not dentro(bi['x'], bi['z']):
                continue
            bx, bz = P(bi['x'], bi['z'])
            d.ellipse([bx - 3, bz - 3, bx + 3, bz + 3], fill=(120, 70, 20))
        for g in f.get('granadas', []):
            gx, gz = P(g['x'], g['z'])
            d.ellipse([gx - 3, gz - 3, gx + 3, gz + 3], fill=(0, 0, 0))
            d.text((gx + 4, gz - 5), '%.1f' % g['t'], fill=(0, 0, 0), font=font)
        j = f['jugador']
        jx, jz = P(j['x'], j['z'])
        r = 3 if j.get('agach') else 5
        d.ellipse([jx - r, jz - r, jx + r, jz + r], fill=(0, 170, 0) if j['vivo'] else (120, 120, 120), outline=(0, 70, 0))
        import math
        for s in f['soldados']:
            if not dentro(s['x'], s['z']):
                continue
            sx, sz = P(s['x'], s['z'])
            c = ROL.get(s['rol'], (0, 0, 0)) if s['vivo'] else (160, 160, 160)
            r = 4
            if s.get('ficha'):
                d.ellipse([sx - 7, sz - 7, sx + 7, sz + 7], outline=(230, 200, 0), width=2)
            d.ellipse([sx - r, sz - r, sx + r, sz + r], fill=c, outline=(0, 0, 0) if s['esc'] != 'Ceniza' else c)
            if s['vivo']:
                a = s['rumbo']
                d.line([sx, sz, sx + math.sin(a) * 8, sz + math.cos(a) * 8], fill=(0, 0, 0))
                d.text((sx + 5, sz + 2), s['rol'][0].upper() + ':' + s['estado'][:5], fill=(30, 30, 30), font=font)
    out = src.replace('.json', '.png')
    img.save(out)
    print(out, img.size)


if __name__ == '__main__':
    main()
