const v=(rol,pose,t,az,el,txt,o={})=>Object.assign({rol,pose,t,az,el,dist:3.6,obj:[0,.9,0],txt},o);
module.exports={cols:4,vistas:[
  v('jefe','Apunta',1.6,.75,.06,'jefe apunta 3/4'),v('asalto','Agachado',1.6,.8,.12,'asalto agachado',{obj:[0,.6,0],dist:3}),
  v('tirador','Cuerpo a tierra',2,1.0,.32,'tirador a tierra + láser',{laser:true,obj:[0,.25,0.3],dist:3.4}),
  v('granadero','Camina',2.35,0,.08,'granadero camina',{seguir:true,relAz:Math.PI/2}),
  v('jefe','Corre',1.9,0,.08,'jefe corre',{seguir:true,relAz:Math.PI/2,dist:3.9}),v('asalto','De costado',1.25,.15,.08,'asalto de costado',{seguir:true}),
  v('jefe','Asoma',1.2,0.1,.08,'jefe asoma'),v('granadero','Apunta',1.6,.6,.08,'granadero luz plena',{plena:true})]};
