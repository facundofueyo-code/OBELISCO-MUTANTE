/* Capturas de la página suelta (prueba_fx.html): trazadoras, impactos, avisos del HUD y vista táctica.
   Uso: node t_pagina.js [ancho alto] [filtro]   → capturas/pNN_*.png
   No hace cola (H.openPage). Cada escena deja el bucle automático apagado y avanza a mano, para congelar el instante. */
const H=require('../harness.js');
const W=+process.argv[2]||1280,Hh=+process.argv[3]||720,FILTRO=process.argv[4]||'';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
  const h=await H.openPage(__dirname+'/prueba_fx.html',{width:W,height:Hh});
  await h.page.waitForFunction('window.__listo===true',{timeout:60000});
  const ev=c=>h.page.evaluate(c=>window.__ev(c),c);
  const suf=W===1280?'':'_'+W;
  const shot=async n=>{if(FILTRO&&!n.includes(FILTRO))return;await sleep(260);await h.shotPage(__dirname+'/capturas/'+n+suf+'.png');console.log('captura',n+suf);};
  const limpiar=()=>ev("auto=false;claro(false);UEFX.reset();UEHUD.reset();UESND.reset();UEDBG.poner(0);UEB.debug=()=>null;delete window.GRAN;P.pos.set(-404,0,607);P.yaw=Math.PI/2;P.pitch=0;parts.forEach(q=>q.alive=false);for(let i=0;i<5;i++)paso(1/60);1");

  /* ---------- A · trazadoras ---------- */
  await limpiar();
  await ev(`(()=>{const m=new V3(-438,1.45,606),v=(x,y,z)=>new V3(x,y,z);
    UEFX.trazadora(m,v(-404.9,1.6,606.2),'fusil');paso(.016);
    UEFX.trazadora(v(-438,1.45,612),v(-398,1.2,609.5),'fusil');paso(.016);
    UEFX.trazadora(m,v(-407,0.02,605.2),'fusil');
    for(let i=0;i<8;i++)UEFX.trazadora(v(-424,1.3,621),v(-405+Math.random()*2,1+Math.random(),608.5+Math.random()*2),'escopeta');paso(.016);
    UEFX.trazadora(v(-438,3.1,602),v(-401,1.5,607.6),'tirador');paso(.016);
    UEFX.trazadora(m,v(-400,2.2,604.8),'fusil');paso(.016);return UEFX.vivos;})()`);
  await shot('p01_trazadoras');
  await ev("paso(.05);paso(.05);1");await shot('p02_rastro_tirador');

  /* ---------- A · impactos ---------- */
  await limpiar();
  await ev(`(()=>{const v=(x,y,z)=>new V3(x,y,z);
    UEFX.impacto(v(-409,1.1,606),v(1,0,0),'metal');UEFX.impacto(v(-410,1.3,608.6),null,'metal');
    UEFX.impacto(v(-409.5,1.6,611),v(1,0,0),'pared');UEFX.impacto(v(-408,.02,605),null,'piso');UEFX.impacto(v(-407,.02,607.5),null,'piso');
    UEFX.sangre(v(-409,1.3,609.6),v(-1,0,.2));UEFX.impacto(v(-408.6,1,604),null,'carne');
    paso(.03);paso(.03);return UEFX.vivos;})()`);
  await shot('p03_impactos_60ms');
  await ev("paso(.05);paso(.05);paso(.05);1");await shot('p04_impactos_210ms');

  /* ---------- B · HUD ---------- */
  const hudLleno=`(()=>{
    UEHUD.radio('Ceniza 1','Ceniza 2, rodealo.','orden_flanco');UEHUD.radio('Ceniza 2','Voy por izquierda.','flanco_izq');UEHUD.radio('Ceniza 3','¡Granada va!','granada');
    UEHUD.alerta(.55,1.2,false);
    window.GRANF=[{p:new V3(-411,0,601),v:new V3(),t:2.2,de:{},tipo:'frag'},{p:new V3(-401,0,609.5),v:new V3(),t:.7,de:{},tipo:'frag'}];window.GRAN={lista:window.GRANF};
    for(let i=0;i<40;i++)paso(1/60);
    UEHUD.golpe(-1.57);UEHUD.golpe(2.9);paso(.05);return 1;})()`;
  await limpiar();await ev(hudLleno);await shot('p05_hud_oscuro');
  await ev("claro(true);1");await shot('p06_hud_claro');
  await ev("claro(false);delete window.GRAN;1");

  /* detección: subiendo, llena, en combate y sin dirección */
  const det=async(n,c)=>{await limpiar();await ev(c);await shot(n);};
  await det('p07_det_25',"UEHUD.alerta(.25,-.9,false);for(let i=0;i<50;i++)paso(1/60);1");
  await det('p08_det_70',"UEHUD.alerta(.7,.5,false);for(let i=0;i<50;i++)paso(1/60);1");
  await det('p09_det_llena',"UEHUD.alerta(.7,.5,false);for(let i=0;i<30;i++)paso(1/60);UEHUD.alerta(1,.5,false);for(let i=0;i<30;i++)paso(1/60);1");
  await ev("claro(true);1");await shot('p10_det_llena_claro');
  await det('p11_det_combate_4s',"UEHUD.alerta(1,-2.4,true);for(let i=0;i<270;i++)paso(1/60);1");
  await det('p12_det_sin_dir',"UEHUD.alerta(.6,null,false);for(let i=0;i<50;i++)paso(1/60);1");
  /* cuatro golpes a la vez + uno renovado */
  await det('p13_golpes',"for(let i=0;i<5;i++)paso(1/60);UEHUD.golpe(0);UEHUD.golpe(1.57);UEHUD.golpe(3.14);UEHUD.golpe(-1.57);paso(.1);1");
  await ev("claro(true);1");await shot('p14_golpes_claro');

  /* ---------- C · vista táctica ---------- */
  await limpiar();await ev("UEB.debug=debugFalso;UEHUD.radio('Ceniza 3','Lo tengo fijado.','fijar');UEFX.trazadora(new V3(-433,1.4,612),new V3(-409.5,1,611),'fusil');UEDBG.poner(1);for(let i=0;i<10;i++)paso(1/60);1");
  await shot('p15_tactica_chica');
  await ev("UEDBG.poner(2);for(let i=0;i<10;i++)paso(1/60);1");await shot('p16_tactica_grande');
  await limpiar();await ev("UEDBG.poner(1);for(let i=0;i<10;i++)paso(1/60);1");await shot('p17_tactica_sin_escuadron');
  await ev("UEDBG.poner(0);1");
  console.log('errores:',JSON.stringify(h.errors));
  await h.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
