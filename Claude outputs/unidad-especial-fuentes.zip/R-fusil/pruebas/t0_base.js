// exploración: datos del mundo y capturas de las armas actuales (sobre base.html, sin tocar nada)
const H=require('../../harness.js');const t0=Date.now();const log=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(1)+'s',...a);
(async()=>{const h=await H.open('../../base.html',{width:960,height:540});log('abierto');
  log('start',JSON.stringify(await h.start()));
  await h.alReten();
  log('conteos',JSON.stringify(await h.ev(`({obst:obstacles.length,glass:obstacles.filter(b=>b.glass).length,cars:VCARS.length,floors:floors.length,ffn:FLOORFN.length,circ:circles.length,wallsAll:WALLS_ALL.length,walls:WALLS.length,
    obY0:obstacles.filter(b=>(b.y0||0)>0).length,obst_near:obstacles.filter(b=>b.x1>-460&&b.x0<-300&&b.z1>590&&b.z0<630).map(b=>[+b.x0.toFixed(1),+b.x1.toFixed(1),+b.z0.toFixed(1),+b.z1.toFixed(1),+(b.y0||0).toFixed(1),+b.y1.toFixed(1),b.glass?1:0]).slice(0,40)})`)));
  log('floorAt costo',JSON.stringify(await h.ev(`(()=>{const t=performance.now();let s=0;for(let i=0;i<20000;i++)s+=floorAt(-330-i*.001,608);const a=performance.now()-t;const t2=performance.now();for(let i=0;i<20000;i++)s+=floorAt(-935+i*.001,628);return {us_reten:a/20*1,us_congreso:(performance.now()-t2)/20,s};})()`)));
  log('rayCars costo',JSON.stringify(await h.ev(`(()=>{const o=new V3(-330,1,608),d=new V3(-1,0,0);const t=performance.now();let n=0;for(let i=0;i<5000;i++){if(rayCars(o,d,.3))n++;}return {us:(performance.now()-t)/5,n};})()`)));
  log('rayWalls costo',JSON.stringify(await h.ev(`(()=>{const o=new V3(-330,1,608),d=new V3(-1,0,0);const t=performance.now();let n=0;for(let i=0;i<5000;i++){if(rayWalls(o,d,.3)<1)n++;}return {us:(performance.now()-t)/5,n};})()`)));
  log('autos cerca',JSON.stringify(await h.ev(`VCARS.filter(c=>Math.hypot(c.x+330,c.z-608)<40).map(c=>({id:c.S.id,x:+c.x.toFixed(1),z:+c.z.toFixed(1),a:+c.a.toFixed(2),L:+c.L.toFixed(2),W:+c.W.toFixed(2),H:+c.H.toFixed(2),hood:c.S.hood,ok:MOV.carOK(c)}))`)));
  // armas actuales: capturas con el mapa oculto
  await h.ev("SECG.A.visible=SECG.B.visible=false;P.pos.set(-330,0,608);P.yaw=Math.PI/2;P.pitch=0;1");
  for(const [i,n] of [[0,'pistola'],[1,'escopeta'],[2,'uzi']]){
    await h.ev(`(()=>{W[wi].g.visible=false;wi=${i};W[wi].g.visible=true;W[wi].anim(W[wi]);hudAmmo();aiming=false;return wi;})()`);await h.step(.6);
    await h.shot('base_'+n+'_cadera.png');log('captura',n);
    await h.ev("aiming=true;1");await h.step(.6);await h.shot('base_'+n+'_mira.png');await h.ev("aiming=false;1");
  }
  // recarga de la uzi a mitad
  await h.ev("(()=>{W[2].ammo=3;reload();return W[2].rT;})()");await h.step(.5);await h.shot('base_uzi_recarga05.png');await h.step(.45);await h.shot('base_uzi_recarga095.png');
  log('errores',h.errors.length,h.errors.slice(0,3).join(' | '));
  await h.close();})().catch(e=>{console.error('FAIL',e.message);process.exit(1);});
