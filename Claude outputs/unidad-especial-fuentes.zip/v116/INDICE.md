# Base 1.16.0: índice y cambios desde la 1.14.0

`base.html` = juego 1.16.0 + `marcar.py` (los 17 marcadores, `UEB` y `UEB.ruido`, cada uno una sola vez; ninguna ancla hubo que adaptar).
`base-view.txt` tiene los mismos números de línea. Líneas gigantes recortadas: **289** three.js, **294** ClipperLib, **1074** y **1618** datos del mapa (A y B), **8837–8839** partituras.

## (a) Índice (líneas de `v116/base-view.txt`)

| Línea | Qué |
|---|---|
| 1034 | `UEB` |
| 1996–2008 | `ZS=268` (corte A/B), `GATE` y `STAGE` (1997), `SECDEF` (2001), `SEC_CUR` (2008) |
| 2628–2677 | `WALLS` 2628, hash 2655, `circles` 2660, `addCircle` 2661, `wallCollide` 2664, `rayWalls` 2671 |
| 3551–3554 | `floors` 3551, `FLOORFN` 3552, `floorAt(x,z)` 3554 |
| 3784 / 4173 | `VEH` / `TEX` |
| 4116 / 4342 | `CARS` (modelos) / `obstacles` |
| 4369–4582 | autos: `VCARS` 4369, `CAOS` 4371, `SEMILLA` 4373, `bCars` 4374, `rayCars` 4520, `carShot` 4528, `carDamage` 4531, `carBoom` 4537, `vehUpdate` 4581 |
| 8561 / 8562 | `MH_B` / `buildSectionB()` |
| 8597–8617 | `spawnPart` 8597, `burst` 8600, `addDecal` 8612 |
| 8642–8887 | audio: `initAudio` 8642, `noise` 8644, `tone` 8645, `sfx` 8789, `PRI` 8829 |
| 8890 / 9031 | `TYPES` / `makeMutant` |
| 10419 | `P` (jugador) |
| 10435–10708 | armas: `WM` 10435, `buildPistol` 10531, `buildShotgun` 10576, `buildUzi` 10612, `anim*`/`reload*` 10649–10687, `W=[…]` 10693, linterna `toggleTorch` 10704 |
| 10811–10859 | `REC` 10811, `hudAmmo` 10841, `hudHP` 10850, `announce` 10853, `feed` 10854, `chooseHole` 10859 |
| 10861–10880 | `spawnEnemy` 10861, `pickType` 10879, `startWave` 10880 |
| 10889–10951 | `reload` 10889, `switchTo` 10892, `fire()` 10912 (`UEB.ruido` 10918, `/*UE:rayo-jugador*/` 10935) |
| 10953–10981 | `damageEnemy` 10953, `killEnemy` 10957, `hurtPlayer` 10981 |
| 11265–11302 | `addPickup` 11269, `addAmmo` 11274, `updatePickups` 11276, `spit` 11286, `updateProjs` 11290 |
| 11304–11970 | `SHJ`: `astar(…,expo)` 11686, `coverCands` 11715, `pickCover` 11721 |
| 11973 | `collide(pos,rad,feetY…)` |
| 11992–12095 | navegación: `EX0…` 11992, `enB/enH/enC/enP` 11993, `ENF` 11994, `eCell` 11997, `enMark` 11998, `enRaster` 11999, `enClr` 12022, `enRasterAll` 12026, `enDirty` 12027, `enSteer` 12053 |
| 12097–12432 | `MOV` |
| 12507–12569 | `updatePlayer` 12507, `updateWeapon` 12524, `updateWaves` 12564 |
| 12570–12791 | `updateEnemies(dt)` |
| 12788–12883 | `restoreProps` 12788, `resetGame` 12793, `prewarmSections` 12817, `startGame` 12854, `gameOver` 12861, `setPaused` 12872 |
| 12887 / 12920 / 12928 / 12949 | teclado (`keydown`) / `/*UE:modulos*/` / `compassTargets` / `frame(now)` |

Marcadores: css 171 · hud 194 · capas 196 · ayuda 240 · inicio 253 · rayo-jugador 10935 · reset 12801 · warm-on 12823 · warm-off 12849 · start 12857 · fin 12861 · pausa 12872 · teclas 12892 · modulos 12920 · brujula 12933 · update 12951 · fx 12955.

**Nuevo desde la 1.15.0**

| Línea | Qué |
|---|---|
| 293–294 | `ClipperLib` 6.4.2 (su propio `<script>`; la 294 es la minificada) |
| 296–1028 | `CALLES` (`<script>` aparte, `window.CALLES`): cabecera 297, `DEF={H:.15…}` 506, `buildCars` 842, `buildGame` 1018, `root.CALLES=` 1026 |
| 2013 | `cellAt(x,z)`: 0 vereda, 1 calle, 2 edificio, 3 pasto, 4 bloqueado (la grilla la corrige `PISO`) |
| 2040–2450 | `PISO`: cabecera 2040, `const PISO` 2044, rampas y `rampAt` 2363–2367, `de(z)` 2400, **`PISO.y` = `function y(x,z)` 2402**, `paso` 2407, lo que exporta 2450 (`y, calzada, vereda, libre, paso, bici, canteros, H, GS…`) |
| 2453 / 2902 / 2993 | `SUBTE` / árboles: `addCircle(…)` con `brk:{k:'tree'}` / `TRAF` (semáforos por mano) |
| 3554 | **`floorAt` toma la altura de `PISO.y(x,z)`** y después le suma `floors` (andenes, escalinatas) y `FLOORFN` |
| 4374–4424 | **`bCars` nuevo**: `keep` 4382, `fijo` 4384, `entra` 4385, `CALLES.buildCars` 4395, malla propia 4416, instanciados 4420, círculos de choque 4423 |
| 4490 / 4491 / 4818 | `MH_XY` / `VALLAS_XY` (sección A, antes de repartir autos) / `MH` |

## (b) Qué cambió desde la 1.14.0 que le importa a este trabajo

**Alturas.** La vereda sigue en 0 y la calzada baja a **−0,15** (`DEF.H=.15`). `PISO.y(x,z)`: −0,15 adentro del polígono de calzada (cuneta incluida), y afuera `rampAt` (vados, cocheras, calles a nivel), que casi siempre da 0. El cordón es un escalón seco. Los canteros se ven 3,5 cm hundidos pero `PISO.y` da 0 ahí. `floorAt` parte de `PISO.y`, y todo se apoya en `PISO.y`: jugador, bichos, autos (`c.by`), vallas, bolsas, calcomanías y pedazos. **Lo que se ponga en la calzada a y=0 (soldados, furgones, vallas, reflectores, granadas, casquillos) queda flotando 15 cm.** Va con `floorAt(x,z)` o `PISO.y(x,z)`.

**Autos: cómo se reparten.** Ya no se sortean a lo largo del eje de cada calle. `bCars(NC0)` llama a `CALLES.buildCars(PISO.GS[sec],{chaos:CAOS(.55),target:NC0,seed:SEMILLA[sec],keep,obs:fijo,noBus:true,ok:entra})`. Salen estacionados contra el cordón, en fila desde cada línea de detención (carril por carril, cada uno en su mano) y el caos (trabados en la bocacalle, contramano, choque, subidos a la vereda, cruzados): `c.kind`. Son 469 + 794 = 1263 en `VCARS` (A primero). Ningún auto va a menos de 6 m de una boca de subte, a menos de 3,4 m de una alcantarilla, pegado a un árbol, farol, poste, bolsa o pared, ni sobre una ciclovía. Para la B, alcantarillas y bolsas se ponen antes que los autos. El generador busca llegar a `NC0` probando densidades: vedar una zona en `keep` o `entra` seguramente mueve autos en otras partes y cambia los índices (no lo probé).

**Autos: cómo se crean.** `c.by=PISO.y` (−0,15 en la calzada). Si queda a caballo del cordón, se inclina (`c.tx`, `c.tz`). Solo los que tienen luces (`c.lit`: patrullero, balizas, faros) llevan malla propia (`c.grp`); los demás van en `InstancedMesh` por modelo, daño y óxido, con cajas de lejos y modelo unido a media distancia. Cada auto deja 3 círculos de choque (`c.cs`, r = W·0,58, `brk:{k:'car'}`) con **`h=c.H+c.by`**, o sea el techo medido desde la vereda (antes `h=c.H`). `rayCars` mide la altura desde `c.by` (`ly=o.y-c.by`) y `carBoom` arma los restos y la explosión sobre `c.by`.

**Canteros y árboles junto al cordón.** Desde la v1.15.0 los árboles de calle van en canteros de 1,2 × 1,2 m (0,8 m en veredas angostas) pegados al cordón, cada 8,5–12,5 m (`PISO.canteros()`, `PISO.GS.B.pits`). El árbol es un círculo `tree` **sin altura**, r = 0,42·s o 0,75·s (0,34–0,52 m en la cuadra). El cantero solo no choca. Faroles (r 0,2), semáforos (0,12–0,15) y señales (0,07) también chocan sin altura. Los postes ahora son por mano y hay peatonales.

**Grilla de navegación.** `enRaster` es **idéntica** a la de la 1.14.0: cambia lo que le llega.
- `isSolid` sale de la grilla nueva de `PISO` (2 edificio, 4 bloqueado). Ni el cordón ni la diferencia de altura entran en `enB`, y `enH` es altura absoluta (desde y=0), no desde el piso.
- Círculo sin `h` (árbol, farol, semáforo, señal, columnas) → `enB=2`, inflado 0,3. Con `h` ≤ 1,7 → trepable (bolsas 0,6; cosas de los frentes 0,45–1,6).
- Autos al final: trepables con su `h` (≈ H−0,15) y, donde no hay otra cosa, `enP=1` (empujable). `enC` es la distancia libre para los bichos grandes.

**Firmas.** Ninguna cambió: `rayCars(o,d,maxT)`, `carDamage(c,n)`, `carBoom(c)`, `rayWalls(o,d,maxT)`, `collide(pos,rad,feetY=0,boss,smash,hc)`, `enDirty(x0,z0,x1,z1)`, `addCircle(x,z,r)`, `floorAt(x,z)`, `spawnEnemy(type,at)`, `damageEnemy(e,dm,dir)`, `hurtPlayer(n,gooHit)`. Cambió el cuerpo de `floorAt` (parte de `PISO.y`), de `rayCars` y de `carBoom` (usan `c.by`). `carDamage`, `rayWalls`, `collide`, `enRaster`, `enDirty`, `addCircle`, `spawnEnemy`, `damageEnemy` y `hurtPlayer` quedaron iguales.

**La cuadra del retén hoy** (`mapa-reten.json`, `mapa-reten-zoom.png`)
- Calzada a −0,15. En x=−438 va de z≈597,75 a ≈617,25: cordón N entre 597,5 y 598, cordón S entre 617 y 617,5. Vereda N 592–597,5 y vereda S 617,5–621,5 a 0; edificios hasta 591,5 y desde 622. En x=−400 la calzada va de ≈596,25 a ≈616,25, la vereda S va de 616,5 a 618,5 y el edificio arranca en 619. La avenida gira ~2°: hacia el oeste se corre al sur (~1,5 m cada 38 m). `floorAt` = `PISO.y` en todo el corte.
- 10 autos en x∈[−470,−300], z∈[585,625], todos instanciados, en la calzada (by −0,15) y sin inclinar. Son 9 en fila y 1 a contramano (788): `VCARS` 779–788. Los que nombra SPEC §6 (−442,2;610,9), (−432,6;608,7) y (−401,8;614,75) ya no existen.
- **Choques con la disposición provisoria de SPEC §6**: el auto 779 (−436,2;599,4) pisa el furgón norte y las vallas norte. El 787 (−381,7;614,0) pisa el auto 6 de la fila (−381,613). El 786 queda a 0,7 m del auto 2 (−417,612,5).
- 22 canteros (10 S, 12 N) y 21 árboles en x∈[−470,−300]. Fila S en z≈614,8–618,1, fila N en z≈593,4–597,6. Hay 4 faroles en la vereda N y semáforos en la esquina de San José (−439,8;595,2) y (−439,8;618,0). Las columnas del pasaje Barolo son 6 círculos r 0,33 en z≈621,3, x −412,1…−405,8.
- Bocas de subte: (−481,4;597) es **nueva** (v1.15.0); siguen (−480;621), (−513,4;599,1) y (−514;623,1). Hay alcantarillas en (−481;609,1), en medio de la avenida detrás de la barricada, y en (−321,1;603,4).

**Volcado.** Mismo formato que antes, más: `P` (`enP`), `cars[].vi` (índice en `VCARS`), `malla` ('propia'|'instanciada'), `kind`, `by`, `tx`, `tz`, `st`, `cs` (círculos [x,z,r,h]). También `circ` (círculos que no son de autos en x∈[−470,−300], z∈[590,622]: x, z, r, h si tiene, k, low), `arboles`, `canteros` y `piso` (cortes en x=−438 y x=−400, z 590→622 cada 0,5: `y`=floorAt, `py`=PISO.y, `g`=cellAt).

**Arnés.** `../harness.js` sirve tal cual: `start()` y `alReten()` andan sin errores, así que no hay copia nueva. `alReten` pone al jugador en y=0 sobre la calzada y en el primer cuadro baja a −0,15.

**Parches viejos.** F (`patch_fx.py`) aplica entero porque solo usa marcadores. M (`patch_bichos.py`) falla en 1 de sus 29 anclas: `else if(pos.y<.15){addDecal(…'#7fbf2a')…}` en `updateProjs` (11294), porque desde la v1.15.0 dice `pos.y<.15&&pos.y<PISO.y(pos.x,pos.z)+.15`.

Scripts: `marcar.py`, `t116.js` (arnés + volcado), `dibujar.py`.
