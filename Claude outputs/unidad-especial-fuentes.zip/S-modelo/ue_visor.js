/* ====================================================================================
   VISOR DE LA UNIDAD ESPECIAL (componente reutilizable)
   crearVisorUE(canvas, opciones) arma una escena de noche con niebla y piso mojado, una regla de
   1,80 m, órbita con mouse y con dedo, y maneja a los soldados de UEM como lo haría la IA (escribe
   u.e y mueve u.root). Depende de THREE (r128) y de UEM. El visor sí usa luces reales; el modelo no.
   opciones: {rol:'jefe', pose:'Apunta', girar:false, sombras:true, pixelRatio, capturas:false}
   ==================================================================================== */
function crearVisorUE(canvas,opciones){
  const op=Object.assign({rol:'jefe',pose:'Apunta',girar:false,sombras:true,capturas:false,
    pixelRatio:Math.min(2,(typeof window!=='undefined'&&window.devicePixelRatio)||1)},opciones||{});
  const V3=THREE.Vector3,PI=Math.PI,TAU=PI*2;
  const renderer=new THREE.WebGLRenderer({canvas,antialias:true,preserveDrawingBuffer:!!op.capturas});
  renderer.setPixelRatio(op.pixelRatio);renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
  renderer.shadowMap.enabled=!!op.sombras;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  const NIEBLA=0x1b1822,scene=new THREE.Scene();scene.background=new THREE.Color(NIEBLA);scene.fog=new THREE.FogExp2(NIEBLA,.045);
  const camara=new THREE.PerspectiveCamera(36,16/9,.05,200);

  /* ---------- luces: sodio de costado, relleno frío y contraluz. "Luz plena" cambia colores e intensidades
     (no la cantidad de luces: así no se recompilan los shaders) ---------- */
  const hemi=new THREE.HemisphereLight(0x5a6488,0x1a140f,.6);scene.add(hemi);
  const sodio=new THREE.SpotLight(0xff9a3c,3.4,32,.6,.65,1.3);sodio.position.set(-5.5,6.5,3.2);
  sodio.castShadow=true;sodio.shadow.mapSize.set(1024,1024);sodio.shadow.bias=-.0004;sodio.shadow.camera.near=1;sodio.shadow.camera.far=30;
  scene.add(sodio,sodio.target);sodio.target.position.set(0,.8,0);
  const contra=new THREE.DirectionalLight(0x8fa8e0,.7);contra.position.set(4,4.5,-6);scene.add(contra);
  let plena=false;
  function luces(){
    if(plena){hemi.color.set(0xdfe4ee);hemi.groundColor.set(0x3a3630);hemi.intensity=1.25;sodio.color.set(0xffffff);sodio.intensity=2.6;
      contra.color.set(0xffffff);contra.intensity=.9;scene.fog.density=.004;scene.background.set(0x2a2833);}
    else{hemi.color.set(0x5a6488);hemi.groundColor.set(0x1a140f);hemi.intensity=.6;sodio.color.set(0xff9a3c);sodio.intensity=3.4;
      contra.color.set(0x8fa8e0);contra.intensity=.7;scene.fog.density=.045;scene.background.set(NIEBLA);}
  }

  /* ---------- piso mojado: casi negro y brillante, con charcos (textura dibujada en un canvas) y el reflejo
     de los soldados (una copia espejada con los mismos huesos que se ve a través del piso) ---------- */
  function texturaCharcos(){
    const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');
    g.fillStyle='#f4f4f4';g.fillRect(0,0,256,256);
    let s=12345;const r=()=>(s=(s*1664525+1013904223)>>>0)/4294967296;
    for(let i=0;i<70;i++){const x=r()*256,y=r()*256,R=8+r()*42,gr=g.createRadialGradient(x,y,0,x,y,R),v=Math.floor(196+r()*36);
      gr.addColorStop(0,`rgb(${v},${v},${v})`);gr.addColorStop(1,'rgba(244,244,244,0)');g.fillStyle=gr;g.beginPath();g.arc(x,y,R,0,TAU);g.fill();}
    const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(6,6);return t;
  }
  const charcos=typeof document!=='undefined'?texturaCharcos():null;
  const piso=new THREE.Mesh(new THREE.PlaneGeometry(80,80),new THREE.MeshStandardMaterial({color:0x121117,roughness:1,metalness:.05,
    roughnessMap:charcos,alphaMap:charcos,transparent:true,opacity:.97}));
  piso.material.onBeforeCompile=sh=>{  /* más brillo donde hay charco; y el reflejo se ve solo ahí */
    sh.fragmentShader=sh.fragmentShader.replace('#include <roughnessmap_fragment>',
      'float roughnessFactor = roughness;\n#ifdef USE_ROUGHNESSMAP\n vec4 texelRoughness = texture2D( roughnessMap, vUv );\n roughnessFactor = mix(0.08, 0.6, (texelRoughness.g-0.76)*4.2);\n#endif');};
  piso.rotation.x=-PI/2;piso.receiveShadow=true;piso.renderOrder=1;scene.add(piso);
  /* regla de 1,80 m con marcas cada 10 cm */
  const regla=new THREE.Group();{
    const c=document.createElement('canvas');c.width=16;c.height=256;const g=c.getContext('2d');
    for(let i=0;i<18;i++){g.fillStyle=i%2?'#c9c2b2':'#2b2a2e';g.fillRect(0,256-(i+1)*256/18,16,256/18);}
    const t=new THREE.CanvasTexture(c);
    const poste=new THREE.Mesh(new THREE.BoxGeometry(.035,1.8,.035),new THREE.MeshStandardMaterial({map:t,roughness:.7}));poste.position.y=.9;poste.castShadow=true;regla.add(poste);
    const e=document.createElement('canvas');e.width=128;e.height=48;const ge=e.getContext('2d');ge.fillStyle='#d8d0c0';ge.font='bold 30px sans-serif';ge.fillText('1,80 m',8,34);
    const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(e),depthWrite:false,fog:true}));sp.scale.set(.42,.16,1);sp.position.set(0,1.93,0);regla.add(sp);
    regla.position.set(-1.15,0,-1.0);scene.add(regla);}
  const reflejos=new THREE.Group();reflejos.scale.y=-1;scene.add(reflejos);

  /* ---------- soldados ---------- */
  const ROLES=Object.keys(UEM.ROLES);
  const FORMACION={jefe:[.35,-1.1,.15],asalto:[1.05,.75,-.1],granadero:[-.95,.25,.12],tirador:[-1.9,-1.9,.25]};
  let soldados=[],modo=op.rol,poseAct=op.pose,tPose=0,linterna=false,laser=false,girar=!!op.girar,ronda=false,tRonda=0,iRonda=0,pausado=false;
  function quitar(){for(const s of soldados){s.u.dispose();if(s.refl)reflejos.remove(s.refl);}soldados=[];}
  function poner(rol,x,z,yaw,sem){
    const u=UEM.crear(rol,{semilla:sem});u.root.position.set(x,0,z);u.root.rotation.y=yaw;scene.add(u.root);
    const refl=new THREE.SkinnedMesh(u.malla.geometry,u.malla.material);refl.bindMode='detached';refl.bind(u.malla.skeleton,new THREE.Matrix4());
    refl.frustumCulled=false;reflejos.add(refl);
    soldados.push({u,refl,x0:x,z0:z,yaw0:yaw,rol});return u;}
  function armar(){
    quitar();
    if(modo==='todos')ROLES.forEach((r,i)=>{const f=FORMACION[r];poner(r,f[0],f[1],f[2],11+i*7);});
    else poner(ROLES.includes(modo)?modo:'jefe',0,0,0,7);
    tPose=0;aplicarInterruptores();
  }
  function aplicarInterruptores(){for(const s of soldados){s.u.e.luz=linterna;}}

  /* ---------- poses de demostración: escriben u.e como lo haría la IA ---------- */
  const SENAS=['avanzar','izq','der','alto'],MUERTES=['atras','adelante','derrumbe','tierra'];
  const ciclo=(t,dur)=>(t%dur)/dur;
  const POSES={
    'De pie':(s,t)=>{},
    'Apunta':(s,t)=>{s.u.e.apunta=1;s.u.e.mYaw=.25*Math.sin(t*.45+s.x0);},
    'Agachado':(s,t)=>{s.u.e.agach=Math.min(1,t/.45);s.u.e.apunta=1;s.u.e.mYaw=.2*Math.sin(t*.4);},
    'Cuerpo a tierra':(s,t)=>{s.u.e.tierra=Math.min(1,t/1.3);s.u.e.apunta=t>1.1?1:.3;s.u.e.mPitch=-.03;},
    'Camina':(s,t)=>{const R=2.2,w=1.4/R,a=t*w+s.x0;mover(s,Math.sin(a)*R,Math.cos(a)*R-R*.3,a+PI/2);s.u.e.apunta=.35;},
    'Corre':(s,t)=>{const R=3.4,w=5.2/R,a=t*w+s.x0;mover(s,Math.sin(a)*R,Math.cos(a)*R-R*.5,a+PI/2);},
    'De costado':(s,t)=>{const x=s.x0+1.3*Math.sin(t*1.0);mover(s,x,s.z0,s.yaw0);s.u.e.apunta=1;},
    'Asoma':(s,t)=>{s.u.e.apunta=1;s.u.e.asoma=Math.sin(t*1.1)>0?1:-1;},
    'Dispara':(s,t,dt)=>{const e=s.u.e;e.apunta=1;const tir=s.rol==='tirador',esc=s.rol==='asalto',per=tir?1.6:esc?1.1:1.2;
      const c=t%per,c0=c-dt;const tiros=tir||esc?[.2]:[.2,.29,.38];for(const k of tiros)if(c0<k&&c>=k)s.u.disparo();
      if(tir&&laser)e.tierra=0;},
    'Recarga':(s,t)=>{const c=t%3.4;s.u.e.apunta=.6;s.u.e.recarga=c<2.6?c/2.6:-1;},
    'Granada':(s,t)=>{const c=t%2.6;s.u.e.lanza=c<1.4?c/1.4:-1;s.u.e.apunta=.4;},
    'Seña':(s,t)=>{const c=t%2.2,i=Math.floor(t/2.2)%4;s.u.e.senal=c<1.8?c/1.8:-1;s.u.e.senalTipo=SENAS[i];},
    'Culatazo':(s,t)=>{const c=t%2;s.u.e.culata=c<1?c:-1;s.u.e.apunta=.5;},
    'Lo hieren':(s,t,dt)=>{const c=t%1.1;s.u.e.apunta=1;if(c-dt<.05&&c>=.05)s.u.golpe((Math.floor(t/1.1)*2.4)%TAU-PI,.8);},
    'Cae':(s,t)=>{const c=t%3.6,i=Math.floor(t/3.6)%4,e=s.u.e;
      if(c<3){if(i===3)e.tierra=1;e.apunta=1;const m=c<.6?-1:Math.min(1,(c-.6)/1.3);
        if(m>=0){e.muerte=e.muerte||{tipo:MUERTES[i],t:0,dir:(i===2?.6:0)};e.muerte.tipo=MUERTES[i];e.muerte.t=m;}else if(e.muerte){s.u.revivir();}}
      else if(e.muerte){s.u.revivir();}},
    /* extras (no están en la lista pedida; sirven para probar capas) */
    'Aturdido':(s,t)=>{s.u.e.aturdido=Math.min(1,t/.8);s.u.e.apunta=.6;},
    'Radio':(s,t)=>{s.u.e.radio=(t%3)<2?1:0;s.u.e.apunta=.3;},
    'Salta':(s,t)=>{const c=t%2.6,ida=Math.floor(t/2.6)%2===0,z=c<1.1?-1+c/1.1*2:1;
      mover(s,s.x0,ida?z:-z,ida?0:PI);s.u.e.salto=c<1.1?c/1.1:-1;}
  };
  const NOMBRES=Object.keys(POSES);
  function mover(s,x,z,yaw){s.u.root.position.set(x,0,z);s.u.root.rotation.y=yaw;}
  function base(s){const e=s.u.e,keep=e.muerte;
    Object.assign(e,{agach:0,tierra:0,apunta:0,mYaw:0,mPitch:0,asoma:0,recarga:-1,salto:-1,lanza:-1,senal:-1,culata:-1,radio:0,aturdido:0});
    e.muerte=keep;e.luz=linterna;
    if(laser&&s.rol==='tirador'){const y=s.u.root.rotation.y,p=s.u.root.position;e.laser=s.laserP||(s.laserP=new V3());
      e.laser.set(p.x+Math.sin(y)*7.5,poseAct==='Cuerpo a tierra'||e.tierra>.5?.02:.9,p.z+Math.cos(y)*7.5);}else e.laser=null;}
  function paso(dt){
    if(ronda){tRonda+=dt;if(tRonda>5.5){tRonda=0;iRonda++;const n=NOMBRES[iRonda%NOMBRES.length];
      if(iRonda%NOMBRES.length===0&&modo!=='todos'){modo=ROLES[(ROLES.indexOf(modo)+1)%ROLES.length];poseAct=n;armar();}else fijarPose(n);}}
    tPose+=dt;
    for(const s of soldados){if(poseAct!=='Cae'&&s.u.e.muerte)s.u.revivir();
      if(poseAct!=='Camina'&&poseAct!=='Corre'&&poseAct!=='De costado')mover(s,s.x0,s.z0,s.yaw0);
      base(s);(POSES[poseAct]||POSES['De pie'])(s,tPose,dt);
      if(laser&&s.rol==='tirador'&&s.u.e.laser){const y=s.u.root.rotation.y,p=s.u.root.position;s.u.e.laser.set(p.x+Math.sin(y)*7.5,s.u.e.tierra>.5?.02:.9,p.z+Math.cos(y)*7.5);}
      s.u.update(dt);}
  }
  function fijarPose(n){if(!POSES[n])return;if(n!==poseAct){for(const s of soldados)if(s.u.e.muerte)s.u.revivir();}poseAct=n;tPose=0;}

  /* ---------- cámara en órbita: arrastrar gira, rueda o pellizco acerca ---------- */
  const orb={az:.55,el:.12,dist:4.6,obj:new V3(0,.95,0)};
  function ubicarCamara(){const c=Math.cos(orb.el);camara.position.set(orb.obj.x+Math.sin(orb.az)*c*orb.dist,orb.obj.y+Math.sin(orb.el)*orb.dist,orb.obj.z+Math.cos(orb.az)*c*orb.dist);camara.lookAt(orb.obj);}
  const punteros=new Map();let pinch0=0,dist0=0;
  canvas.style.touchAction='none';
  canvas.addEventListener('pointerdown',ev=>{canvas.setPointerCapture(ev.pointerId);punteros.set(ev.pointerId,{x:ev.clientX,y:ev.clientY});
    if(punteros.size===2){const [a,b]=[...punteros.values()];pinch0=Math.hypot(a.x-b.x,a.y-b.y);dist0=orb.dist;}});
  canvas.addEventListener('pointermove',ev=>{const p=punteros.get(ev.pointerId);if(!p)return;
    if(punteros.size===1){orb.az-=(ev.clientX-p.x)*.008;orb.el=Math.max(-.12,Math.min(1.35,orb.el+(ev.clientY-p.y)*.006));}
    p.x=ev.clientX;p.y=ev.clientY;
    if(punteros.size===2){const [a,b]=[...punteros.values()],d=Math.hypot(a.x-b.x,a.y-b.y);if(pinch0>0)orb.dist=Math.max(1.2,Math.min(16,dist0*pinch0/d));}});
  const fin=ev=>{punteros.delete(ev.pointerId);pinch0=0;};
  canvas.addEventListener('pointerup',fin);canvas.addEventListener('pointercancel',fin);
  canvas.addEventListener('wheel',ev=>{ev.preventDefault();orb.dist=Math.max(1.2,Math.min(16,orb.dist*Math.pow(1.0012,ev.deltaY)));},{passive:false});

  /* ---------- bucle: se frena si el visor no se ve o la pestaña está oculta ---------- */
  let visible=true,ultimo=0,vivo=true;
  if(typeof IntersectionObserver!=='undefined'){const io=new IntersectionObserver(en=>{visible=en[0].isIntersecting;});io.observe(canvas);}
  function dibujar(){ubicarCamara();renderer.render(scene,camara);}
  function cuadro(ahora){
    if(!vivo)return;requestAnimationFrame(cuadro);
    const dt=Math.min(.05,ultimo?(ahora-ultimo)/1000:0);ultimo=ahora;
    if(pausado||!visible||document.hidden)return;
    if(girar)orb.az+=dt*.25;
    paso(dt);dibujar();
  }
  function tam(){const w=canvas.clientWidth||canvas.width,h=canvas.clientHeight||canvas.height;renderer.setSize(w,h,false);camara.aspect=w/h;camara.updateProjectionMatrix();}
  luces();tam();armar();
  if(typeof requestAnimationFrame!=='undefined')requestAnimationFrame(cuadro);

  return {
    rol(n){modo=n==='todos'||ROLES.includes(n)?n:'jefe';orb.obj.set(0,modo==='todos'?.8:.95,modo==='todos'?-.4:0);orb.dist=modo==='todos'?7.5:4.6;armar();},
    pose(n){fijarPose(n);},
    linterna(b){linterna=!!b;aplicarInterruptores();},
    laser(b){laser=!!b;},
    girar(b){girar=!!b;},
    luzPlena(b){plena=!!b;luces();},
    ronda(b){ronda=!!b;tRonda=0;iRonda=Math.max(0,NOMBRES.indexOf(poseAct));},
    pausa(b){pausado=!!b;},
    tam,
    info(){const i=renderer.info.render,r=soldados[0]?UEM.info(soldados[0].rol):null;
      return {triangulos:i.triangles,llamadas:i.calls,soldados:soldados.length,porSoldado:r};},
    /* extras para pruebas y capturas */
    poses:NOMBRES.slice(),roles:ROLES.slice(),
    avanzar(seg,dt=1/60){const n=Math.round(seg/dt);for(let i=0;i<n;i++)paso(dt);},
    dibujar,
    camara(az,el,dist,x,y,z){if(az!==undefined)orb.az=az;if(el!==undefined)orb.el=el;if(dist!==undefined)orb.dist=dist;if(x!==undefined)orb.obj.set(x,y,z);ubicarCamara();},
    interno(){return {renderer,scene,camara,soldados,orb,reflejos,regla,piso};},
    destruir(){vivo=false;quitar();renderer.dispose();}
  };
}
