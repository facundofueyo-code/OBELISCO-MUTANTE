/* ====================================================================================
   UEM · UNIDAD ESPECIAL · modelo, armas y animación de los soldados (Three.js r128)
   ------------------------------------------------------------------------------------
   Todo hecho por código: una SkinnedMesh por soldado (cuerpo + equipo + arma, color por
   vértice, un solo material) y una segunda malla aditiva para lo que brilla (linterna,
   láser, fogonazo, luz de la nuca). Ninguna luz real de Three.js.
   Modelo mirando a +Z, pies en y=0. El lado izquierdo del soldado es +X.
   Contrato: UEM.ROLES · UEM.crear(rol,{semilla}) · UEM.granada() · UEM.calentar(scene,on)
   ==================================================================================== */
const UEM=(()=>{
const V3=THREE.Vector3,Q4=THREE.Quaternion,M4=THREE.Matrix4;
const PI=Math.PI,TAU=PI*2,RAD=PI/180;
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
const sat=x=>x<0?0:x>1?1:x;
const sst=(a,b,x)=>{const t=sat((x-a)/(b-a));return t*t*(3-2*t);};   /* escalón suave */
const ease=t=>t*t*(3-2*t);
const envol=a=>{a=(a+PI)%TAU;if(a<0)a+=TAU;return a-PI;};              /* ángulo a -PI…PI */
/* azar con semilla (el modelo se arma igual en cada carga; cada soldado varía según su semilla) */
function azarDe(s){s=(s>>>0)||1;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}

/* ---------- roles ---------- */
const ROLES={
  jefe:     {nombre:'Jefe',     arma:'fusil',   desc:'Antena larga de radio en la espalda y micrófono. Se queda atrás de la base de fuego y da las órdenes con señas.'},
  asalto:   {nombre:'Asalto',   arma:'escopeta',desc:'Más liviano: sin mochila, canana de cartuchos cruzada y hombreras. Flanquea y empuja de cerca.'},
  granadero:{nombre:'Granadero',arma:'fusil',   desc:'Portagranadas en el pecho y morral al costado. Te saca de la cobertura con granadas.'},
  tirador:  {nombre:'Tirador',  arma:'tirador', desc:'Velo de tela sobre el casco y los hombros, fusil largo con mira, bípode y supresor. Láser rojo antes de cada tiro.'}
};

/* ---------- paleta: color (lineal, como el resto del juego) + aspereza + metal + emisión ----------
   La tela es negra mate; el equipo, gris carbón apenas más claro para que el volumen se lea de noche. */
const PAL={
  tela:   [0x16171b,.96,0,0],   /* uniforme */
  tela2:  [0x1b1c21,.94,0,0],   /* refuerzos, bolsillos */
  equipo: [0x2a2c31,.86,0,0],   /* chaleco, portacargadores, correaje */
  equipo2:[0x34363b,.84,0,0],   /* tapas, hebillas de plástico, bordes */
  velcro: [0x43454a,.98,0,0],   /* velcro vacío: donde iría un parche */
  casco:  [0x1d1e22,.72,.05,0],
  goma:   [0x101114,.48,.0,0],  /* máscara */
  goma2:  [0x191a1e,.55,.0,0],
  metal:  [0x26272a,.42,.75,0], /* hebillas, rieles, filtro */
  arma:   [0x17181a,.50,.55,0], /* acero pavonado */
  poli:   [0x1a1b1d,.66,.05,0], /* polímero del arma */
  cuero:  [0x121214,.58,0,0],   /* borcegos */
  suela:  [0x0b0b0c,.9,0,0],
  guante: [0x18191c,.8,0,0],
  rodilla:[0x232428,.6,.05,0],  /* rodilleras y coderas: plástico duro */
  lente:  [0x16283a,.04,.0,1.1],/* lentes de la máscara: vidrio oscuro con brillo frío tenue (emisivo, no ilumina nada) */
  lente2: [0x30404c,.10,.0,.25],
  vidrio: [0x1a2630,.08,.2,.10],/* ópticas del arma */
  led:    [0xff2010,.4,0,3.2],  /* luz roja de la nuca */
  laton:  [0x8a6a2c,.38,.85,0], /* vainas y culotes */
  cart:   [0x3a1210,.6,0,0],    /* cartuchos de escopeta */
  foco:   [0xd8e4f0,.2,0,.9],   /* lente de la linterna */
  velo:   [0x1e1e20,.98,0,0],   /* velo del tirador: tela opaca, apenas más clara */
  granada:[0x1c1f17,.6,.1,0],   /* granada: verde oliva casi negro */
  /* efectos (malla aditiva): [color, modo, exponente, -]. modo 0 plano, 1 volumen de borde suave, 2 resplandor de frente */
  fxHaz:  [0xfff1d6,1,1.6,0],
  fxNucleo:[0xfff4e0,1,2.4,0],
  fxDeslumbre:[0xfff6ea,2,7,0],
  fxHalo: [0xfff1d6,2,2.5,0],
  fxFogonazo:[0xffc070,0,1,0],
  fxFogoFrente:[0xffd890,2,1.5,0],
  fxLaser:[0xff1a0a,1,1,0],
  fxLaserHalo:[0xff2010,1,2.5,0],
  fxPunto:[0xff3020,0,1,0],
  fxLed:  [0xff2a10,0,1,0],
  fxLente:[0x9fc4ff,2,2.2,0]
};

/* ====================================================================================
   CONSTRUCTOR DE MALLAS
   Junta primitivas redondeadas en una sola geometría con color, material (aspereza, metal,
   emisión) y hueso por vértice. Las normales salen de promediar las caras por área: con los
   chaflanes, las caras grandes quedan planas y los bordes, redondeados.
   ==================================================================================== */
function Constructor(H){               /* H: {nombreDeHueso: índice} */
  const pos=[],nor=[],col=[],uem=[],ski=[],skw=[],idx=[];
  const M=new M4(),N3=new THREE.Matrix3(),pila=[];
  let esp=1,inv=false,cr=1,cg=1,cb=1,ur=1,um=0,ue=0,hueso=0,pesoFn=null,tinteFn=null,tris=0,varia=.06;
  const jit=azarDe(20261003),t=new V3(),n=new V3(),eu=new THREE.Euler(),m2=new M4(),qa=new Q4();
  const G={H};
  /* material actual (clave de PAL) con un factor de brillo opcional */
  G.mat=(clave,k=1)=>{const p=PAL[clave],c=p[0];cr=((c>>16)&255)/255*k;cg=((c>>8)&255)/255*k;cb=(c&255)/255*k;ur=p[1];um=p[2];ue=p[3];return G;};
  G.hueso=nombre=>{if(H[nombre]===undefined)throw new Error('UEM: hueso desconocido '+nombre);hueso=H[nombre];pesoFn=null;return G;};
  G.peso=fn=>{pesoFn=fn;return G;};    /* fn(x,y,z del modelo) → [hueso0,hueso1,peso1] */
  G.tinte=fn=>{tinteFn=fn;return G;};  /* fn(x,y,z del modelo) → factor de brillo, o clave de PAL */
  G.lado=s=>{esp=s;return G;};         /* -1: espeja en X (lado derecho) */
  G.varia=v=>{varia=v;return G;};
  /* transformación local de lo que se emite a continuación */
  G.en=(x=0,y=0,z=0,rx=0,ry=0,rz=0,orden='YXZ')=>{eu.set(rx,ry,rz,orden);M.makeRotationFromEuler(eu);M.setPosition(x,y,z);return G;};
  G.guardar=()=>{pila.push(M.clone());return G;};
  G.volver=()=>{M.copy(pila.pop());return G;};
  G.mover=(x,y,z,rx=0,ry=0,rz=0,orden='YXZ')=>{eu.set(rx,ry,rz,orden);m2.makeRotationFromEuler(eu);m2.setPosition(x,y,z);M.multiply(m2);return G;};
  G.escala=(x,y,z)=>{m2.makeScale(x,y,z);M.multiply(m2);return G;};
  G.tris=()=>tris;

  function emit(P,T){
    const nv=P.length/3,NN=new Float32Array(P.length);
    for(let i=0;i<T.length;i+=3){const a=T[i]*3,b=T[i+1]*3,c=T[i+2]*3;
      const ux=P[b]-P[a],uy=P[b+1]-P[a+1],uz=P[b+2]-P[a+2],vx=P[c]-P[a],vy=P[c+1]-P[a+1],vz=P[c+2]-P[a+2];
      const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
      NN[a]+=nx;NN[a+1]+=ny;NN[a+2]+=nz;NN[b]+=nx;NN[b+1]+=ny;NN[b+2]+=nz;NN[c]+=nx;NN[c+1]+=ny;NN[c+2]+=nz;}
    N3.getNormalMatrix(M);const giro=(M.determinant()<0)!==(esp<0)!==inv,base=pos.length/3,k=1+(jit()-.5)*2*varia;
    for(let i=0;i<nv;i++){
      t.set(P[i*3],P[i*3+1],P[i*3+2]).applyMatrix4(M);n.set(NN[i*3],NN[i*3+1],NN[i*3+2]).applyMatrix3(N3);
      if(inv)n.negate();
      if(n.lengthSq()<1e-20)n.set(0,1,0);else n.normalize();
      if(esp<0){t.x=-t.x;n.x=-n.x;}
      pos.push(t.x,t.y,t.z);nor.push(n.x,n.y,n.z);
      let r=cr*k,g=cg*k,b=cb*k,a=ur,m=um,e=ue;
      if(tinteFn){const f=tinteFn(t.x,t.y,t.z);
        if(typeof f==='string'){const p=PAL[f],c=p[0];r=((c>>16)&255)/255*k;g=((c>>8)&255)/255*k;b=(c&255)/255*k;a=p[1];m=p[2];e=p[3];}
        else{r*=f;g*=f;b*=f;}}
      col.push(r,g,b);uem.push(a,m,e);
      if(pesoFn){const w=pesoFn(t.x,t.y,t.z);ski.push(w[0],w[1],0,0);skw.push(1-w[2],w[2],0,0);}
      else{ski.push(hueso,0,0,0);skw.push(1,0,0,0);}
    }
    for(let i=0;i<T.length;i+=3){if(giro)idx.push(base+T[i],base+T[i+2],base+T[i+1]);else idx.push(base+T[i],base+T[i+1],base+T[i+2]);}
    tris+=T.length/3;
  }
  /* da vuelta los triángulos que miran hacia el punto de referencia (para primitivas convexas) */
  function afuera(P,T,ref){
    for(let i=0;i<T.length;i+=3){const a=T[i]*3,b=T[i+1]*3,c=T[i+2]*3;
      const ux=P[b]-P[a],uy=P[b+1]-P[a+1],uz=P[b+2]-P[a+2],vx=P[c]-P[a],vy=P[c+1]-P[a+1],vz=P[c+2]-P[a+2];
      const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
      const gx=(P[a]+P[b]+P[c])/3,gy=(P[a+1]+P[b+1]+P[c+1])/3,gz=(P[a+2]+P[b+2]+P[c+2])/3;
      const R=typeof ref==='function'?ref(gx,gy,gz):ref;
      if(nx*(gx-R[0])+ny*(gy-R[1])+nz*(gz-R[2])<0){const s=T[i+1];T[i+1]=T[i+2];T[i+2]=s;}}
  }
  G.emit=emit;G.afuera=afuera;
  G.invertir=v=>{inv=v;return G;};     /* caras hacia adentro (interior de un casco, de una capucha) */

  /* caja con chaflán, centrada. c=0: aristas vivas */
  G.caja=(sx,sy,sz,c)=>{const hx=sx/2,hy=sy/2,hz=sz/2;
    if(c===undefined)c=Math.min(sx,sy,sz)*.2;c=Math.min(c,hx*.9,hy*.9,hz*.9);
    const P=[],T=[],v=(i,j,k,f)=>(i*4+j*2+k)*3+f,q=(a,b,c_,d)=>T.push(a,b,c_,a,c_,d);
    for(let i=0;i<2;i++)for(let j=0;j<2;j++)for(let k=0;k<2;k++){const x=i?1:-1,y=j?1:-1,z=k?1:-1;
      P.push(x*hx,y*(hy-c),z*(hz-c), x*(hx-c),y*hy,z*(hz-c), x*(hx-c),y*(hy-c),z*hz);}
    for(let i=0;i<2;i++){q(v(i,0,0,0),v(i,1,0,0),v(i,1,1,0),v(i,0,1,0));q(v(0,i,0,1),v(1,i,0,1),v(1,i,1,1),v(0,i,1,1));q(v(0,0,i,2),v(1,0,i,2),v(1,1,i,2),v(0,1,i,2));}
    if(c>0){for(let i=0;i<2;i++)for(let j=0;j<2;j++){q(v(i,j,0,0),v(i,j,1,0),v(i,j,1,1),v(i,j,0,1));q(v(i,0,j,0),v(i,1,j,0),v(i,1,j,2),v(i,0,j,2));q(v(0,i,j,1),v(1,i,j,1),v(1,i,j,2),v(0,i,j,2));}
      for(let i=0;i<2;i++)for(let j=0;j<2;j++)for(let k=0;k<2;k++)T.push(v(i,j,k,0),v(i,j,k,1),v(i,j,k,2));}
    afuera(P,T,[0,0,0]);
    if(c<=0){/* sin chaflán: una cara por lado, sin compartir vértices */
      for(let f=0;f<12;f+=2){emit([0,1,2,3,4,5].map(o=>T[f*3+o]).reduce((a,ix)=>(a.push(P[ix*3],P[ix*3+1],P[ix*3+2]),a),[]),[0,1,2,3,4,5]);}return G;}
    emit(P,T);return G;};

  /* cilindro o cono a lo largo de +Y, de 0 a h. tapas: 1 abajo, 2 arriba, 3 las dos */
  G.cil=(r0,r1,h,seg=8,tapas=3)=>{const P=[],T=[];
    for(let i=0;i<seg;i++){const a=i/seg*TAU,c=Math.cos(a),s=Math.sin(a);P.push(c*r0,0,s*r0,c*r1,h,s*r1);}
    for(let i=0;i<seg;i++){const a=i*2,b=((i+1)%seg)*2;if(r1>1e-6)T.push(a,a+1,b+1);if(r0>1e-6)T.push(a,b+1,b);}
    emit(P,T);
    for(const top of [0,1]){if(!(tapas&(top?2:1)))continue;const r=top?r1:r0;if(r<1e-6)continue;const Pc=[0,top?h:0,0],Tc=[];
      for(let i=0;i<seg;i++){const a=i/seg*TAU;Pc.push(Math.cos(a)*r,top?h:0,Math.sin(a)*r);}
      for(let i=0;i<seg;i++){const a=1+i,b=1+(i+1)%seg;if(top)Tc.push(0,b,a);else Tc.push(0,a,b);}
      emit(Pc,Tc);}
    return G;};
  /* cilindro entre dos puntos */
  G.tubo=(ax,ay,az,bx,by,bz,r0,r1,seg=8,tapas=3)=>{t.set(bx-ax,by-ay,bz-az);const L=t.length();if(L<1e-6)return G;
    qa.setFromUnitVectors(n.set(0,1,0),t.multiplyScalar(1/L));G.guardar();m2.makeRotationFromQuaternion(qa);m2.setPosition(ax,ay,az);M.multiply(m2);G.cil(r0,r1===undefined?r0:r1,L,seg,tapas);return G.volver();};

  /* torno alrededor de Y. perfil: [[r,y],…] recorrido de abajo hacia arriba por afuera. Un punto repetido corta el suavizado (arista viva) */
  G.torno=(perfil,seg=10)=>{let ini=0;
    for(let k=1;k<=perfil.length;k++){
      const corte=k===perfil.length||(Math.abs(perfil[k][0]-perfil[k-1][0])<1e-9&&Math.abs(perfil[k][1]-perfil[k-1][1])<1e-9);
      if(!corte)continue;const tr=perfil.slice(ini,k);ini=k;if(tr.length<2)continue;
      const P=[],T=[];for(const [r,y] of tr)for(let i=0;i<seg;i++){const a=i/seg*TAU;P.push(Math.cos(a)*r,y,Math.sin(a)*r);}
      for(let j=0;j<tr.length-1;j++)for(let i=0;i<seg;i++){const a=j*seg+i,b=j*seg+(i+1)%seg,a1=a+seg,b1=b+seg;
        if(tr[j+1][0]>1e-6)T.push(a,a1,b1);if(tr[j][0]>1e-6)T.push(a,b1,b);}
      emit(P,T);}
    return G;};

  /* piel entre secciones apiladas en Y. sección: [y, cx, cz, rx, rzAdelante, rzAtrás, exponente]
     (exponente 2 = elipse; más alto = más cuadrado). tapa: 1 primera, 2 última */
  G.loft=(secs,seg=10,tapa=3,nDef=2)=>{const P=[],T=[],S=secs.length;
    for(const s of secs){const y=s[0],cx=s[1]||0,cz=s[2]||0,rx=s[3],rf=s[4]===undefined?rx:s[4],rb=s[5]===undefined?rf:s[5],ex=2/(s[6]||nDef);
      for(let i=0;i<seg;i++){const a=i/seg*TAU,c=Math.cos(a),sn=Math.sin(a);
        P.push(cx+rx*Math.sign(c)*Math.pow(Math.abs(c),ex),y,cz+(sn>=0?rf:rb)*Math.sign(sn)*Math.pow(Math.abs(sn),ex));}}
    const sube=secs[S-1][0]>=secs[0][0];
    for(let j=0;j<S-1;j++)for(let i=0;i<seg;i++){const a=j*seg+i,b=j*seg+(i+1)%seg,a1=a+seg,b1=b+seg;
      if(sube)T.push(a,a1,b1,a,b1,b);else T.push(a,b1,a1,a,b,b1);}
    for(const fin of [0,1]){if(!(tapa&(fin?2:1)))continue;const j=fin?S-1:0,s=secs[j],c=P.length/3;P.push(s[1]||0,s[0],s[2]||0);
      for(let i=0;i<seg;i++){const a=j*seg+i,b=j*seg+(i+1)%seg;if((fin===1)===sube)T.push(c,b,a);else T.push(c,a,b);}}
    emit(P,T);return G;};

  /* elipsoide. opt.f0, opt.f1: ángulo polar inicial y final (0 = polo de arriba); opt.corte(az) → ángulo final por azimut (casco) */
  G.esfera=(rx,ry,rz,seg=10,anillos=6,opt={})=>{const P=[],T=[],f0=opt.f0||0,polo=f0<1e-6;
    const fin=a=>opt.corte?opt.corte(a):(opt.f1===undefined?PI:opt.f1);
    if(polo)P.push(0,ry,0);
    for(let j=polo?1:0;j<=anillos;j++)for(let i=0;i<seg;i++){const a=i/seg*TAU,f=f0+(fin(a)-f0)*j/anillos,sf=Math.sin(f);
      P.push(rx*sf*Math.cos(a),ry*Math.cos(f),rz*sf*Math.sin(a));}
    const fila=j=>polo?1+(j-1)*seg:j*seg;
    for(let j=polo?1:0;j<anillos;j++)for(let i=0;i<seg;i++){const a=fila(j)+i,b=fila(j)+(i+1)%seg,a1=a+seg,b1=b+seg;T.push(a,b,b1,a,b1,a1);}
    if(polo)for(let i=0;i<seg;i++)T.push(0,1+(i+1)%seg,1+i);
    const cierra=!opt.corte&&(opt.f1===undefined||opt.f1>PI-1e-6);
    if(!cierra&&opt.tapa){const c=P.length/3,j=anillos;let cy=0;for(let i=0;i<seg;i++)cy+=P[(fila(j)+i)*3+1];P.push(0,cy/seg,0);for(let i=0;i<seg;i++)T.push(c,fila(j)+i,fila(j)+(i+1)%seg);}
    afuera(P,T,[0,opt.refY||0,0]);emit(P,T);return G;};

  /* prisma: polígono en XY (cualquier forma, sin agujeros) extruido en Z con espesor e y chaflán c.
     suave: las esquinas del contorno se redondean (equipo blando); si no, quedan facetadas (piezas del arma) */
  G.prisma=(poly,e,c=0,suave=false)=>{let ar=0;const np=poly.length;
    for(let i=0;i<np;i++){const p=poly[i],q=poly[(i+1)%np];ar+=p[0]*q[1]-q[0]*p[1];}
    if(ar<0)poly=poly.slice().reverse();
    c=Math.min(c,e*.45);const h=e/2;
    /* contorno achicado para las caras de adelante y atrás */
    let ins=poly;if(c>0){const E=[];for(let i=0;i<np;i++){const a=poly[i],b=poly[(i+1)%np];let dx=b[0]-a[0],dy=b[1]-a[1];const l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;E.push([a[0]-dy*c,a[1]+dx*c,dx,dy]);}
      ins=[];for(let i=0;i<np;i++){const A=E[(i+np-1)%np],B=E[i],den=A[2]*B[3]-A[3]*B[2];
        if(Math.abs(den)<1e-5){ins.push([B[0],B[1]]);continue;}const tt=((B[0]-A[0])*B[3]-(B[1]-A[1])*B[2])/den;ins.push([A[0]+A[2]*tt,A[1]+A[3]*tt]);}}
    const caras=THREE.ShapeUtils.triangulateShape(ins.map(p=>new THREE.Vector2(p[0],p[1])),[]);
    if(suave){const P=[],T=[];
      for(const p of ins)P.push(p[0],p[1],h);for(const p of poly)P.push(p[0],p[1],h-c);for(const p of poly)P.push(p[0],p[1],-h+c);for(const p of ins)P.push(p[0],p[1],-h);
      for(const f of caras){T.push(f[0],f[1],f[2]);T.push(3*np+f[0],3*np+f[2],3*np+f[1]);}
      for(let i=0;i<np;i++){const j=(i+1)%np;for(let k=0;k<3;k++){if(c<=0&&k!==1)continue;const a=k*np+i,b=k*np+j,a1=a+np,b1=b+np;T.push(a,a1,b1,a,b1,b);}}
      emit(P,T);return G;}
    {const P=[],T=[];for(const p of ins)P.push(p[0],p[1],h);for(const f of caras)T.push(f[0],f[1],f[2]);emit(P,T);}
    {const P=[],T=[];for(const p of ins)P.push(p[0],p[1],-h);for(const f of caras)T.push(f[0],f[2],f[1]);emit(P,T);}
    for(let i=0;i<np;i++){const j=(i+1)%np,a=poly[i],b=poly[j],ia=ins[i],ib=ins[j];
      emit([a[0],a[1],h-c,a[0],a[1],-h+c,b[0],b[1],-h+c,b[0],b[1],h-c],[0,1,2,0,2,3]);
      if(c>0){emit([ia[0],ia[1],h,a[0],a[1],h-c,b[0],b[1],h-c,ib[0],ib[1],h],[0,1,2,0,2,3]);
        emit([a[0],a[1],-h+c,ia[0],ia[1],-h,ib[0],ib[1],-h,b[0],b[1],-h+c],[0,1,2,0,2,3]);}}
    return G;};

  /* cinta (correa) a lo largo de puntos: ancho w de costado, espesor e hacia la normal nh (vector o función del índice) */
  G.cinta=(pts,w,e,nh)=>{const P=[],T=[],C=[],tg=new V3(),sd=new V3(),up=new V3(),N=pts.length;
    for(let i=0;i<N;i++){const p=pts[i],a=pts[Math.max(0,i-1)],b=pts[Math.min(N-1,i+1)];tg.set(b[0]-a[0],b[1]-a[1],b[2]-a[2]).normalize();
      const h=typeof nh==='function'?nh(i,p):nh;up.set(h[0],h[1],h[2]);sd.crossVectors(tg,up).normalize();up.crossVectors(sd,tg).normalize();
      C.push(p);for(const [s,u] of [[1,1],[-1,1],[-1,-1],[1,-1]])P.push(p[0]+sd.x*s*w/2+up.x*u*e/2,p[1]+sd.y*s*w/2+up.y*u*e/2,p[2]+sd.z*s*w/2+up.z*u*e/2);}
    for(let i=0;i<N-1;i++)for(let k=0;k<4;k++){const a=i*4+k,b=i*4+(k+1)%4,a1=a+4,b1=b+4;T.push(a,a1,b1,a,b1,b);}
    T.push(0,1,2,0,2,3);const z=(N-1)*4;T.push(z,z+2,z+1,z,z+3,z+2);
    const nt=T.length/3;let it=0;
    afuera(P,T,(gx,gy,gz)=>{const k=it++;if(k>=nt-4){const q=C[k<nt-2?Math.min(1,N-1):Math.max(0,N-2)];return q;}
      let best=0,bd=1e9;for(let i=0;i<N;i++){const d=(C[i][0]-gx)**2+(C[i][1]-gy)**2+(C[i][2]-gz)**2;if(d<bd){bd=d;best=i;}}
      const i0=Math.max(0,Math.min(N-2,best)),q0=C[i0],q1=C[i0+1];return [(q0[0]+q1[0])/2,(q0[1]+q1[1])/2,(q0[2]+q1[2])/2];});
    emit(P,T);return G;};

  /* disco plano mirando a +Y (o anillo si r0>0) */
  G.disco=(r,seg=10,r0=0)=>{const P=[],T=[];
    if(r0<=0){P.push(0,0,0);for(let i=0;i<seg;i++){const a=i/seg*TAU;P.push(Math.cos(a)*r,0,Math.sin(a)*r);}for(let i=0;i<seg;i++)T.push(0,1+(i+1)%seg,1+i);}
    else{for(let i=0;i<seg;i++){const a=i/seg*TAU,c=Math.cos(a),s=Math.sin(a);P.push(c*r0,0,s*r0,c*r,0,s*r);}for(let i=0;i<seg;i++){const a=i*2,b=((i+1)%seg)*2;T.push(a,b,b+1,a,b+1,a+1);}}
    emit(P,T);return G;};

  /* toro alrededor de Y */
  G.toro=(R,r,segR=12,segr=5)=>{const P=[],T=[];
    for(let i=0;i<segR;i++){const a=i/segR*TAU;for(let j=0;j<segr;j++){const b=j/segr*TAU,q=R+Math.cos(b)*r;P.push(Math.cos(a)*q,Math.sin(b)*r,Math.sin(a)*q);}}
    for(let i=0;i<segR;i++)for(let j=0;j<segr;j++){const a=i*segr+j,b=i*segr+(j+1)%segr,a1=((i+1)%segR)*segr+j,b1=((i+1)%segR)*segr+(j+1)%segr;T.push(a,b,b1,a,b1,a1);}
    afuera(P,T,(gx,gy,gz)=>{const l=Math.hypot(gx,gz)||1;return [gx/l*R,0,gz/l*R];});emit(P,T);return G;};

  /* orienta lo que sigue para que su +Y apunte a (dx,dy,dz), parado en (x,y,z); giro: vuelta extra sobre ese eje */
  G.dir=(x,y,z,dx,dy,dz,giro=0)=>{t.set(dx,dy,dz).normalize();qa.setFromUnitVectors(n.set(0,1,0),t);
    if(giro){const q2=new Q4().setFromAxisAngle(n.set(0,1,0),giro);qa.multiply(q2);}
    M.makeRotationFromQuaternion(qa);M.setPosition(x,y,z);return G;};
  /* manguera: tubo redondo a lo largo de una polilínea (dedos, cables). rads: número o lista por punto */
  G.manguera=(pts,rads,seg=5,tapas=3)=>{const P=[],T=[],N=pts.length,tg=new V3(),rf=new V3(),nn=new V3(),bb=new V3();
    for(let i=0;i<N;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(N-1,i+1)];tg.set(b[0]-a[0],b[1]-a[1],b[2]-a[2]).normalize();
      if(i===0){rf.set(0,0,1);if(Math.abs(tg.z)>.85)rf.set(1,0,0);nn.crossVectors(rf,tg).normalize();}
      else{nn.addScaledVector(tg,-nn.dot(tg));if(nn.lengthSq()<1e-12){rf.set(0,1,0);nn.crossVectors(rf,tg);}nn.normalize();}
      bb.crossVectors(tg,nn);const r=Array.isArray(rads)?rads[i]:rads;
      for(let k=0;k<seg;k++){const th=k/seg*TAU,c=Math.cos(th),s=Math.sin(th);
        P.push(pts[i][0]+r*(c*nn.x+s*bb.x),pts[i][1]+r*(c*nn.y+s*bb.y),pts[i][2]+r*(c*nn.z+s*bb.z));}}
    for(let i=0;i<N-1;i++)for(let k=0;k<seg;k++){const a=i*seg+k,b=i*seg+(k+1)%seg;T.push(a,b,b+seg,a,b+seg,a+seg);}
    const nl=T.length/3;let c0=-1,c1=-1;
    if(tapas&1){c0=P.length/3;P.push(pts[0][0],pts[0][1],pts[0][2]);for(let k=0;k<seg;k++)T.push(c0,(k+1)%seg,k);}
    if(tapas&2){c1=P.length/3;const e=pts[N-1],o=(N-1)*seg;P.push(e[0],e[1],e[2]);for(let k=0;k<seg;k++)T.push(c1,o+k,o+(k+1)%seg);}
    /* sentido de las caras: hacia afuera del eje (las tapas, hacia afuera del extremo) */
    let it=0;const p0=pts[0],p1=pts[Math.min(1,N-1)],q0=pts[N-1],q1=pts[Math.max(0,N-2)];
    afuera(P,T,(gx,gy,gz)=>{const k=it++;
      if(k>=nl){const fin=(tapas&1)&&k<nl+seg?0:1;const a=fin?q0:p0,b=fin?q1:p1;return [(a[0]*2+b[0])/3,(a[1]*2+b[1])/3,(a[2]*2+b[2])/3];}
      let best=0,bd=1e9;for(let i=0;i<N-1;i++){const a=pts[i],b=pts[i+1];const vx=b[0]-a[0],vy=b[1]-a[1],vz=b[2]-a[2];
        let u=((gx-a[0])*vx+(gy-a[1])*vy+(gz-a[2])*vz)/(vx*vx+vy*vy+vz*vz||1);u=u<0?0:u>1?1:u;
        const d=(a[0]+vx*u-gx)**2+(a[1]+vy*u-gy)**2+(a[2]+vz*u-gz)**2;if(d<bd){bd=d;best=[a[0]+vx*u,a[1]+vy*u,a[2]+vz*u];}}
      return best;});
    emit(P,T);return G;};
  /* triángulos sueltos ya armados (para mallas a medida: velo, haces) */
  G.crudo=(P,T)=>{emit(P,T);return G;};

  /* geometría final */
  G.fin=()=>{const g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(nor,3));
    g.setAttribute('color',new THREE.Float32BufferAttribute(col,3));g.setAttribute('uem',new THREE.Float32BufferAttribute(uem,3));
    g.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(ski,4));g.setAttribute('skinWeight',new THREE.Float32BufferAttribute(skw,4));
    g.setIndex(pos.length/3>65535?new THREE.Uint32BufferAttribute(idx,1):new THREE.Uint16BufferAttribute(idx,1));
    g.userData.tris=tris;return g;};
  return G;
}

/* ====================================================================================
   ESQUELETO
   Huesos "planos": todos cuelgan del mismo grupo y en cada cuadro se les escribe la
   transformación en el espacio del modelo. La jerarquía la resolvemos nosotros (PADRE/OFF),
   así podemos mezclar poses, hacer IK y soltar el arma sin pelear con la de Three.
   En la pose de enlace todos los huesos tienen rotación identidad y están en su articulación:
   la geometría se arma directamente en esa pose (brazos colgando, palmas hacia el muslo).
   Los huesos que nacen en el origen (arma, cargador, FX…) tienen su geometría en coordenadas
   propias: el arma apunta a +Z con el origen en la cantonera.
   ==================================================================================== */
const HUESOS=[
  /* nombre        padre          articulación (x,y,z) */
  ['cadera',     null,          0,    .975,  0],
  ['columna',    'cadera',      0,    1.10, -.005],
  ['pecho',      'columna',     0,    1.27, -.01],
  ['cuello',     'pecho',       0,    1.505,-.015],
  ['cabeza',     'cuello',      0,    1.585, 0],
  ['brazoI',     'pecho',       .19,  1.45, -.025],
  ['antebrazoI', 'brazoI',      .19,  1.15, -.025],
  ['manoI',      'antebrazoI',  .19,  .885, -.025],
  ['dedosI',     'manoI',       .19,  .79,  -.025],   /* nudillos: falanges proximales */
  ['dedosI2',    'dedosI',      .19,  .745, -.025],   /* falanges medias y distales */
  ['brazoD',     'pecho',      -.19,  1.45, -.025],
  ['antebrazoD', 'brazoD',     -.19,  1.15, -.025],
  ['manoD',      'antebrazoD', -.19,  .885, -.025],
  ['indiceD',    'manoD',      -.19,  .79,   .005],   /* índice derecho: fuera del gatillo o adentro */
  ['musloI',     'cadera',      .095, .93,   0],
  ['piernaI',    'musloI',      .095, .50,   0],
  ['pieI',       'piernaI',     .095, .085,  0],
  ['punteraI',   'pieI',        .095, .025,  .135],
  ['musloD',     'cadera',     -.095, .93,   0],
  ['piernaD',    'musloD',     -.095, .50,   0],
  ['pieD',       'piernaD',    -.095, .085,  0],
  ['punteraD',   'pieD',       -.095, .025,  .135],
  /* sueltos (origen propio) */
  ['arma',null,0,0,0],['cargador',null,0,0,0],['corredera',null,0,0,0],['bipode',null,0,0,0],
  ['granada',null,0,0,0],['vaina1',null,0,0,0],['vaina2',null,0,0,0],
  ['antena1',null,0,0,0],['antena2',null,0,0,0],['antena3',null,0,0,0],
  ['haz',null,0,0,0],['fogonazo',null,0,0,0],['laser',null,0,0,0],['laserPunto',null,0,0,0],['led',null,0,0,0]
];
const NH=HUESOS.length,H={},PADRE=[],BIND=[],OFF=[];
HUESOS.forEach((h,i)=>{H[h[0]]=i;});
HUESOS.forEach((h,i)=>{PADRE[i]=h[1]===null?-1:H[h[1]];BIND[i]=new V3(h[2],h[3],h[4]);});
HUESOS.forEach((h,i)=>{OFF[i]=PADRE[i]<0?BIND[i].clone():BIND[i].clone().sub(BIND[PADRE[i]]);});
const NCUERPO=H.punteraD+1;                 /* los primeros NCUERPO huesos forman el cuerpo */
/* inversas de enlace: solo traslación (rotación identidad en la pose de enlace) */
const INVERSAS=BIND.map(b=>new M4().makeTranslation(-b.x,-b.y,-b.z));

/* largos de los segmentos (salen de las articulaciones de arriba) */
const L_BRAZO=.30,L_ANTEBRAZO=.265,L_MUSLO=.43,L_PIERNA=.415;
const ALTO_TOBILLO=.085;                     /* tobillo sobre la suela con el pie plano */

/* esferas de impacto: [hueso, x,y,z en el marco del hueso, radio, parte]. Un 10 % más grandes
   que el cuerpo; se recalculan solo cuando alguien pregunta (u.rayo) */
const ESFERAS=[
  ['cabeza',0,.085,.012,.135,'cabeza'],['cuello',0,.035,0,.075,'cabeza'],
  ['pecho',0,.07,.015,.205,'torso'],['pecho',0,.19,-.005,.175,'torso'],['columna',0,.06,0,.185,'torso'],['cadera',0,-.03,-.005,.195,'torso'],
  ['brazoI',0,-.08,0,.075,'brazo'],['brazoI',0,-.21,0,.065,'brazo'],['antebrazoI',0,-.07,0,.06,'brazo'],['antebrazoI',0,-.19,0,.052,'brazo'],['manoI',0,-.07,0,.058,'brazo'],
  ['brazoD',0,-.08,0,.075,'brazo'],['brazoD',0,-.21,0,.065,'brazo'],['antebrazoD',0,-.07,0,.06,'brazo'],['antebrazoD',0,-.19,0,.052,'brazo'],['manoD',0,-.07,0,.058,'brazo'],
  ['musloI',0,-.1,0,.105,'pierna'],['musloI',0,-.3,0,.088,'pierna'],['piernaI',0,-.1,0,.075,'pierna'],['piernaI',0,-.3,0,.066,'pierna'],['pieI',0,-.03,.06,.078,'pierna'],
  ['musloD',0,-.1,0,.105,'pierna'],['musloD',0,-.3,0,.088,'pierna'],['piernaD',0,-.1,0,.075,'pierna'],['piernaD',0,-.3,0,.066,'pierna'],['pieD',0,-.03,.06,.078,'pierna']
].map(e=>({b:H[e[0]],o:new V3(e[1],e[2],e[3]),r:e[4],parte:e[5]}));

/* ====================================================================================
   CUERPO Y EQUIPO
   Todo en la pose de enlace (brazos colgando). Las piezas de los dos lados se arman del lado
   izquierdo (+X) y se espejan con G.lado(-1). Pesos rígidos salvo el torso y el velo, que
   reparten entre dos huesos para que la cintura y el cuello doblen sin cortes.
   ==================================================================================== */

/* torso: cadera → columna → pecho según la altura */
const pesoTorso=(x,y,z)=>y<1.10?[H.cadera,H.columna,sst(1.00,1.10,y)]:[H.columna,H.pecho,sst(1.15,1.29,y)];

/* ---------- agarre de las manos ----------
   Coordenadas de la mano IZQUIERDA en la pose de enlace, relativas a la muñeca: la palma mira a -X,
   los dedos a -Y, el pulgar a +Z. La derecha es su espejo en X (palma a +X).
   El objeto agarrado es un cilindro que cruza la palma en diagonal (de la base del meñique hacia la
   del índice): pasa por C con dirección (0,-sin d, cos d). */
const AGARRE={
  I:{c:new V3(-.037,-.082,0),d:.42,r:.024},   /* guardamanos */
  D:{c:new V3(-.036,-.084,0),d:.36,r:.017}    /* empuñadura de pistola */
};
const DEDOS=[ /* z del nudillo, y del nudillo, largo, radio  (índice → meñique) */
  [.030,-.093,.086,.0088],[.0095,-.097,.094,.0092],[-.0105,-.095,.089,.0089],[-.029,-.089,.072,.0080]];

/* curva de un dedo envolviendo el cilindro del agarre (coordenadas de mano izquierda) */
function curvaDedo(ag,zk,yk,largo,cierre=1){
  const td=Math.tan(ag.d),cx=ag.c.x,cy=ag.c.y-zk*td,kx=.002,ky=yk;
  const R0=Math.hypot(kx-cx,ky-cy),R=ag.r+.0095,a0=Math.atan2(ky-cy,kx-cx);
  const vuelta=largo/((R0+R)/2)*cierre,pts=[],N=5;
  for(let i=0;i<=N;i++){const s=i/N,a=a0-s*vuelta,r=lerp(R0,R,ease(Math.min(1,s*1.6)));
    /* el dedo baja un poco por el cilindro diagonal a medida que lo rodea */
    pts.push([cx+Math.cos(a)*r,cy+Math.sin(a)*r-s*.004,zk]);}
  return pts;
}

/* mano con guante. lado 1: izquierda (dedos en dos huesos, se abren para las señas);
   lado -1: derecha (dedos fijos alrededor de la empuñadura, índice en su propio hueso) */
function mano(G,lado){
  const izq=lado>0,W=BIND[izq?H.manoI:H.manoD],wx=Math.abs(W.x),wy=W.y,wz=W.z,ag=izq?AGARRE.I:AGARRE.D;
  const P=(x,y,z)=>[wx+x,wy+y,wz+z];
  G.lado(lado).hueso(izq?'manoI':'manoD').mat('guante');
  /* palma y dorso */
  G.en(wx,wy-.05,wz).caja(.03,.094,.084,.013);
  G.mat('equipo2').en(wx+.017,wy-.07,wz).caja(.009,.034,.07,.004);           /* protector de nudillos */
  G.mat('guante').en(wx,wy-.012,wz).escala(1,1,1.12).cil(.037,.04,.05,10,0);  /* puño del guante */
  G.mat('equipo2').en(wx,wy+.03,wz).escala(1,1,1.12).cil(.041,.041,.012,10,0);
  /* pulgar (fijo): sobre el guardamanos apunta adelante; en la empuñadura, la rodea */
  const pu=izq?[[-.006,-.028,.034],[-.016,-.048,.052],[-.024,-.066,.068],[-.028,-.082,.08]]
              :[[-.006,-.028,.034],[-.022,-.045,.046],[-.042,-.058,.05],[-.056,-.07,.046]];
  G.mat('guante').en(0,0,0).manguera(pu.map(p=>P(...p)),[.011,.0105,.0095,.0085],5,3);
  if(izq){
    /* cuatro dedos rectos en la pose de enlace: proximal en dedosI, el resto en dedosI2 */
    const yk=BIND[H.dedosI].y-wy,yk2=BIND[H.dedosI2].y-wy;
    for(const [zk,ykk,lg,r] of DEDOS){const s0=yk2+.003,e=Math.min(ykk-lg+.002,yk2-.016);
      G.hueso('dedosI').manguera([P(.002,ykk+.004,zk),P(.002,yk2-.002,zk)],[r,r*.97],5,1);
      G.hueso('dedosI2').manguera([P(.002,s0,zk),P(.002,lerp(s0,e,.5),zk),P(.0015,lerp(s0,e,.85),zk),P(0,e,zk)],[r*.96,r*.92,r*.8,r*.45],5,2);
    }
  }else{
    /* medio, anular y meñique envolviendo la empuñadura; el índice va aparte */
    for(let i=1;i<4;i++){const [zk,yk,lg,r]=DEDOS[i];
      const c=curvaDedo(ag,zk,yk,lg).map(p=>P(...p));G.manguera(c,[r,r,r*.97,r*.93,r*.85,r*.5],5,2);}
    const [zk,yk,lg,r]=DEDOS[0],K=BIND[H.indiceD];
    G.hueso('indiceD').manguera([P(.002,yk+.004,zk),P(.002,yk-.04,zk),P(-.006,yk-.068,zk),P(-.013,yk-lg+.008,zk),P(-.015,yk-lg+.002,zk)],[r,r*.95,r*.9,r*.75,r*.4],5,2);
  }
  G.lado(1);
}

/* brazo: hombro, manga, codera, antebrazo */
function brazo(G,lado,rol){
  const izq=lado>0,b=izq?'I':'D',S=BIND[H['brazo'+b]],E=BIND[H['antebrazo'+b]],x=Math.abs(S.x);
  G.lado(lado).hueso('brazo'+b).mat('tela');
  G.en(x,S.y-.004,S.z).esfera(.067,.071,.069,10,5);
  G.en(0,0,0).loft([[S.y-.005,x,S.z,.063,.063,.065],[1.33,x,S.z,.06,.061,.061],[1.22,x,-.025,.053,.055,.054],[E.y-.01,x,E.z,.051,.052,.052]],10,0);
  G.mat('velcro').en(x+.058,1.36,S.z+.002,0,0,-.08).caja(.006,.062,.072,0);       /* velcro vacío */
  if(rol==='asalto'){G.mat('equipo2').en(x+.016,S.y+.018,S.z).esfera(.088,.07,.086,10,3,{f1:1.3,tapa:false});
    G.mat('equipo2').invertir(true).en(x+.016,S.y+.014,S.z).esfera(.084,.066,.082,8,2,{f1:1.3}).invertir(false);}
  G.hueso('antebrazo'+b).mat('tela');
  G.en(x,E.y,E.z).esfera(.051,.051,.051,8,4);
  G.en(0,0,0).loft([[E.y,x,E.z,.051,.052,.052],[1.06,x,-.022,.048,.049,.047],[.95,x,-.025,.04,.041,.039],[.90,x,-.025,.038,.038,.038]],10,0);
  G.mat('rodilla').en(x,E.y-.008,E.z-.04,-.12,0,0).esfera(.047,.058,.03,8,4);         /* codera */
  G.mat('equipo2').en(x,E.y-.07,E.z-.004).cil(.05,.049,.016,10,0);                    /* correa de la codera */
  G.lado(1);
}

/* pierna: pantalón amplio con bolsillo, rodillera, canilla y borceguí (puntera en su propio hueso) */
function pierna(G,lado){
  const izq=lado>0,b=izq?'I':'D',x=.095;
  G.lado(lado).hueso('muslo'+b).mat('tela');
  G.en(x+.006,.935,-.005).esfera(.106,.1,.106,8,4);
  G.en(0,0,0).loft([[.95,.104,0,.106,.102,.108],[.85,.106,.005,.103,.101,.103],[.72,.103,.008,.094,.092,.09],[.60,.099,.006,.082,.081,.079],[.52,x,.004,.074,.075,.072]],10,0);
  G.mat('tela2').en(x+.1,.735,.012,0,0,-.05).caja(.034,.16,.12,.012);                 /* bolsillo */
    G.hueso('pierna'+b).mat('tela');
  G.en(x,.50,0).esfera(.073,.073,.073,6,3);
  G.en(0,0,0).loft([[.50,x,.002,.073,.075,.073],[.40,x,-.004,.071,.07,.078],[.27,x,-.006,.066,.066,.07],[.205,x,0,.068,.072,.072],[.17,x,0,.062,.066,.066]],10,0);
  G.mat('rodilla').en(x,.50,.052).esfera(.07,.086,.034,8,4);                          /* rodillera */
  G.mat('equipo2').en(x,.43,0).cil(.073,.072,.018,10,0);
  /* borceguí: caña, empeine, puntera y suela con taco */
  const bota=(secs)=>G.loft(secs.map(([z,hw,yc,ab,ar])=>[z,0,-yc,hw,ab,ar,2.6]),10,3);
  G.mat('cuero');   /* la caña va con la canilla: así no se despega cuando el pie se estira */
  G.en(0,0,0).loft([[.07,x,-.008,.051,.062,.056,2.4],[.13,x,-.006,.055,.057,.059,2.2],[.215,x,-.004,.061,.061,.063,2]],10,0);
  G.mat('equipo2').en(x,.198,-.005).cil(.063,.064,.02,10,0);
  G.hueso('pie'+b).mat('cuero');
  G.mat('cuero').en(x,0,0,PI/2,0,0);bota([[-.085,.038,.06,.05,.03],[-.065,.047,.062,.055,.045],[-.01,.05,.066,.062,.055],[.07,.051,.056,.052,.04],[.125,.05,.047,.043,.031]]);
  G.mat('suela').en(x,.011,-.02).caja(.106,.022,.15,0);
  G.en(x,.008,.085).caja(.102,.016,.08,0);
  G.hueso('puntera'+b).mat('cuero').en(x,0,0,PI/2,0,0);bota([[.12,.05,.047,.043,.031],[.17,.048,.042,.039,.027],[.205,.039,.038,.034,.021],[.222,.02,.035,.024,.012]]);
  G.mat('suela').en(x,.009,.175).caja(.1,.018,.095,0);
  G.lado(1);
}

/* cabeza: pasamontañas, máscara antigás con lentes redondos y filtro lateral, casco de corte alto */
function cabeza(G,rol){
  G.lado(1).hueso('cuello').mat('tela2');
  G.en(0,0,0).loft([[1.495,0,-.012,.062,.058,.062],[1.56,0,-.008,.058,.056,.06],[1.625,0,0,.06,.058,.064]],10,0);
  G.hueso('cabeza').mat('tela2').en(0,1.672,0).esfera(.079,.104,.097,10,5);           /* pasamontañas */
  /* cuerpo de la máscara: frente ancho y plano, mentón y "hocico" */
  G.mat('goma').en(0,0,0).loft([
    [1.548,0,.040,.040,.045,.03,2.2],[1.562,0,.034,.064,.068,.045,2.3],[1.595,0,.026,.083,.088,.06,2.4],
    [1.635,0,.020,.090,.090,.07,2.5],[1.685,0,.016,.092,.090,.075,2.6],[1.722,0,.012,.086,.086,.075,2.5],[1.746,0,.008,.07,.074,.07,2.2]],14,3);
  /* lentes: copa de goma, aro de metal y vidrio con brillo frío. Miran un poco hacia afuera (de insecto) */
  for(const s of [1,-1]){G.lado(s);
    const dx=.30,dz=1,l=Math.hypot(dx,dz),ux=dx/l,uz=dz/l,cx=.037,cy=1.69,cz=.103;
    G.mat('goma2').dir(cx-ux*.012,cy,cz-uz*.012,ux,0,uz).cil(.032,.029,.034,12,2);
    G.mat('metal').dir(cx+ux*.0215,cy,cz+uz*.0215,ux,0,uz).toro(.0258,.0032,12,3);
    G.mat('lente').dir(cx+ux*.0205,cy,cz+uz*.0205,ux,0,uz).disco(.0262,12);
  }
  G.lado(1);
  /* hocico: fonador inclinado hacia abajo con rejilla oscura y válvula de exhalación debajo, como mandíbulas */
  {const d=[0,-.5,.87],o=[0,1.603,.092];
    G.mat('goma2').dir(o[0],o[1],o[2],...d).cil(.034,.029,.046,12,0);
    G.mat('equipo').tinte((x,y,z)=>(Math.floor((y*.5+z*.87)*260)%2?.55:1.05)).dir(o[0]+d[0]*.046,o[1]+d[1]*.046,o[2]+d[2]*.046,...d).torno([[.029,0],[.027,.008],[.02,.014],[0,.016]],12);G.tinte(null);
    G.mat('metal').dir(o[0]+d[0]*.03,o[1]+d[1]*.03,o[2]+d[2]*.03,...d).cil(.0335,.0335,.005,12,0);
    for(const sx of [1,-1])G.mat('goma2').dir(sx*.045,1.585,.083,sx*.55,-.45,.7).cil(.014,.011,.03,8,2);}
  G.mat('goma').en(0,1.651,.108,-.25,0,0).caja(.022,.05,.018,.008);                    /* puente entre los lentes */
  /* filtro en la mejilla izquierda, apuntando afuera, adelante y abajo */
  const fd=[.78,-.32,.54],fm=[.072,1.598,.07];
  G.mat('goma2').dir(fm[0],fm[1],fm[2],...fd).cil(.025,.025,.02,10,0);
  G.mat('metal').dir(fm[0]+fd[0]*.018,fm[1]+fd[1]*.018,fm[2]+fd[2]*.018,...fd)
    .torno([[.026,0],[.041,.003],[.042,.016],[.039,.019],[.042,.022],[.042,.05],[.036,.057],[0,.058]],10);
  /* correas del arnés debajo del casco */
  for(const s of [1,-1]){G.lado(s).mat('equipo');
    const pts=[35,5,-30,-62,-90].map(a=>[.066*Math.cos(a*RAD),1.604,.079*Math.sin(a*RAD)]);
    G.en(0,0,0).cinta(pts,.016,.004,(i,p)=>[p[0],0,p[2]]);}
  G.lado(1);
  const velo=rol==='tirador';
  /* casco de corte alto: alto sobre las orejas, bajo atrás */
  const cy=1.694,ry=.111,rx=.109,rz=.123;
  const borde=a=>{const s=Math.sin(a);return s>0?lerp(1.716,1.738,Math.pow(s,1.2)):lerp(1.716,1.648,Math.pow(-s,.8));};
  const corte=a=>Math.acos(clamp((borde(a)-cy)/ry,-1,1));
  G.mat('casco').en(0,cy,-.008).esfera(rx,ry,rz,16,7,{corte});
  G.mat('goma').invertir(true).en(0,cy-.004,-.008).esfera(rx*.94,ry*.94,rz*.94,10,4,{corte}).invertir(false);
  { const pts=[];for(let i=0;i<=14;i++){const a=i/14*TAU,f=corte(a);pts.push([rx*1.005*Math.sin(f)*Math.cos(a),cy+ry*Math.cos(f),-.008+rz*1.005*Math.sin(f)*Math.sin(a)]);}
    G.mat('goma2').en(0,0,0).cinta(pts,.014,.008,(i,p)=>[p[0],0,p[2]+.008]); }
  if(!velo){
    /* rieles laterales */
    for(const s of [1,-1]){G.lado(s);const pts=[];
      for(let i=0;i<=6;i++){const a=lerp(.55,-.85,i/6),f=corte(a)-.17;pts.push([rx*1.06*Math.sin(f)*Math.cos(a),cy+ry*1.04*Math.cos(f),-.008+rz*1.06*Math.sin(f)*Math.sin(a)]);}
      G.mat('equipo2').en(0,0,0).cinta(pts,.019,.011,(i,p)=>[p[0],(p[1]-cy)*.4,(p[2]+.008)*.6]);}
    G.lado(1);
    G.mat('metal').en(0,1.752,.117,-.42,0,0).caja(.038,.024,.014,.005);                   /* soporte frontal */
    if(rol==='jefe'){   /* visor nocturno levantado: dos tubos que se leen como antenas de insecto */
      G.mat('arma').en(0,1.786,.112,-.9,0,0).caja(.075,.026,.03,.008);
      for(const sx of [1,-1]){G.mat('arma').dir(sx*.031,1.79,.118,sx*.08,.62,-.78).cil(.0165,.015,.075,8,2);
        G.mat('vidrio').dir(sx*.031+sx*.08*.076,1.79+.62*.076,.118-.78*.076,sx*.08,.62,-.78).disco(.0135,8);}}
    G.mat('velcro').en(0,1.803,-.012,-.05,0,0).caja(.07,.006,.10,0);
    G.mat('velcro').en(0,1.716,-.121,.42,0,0).caja(.08,.05,.006,0);
    G.mat('equipo').en(0,1.667,-.126,.18,0,0).caja(.1,.052,.034,.012);                   /* contrapeso */
    G.mat('equipo2').en(0,1.722,-.13,.42,0,0).caja(.024,.016,.012,0);                 /* luz de la nuca */
    G.mat('led').en(0,1.722,-.137,.42,0,0).caja(.012,.008,.004,0);
    /* auriculares de radio sobre las orejas (el jefe, más grandes) */
    const ra=rol==='jefe'?.041:.035;
    for(const s of [1,-1]){G.lado(s).mat('equipo');
      G.en(.094,1.662,-.004,0,0,-PI/2).cil(ra,ra-.004,.034,12,2);
      G.mat('equipo2').en(0,0,0).cinta([[.125,1.672,-.004],[.122,1.70,-.006],[.118,1.715,-.008]],.012,.008,[1,0,0]);}
    G.lado(1);
  }else{
    /* velo del tirador: tela sobre el casco que cae sobre hombros y espalda, con el borde deshilachado.
       Arriba va con la cabeza, abajo con el pecho: así acompaña cuando gira la cabeza */
    const az=azarDe(777),seg=18,ani=[
      [1.838,0,-.01,.02,.02,.02],[1.81,0,-.01,.10,.10,.115],[1.75,0,-.01,.132,.122,.148],[1.69,0,-.01,.142,.062,.158],
      [1.62,0,-.01,.15,.034,.16],[1.55,0,-.012,.17,.05,.165],[1.49,0,-.012,.21,.075,.175],[1.44,0,-.015,.255,.12,.185]];
    const P=[],T=[],cols=[];
    for(const [y,cx,cz,rx_,rf,rb] of ani)for(let i=0;i<seg;i++){const a=i/seg*TAU,c=Math.cos(a),s=Math.sin(a),e=2/2.4;
      P.push(cx+rx_*Math.sign(c)*Math.pow(Math.abs(c),e),y,cz+(s>=0?rf:rb)*Math.sign(s)*Math.pow(Math.abs(s),e));}
    /* ruedo: más largo atrás, irregular */
    const base=P.length/3-seg;
    for(let i=0;i<seg;i++){const a=i/seg*TAU,s=Math.sin(a),c=Math.cos(a),j=base+i,x=P[j*3],z=P[j*3+2];
      const yb=lerp(1.39,1.20,sat(-s*.9+.25))-az()*.05,k=1.08+az()*.04;P.push(x*k,yb,z*k-(s<0?.01:0));}
    const nr=ani.length+1;
    for(let r=0;r<nr-1;r++)for(let i=0;i<seg;i++){const a=r*seg+i,b=r*seg+(i+1)%seg;T.push(a,a+seg,b+seg,a,b+seg,b);}
    G.hueso('cabeza').peso((x,y,z)=>[H.pecho,H.cabeza,sst(1.47,1.62,y)]).mat('velo');
    G.tinte((x,y,z)=>.8+.4*Math.abs(Math.sin(x*61+y*37)*Math.sin(z*53-y*29)));
    G.en(0,0,0).crudo(P,T);
    /* tiras sueltas atrás */
    for(let i=0;i<5;i++){const a=-PI/2+(i-2)*.32,x=Math.cos(a)*.2,z=Math.sin(a)*.18-.01,y0=1.40,l=.16+az()*.1;
      G.en(x,y0-l/2,z,0,a+PI/2,0).caja(.035,l,.006,.002);}
    G.tinte(null).hueso('cabeza');
    G.mat('led').en(0,1.722,-.162,.42,0,0).caja(.012,.008,.004,0);              /* la luz va sobre el velo */
  }
}

/* torso, chaleco y cinturón; lo que cambia por rol, al final */
function torso(G,rol){
  G.lado(1).hueso('cadera').peso(pesoTorso).mat('tela');
  G.en(0,0,0).loft([
    [.855,0,-.01,.13,.07,.09,2.2],[.90,0,-.01,.172,.094,.115,2.3],[.96,0,-.008,.18,.10,.12,2.4],[1.03,0,-.005,.166,.099,.106,2.4],
    [1.10,0,-.004,.152,.098,.096,2.4],[1.19,0,0,.16,.108,.10,2.4],[1.29,0,.004,.176,.118,.104,2.5],[1.38,0,0,.186,.112,.102,2.6],
    [1.44,0,-.008,.18,.092,.094,2.5],[1.485,0,-.012,.14,.074,.08,2.2],[1.515,0,-.014,.075,.06,.062,2]],14,3);
  /* cinturón con hebilla y cartucheras */
  G.hueso('cadera').mat('equipo').en(0,0,0).loft([[.985,0,-.006,.186,.114,.126,2.6],[1.037,0,-.005,.177,.112,.12,2.6]],16,0);
  G.mat('metal').en(0,1.011,.117).caja(.058,.04,.014,.004);
  G.mat('equipo').en(0,.99,-.145,-.06,0,0).caja(.14,.09,.06,.018);                       /* botiquín atrás */
  G.mat('equipo').en(.168,.99,-.07,0,-.5,0).caja(.05,.08,.045,.012);
  G.mat('equipo').en(-.17,.99,-.06,0,.5,0).caja(.05,.08,.045,.012);
  /* chaleco portaplacas */
  G.hueso('pecho').mat('equipo');
  G.en(0,1.305,.133,-.08,0,0).caja(.285,.31,.045,.012);
  G.en(0,1.30,-.121,.04,0,0).caja(.29,.33,.04,.012);
  G.en(0,0,0).loft([[1.15,0,0,.181,.126,.117,3],[1.30,0,.004,.192,.131,.121,3]],16,0);
  for(const s of [1,-1]){G.lado(s).mat('equipo').en(0,0,0)
    .cinta([[.095,1.455,.122],[.11,1.50,.062],[.116,1.517,-.01],[.106,1.49,-.08],[.095,1.452,-.112]],.056,.014,(i,p)=>[p[0]-.1,p[1]-1.43,p[2]]);}
  G.lado(1);
  G.mat('velcro').en(0,1.405,.157,-.08,0,0).caja(.12,.056,.004,0);                   /* parche vacío */
  G.mat('equipo').en(.198,1.235,.005).caja(.045,.11,.06,.014);                            /* portarradio */
  G.mat('equipo').en(-.197,1.225,-.01).caja(.04,.085,.055,.012);
  const tripleCargador=()=>{for(const x of [-.078,0,.078]){
    G.mat('equipo').en(x,1.222,.176,-.05,0,0).caja(.072,.12,.05,.014);
    G.mat('equipo2').en(x,1.288,.178,-.05,0,0).caja(.068,.014,.052,.005);}};
  if(rol==='jefe'){
    tripleCargador();
    G.mat('equipo').en(0,1.31,-.185,.04,0,0).caja(.165,.25,.078,.014);                   /* mochila de radio */
    G.mat('poli').en(.042,1.448,-.19).caja(.068,.05,.05,.01);
    G.mat('metal').en(.06,1.47,-.195).cil(.01,.008,.035,8,2);
    G.mat('goma').en(0,0,0).cinta([[.06,1.44,-.17],[.10,1.50,-.085],[.122,1.527,0],[.112,1.475,.1],[.09,1.405,.165]],.009,.007,[0,1,0]);
    G.mat('poli').en(.088,1.392,.172,-.08,0,0).caja(.036,.046,.022,.006);                 /* pulsador */
  }else if(rol==='asalto'){
    /* canana cruzada con cartuchos (del hombro izquierdo a la cadera derecha) */
    const cp=[[.125,1.505,.06],[.105,1.44,.167],[.035,1.335,.178],[-.045,1.225,.178],[-.115,1.125,.164],[-.168,1.035,.112]];
    G.mat('cuero').en(0,0,0).cinta(cp,.058,.012,[0,0,1]);
    const cb=[[-.12,1.03,.10],[-.19,1.05,-.02],[-.15,1.15,-.13],[-.02,1.32,-.155],[.09,1.45,-.12],[.125,1.505,-.03],[.125,1.505,.06]];
    G.en(0,0,0).cinta(cb,.058,.012,(i,p)=>[p[0]*.5,0,p[2]]);
    for(let i=0;i<8;i++){const u=.08+i*.105,k=Math.min(cp.length-2,Math.floor(u*(cp.length-1))),f=u*(cp.length-1)-k;
      const a=cp[k],b=cp[k+1],px=lerp(a[0],b[0],f),py=lerp(a[1],b[1],f),pz=lerp(a[2],b[2],f)+.014;
      const tx=b[0]-a[0],ty=b[1]-a[1],l=Math.hypot(tx,ty),wx=-ty/l,wy=tx/l;
      G.mat('cart').dir(px-wx*.024,py-wy*.024,pz,wx,wy,0).cil(.0098,.0098,.04,6,2);
      G.mat('laton').dir(px+wx*.016,py+wy*.016,pz,wx,wy,0).cil(.0102,.0102,.011,6,2);}
    for(const s of [1,-1])G.lado(s).mat('equipo').en(.125,1.205,.155,-.05,0,0).caja(.06,.075,.045,.014);
    G.lado(1);
  }else if(rol==='granadero'){
    /* cuatro portagranadas en el pecho, con la granada asomando */
    for(const x of [-.108,-.036,.036,.108]){
      G.mat('equipo').en(x,1.222,.18,-.05,0,0).caja(.064,.088,.058,.022);
      G.mat('granada').en(x,1.284,.18).esfera(.027,.026,.027,8,4);
      G.mat('metal').en(x+.012,1.302,.18,0,0,-.4).caja(.008,.03,.012,0);}
    for(const s of [1,-1])G.lado(s).mat('equipo').en(.196,1.21,.072,0,-.6,0).caja(.04,.12,.075,.014);
    G.lado(1);
    G.mat('equipo').en(0,1.30,-.162,.04,0,0).caja(.24,.25,.05,.014);
    /* correa del morral: del hombro derecho a la cadera izquierda, por delante y por la espalda */
    G.peso((x,y,z)=>[H.cadera,H.pecho,sst(1.04,1.18,y)]).mat('tela2').en(0,0,0)
      .cinta([[.205,1.04,.10],[.15,1.15,.172],[.05,1.30,.19],[-.06,1.42,.172],[-.112,1.5,.08],[-.115,1.515,-.02],[-.07,1.43,-.15],[.07,1.22,-.168],[.20,1.05,-.075]],.045,.01,(i,p)=>[p[0]*.6,0,p[2]]);
    G.hueso('cadera').mat('tela2').en(.232,.94,.02,0,0,-.08).caja(.092,.21,.25,.032);    /* morral */
    G.mat('equipo').en(.236,1.03,.02,0,0,-.08).caja(.098,.055,.255,.014);
  }else{
    tripleCargador();
    G.mat('equipo').en(0,1.30,-.162,.04,0,0).caja(.24,.25,.05,.014);
  }
  /* cartuchera de pierna con la pistola (derecha) */
  G.lado(1).hueso('musloD').mat('equipo');
  G.en(-.183,.79,.004,0,0,.06).caja(.014,.17,.10,.004);
  G.en(-.203,.77,.006,0,0,.06).caja(.045,.15,.088,.016);
  G.mat('poli').en(-.205,.866,-.012,.28,0,.06).caja(.03,.07,.04,.01);
  G.mat('equipo2').en(-.095,.835,.0).cil(.087,.086,.02,10,0);
  G.en(-.095,.70,.004).cil(.078,.077,.02,10,0);
  G.hueso('cadera').mat('equipo2').en(0,0,0).cinta([[-.165,1.0,.02],[-.18,.93,.012],[-.185,.88,.008]],.03,.006,[-1,0,0]);
}

/* ====================================================================================
   ARMAS (en coordenadas propias: origen en el centro de la cantonera, +Z hacia la boca,
   +Y arriba, +X a la izquierda del arma). Genéricas: ningún modelo de fábrica.
   Cada una devuelve su FICHA: dónde van las manos, la boca, la linterna, el cargador…
   ==================================================================================== */
const enZ=(G,x,y,z)=>G.en(x,y,z,PI/2,0,0);                 /* lo que sigue, a lo largo de +Z */
const perfil=(G,x,y,z)=>G.en(x,y,z,0,-PI/2,0);              /* polígono en (z,y), espesor en X */
const dientes=f=>(x,y,z)=>(Math.floor(z/.0105)%2?.62:1.12)*f;  /* rieles con dientes */

/* agarre: arma la rotación y la posición de la muñeca (en el arma) para que el cilindro que
   cruza la palma (AGARRE) coincida con el eje C,a del arma, con la palma mirando hacia p */
function agarre(izq,C,a,p){
  const ag=izq?AGARRE.I:AGARRE.D,ah=new V3(0,-Math.sin(ag.d),Math.cos(ag.d)),ph=new V3(izq?-1:1,0,0),Ch=ag.c.clone();if(!izq)Ch.x=-Ch.x;
  const e1=ah.normalize(),e2=ph.addScaledVector(e1,-ph.dot(e1)).normalize(),e3=new V3().crossVectors(e1,e2);
  const f1=a.clone().normalize(),f2=p.clone().addScaledVector(f1,-p.dot(f1)).normalize(),f3=new V3().crossVectors(f1,f2);
  const R=new M4().makeBasis(f1,f2,f3).multiply(new M4().makeBasis(e1,e2,e3).transpose());
  const q=new Q4().setFromRotationMatrix(R);
  return {q,p:C.clone().sub(Ch.applyQuaternion(q))};
}

function fusil(G){
  G.lado(1).hueso('arma').varia(.03);
  G.mat('goma').en(0,-.008,.01).caja(.044,.135,.02,.006);
  G.mat('poli');perfil(G,0,0,0).prisma([[.02,.062],[.15,.055],[.19,.04],[.195,.012],[.15,-.03],[.02,-.072]],.04,.007);
  G.mat('metal').en(0,.045,.12).caja(.012,.012,.03,.003);
  G.mat('arma');G.en(0,0,0).tubo(0,.035,.13,0,.035,.27,.0155,.0155,10,0);
  G.mat('arma');perfil(G,0,0,0).prisma([[.255,.03],[.40,.03],[.40,0],[.385,-.025],[.335,-.03],[.30,-.028],[.262,-.018]],.03,.003);
  G.mat('poli').en(0,-.03,.355).caja(.03,.04,.07,.006);
  G.mat('arma').en(0,.051,.36).caja(.032,.042,.235,.005);
  G.tinte(dientes(1)).en(0,.078,.495).caja(.022,.011,.49,.002).tinte(null);
  G.mat('metal').en(-.0175,.048,.37).caja(.003,.018,.058,0);
  G.mat('arma').en(0,.07,.258).caja(.038,.008,.02,0);
  G.mat('poli');perfil(G,0,0,0).prisma([[.272,-.02],[.307,-.022],[.295,-.075],[.288,-.13],[.258,-.128],[.255,-.09],[.262,-.04]],.03,.008);
  G.mat('arma').en(0,-.05,.335).caja(.008,.006,.055,.002);
  G.mat('metal').en(0,-.036,.323,.25,0,0).caja(.004,.02,.006,0);
  G.mat('poli').tinte((x,y,z)=>(Math.floor(z/.022)%2?.8:1.05));enZ(G,0,.04,.47).cil(.0265,.0265,.275,8,3);G.tinte(null);
  G.mat('arma');G.en(0,0,0).tubo(0,.035,.745,0,.035,.86,.0085,.0085,8,0);
  enZ(G,0,.035,.86).torno([[.0085,0],[.0115,.002],[.0115,.064],[.006,.07],[0,.07]],8);
  /* mira de punto rojo */
  G.mat('arma').en(0,.093,.385).caja(.026,.02,.045,.004);
  enZ(G,0,.116,.358).torno([[0,0],[.0175,.002],[.0175,.05],[.019,.06],[.016,.06]],10);
  G.mat('vidrio');enZ(G,0,.116,.412).disco(.0145,10);
  G.mat('arma').en(-.019,.116,.385,0,0,PI/2).cil(.006,.006,.008,6,2);
  /* linterna al costado izquierdo del guardamanos */
  G.mat('arma').en(.03,.04,.70).caja(.012,.022,.03,.003);
  enZ(G,.043,.04,.63).torno([[0,0],[.0125,.003],[.0125,.095],[.0165,.102],[.0165,.13]],8);
  G.mat('foco');enZ(G,.043,.04,.7605).disco(.0145,10);
  /* cargador curvo de 30 (hueso propio: en la recarga pasa a la mano) */
  G.hueso('cargador').mat('poli');
  perfil(G,0,0,0).prisma([[-.017,.004],[.019,.004],[.024,-.07],[.037,-.15],[.054,-.212],[.022,-.224],[.006,-.16],[-.008,-.08]],.024,.004);
  G.mat('arma').en(0,-.216,.038,-.3,0,0).caja(.028,.012,.042,.003);
  G.varia(.06);
  return {tipo:'fusil',
    agD:agarre(false,new V3(0,-.075,.283),new V3(0,.944,.33),new V3(1,0,.25)),
    agI:agarre(true,new V3(0,.04,.585),new V3(0,0,1),new V3(-.5,.86,0)),
    boca:new V3(0,.035,.93),luz:new V3(.043,.04,.762),ojo:new V3(0,.116,.30),cargador:new V3(0,-.035,.355),
    eyeccion:new V3(-.02,.048,.37),guarda:new V3(0,.04,.585),patada:1,culataLargo:.19};
}

function escopeta(G){
  G.lado(1).hueso('arma').varia(.03);
  G.mat('goma').en(0,-.01,.011).caja(.045,.14,.022,.007);
  G.mat('poli');perfil(G,0,0,0).prisma([[.02,.058],[.24,.042],[.275,.025],[.275,-.02],[.21,-.03],[.02,-.08]],.042,.008);
  perfil(G,0,0,0).prisma([[.25,-.02],[.285,-.022],[.275,-.075],[.268,-.13],[.238,-.128],[.235,-.09],[.24,-.04]],.03,.008);
  G.mat('arma').en(0,.017,.39).caja(.038,.075,.22,.008);
  G.mat('metal').en(-.0195,.03,.40).caja(.003,.022,.06,0);
  G.mat('suela').en(0,-.021,.42).caja(.022,.004,.07,0);
  G.mat('arma').en(0,-.03,.31).caja(.008,.006,.05,.002);
  G.mat('metal').en(0,-.026,.30,.25,0,0).caja(.004,.018,.006,0);
  G.mat('arma');G.en(0,0,0).tubo(0,.04,.50,0,.04,.95,.0115,.0115,10,0);
  G.mat('suela');enZ(G,0,.04,.9502).disco(.0115,10);
  G.mat('arma');G.en(0,0,0).tubo(0,.011,.50,0,.011,.875,.0105,.0105,8,0);
  enZ(G,0,.011,.875).torno([[.0105,0],[.0115,.003],[.0115,.02],[.008,.024],[0,.024]],8);
  G.mat('arma').en(0,.026,.86).caja(.02,.05,.022,.004);
  G.mat('metal').en(0,.055,.94).esfera(.003,.003,.003,6,3);
  G.mat('arma').en(0,.062,.47).caja(.022,.016,.012,.003);
  /* portacartuchos al costado izquierdo, con cuatro cartuchos */
  G.mat('equipo').en(.0215,.012,.40).caja(.006,.052,.10,.002);
  for(let i=0;i<4;i++){const z=.362+i*.025;
    G.mat('cart').en(.031,-.024,z).cil(.0095,.0095,.046,6,1);G.mat('laton').en(.031,.022,z).cil(.0098,.0098,.012,6,2);}
  /* linterna abrazada al cañón */
  G.mat('arma').en(.026,.03,.81).caja(.014,.024,.028,.003);
  enZ(G,.038,.03,.76).torno([[0,0],[.0125,.003],[.0125,.09],[.0165,.097],[.0165,.124]],8);
  G.mat('foco');enZ(G,.038,.03,.8845).disco(.0145,10);
  /* corredera (hueso propio: el guardamanos que bombea) */
  G.hueso('corredera').mat('poli').tinte((x,y,z)=>(Math.floor((z+.2)/.012)%2?.75:1.08)).en(0,0,0).caja(.048,.044,.17,.014).tinte(null);
  /* un cartucho suelto en el hueso del cargador: es el que la mano mete en la recarga */
  G.hueso('cargador').mat('cart').en(0,-.023,0).cil(.0095,.0095,.046,6,1);G.mat('laton').en(0,.023,0).cil(.0098,.0098,.012,6,2);
  G.varia(.06);
  return {tipo:'escopeta',
    agD:agarre(false,new V3(0,-.075,.262),new V3(0,.944,.33),new V3(1,0,.25)),
    agI:agarre(true,new V3(0,.014,.645),new V3(0,0,1),new V3(-.55,.83,0)),agIcorredera:true,
    boca:new V3(0,.04,.952),luz:new V3(.038,.03,.886),ojo:new V3(0,.064,.30),corredera:new V3(0,.014,.645),
    cargador:new V3(0,-.03,.42),eyeccion:new V3(-.02,.03,.40),guarda:new V3(0,.014,.645),patada:1.7,culataLargo:.24};
}

function tirador(G){
  G.lado(1).hueso('arma').varia(.03);
  G.mat('goma').en(0,-.01,.011).caja(.045,.14,.022,.007);
  G.mat('poli');perfil(G,0,0,0).prisma([[.02,.062],[.07,.08],[.20,.08],[.23,.06],[.25,.04],[.25,.005],[.19,-.035],[.03,-.088],[.02,-.088]],.042,.008);
  G.mat('arma');G.en(0,0,0).tubo(0,.035,.20,0,.035,.28,.0155,.0155,10,0);
  perfil(G,0,0,0).prisma([[.275,.03],[.43,.03],[.43,0],[.415,-.025],[.355,-.03],[.32,-.028],[.282,-.018]],.03,.003);
  G.en(0,.052,.39).caja(.034,.044,.25,.005);
  G.tinte(dientes(1)).en(0,.08,.575).caja(.022,.011,.61,.002).tinte(null);
  G.mat('metal').en(-.0185,.05,.40).caja(.003,.018,.06,0);
  G.mat('poli');perfil(G,0,0,0).prisma([[.292,-.02],[.327,-.022],[.315,-.075],[.308,-.13],[.278,-.128],[.275,-.09],[.282,-.04]],.03,.008);
  G.mat('arma').en(0,-.05,.355).caja(.008,.006,.055,.002);
  G.mat('poli').tinte((x,y,z)=>(Math.floor(z/.024)%2?.8:1.05));enZ(G,0,.04,.50).cil(.0275,.0275,.38,8,3);G.tinte(null);
  G.mat('arma');G.en(0,0,0).tubo(0,.035,.88,0,.035,1.0,.0095,.0095,8,0);
  enZ(G,0,.035,.995).torno([[.0095,0],[.021,.004],[.021,.222],[.018,.23],[.008,.23],[0,.23]],12);
  /* mira telescópica con anillas y torretas */
  G.mat('arma');for(const z of [.37,.48]){G.en(0,.096,z).caja(.024,.026,.02,.004);enZ(G,0,.122,z-.009).cil(.0185,.0185,.018,10,0);}
  enZ(G,0,.122,.305).torno([[0,0],[.019,0],[.021,.005],[.021,.035],[.0155,.05],[.0155,.25],[.025,.29],[.0255,.33],[.024,.335],[0,.335]],10);
  G.mat('vidrio');enZ(G,0,.122,.6405).disco(.021,10);
  G.mat('arma').en(0,.137,.45).cil(.012,.012,.022,8,2);
  G.en(-.0145,.122,.45,0,0,PI/2).cil(.011,.011,.02,8,2);
  /* módulo láser a la derecha del guardamanos */
  G.mat('poli').en(-.036,.042,.80).caja(.022,.026,.05,.005);
  G.mat('vidrio');enZ(G,-.036,.046,.8255).disco(.006,8);
  /* bípode (hueso propio): patas plegadas hacia adelante, se bajan rotando */
  G.hueso('bipode').mat('arma').en(0,-.004,0).caja(.034,.02,.03,.005);
  for(const s of [1,-1]){G.en(0,0,0).tubo(s*.012,-.01,.004,s*.045,-.012,.215,.0058,.005,6,2);G.mat('goma').en(s*.045,-.012,.218).esfera(.008,.008,.008,6,3);G.mat('arma');}
  /* cargador recto de 10 */
  G.hueso('cargador').mat('poli');perfil(G,0,0,0).prisma([[-.026,.004],[.024,.004],[.026,-.105],[-.024,-.105]],.026,.004);
  G.mat('arma').en(0,-.107,0).caja(.03,.01,.054,.003);
  G.varia(.06);
  return {tipo:'tirador',
    agD:agarre(false,new V3(0,-.075,.303),new V3(0,.944,.33),new V3(1,0,.25)),
    agI:agarre(true,new V3(0,.04,.66),new V3(0,0,1),new V3(-.5,.86,0)),
    boca:new V3(0,.035,1.225),laser:new V3(-.036,.046,.827),ojo:new V3(0,.122,.27),cargador:new V3(0,-.035,.395),bipode:new V3(0,.005,.84),
    eyeccion:new V3(-.02,.05,.40),guarda:new V3(0,.04,.66),patada:1.35,culataLargo:.25};
}

/* granada de mano: cuerpo, espoleta, palanca y anilla (origen en el centro) */
function granadaGeo(G,hueso){
  G.lado(1).hueso(hueso).mat('granada').en(0,0,0).esfera(.031,.036,.031,10,6);
  G.mat('metal').en(0,.03,0).cil(.0105,.0095,.024,8,2);
  G.en(0,0,0).cinta([[.006,.054,0],[.02,.051,0],[.033,.03,0],[.034,.0,0],[.027,-.02,0]],.012,.003,(i,p)=>[p[0],p[1]*.3,0]);
  G.en(-.017,.046,0,PI/2,0,0).toro(.011,.0017,10,3);
}

/* ====================================================================================
   MATERIALES Y GEOMETRÍAS COMPARTIDAS
   Un material para el cuerpo (color por vértice; aspereza, metal y emisión también por vértice
   en el atributo 'uem') y uno aditivo para los efectos. Se crean una vez y los comparten todos.
   ==================================================================================== */
const MAT={};
function parcheUem(sh){
  sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nattribute vec3 uem;\nvarying vec3 vUem;')
    .replace('#include <begin_vertex>','#include <begin_vertex>\n\tvUem = uem;');
  sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nvarying vec3 vUem;')
    .replace('#include <roughnessmap_fragment>','float roughnessFactor = roughness * vUem.x;')
    .replace('#include <metalnessmap_fragment>','float metalnessFactor = metalness * vUem.y;')
    .replace('#include <emissivemap_fragment>','totalEmissiveRadiance += diffuseColor.rgb * vUem.z;');
}
const FX_VS=`
#include <common>
#include <skinning_pars_vertex>
#include <fog_pars_vertex>
attribute vec3 uem;
varying vec3 vCol; varying vec3 vN; varying vec3 vV; varying vec2 vModo;
void main(){
  #include <beginnormal_vertex>
  #include <skinbase_vertex>
  #include <skinnormal_vertex>
  #include <defaultnormal_vertex>
  #include <begin_vertex>
  #include <skinning_vertex>
  #include <project_vertex>
  #include <fog_vertex>
  vCol = color; vN = transformedNormal; vV = -mvPosition.xyz; vModo = uem.xy;
}`;
const FX_FS=`
#include <common>
#include <fog_pars_fragment>
uniform float uInt;
varying vec3 vCol; varying vec3 vN; varying vec3 vV; varying vec2 vModo;
void main(){
  vec3 n = normalize(vN), v = normalize(vV);
  float d = dot(n, v), k = 1.0;
  if (vModo.x > 1.5) k = pow(max(d, 0.0), vModo.y);          /* resplandor: solo de frente */
  else if (vModo.x > 0.5) k = pow(abs(d), vModo.y);          /* volumen: se apaga en los bordes */
  vec3 c = vCol * k * uInt;
  #ifdef USE_FOG
    #ifdef FOG_EXP2
      float f = 1.0 - exp(-fogDensity * fogDensity * fogDepth * fogDepth);
    #else
      float f = smoothstep(fogNear, fogFar, fogDepth);
    #endif
    c *= 1.0 - f * 0.85;                                     /* la niebla lo apaga menos que a un objeto: lo dispersa */
  #endif
  gl_FragColor = vec4(c, 1.0);
}`;
function materiales(){
  if(MAT.cuerpo)return MAT;
  const m=new THREE.MeshStandardMaterial({vertexColors:true,roughness:1,metalness:1});
  m.skinning=true;m.onBeforeCompile=parcheUem;m.customProgramCacheKey=()=>'uem-piel';m.name='UEM cuerpo';
  const g=new THREE.MeshStandardMaterial({vertexColors:true,roughness:1,metalness:1});
  g.onBeforeCompile=parcheUem;g.customProgramCacheKey=()=>'uem-suelto';g.name='UEM suelto';
  const f=new THREE.ShaderMaterial({name:'UEM efectos',uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.fog,{uInt:{value:1}}]),
    vertexShader:FX_VS,fragmentShader:FX_FS,vertexColors:true,fog:true,transparent:true,depthWrite:false,
    blending:THREE.AdditiveBlending,side:THREE.DoubleSide});
  f.skinning=true;
  MAT.cuerpo=m;MAT.suelto=g;MAT.fx=f;
  return MAT;
}

/* ---------- efectos: todo lo que brilla, en una sola malla aditiva atada a sus huesos ---------- */
function armarFx(G,rol,ficha){
  G.lado(1).varia(0);
  const radial=(R,f0,f1=0)=>(x,y,z)=>lerp(f0,f1,Math.min(1,Math.hypot(x,y)/R));
  /* linterna: cono exterior de ~14 m y núcleo más angosto, más el deslumbre en el foco */
  if(ficha.luz){
    G.hueso('haz').mat('fxHaz',.34).tinte((x,y,z)=>z<1.5?lerp(1,.62,z/1.5):lerp(.62,0,(z-1.5)/12.5));
    enZ(G,0,0,0).cil(.022,.25,1.5,12,0);enZ(G,0,0,1.5).cil(.25,1.9,12.5,12,0);
    G.mat('fxNucleo',.42).tinte((x,y,z)=>z<1?lerp(1,.6,z):lerp(.6,0,(z-1)/8));
    enZ(G,0,0,0).cil(.016,.075,1,10,0);enZ(G,0,0,1).cil(.075,.5,8,10,0);
    G.mat('fxDeslumbre',4).tinte(radial(.07,1));enZ(G,0,0,.004).disco(.07,12);
    G.mat('fxHalo',.9).tinte(radial(.34,1));enZ(G,0,0,.006).disco(.34,12);
    G.tinte(null);
  }
  /* fogonazo: estrella de tres hojas hacia adelante y un disco de frente */
  G.hueso('fogonazo');
  for(let i=0;i<3;i++){const a=i*PI/3;G.mat('fxFogonazo',3).tinte((x,y,z)=>lerp(1,.05,z/.24));
    G.en(0,0,0,0,0,a).crudo([0,0,0, .04,0,.08, 0,0,.24, -.04,0,.08],[0,1,2,0,2,3]);}
  G.mat('fxFogoFrente',3).tinte(radial(.09,1));enZ(G,0,0,.02).disco(.09,10);G.tinte(null);
  /* láser: hilo fino y un halo, de z=0 a z=1 (el hueso se estira hasta el punto) */
  if(ficha.laser){
    G.hueso('laser').mat('fxLaser',1.6);enZ(G,0,0,0).cil(.0045,.0045,1,5,0);
    G.mat('fxLaserHalo',.32);enZ(G,0,0,0).cil(.02,.02,1,6,0);
    G.hueso('laserPunto');
    for(const [rx,ry] of [[0,0],[PI/2,0],[0,PI/2]]){G.mat('fxPunto',2.4).tinte(radial(.035,1));G.en(0,0,0,rx,ry,0).disco(.035,10);}
    G.tinte(null);
  }
  /* luz roja de la nuca */
  G.hueso('led');
  for(const [rx,ry] of [[0,0],[PI/2,0],[0,PI/2]]){G.mat('fxLed',2.2).tinte(radial(.026,1));G.en(0,0,0,rx,ry,0).disco(.026,8);}
  G.tinte(null);
  /* reflejo frío de los lentes: se ve cuando te miran */
  G.hueso('cabeza');
  for(const s of [1,-1]){G.lado(s);const dx=.30,l=Math.hypot(dx,1),ux=dx/l,uz=1/l,cx=.037,cy=1.69,cz=.103;
    G.mat('fxLente',1.1).tinte(radial(.025,1,.25));G.dir(cx+ux*.024,cy,cz+uz*.024,ux,0,uz).disco(.025,10);}
  G.lado(1).tinte(null).varia(.06);
}

/* geometría por rol (se arma una vez y se comparte) */
const GEO={};
function geometriaDe(rol){
  if(GEO[rol])return GEO[rol];
  const G=Constructor(H);
  torso(G,rol);brazo(G,1,rol);brazo(G,-1,rol);mano(G,1);mano(G,-1);pierna(G,1);pierna(G,-1);cabeza(G,rol);
  const arma=ROLES[rol].arma,ficha=arma==='escopeta'?escopeta(G):arma==='tirador'?tirador(G):fusil(G);
  granadaGeo(G,'granada');
  /* vainas: latón (o cartucho rojo en la escopeta) */
  for(const v of ['vaina1','vaina2']){G.hueso(v);
    if(arma==='escopeta'){G.mat('cart').en(0,-.023,0).cil(.0095,.0095,.046,6,1);G.mat('laton').en(0,.023,0).cil(.0098,.0098,.012,6,2);}
    else G.mat('laton').en(0,-.022,0).cil(.0048,.0042,.045,6,2);}
  if(rol==='jefe'){  /* antena de látigo: tres tramos de 0,34 m sobre +Y */
    G.hueso('antena1').mat('goma').en(0,0,0).cil(.0075,.0055,.06,6,1);G.mat('arma').en(0,.05,0).cil(.0062,.0055,.29,5,0);
    G.hueso('antena2').en(0,0,0).cil(.0055,.0045,.34,5,0);
    G.hueso('antena3').en(0,0,0).cil(.0045,.003,.33,5,0);G.mat('goma').en(0,.335,0).esfera(.007,.007,.007,6,3);
  }
  const cuerpo=G.fin();cuerpo.boundingSphere=new THREE.Sphere(new V3(0,.6,0),2.4);cuerpo.boundingBox=new THREE.Box3(new V3(-2.4,-.2,-2.4),new V3(2.4,2.2,2.4));
  const F=Constructor(H);armarFx(F,rol,ficha);const fx=F.fin();fx.boundingSphere=new THREE.Sphere(new V3(0,.6,0),60);
  return GEO[rol]={cuerpo,fx,ficha,tris:cuerpo.userData.tris,trisFx:fx.userData.tris};
}
let GEO_GRANADA=null;
function granada(){
  materiales();
  if(!GEO_GRANADA){const G=Constructor(H);granadaGeo(G,'cadera');GEO_GRANADA=G.fin();
    GEO_GRANADA.deleteAttribute('skinIndex');GEO_GRANADA.deleteAttribute('skinWeight');GEO_GRANADA.computeBoundingSphere();}
  const m=new THREE.Mesh(GEO_GRANADA,MAT.suelto);m.castShadow=true;m.name='UEM granada';return m;
}

/* ====================================================================================
   POSES: matemática, IK de dos huesos y resolución del esqueleto
   Una POSE es una descripción chica del cuerpo en el espacio del modelo: cadera (posición y
   giro), giros locales de columna, pecho, cuello y cabeza, y para cada mano y cada pie un
   objetivo (posición de la muñeca o el tobillo, orientación, y hacia dónde va el codo o la
   rodilla). Dos poses se mezclan componente a componente y siempre se resuelven con la misma
   cadena, así que cualquier mezcla queda armada (no se despegan los miembros).
   ==================================================================================== */
const EJX=new V3(1,0,0),EJY=new V3(0,1,0),EJZ=new V3(0,0,1),QI=new Q4();
const _eu=new THREE.Euler(),_mb=new M4(),_bx=new V3(),_by=new V3(),_bz=new V3();
function qE(q,x,y,z){return q.setFromEuler(_eu.set(x,y,z,'YXZ'));}
/* +Z local → fwd, +Y local → up (ortogonalizado) */
function qBase(q,fwd,up){
  _bz.copy(fwd).normalize();_bx.crossVectors(up,_bz);
  if(_bx.lengthSq()<1e-8)_bx.crossVectors(Math.abs(_bz.y)<.9?EJY:EJX,_bz);
  _bx.normalize();_by.crossVectors(_bz,_bx);_mb.makeBasis(_bx,_by,_bz);return q.setFromRotationMatrix(_mb);}
/* segmento de miembro: -Y local → dir; +Z local, hacia 'frente' */
function qSeg(q,dir,frente){
  _by.copy(dir).negate().normalize();_bz.copy(frente).addScaledVector(_by,-frente.dot(_by));
  if(_bz.lengthSq()<1e-10)_bz.crossVectors(EJX,_by);_bz.normalize();_bx.crossVectors(_by,_bz);
  _mb.makeBasis(_bx,_by,_bz);return q.setFromRotationMatrix(_mb);}
/* mano: los dedos (−Y local) hacia 'dedos'; la palma (−X la izquierda, +X la derecha) hacia 'palma' */
function qMano(q,izq,dedos,palma){
  _by.copy(dedos).negate().normalize();_bx.copy(palma);if(izq)_bx.negate();
  _bx.addScaledVector(_by,-_bx.dot(_by));if(_bx.lengthSq()<1e-10)_bx.crossVectors(_by,EJZ);_bx.normalize();
  _bz.crossVectors(_bx,_by);_mb.makeBasis(_bx,_by,_bz);return q.setFromRotationMatrix(_mb);}
const _ia=new V3(),_ib=new V3();
/* IK analítica de dos huesos. A: articulación de arriba, T: objetivo. Escribe el codo/rodilla en B,
   el extremo real en E (si no llega, queda corto sobre la recta) y la normal del plano de doblez en N */
function ik2(A,T,L1,L2,polo,B,E,N,ymin){
  _ia.subVectors(T,A);let d=_ia.length();if(d<1e-6){_ia.set(0,-1,0);d=1e-6;}else _ia.divideScalar(d);
  const dd=clamp(d,Math.abs(L1-L2)+1e-4,(L1+L2)*.9995);
  N.copy(polo).addScaledVector(_ia,-polo.dot(_ia));
  if(N.lengthSq()<1e-10){N.set(0,0,1).addScaledVector(_ia,-_ia.z);if(N.lengthSq()<1e-10)N.set(1,0,0);}
  N.normalize();
  const ca=(L1*L1+dd*dd-L2*L2)/(2*L1*dd),sa=Math.sqrt(Math.max(0,1-ca*ca));
  /* piso: si el codo o la rodilla quedarían por debajo de ymin, el plano de doblez gira sobre el eje
     (lo mínimo necesario) para que la articulación quede arriba */
  if(ymin!==undefined){const cy=A.y+_ia.y*L1*ca,r=L1*sa;
    if(cy+r*N.y<ymin&&r>1e-4){_ib.crossVectors(_ia,N);const R=Math.hypot(N.y,_ib.y);
      if(R>1e-6){const k=(ymin-cy)/(r*R),f0=Math.atan2(_ib.y,N.y);let f;
        if(k>=1)f=f0;else{const ac=Math.acos(Math.max(-1,k)),f1=envol(f0-ac),f2=envol(f0+ac);f=Math.abs(f1)<Math.abs(f2)?f1:f2;}
        const c=Math.cos(f),s=Math.sin(f);N.multiplyScalar(c).addScaledVector(_ib,s).normalize();}}}
  B.copy(A).addScaledVector(_ia,L1*ca).addScaledVector(N,L1*sa);E.copy(A).addScaledVector(_ia,dd);
}

function nuevaPose(){
  const m=()=>({p:new V3(),q:new Q4(),polo:new V3(0,-1,0)});
  return {pel:new V3(),pelQ:new Q4(),col:new Q4(),pec:new Q4(),cue:new Q4(),cab:new Q4(),mano:[m(),m()],pie:[m(),m()],ded:[0,0,0],punta:[0,0]};
}
function copiarPose(o,a){
  o.pel.copy(a.pel);o.pelQ.copy(a.pelQ);o.col.copy(a.col);o.pec.copy(a.pec);o.cue.copy(a.cue);o.cab.copy(a.cab);
  for(let i=0;i<2;i++){o.mano[i].p.copy(a.mano[i].p);o.mano[i].q.copy(a.mano[i].q);o.mano[i].polo.copy(a.mano[i].polo);
    o.pie[i].p.copy(a.pie[i].p);o.pie[i].q.copy(a.pie[i].q);o.pie[i].polo.copy(a.pie[i].polo);o.punta[i]=a.punta[i];}
  o.ded[0]=a.ded[0];o.ded[1]=a.ded[1];o.ded[2]=a.ded[2];return o;
}
/* o = a mezclado con b (w=0 → a, w=1 → b). o puede ser a. manos/pies: qué partes mezclar */
function mezclarPose(o,a,b,w,manos=true,pies=true){
  if(w<=0){if(o!==a)copiarPose(o,a);return o;}
  o.pel.lerpVectors(a.pel,b.pel,w);o.pelQ.copy(a.pelQ).slerp(b.pelQ,w);
  o.col.copy(a.col).slerp(b.col,w);o.pec.copy(a.pec).slerp(b.pec,w);o.cue.copy(a.cue).slerp(b.cue,w);o.cab.copy(a.cab).slerp(b.cab,w);
  for(let i=0;i<2;i++){
    if(manos){const x=o.mano[i],y=a.mano[i],z=b.mano[i];x.p.lerpVectors(y.p,z.p,w);x.q.copy(y.q).slerp(z.q,w);x.polo.lerpVectors(y.polo,z.polo,w);}
    else if(o!==a){o.mano[i].p.copy(a.mano[i].p);o.mano[i].q.copy(a.mano[i].q);o.mano[i].polo.copy(a.mano[i].polo);}
    if(pies){const x=o.pie[i],y=a.pie[i],z=b.pie[i];x.p.lerpVectors(y.p,z.p,w);x.q.copy(y.q).slerp(z.q,w);x.polo.lerpVectors(y.polo,z.polo,w);o.punta[i]=lerp(a.punta[i],b.punta[i],w);}
    else if(o!==a){o.pie[i].p.copy(a.pie[i].p);o.pie[i].q.copy(a.pie[i].q);o.pie[i].polo.copy(a.pie[i].polo);o.punta[i]=a.punta[i];}
  }
  for(let i=0;i<3;i++)o.ded[i]=lerp(a.ded[i],b.ded[i],w);
  return o;
}
const _gq=new Q4();
/* gira una pose entera alrededor del eje Y que pasa por el origen del modelo */
function girarPose(o,ang){
  if(Math.abs(ang)<1e-5)return o;const q=qE(_gq,0,ang,0);
  o.pel.applyQuaternion(q);o.pelQ.premultiply(q);
  for(let i=0;i<4;i++){const m=i<2?o.mano[i]:o.pie[i-2];m.p.applyQuaternion(q);m.q.premultiply(q);m.polo.applyQuaternion(q);}
  return o;
}

/* ---------- resolución: de la pose a las transformaciones de los huesos ---------- */
function cadena(P,Q,i,local){const p=PADRE[i];Q[i].copy(Q[p]).multiply(local);P[i].copy(OFF[i]).applyQuaternion(Q[p]).add(P[p]);}
function resolverColumna(st,sp,conCabeza=true){
  const P=st.P,Q=st.Q;P[H.cadera].copy(sp.pel);Q[H.cadera].copy(sp.pelQ);
  cadena(P,Q,H.columna,sp.col);cadena(P,Q,H.pecho,sp.pec);
  if(conCabeza){cadena(P,Q,H.cuello,sp.cue);cadena(P,Q,H.cabeza,sp.cab);}
}
/* puntos del borceguí para no hundirlo: del pie (marco del tobillo) y de la puntera (marco de la base de los dedos, que se dobla aparte) */
const PUNTOS_PIE=[[0,-.085,-.08],[0,-.085,.12],[0,.05,0],[0,.06,.1],[.053,-.085,-.09],[-.053,-.085,-.09],[.053,-.085,.12],[-.053,-.085,.12],[0,-.07,-.1],[.06,.0,-.04],[-.06,.0,-.04]].map(a=>new V3(...a));
const PUNTOS_PUNTA=[[0,-.025,.08],[0,.035,.085],[.05,-.025,.04],[-.05,-.025,.04]].map(a=>new V3(...a));
const _rqp=new Q4(),_ra=new V3(),_rb=new V3(),_rc=new V3(),_rd=new V3(),_rn=new V3(),_rg=new V3(),_rq=new Q4();
function resolverMiembros(st,sp){
  const P=st.P,Q=st.Q;
  for(let l=0;l<2;l++){                                    /* brazos: 0 izquierdo, 1 derecho */
    const b=l?H.brazoD:H.brazoI,a=b+1,m=b+2,h=sp.mano[l];
    _ra.copy(OFF[b]);_ra.x*=st.kx;_ra.applyQuaternion(Q[H.pecho]).add(P[H.pecho]);
    /* el hombro se adelanta (hasta 4,5 cm) cuando la mano queda lejos: la clavícula */
    _rg.subVectors(h.p,_ra);const d=_rg.length(),alc=(L_BRAZO+L_ANTEBRAZO)*.96;
    if(d>alc)_ra.addScaledVector(_rg,Math.min(.045,d-alc)/d);
    ik2(_ra,h.p,L_BRAZO,L_ANTEBRAZO,h.polo,_rb,_rc,_rn,.062);
    _rn.negate();                                          /* el pliegue del codo mira al lado contrario del codo */
    P[b].copy(_ra);_rg.subVectors(_rb,_ra);qSeg(Q[b],_rg,_rn);
    P[a].copy(_rb);_rg.subVectors(_rc,_rb);qSeg(Q[a],_rg,_rn);
    P[m].copy(_rc);Q[m].copy(h.q);
  }
  cadena(P,Q,H.dedosI,qE(_rq,0,0,-sp.ded[0]));cadena(P,Q,H.dedosI2,qE(_rq,0,0,-sp.ded[1]));cadena(P,Q,H.indiceD,qE(_rq,0,0,sp.ded[2]));
  for(let l=0;l<2;l++){                                    /* piernas */
    const t=l?H.musloD:H.musloI,s=t+1,p=t+2,f=sp.pie[l];
    /* el borceguí nunca entra en el piso: si algún punto del pie quedaría abajo, sube el tobillo */
    let my=1;for(const q of PUNTOS_PIE){_rg.copy(q).applyQuaternion(f.q);my=Math.min(my,_rg.y);}
    _rq.copy(f.q).multiply(qE(_rqp,sp.punta[l],0,0));_rd.copy(OFF[t+3]).applyQuaternion(f.q);
    for(const q of PUNTOS_PUNTA){_rg.copy(q).applyQuaternion(_rq).add(_rd);my=Math.min(my,_rg.y);}
    if(f.p.y+my<.002)f.p.y=.002-my;
    _ra.copy(OFF[t]).applyQuaternion(Q[H.cadera]).add(P[H.cadera]);
    ik2(_ra,f.p,L_MUSLO,L_PIERNA,f.polo,_rb,_rc,_rn,.08);
    P[t].copy(_ra);_rg.subVectors(_rb,_ra);qSeg(Q[t],_rg,_rn);
    P[s].copy(_rb);_rg.subVectors(_rc,_rb);qSeg(Q[s],_rg,_rn);
    P[p].copy(_rc);Q[p].copy(f.q);
    cadena(P,Q,t+3,qE(_rq,sp.punta[l],0,0));
  }
}

/* pie apoyado: dado el punto de apoyo (proyección del tobillo con el pie plano), el rumbo y el
   cabeceo (positivo: talón arriba, pivota en la base de los dedos; negativo: punta arriba, pivota en el talón),
   escribe el tobillo y la orientación del pie */
const _pa=new V3(),_pq=new Q4(),BOLA=new V3(0,-.06,.135),TALON=new V3(0,-.078,-.07);
function piePlantado(f,x,y,z,rumbo,cabeceo,giroExtra=0){
  qE(f.q,0,rumbo,0);
  const piv=cabeceo>=0?BOLA:TALON;
  _pa.copy(piv).applyQuaternion(f.q);                       /* pivote con el pie plano */
  qE(_pq,cabeceo,rumbo,giroExtra);
  f.p.set(x,y+ALTO_TOBILLO,z).add(_pa);                      /* punto del pivote en el mundo del modelo */
  _pa.copy(piv).applyQuaternion(_pq);f.p.sub(_pa);f.q.copy(_pq);
}

/* ====================================================================================
   ANIMACIÓN DEL SOLDADO VIVO
   Orden de cada cuadro: movimiento del root → pies (clavados en el mundo, con el paso atado a la
   distancia) → cadera y columna (postura, puntería, capas) → cabeza → arma → manos → miembros.
   ==================================================================================== */

/* posturas fijas: rodillas en el piso → plancha con una mano al piso → panza abajo.
   pies: {anc:[x,z,rumbo,cabeceo]} (apoyado, con piePlantado) o {p,fwd,up}; y el polo de la rodilla */
function poseFija(pel,pelE,colE,pecE,pies){
  const p=nuevaPose();p.pel.set(...pel);qE(p.pelQ,...pelE);qE(p.col,...colE);qE(p.pec,...pecE);
  for(let i=0;i<2;i++){const f=pies[i],o=p.pie[i];
    if(f.anc){piePlantado(o,f.anc[0],0,f.anc[1],f.anc[2],f.anc[3]);p.punta[i]=-f.anc[3];}
    else{o.p.set(...f.p);qBase(o.q,new V3(...f.fwd),new V3(...f.up));p.punta[i]=0;}
    o.polo.set(...f.polo).normalize();}
  return p;
}
const K_RODILLAS=poseFija([0,.53,-.06],[.22,0,0],[.12,0,0],[.1,0,0],
  [{anc:[.12,-.585,0,1.15],polo:[0,-.35,1]},{anc:[-.12,-.585,0,1.15],polo:[0,-.35,1]}]);
const K_MANOS=poseFija([0,.37,-.40],[1.28,0,0],[.12,0,0],[.06,0,0],
  [{anc:[.14,-1.38,0,1.3],polo:[0,-.3,1]},{anc:[-.14,-1.38,0,1.3],polo:[0,-.3,1]}]);
const K_TIERRA=poseFija([0,.19,-.12],[PI/2,0,0],[-.26,0,0],[-.36,0,0],
  [{p:[.27,.105,-1.0],fwd:[.3,-.28,-.91],up:[.1,-.95,.28],polo:[.6,-1,0]},{p:[-.27,.105,-1.0],fwd:[-.3,-.28,-.91],up:[-.1,-.95,.28],polo:[-.6,-1,0]}]);
/* pie al arrastrarse: la pierna activa se recoge hacia el costado */
const PIE_ARRASTRE=[new V3(.40,.08,-.60),new V3(-.40,.08,-.60)],POLO_ARRASTRE=[new V3(1,-.25,.3).normalize(),new V3(-1,-.25,.3).normalize()];

/* descanso de los pies (modelo): [x, z, rumbo] de pie quieto / de pie andando / rodilla en tierra / agachado andando */
const DESCANSO=[
  [[.14,.11,.12],[.10,0,.06],[.13,.31,.10],[.14,0,.15]],
  [[-.13,-.12,-.38],[-.10,0,-.06],[-.15,-.42,-.15],[-.14,0,-.15]]];

/* claves de las capas (constantes: nada se arma en cada cuadro) */
const KC1=[[0,0],[.25,0],[.45,-.6],[.56,.45],[.75,.3],[1,0]],
  KC2=[[0,0],[.3,0],[.45,-.15],[.56,.25],[.72,.15],[1,0]],
  KC3=[[0,0],[.3,-.45],[.42,-.1],[.5,.45],[.65,.35],[1,0]],
  KC4=[[0,0],[.3,-.05],[.5,.22],[.65,.15],[1,0]],
  KC5=[[0,0],[.3,-.04],[.5,.11],[.7,.08],[1,0]],
  KC6=[[0,0],[.15,-.1],[.3,.1],[.45,.36],[.62,.24],[.78,-.12],[.9,-.05],[1,0]],
  KC7=[[0,0],[.3,.08],[.6,.05],[1,0]],
  KC8=[[0,0],[.3,.4],[.5,.62],[.75,.2],[1,0]],
  KC9=[[0,0],[.35,.25],[.55,.35],[.75,0]],
  KC10=[[0,-.12,.12,.12],[.3,-.24,.10,-.02],[.42,-.12,.20,.25],[.5,-.03,.30,.52],[.62,-.04,.28,.47],[.85,-.1,.15,.2],[1,-.12,.12,.12]],
  KC11=[[0,.25,-.3,1],[.3,.55,.35,.75],[.42,1,.25,-.05],[.5,.38,-.3,-.88],[.62,.4,-.25,-.88],[.85,.3,-.2,.9],[1,.25,-.3,1]],
  KC12=[[.17,0],[.25,.14],[.33,.25]],
  KC13=[[.48,.12],[.58,.06],[.64,0]],
  KC14=[[0,0],[.15,0],[.55,1],[.8,1],[1,0]],
  KC15=[[0,-.1,-.05,.25],[.14,.02,-.06,.22],[.24,-.05,.12,.3],[.40,-.30,.36,-.22],[.47,-.32,.38,-.18],[.55,-.12,.48,.38],[.68,.14,-.18,.38],[.8,.05,-.1,.3],[1,-.1,-.05,.25]],
  KC16=[[0,-.7,-.6,-.2],[.24,-.8,-.4,-.2],[.40,-.7,.55,-.45],[.55,-.6,.3,.2],[.68,-.4,-.7,.3],[1,-.7,-.6,-.2]],
  KC17=[[0,-.5],[.4,.6],[.55,.2],[.7,-.6]],
  KC18=[[0,0],[.35,1],[.55,1],[1,0]];
const fr=x=>x-Math.floor(x);
/* curva por tramos: claves [[t,v],…] con escalón suave entre claves */
function curva(t,k){if(t<=k[0][0])return k[0][1];for(let i=1;i<k.length;i++)if(t<=k[i][0]){const a=k[i-1],b=k[i];return lerp(a[1],b[1],ease((t-a[0])/(b[0]-a[0])));}return k[k.length-1][1];}
/* lo mismo con vectores: claves [[t,x,y,z],…] */
function curvaV(t,k,o){if(t<=k[0][0])return o.set(k[0][1],k[0][2],k[0][3]);
  for(let i=1;i<k.length;i++)if(t<=k[i][0]){const a=k[i-1],b=k[i],w=ease((t-a[0])/(b[0]-a[0]));return o.set(lerp(a[1],b[1],w),lerp(a[2],b[2],w),lerp(a[3],b[3],w));}
  const z=k[k.length-1];return o.set(z[1],z[2],z[3]);}
/* resorte amortiguado: x'' = -w²x - 2zw x' */
function resorte(s,x,v,w,z,dt){const a=-w*w*s[x]-2*z*w*s[v];s[v]+=a*dt;s[x]+=s[v]*dt;}

/* pasa un punto del marco del pecho (o de cualquier hueso) al modelo */
const aModelo=(st,hueso,x,y,z,o)=>o.set(x,y,z).applyQuaternion(st.Q[hueso]).add(st.P[hueso]);

/* ---------- movimiento del root ---------- */
function movimiento(st,root,dt){
  const yaw=root.rotation.y,px=root.position.x,pz=root.position.z;
  if(st.nuevo){st.prevX=px;st.prevZ=pz;st.prevYaw=yaw;st.nuevo=false;st.reubicar=true;}
  let dx=px-st.prevX,dz=pz-st.prevZ;st.prevX=px;st.prevZ=pz;
  if(dx*dx+dz*dz>2.25){dx=dz=0;st.reubicar=true;st.vel.set(0,0,0);}     /* teletransporte: se reacomoda */
  st.dyaw=envol(yaw-st.prevYaw);st.prevYaw=yaw;st.yaw=yaw;st.px=px;st.pz=pz;
  st.cy=Math.cos(yaw);st.sy=Math.sin(yaw);
  st.dist=Math.hypot(dx,dz)/st.k;
  if(dt>0){const a=Math.min(1,dt*9);st.vel.x+=(dx/st.k/dt-st.vel.x)*a;st.vel.z+=(dz/st.k/dt-st.vel.z)*a;}
  st.rap=Math.hypot(st.vel.x,st.vel.z);
  st.vlx=st.cy*st.vel.x-st.sy*st.vel.z;st.vlz=st.sy*st.vel.x+st.cy*st.vel.z;   /* velocidad en el marco del cuerpo */
}
const aMundo=(st,lx,lz,o)=>{o.x=st.px+(st.cy*lx+st.sy*lz)*st.k;o.z=st.pz+(-st.sy*lx+st.cy*lz)*st.k;return o;};
const aLocal=(st,wx,wz,o)=>{const dx=(wx-st.px)/st.k,dz=(wz-st.pz)/st.k;o.x=st.cy*dx-st.sy*dz;o.z=st.sy*dx+st.cy*dz;return o;};

/* ---------- pies clavados en el mundo ----------
   Andando, la fase avanza con la distancia: cada pie levanta cuando su fase entra en vuelo y cae
   adelante, en el lugar donde va a quedar el cuerpo (predicción con la velocidad). Apoyado no se mueve
   en el mundo: no patina. Quieto, si un pie quedó lejos de su lugar (frenó a mitad de paso, giró,
   cambió de postura), da un paso corto para acomodarse. */
const _fa=new V3(),_fb=new V3();
function pies(st,dt,L,beta,alza,mv,ag,cr){
  const kn=ag*(1-mv);
  for(let i=0;i<2;i++){const D=DESCANSO[i];
    st.rest[i].set(descanso(D,0,mv,ag),0,descanso(D,1,mv,ag));st.restYaw[i]=descanso(D,2,mv,ag);}
  if(st.reubicar){for(let i=0;i<2;i++){const f=st.pie[i];aMundo(st,st.rest[i].x,st.rest[i].z,f.w);f.yaw=st.yaw+st.restYaw[i];f.vuelo=false;f.pos.copy(f.w);f.yawAct=f.yaw;f.alto=0;f.cab=0;f.ciclo=-9;}st.reubicar=false;}
  const mov=st.rap>.06&&st.ti<.5,vn=st.rap||1,dwx=st.vel.x/vn,dwz=st.vel.z/vn;
  const err=st.errPie;
  for(let i=0;i<2;i++){const f=st.pie[i];aMundo(st,st.rest[i].x,st.rest[i].z,_fa);
    err[i]=Math.hypot(f.w.x-_fa.x,f.w.z-_fa.z)/st.k+.16*Math.abs(envol(f.yaw-st.yaw-st.restYaw[i]));}
  for(let i=0;i<2;i++){
    const f=st.pie[i],o=st.pie[1-i],yawR=st.yaw+st.restYaw[i],q=fr(st.fase+i*.5),ciclo=Math.floor(st.fase+i*.5);
    aMundo(st,st.rest[i].x,st.rest[i].z,_fa);
    if(f.vuelo){
      if(f.modo===0){
        const sF=ciclo>f.ciclo?1:(q-f.q0)/(1-f.q0);
        f.s=mov?Math.max(f.s,Math.min(1,sF)):Math.min(1,f.s+dt/.2);
        const resto=mov?((1-f.s)*(1-beta)*L+beta*L*.4)*st.k:0;   /* cae un poco adelante: el apoyo queda más atrás que adelante */
        _fb.set(_fa.x+dwx*resto,0,_fa.z+dwz*resto);
      }else{f.s=Math.min(1,f.s+dt/f.dur);_fb.copy(_fa);}
      const w=ease(f.s);
      f.pos.x=lerp(f.desde.x,_fb.x,w);f.pos.z=lerp(f.desde.z,_fb.z,w);
      f.alto=f.alza*Math.pow(Math.sin(PI*f.s),.8);
      f.yawAct=f.desdeYaw+envol(yawR-f.desdeYaw)*w;
      f.cab=f.modo===0?(-(.5+.4*cr)*Math.sin(PI*Math.min(1,f.s*1.7))*(f.s<.59?1:0)+.28*sst(.55,.85,f.s)*(1-sst(.9,1,f.s))):0;
      if(f.s>=1){f.vuelo=false;f.w.copy(_fb);f.yaw=yawR;f.pos.copy(f.w);f.yawAct=yawR;f.alto=0;f.cab=0;}
    }else{
      f.pos.copy(f.w);f.yawAct=f.yaw;f.alto=0;f.cab=0;
      if(mov){
        if(q>=beta&&ciclo>f.ciclo&&(cr>.3||!o.vuelo)){f.vuelo=true;f.modo=0;f.s=0;f.q0=Math.min(q,.97);f.ciclo=ciclo;f.desde.copy(f.w);f.desdeYaw=f.yaw;f.alza=alza;}
      }else if(!o.vuelo&&st.t>st.pausaPaso&&st.ti<.3){
        const umbral=kn>.5?.07:.11;
        if(err[i]>umbral&&err[i]>=err[1-i]){f.vuelo=true;f.modo=1;f.s=0;f.dur=lerp(.24,.32,ag);f.desde.copy(f.w);f.desdeYaw=f.yaw;f.alza=lerp(.07,.05,ag);st.pausaPaso=st.t+f.dur+.04;}
      }
    }
  }
}

/* ---------- el soldado vivo ---------- */
const _v=[0,1,2,3,4,5,6,7].map(()=>new V3()),_w=[0,1,2,3].map(()=>new Q4());
/* lleva una mano hacia el objetivo de una capa (_v[5] posición, _w[3] giro, _v[6] codo) con peso w */
function fijar(m,w){if(w<=0)return;m.p.lerp(_v[5],w);m.q.slerp(_w[3],w);m.polo.lerp(_v[6],w).normalize();}
function descanso(D,j,mv,ag){return lerp(lerp(D[0][j],D[1][j],mv),lerp(D[2][j],D[3][j],mv),ag);}
function vivo(st,e,dt){
  const sp=st.sp,fi=st.ficha,P=st.P,Q=st.Q,a1=_v[0],a2=_v[1],a3=_v[2],a4=_v[3],a5=_v[4],a6=_v[5],a7=_v[6],a8=_v[7],q1=_w[0],q2=_w[1],q3=_w[2],q4=_w[3];
  /* entradas, apenas suavizadas (la IA puede saltar de golpe) */
  st.ap+=(sat(e.apunta)-st.ap)*Math.min(1,dt*14);st.ag+=(sat(e.agach)-st.ag)*Math.min(1,dt*12);st.ti+=(sat(e.tierra)-st.ti)*Math.min(1,dt*12);
  st.as+=(clamp(e.asoma||0,-1,1)-st.as)*Math.min(1,dt*10);st.mYaw+=(clamp(e.mYaw||0,-1.3,1.3)-st.mYaw)*Math.min(1,dt*18);st.mPitch+=(clamp(e.mPitch||0,-.9,.9)-st.mPitch)*Math.min(1,dt*18);
  st.radio+=(sat(e.radio||0)-st.radio)*Math.min(1,dt*8);st.aturd+=(sat(e.aturdido||0)-st.aturd)*Math.min(1,dt*5);
  const ti=st.ti,ag=st.ag*(1-sst(0,.35,ti)),rap=st.rap,mv=sst(.1,.55,rap),cr=sst(2.6,4.8,rap)*(1-ag),at=st.aturd;
  const rec=e.recarga>=0?sat(e.recarga):-1,lan=e.lanza>=0?sat(e.lanza):-1,sen=e.senal>=0?sat(e.senal):-1,cul=e.culata>=0?sat(e.culata):-1,sal=e.salto>=0?sat(e.salto):-1;
  /* ---- paso ---- */
  const L=lerp(.8+.4*rap,.66+.3*rap,ag)*st.ritmo,beta=lerp(lerp(.54,.26,cr),.6,ag),alza=lerp(lerp(.11,.2,cr),.075,ag);
  if(rap>.05&&ti<.5)st.fase+=st.dist/L;
  if(ti>.5&&rap>.03)st.faseR+=st.dist/.9;
  pies(st,dt,L,beta,alza,mv,ag,cr);
  /* ---- pose base de pie / agachado ---- */
  const fw=st.fase*TAU;
  let py=lerp(lerp(lerp(.948-.012*st.ap,.945,mv),.915,cr),lerp(.535,.67,mv),ag);
  py+=mv*(1-ag*.5)*(-.016*(1-cr)*Math.cos(2*fw)-.03*cr*Math.cos(2*fw-beta*TAU))+st.respira*.004*Math.sin(st.t*1.6+st.fase0);
  const osc=.07*mv*(1-cr*.5)*Math.sin(fw);
  sp.pel.set(.022*mv*(1-cr)*Math.sin(fw)+.1*st.as*(1-ti),py-.05*Math.abs(st.as),lerp(0,.05,cr)+lerp(0,-.04,ag*(1-mv)));
  const lean=lerp(lerp(.09+.07*st.ap,.1,mv),.24,cr)+lerp(0,lerp(.12,.38,mv),ag);
  qE(sp.pelQ,lean*.6,.2*st.mYaw-.06*st.ap+osc,0);
  qE(sp.col,lean*.2+.06*at,.3*st.mYaw-osc*.6,.4*st.as);
  qE(sp.pec,lean*.2-.1*st.mPitch*(1-ti)+.1*at,.33*st.mYaw-(.16+.14*st.ap)*(1-ti)-osc*.4,.32*st.as);
  /* piernas desde los pies clavados */
  for(let i=0;i<2;i++){const f=st.pie[i],o=sp.pie[i];aLocal(st,f.pos.x,f.pos.z,a1);
    const ry=envol(f.yawAct-st.yaw),arrod=i===1?ag*(1-mv)*(1-ti):0;
    piePlantado(o,a1.x,f.alto,a1.z,ry,f.vuelo?f.cab:1.15*arrod);
    sp.punta[i]=f.vuelo?0:-1.15*arrod;
    o.polo.set(Math.sin(ry)+(i?-.15:.15),-.45*arrod,Math.cos(ry)).normalize();}
  /* cuerpo a tierra: rodillas → manos al piso → panza abajo (pasando por poses intermedias) */
  if(ti>.001){
    if(ti<.4)mezclarPose(sp,sp,K_RODILLAS,ease(ti/.4),false);
    else if(ti<.7)mezclarPose(sp,K_RODILLAS,K_MANOS,ease((ti-.4)/.3),false);
    else{const pr=st.poseT;copiarPose(pr,K_TIERRA);
      /* arrastrarse: piernas alternadas y un poco de rolido */
      if(rap>.03){const s=Math.sin(st.faseR*TAU),w=sst(.03,.25,rap);
        for(let i=0;i<2;i++){const c=sat((i?-s:s))*w,o=pr.pie[i];o.p.lerp(PIE_ARRASTRE[i],c);o.polo.lerp(POLO_ARRASTRE[i],c).normalize();}
        pr.pelQ.multiply(qE(q1,0,0,.12*s*w));}
      mezclarPose(sp,K_MANOS,pr,ease((ti-.7)/.3),false);}
    if(ti>.85){sp.pec.multiply(qE(q1,-.25*st.mPitch,.25*st.mYaw,.18*st.as));sp.pelQ.multiply(qE(q1,0,.15*st.mYaw,0));}
  }
  /* capas que mueven el tronco */
  if(lan>=0){const tw=curva(lan,KC1),lb=curva(lan,KC2);
    sp.pec.multiply(qE(q1,lb*.6,tw*.6,0));sp.col.multiply(qE(q1,lb*.4,tw*.4,0));}
  if(cul>=0){const tw=curva(cul,KC3),lb=curva(cul,KC4);
    sp.pec.multiply(qE(q1,lb*.5,tw*.55,0));sp.col.multiply(qE(q1,lb*.5,tw*.45,0));sp.pel.z+=curva(cul,KC5)*(1-ti);}
  if(sal>=0){const sy=curva(sal,KC6);
    sp.pel.y+=sy;sp.pel.z+=curva(sal,KC7);sp.pelQ.multiply(qE(q1,curva(sal,KC8),0,curva(sal,KC9)));}
  if(at>.001){sp.col.multiply(qE(q1,.06*at*Math.sin(st.t*1.3),0,.1*at*Math.sin(st.t*.9)));sp.pel.y-=.06*at;}
  /* golpes y patada del arma: resortes sobre el pecho */
  sp.pec.multiply(qE(q1,st.gp-st.rp*.12,0,st.gr));sp.col.multiply(qE(q1,st.gp*.5,0,st.gr*.5));
  /* el pie de atrás levanta el talón (pivota en la base de los dedos) y, si igual no llega, la cadera baja un poco */
  resolverColumna(st,sp,false);
  if(ti<.5){let baja=0;
    for(let i=0;i<2;i++){const f=st.pie[i],o=sp.pie[i];
      a1.copy(OFF[i?H.musloD:H.musloI]).applyQuaternion(Q[H.cadera]).add(P[H.cadera]);
      if(!f.vuelo&&!(i===1&&ag*(1-mv)>.3)){
        const atras=-((o.p.x-a1.x)*st.vlx+(o.p.z-a1.z)*st.vlz)/(rap||1);
        const c=mv*clamp((atras-.17)*2.4,0,.85);
        if(c>0){aLocal(st,f.pos.x,f.pos.z,a2);piePlantado(o,a2.x,0,a2.z,envol(f.yawAct-st.yaw),c);sp.punta[i]=-c;}}
      if(f.vuelo&&f.s>.15&&f.s<.85)continue;
      const dh=Math.hypot(a1.x-o.p.x,a1.z-o.p.z),lm=(L_MUSLO+L_PIERNA)*.995;
      if(dh<lm){const ym=o.p.y+Math.sqrt(lm*lm-dh*dh);baja=Math.max(baja,a1.y-ym);}}
    baja=Math.min(baja,.11)*(1-sst(.3,.5,ti));if(sal>.15&&sal<.85)baja=0;
    if(baja>0){sp.pel.y-=baja;resolverColumna(st,sp,false);}}
  /* ---- cabeza: mira hacia donde apunta; con el arma al hombro, mejilla a la culata ---- */
  const apE=st.ap*(1-sat(st.golpeT*3))*(1-.85*at)*(1-.5*cr);
  qE(q1,-st.mPitch*.85+.2*apE*(1-ti*.5)+.35*at+.3*at*Math.sin(st.t*.7),st.mYaw*.97,.14*apE*(1-ti*.6)+.12*st.radio-.25*at*Math.sin(st.t*.5)+.3*st.as*(1-ti));
  q2.copy(Q[H.pecho]).invert().multiply(q1);
  sp.cue.copy(QI).slerp(q2,.45);sp.cab.copy(sp.cue).invert().multiply(q2);
  sp.cab.multiply(qE(q3,st.gp*1.6,0,st.gr*1.6));
  cadena(P,Q,H.cuello,sp.cue);cadena(P,Q,H.cabeza,sp.cab);
  a1.set(0,ti,1-ti).applyQuaternion(Q[H.pecho]);st.yawPecho=Math.atan2(a1.x,a1.z);
  /* ---- arma ---- */
  armaViva(st,e,dt,apE,ti,rec,lan,sen,cul,sal,cr);
  /* ---- manos ---- */
  manosVivas(st,e,ti,rec,lan,sen,cul,sal,at);
  resolverMiembros(st,sp);
}

/* ---------- el arma en las manos ---------- */
function armaViva(st,e,dt,apE,ti,rec,lan,sen,cul,sal,cr){
  const P=st.P,Q=st.Q,W=st.arma,fi=st.ficha,a1=_v[0],a2=_v[1],a3=_v[2],a4=_v[3],a5=_v[4],a6=_v[5],q1=_w[0],q2=_w[1],q3=_w[2];
  const ya=st.mYaw,pa=st.mPitch;
  a1.set(Math.sin(ya)*Math.cos(pa),Math.sin(pa),Math.cos(ya)*Math.cos(pa));          /* hacia dónde apunta */
  /* al hombro: cantonera en el bolsillo del hombro derecho, la mira frente al ojo */
  aModelo(st,H.pecho,-.125*st.kx,.205,.10,st.pAim);qBase(st.qAim,a1,EJY);
  aModelo(st,H.cabeza,-.034,.105,.075,a2);                                             /* ojo derecho (detrás del lente) */
  a3.copy(fi.ojo).applyQuaternion(st.qAim).add(st.pAim);                               /* dónde queda la mira */
  a2.sub(a3);a4.set(1,0,0).applyQuaternion(st.qAim);a5.set(0,1,0).applyQuaternion(st.qAim);
  st.pAim.addScaledVector(a4,clamp(a2.dot(a4),-.04,.04)).addScaledVector(a5,clamp(a2.dot(a5)-.012,-.06,.05));
  /* arma baja: la boca abajo y hacia adentro (en el piso, apenas baja) */
  const yl=ya+.28*(1-ti),pl=lerp(-.58+pa*.3,pa-.1,ti);
  a6.set(Math.sin(yl)*Math.cos(pl),Math.sin(pl),Math.cos(yl)*Math.cos(pl));
  qBase(st.qLow,a6,EJY);aModelo(st,H.pecho,-.115*st.kx,lerp(.165,.19,ti),.105,st.pLow);
  const w=ease(apE);W.p.lerpVectors(st.pLow,st.pAim,w);W.q.copy(st.qLow).slerp(st.qAim,w);
  /* corriendo, el arma rebota un poco */
  if(cr>0){W.p.y+=.012*cr*Math.sin(st.fase*TAU*2);W.q.multiply(qE(q1,.03*cr*Math.sin(st.fase*TAU*2+1),0,0));}
  /* recarga: el arma se acerca al pecho y se ladea para que la mano llegue al brocal */
  if(rec>=0){const wr=sst(0,.12,rec)*(1-sst(.86,1,rec));if(wr>0){
    const esc=fi.tipo==='escopeta';
    aModelo(st,H.pecho,-.13,lerp(.03,.2,ti),lerp(0,-.1,ti),a2);qE(q1,-.4+.25*ti,.35*(1-.6*ti),(esc?.8:.5)*(1-.5*ti));q1.premultiply(qE(q2,0,st.yawPecho,0));
    W.p.lerp(a2,wr);W.q.slerp(q1,wr);}}
  /* granada: el arma queda colgando en la mano izquierda, boca abajo */
  if(lan>=0){const wl=sst(0,.13,lan)*(1-sst(.8,.98,lan));if(wl>0){
    a3.set(.1,-.45,.89).normalize().applyQuaternion(qE(q2,0,st.yawPecho,0));qBase(q1,a3,EJY);
    aModelo(st,H.pecho,.26,-.28,.17,a2);a4.copy(fi.guarda).applyQuaternion(q1);a2.sub(a4);
    W.p.lerp(a2,wl);W.q.slerp(q1,wl);}}
  /* seña: una sola mano en el arma, boca al piso */
  if(sen>=0){const ws=sst(0,.15,sen)*(1-sst(.85,1,sen));if(ws>0){
    aModelo(st,H.pecho,-.11,.09,.11,a2);a3.set(Math.sin(ya+.2),-1.05,Math.cos(ya+.2)).normalize();qBase(q1,a3,EJY);
    W.p.lerp(a2,ws);W.q.slerp(q1,ws);}}
  /* culatazo: carga atrás, la culata sale adelante a la altura de la cara */
  if(cul>=0){const wc=sst(0,.12,cul)*(1-sst(.82,1,cul));if(wc>0){
    curvaV(cul,KC10,a4);
    aModelo(st,H.pecho,a4.x,a4.y,a4.z,a2);
    curvaV(cul,KC11,a3).normalize();
    a3.applyQuaternion(qE(q2,0,st.yawPecho,0));qBase(q1,a3,EJY);
    W.p.lerp(a2,wc);W.q.slerp(q1,wc);}}
  /* salto: el arma va en la mano derecha, al costado */
  if(sal>=0){const wv=sst(.05,.2,sal)*(1-sst(.8,.95,sal));if(wv>0){
    aModelo(st,H.pecho,-.2,-.05,.12,a2);a3.set(-.2,-.75,.6).normalize();qBase(q1,a3,EJY);W.p.lerp(a2,wv);W.q.slerp(q1,wv);}}
  /* patada del arma: gira sobre la cantonera y retrocede */
  W.q.multiply(qE(q1,-st.rp,0,0));a1.set(0,0,-st.rb).applyQuaternion(W.q);W.p.add(a1);
  /* cuerpo a tierra con bípode: el arma apoya un poco más alto */
  if(fi.bipode&&ti>.85&&apE>.5)W.p.y+=.0;
}

/* ---------- manos: agarradas al arma, salvo que una capa las lleve a otro lado ---------- */
function manosVivas(st,e,ti,rec,lan,sen,cul,sal,at){
  const sp=st.sp,P=st.P,Q=st.Q,W=st.arma,fi=st.ficha,a1=_v[0],a2=_v[1],a3=_v[2],a4=_v[3],a5=_v[4],a6=_v[5],a7=_v[6],q1=_w[0],q2=_w[1],q3=_w[2],q4=_w[3],mI=sp.mano[0],mD=sp.mano[1];
  /* derecha en la empuñadura, izquierda en el guardamanos (o en la corredera de la escopeta) */
  mD.q.copy(W.q).multiply(fi.agD.q);mD.p.copy(fi.agD.p).applyQuaternion(W.q).add(W.p);
  a1.copy(fi.agI.p);if(fi.agIcorredera)a1.z-=st.bombaZ;
  mI.q.copy(W.q).multiply(fi.agI.q);mI.p.copy(a1).applyQuaternion(W.q).add(W.p);
  /* si el guardamanos queda lejos, la mano se corre hacia atrás sobre él (la corredera no deja mucho) */
  {a2.copy(OFF[H.brazoI]);a2.x*=st.kx;a2.applyQuaternion(Q[H.pecho]).add(P[H.pecho]);a3.set(0,0,-1).applyQuaternion(W.q);
    const tope=fi.agIcorredera&&cul<0&&ti<.5?.05:.14,alc=(L_BRAZO+L_ANTEBRAZO)+.035;let corre=0;
    for(let it=0;it<3;it++){const d=a4.subVectors(mI.p,a2).length();if(d<=alc)break;
      const c=Math.min(tope-corre,(d-alc)*1.4);if(c<=1e-4)break;mI.p.addScaledVector(a3,c);corre+=c;}}
  /* codos: abajo y un poco afuera (de pie, en el marco del pecho sin su cabeceo); en el piso, apoyados */
  qE(q1,0,st.yawPecho,0);
  mD.polo.set(-.72,-.66,-.18).applyQuaternion(q1);mI.polo.set(.42,-.9,0).applyQuaternion(q1);
  if(ti>0){mD.polo.lerp(a1.set(-.5,-.86,.12),ti).normalize();mI.polo.lerp(a1.set(.5,-.86,.15),ti).normalize();}
  sp.ded[0]=1.05;sp.ded[1]=1.2;sp.ded[2]=st.ap>.85?.72:.12;
  if(st.armaSuelta){   /* sin arma: manos sueltas al costado */
    aModelo(st,H.cadera,.24,-.18,.03,mI.p);qMano(mI.q,true,a1.set(0,-1,.1),a2.set(-1,0,0));
    aModelo(st,H.cadera,-.24,-.18,.03,mD.p);qMano(mD.q,false,a1.set(0,-1,.1),a2.set(1,0,0));
    mI.polo.set(.3,0,-1);mD.polo.set(-.3,0,-1);sp.ded[0]=.4;sp.ded[1]=.5;sp.ded[2]=.4;return;}
  /* recarga */
  if(rec>=0&&fi.tipo!=='escopeta'){
    /* cargador: en el arma, en la mano, guardado o nuevo en la mano */
    const enMano=rec>.17&&rec<.64,visible=rec<.33||rec>.43;st.cargVis=visible?1:0;st.cargMano=enMano;
    /* agarre del cargador: palma de costado, dedos hacia adelante */
    a2.copy(fi.cargador).applyQuaternion(W.q).add(W.p);
    a3.set(0,-1,0).applyQuaternion(W.q);                        /* eje del cargador (hacia abajo) */
    const wMano=sst(.04,.16,rec)*(1-sst(.8,.93,rec));
    let objetivo;
    if(rec<.17){a6.copy(a2).addScaledVector(a3,.1);}                                             /* va al cargador */
    else if(rec<.33){a6.copy(a2).addScaledVector(a3,.1+curva(rec,KC12));}/* lo saca */
    else if(rec<.48){aModelo(st,H.cadera,.20,lerp(.0,.1,ti),.02,a4);aModelo(st,H.pecho,lerp(.078,.2,ti),-.06,lerp(.24,.05,ti),a5);a4.y=Math.max(a4.y,.08);a5.y=Math.max(a5.y,.09);
      a6.lerpVectors(a4,a5,sst(.38,.46,rec));}                                                    /* lo guarda y saca otro del chaleco */
    else if(rec<.64){aModelo(st,H.pecho,lerp(.078,.2,ti),-.06,lerp(.24,.05,ti),a5);a5.y=Math.max(a5.y,.09);a4.copy(a2).addScaledVector(a3,.1+curva(rec,KC13));
      a6.lerpVectors(a5,a4,sst(.48,.58,rec));}                                                    /* lo mete */
    else if(rec<.8){a4.set(.045,.02,.37).applyQuaternion(W.q).add(W.p);a5.copy(a2).addScaledVector(a3,.1);
      a6.lerpVectors(a5,a4,sst(.64,.72,rec));}                                                    /* golpe al retén */
    else a6.copy(mI.p);
    a4.set(0,0,1).applyQuaternion(W.q);qMano(q4,true,a4,a5.set(-1,.2,0).applyQuaternion(W.q));
    a7.set(.6,-.7,.2);fijar(mI,wMano);
    sp.ded[0]=lerp(sp.ded[0],1.3,wMano);sp.ded[1]=lerp(sp.ded[1],1.35,wMano);
    /* el cargador sigue a la mano mientras está en ella */
    st.cargEnMano=enMano?1:0;
  }else if(rec>=0){
    /* escopeta: tres cartuchos desde la canana a la ventana de carga */
    const c=fr(rec*3.2),wMano=sst(.03,.12,rec)*(1-sst(.88,.97,rec));
    aModelo(st,H.pecho,-.03,.09,.20,a4);a5.set(0,-.045,.42).applyQuaternion(W.q).add(W.p);
    a6.lerpVectors(a4,a5,curva(c,KC14));
    a4.set(0,.3,1).applyQuaternion(W.q);qMano(q4,true,a4,a5.set(0,1,0).applyQuaternion(W.q));
    a7.set(.6,-.7,0);fijar(mI,wMano);
    st.cargVis=wMano>.5&&c>.12&&c<.62?1:0;st.cargEnMano=1;
  }else{st.cargVis=1;st.cargEnMano=0;}
  /* granada: la derecha va al chaleco, la saca, carga atrás y lanza (sale en 0,55) */
  if(lan>=0){
    const wl=sst(.02,.12,lan)*(1-sst(.78,.95,lan));
    curvaV(lan,KC15,a1);
    a6.copy(a1).applyQuaternion(qE(q1,0,st.yawPecho,0)).add(P[H.pecho]);
    curvaV(lan,KC16,a7).applyQuaternion(q1).normalize();
    a2.set(0,0,1).applyQuaternion(q1);a3.copy(a7).negate();qMano(q4,false,a2.set(-.2,curva(lan,KC17),.8).applyQuaternion(q1),a3.set(.5,0,.3).applyQuaternion(q1));
    fijar(mD,wl);sp.ded[2]=lerp(sp.ded[2],.9,wl);
    st.granVis=lan>.15&&lan<.55?1:0;
  }else st.granVis=0;
  /* seña del jefe con la mano izquierda */
  if(sen>=0){
    const ws=sst(0,.17,sen)*(1-sst(.83,1,sen)),tipo=e.senalTipo||'avanzar',h=(sen-.17)/.66,osc=Math.sin(sat(h)*TAU*2);
    qE(q1,0,st.yawPecho,0);let abierto=1;
    if(tipo==='alto'){a1.set(.30,.40,.06);a2.set(.05,1,.05);a3.set(0,0,1);a7.set(1,-.3,-.1);abierto=0;}
    else if(tipo==='izq'){a1.set(.64,.15+.04*osc,.10);a2.set(1,.05,.1);a3.set(0,0,1);a7.set(0,-1,-.4);}
    else if(tipo==='der'){a1.set(-.30,.16+.03*osc,.42);a2.set(-1,0,.15);a3.set(0,0,-1);a7.set(.3,-1,.2);}
    else{const c=.5+.5*osc;a1.set(.24,lerp(.42,.16,c),lerp(.16,.56,c));a2.set(0,lerp(.7,0,c),lerp(.7,1,c));a3.set(-1,0,0);a7.set(.5,-1,-.2);}
    a6.copy(a1).applyQuaternion(q1).add(P[H.pecho]);a2.applyQuaternion(q1);a3.applyQuaternion(q1);a7.applyQuaternion(q1);
    qMano(q4,true,a2,a3);fijar(mI,ws);
    sp.ded[0]=lerp(sp.ded[0],abierto?.08:1.55,ws);sp.ded[1]=lerp(sp.ded[1],abierto?.05:1.7,ws);
  }
  /* camino a cuerpo a tierra: la izquierda se apoya en el piso */
  if(ti>.55&&ti<.97){const wt=sst(.56,.68,ti)*(1-sst(.86,.97,ti));a6.set(.25,.05,lerp(.42,.36,sst(.6,.9,ti)));
    qMano(q4,true,a2.set(.15,0,1),a3.set(0,-1,0));a7.set(1,.2,-.6);fijar(mI,wt);sp.ded[0]=lerp(sp.ded[0],.15,wt);sp.ded[1]=lerp(sp.ded[1],.1,wt);}
  /* radio: la izquierda al pulsador del pecho */
  if(st.radio>.01&&rec<0&&sen<0){aModelo(st,H.pecho,.09,.12,.20,a6);qE(q1,0,st.yawPecho,0);
    a2.set(-.5,.6,.3).applyQuaternion(q1);a3.set(-.2,0,-1).applyQuaternion(q1);qMano(q4,true,a2,a3);a7.set(.8,-.5,-.2).applyQuaternion(q1);
    fijar(mI,st.radio);sp.ded[0]=lerp(sp.ded[0],1.3,st.radio);sp.ded[1]=lerp(sp.ded[1],1.0,st.radio);}
  /* aturdido: se agarra la máscara */
  if(at>.4){const wa=sst(.4,.8,at);aModelo(st,H.cabeza,.11,.06,.06,a6);a2.set(-.3,.8,.3);a3.set(-1,0,-.2);
    a2.applyQuaternion(Q[H.cabeza]);a3.applyQuaternion(Q[H.cabeza]);qMano(q4,true,a2,a3);a7.set(1,-.6,0);fijar(mI,wa);}
  /* salto: la izquierda se apoya arriba de la valla (clavada en el mundo) */
  if(sal>=0){const wv=sst(.2,.3,sal)*(1-sst(.56,.66,sal)),wl=sst(.04,.16,sal)*(1-sst(.82,.95,sal));
    if(wl>0){aModelo(st,H.pecho,.2,-.02,.32,a6);qMano(q4,true,a2.set(.1,-.3,1),a3.set(-.3,-.6,.2));a7.set(1,-.4,-.3);fijar(mI,wl);}
    if(sal<.26||!st.saltoFijo){aModelo(st,H.cadera,.16,.0,.38,a1);aMundo(st,a1.x,a1.z,st.saltoW);st.saltoFijo=sal>=.26;}
    if(wv>0){aLocal(st,st.saltoW.x,st.saltoW.z,a6);a6.y=1.16;qMano(q4,true,a2.set(-.2,0,1),a3.set(0,-1,0));a7.set(1,.2,-.4);fijar(mI,wv);}
    /* piernas recogidas por encima de la valla */
    const wp=sst(.25,.38,sal)*(1-sst(.6,.78,sal));
    if(wp>0)for(let i=0;i<2;i++){const o=sp.pie[i];a1.set(i?-.05:.18,lerp(.75,1.12,sst(.25,.45,sal)),i?.05:-.06);
      o.p.lerp(a1,wp);o.polo.lerp(a2.set(i?-.4:.6,.2,1),wp).normalize();o.q.slerp(qE(q1,-.5,i?-.3:.4,0),wp);}
  }else st.saltoFijo=false;
}

/* ====================================================================================
   MUERTES
   Cuatro caídas armadas como poses clave. La primera clave es una foto de la pose viva en el
   momento de morir, así que arranca desde donde estaba. Los tramos que caen aceleran (gravedad)
   y al tocar el piso hay un rebote chico. 'dir' (de dónde vino el tiro) gira el plano de caída.
   Formato de cada clave: [t, cadera, giroCadera, columna, pecho, cuello, cabeza, manoI, manoD, pieI, pieD, dedos, tramo]
   mano: [posición muñeca, hacia dónde los dedos, hacia dónde la palma, codo]
   pie: 'S' (queda donde estaba) o [tobillo, hacia dónde la punta, hacia dónde el empeine, rodilla]
   tramo: cómo se llega a esta clave: 'o' frena, 'i' cae (acelera), 'e' suave
   ==================================================================================== */
const MUERTES={
  atras:[
    [.16,[0,.93,-.07],[-.18,0,0],[-.15,0,0],[-.25,0,0],[-.2,0,0],[-.3,0,0],
      [[.30,1.30,.22],[.2,.8,.6],[-1,0,0],[1,-.5,-.3]],[[-.30,1.25,.18],[-.2,.8,.6],[1,0,0],[-1,-.5,-.3]],'S','S',[.3,.3,.2],'o'],
    [.42,[0,.42,-.30],[-.75,0,0],[-.05,0,0],[-.1,0,0],[.25,0,0],[.2,0,0],
      [[.34,.95,-.05],[.3,1,0],[0,0,1],[1,0,-1]],[[-.36,.90,-.10],[-.3,1,0],[0,0,1],[-1,0,-1]],
      [[.13,.10,.14],[.15,.55,.82],[0,.83,-.55],[.2,.5,1]],[[-.15,.10,.08],[-.15,.55,.82],[0,.83,-.55],[-.2,.5,1]],[.4,.4,.3],'i'],
    [.70,[0,.205,-.62],[-PI/2,0,0],[.18,0,0],[.16,0,0],[-.12,0,0],[-.1,.35,0],
      [[.55,.06,-1.05],[.7,0,-.7],[0,0,1],[1,.1,0]],[[-.53,.06,-1.03],[-.7,0,-.7],[0,0,1],[-1,.1,0]],
      [[.20,.095,.26],[.45,.88,.1],[0,.1,-1],[0,1,0]],[[-.22,.095,.22],[-.45,.88,.1],[0,.1,-1],[0,1,0]],[.45,.5,.3],'i'],
    [1,[0,.205,-.64],[-PI/2,0,.1],[.17,0,0],[.16,0,0],[-.12,0,0],[-.1,.75,0],
      [[.58,.06,-.98],[.8,0,-.5],[0,0,1],[1,.1,0]],[[-.44,.065,-.80],[-.8,0,.4],[0,0,1],[-1,.2,0]],
      [[.24,.095,.0],[.6,.75,.25],[0,.3,-1],[.6,1,.3]],[[-.22,.095,.22],[-.5,.85,.1],[0,.1,-1],[0,1,0]],[.5,.6,.35],'e']],
  adelante:[
    [.15,[0,.92,.05],[.25,0,0],[.25,0,0],[.25,0,0],[.3,0,0],[.3,0,0],
      [[.24,.95,.25],[0,-1,.3],[-1,0,0],[1,0,-1]],[[-.24,.95,.20],[0,-1,.3],[1,0,0],[-1,0,-1]],'S','S',[.3,.3,.2],'o'],
    [.42,[0,.52,.02],[.35,0,0],[.3,0,0],[.3,0,0],[.4,0,0],[.4,0,0],
      [[.25,.50,.30],[0,-1,.2],[-1,0,0],[1,0,-1]],[[-.25,.50,.28],[0,-1,.2],[1,0,0],[-1,0,-1]],
      [[.13,.175,-.42],[0,-.91,.41],[0,.41,.91],[0,-.3,1]],[[-.13,.175,-.42],[0,-.91,.41],[0,.41,.91],[0,-.3,1]],[.4,.4,.3],'i'],
    [.72,[0,.195,.32],[PI/2,.08,0],[-.1,0,0],[-.12,0,0],[-.25,0,0],[-.1,1.2,0],
      [[.40,.06,.66],[.3,0,1],[-1,0,0],[1,.3,-.3]],[[-.33,.065,.26],[-.1,0,-1],[-1,0,0],[-1,.3,0]],
      [[.20,.07,-.54],[.3,-.45,-.84],[.15,-.88,.45],[.3,-1,0]],[[-.17,.07,-.57],[-.3,-.45,-.84],[-.15,-.88,.45],[-.3,-1,0]],[.45,.5,.35],'i'],
    [1,[0,.195,.33],[PI/2,.1,.05],[-.1,0,0],[-.12,0,0],[-.2,0,0],[-.1,1.35,0],
      [[.42,.06,.62],[.4,0,1],[-1,0,0],[1,.3,-.3]],[[-.32,.065,.28],[-.1,0,-1],[-1,0,0],[-1,.3,0]],
      [[.20,.07,-.54],[.3,-.45,-.84],[.15,-.88,.45],[.3,-1,0]],[[-.45,.08,-.36],[-.5,-.3,-.8],[-.2,-.9,.3],[-1,-.2,.3]],[.5,.6,.4],'e']],
  derrumbe:[
    [.25,[0,.72,-.02],[.3,0,.05],[.35,0,0],[.35,0,0],[.45,0,0],[.4,0,0],
      [[.22,.65,.12],[0,-1,0],[-1,0,0],[1,0,-1]],[[-.22,.65,.12],[0,-1,0],[1,0,0],[-1,0,-1]],'S','S',[.3,.3,.2],'o'],
    [.52,[0,.42,-.06],[.45,0,.12],[.4,0,0],[.35,0,0],[.5,0,0],[.4,0,0],
      [[.24,.30,.22],[0,-.6,1],[-.5,-.8,0],[1,0,-.5]],[[-.24,.30,.22],[0,-.6,1],[.5,-.8,0],[-1,0,-.5]],
      [[.12,.175,-.40],[0,-.91,.41],[0,.41,.91],[0,-.3,1]],[[-.12,.175,-.40],[0,-.91,.41],[0,.41,.91],[0,-.3,1]],[.4,.4,.3],'i'],
    [.82,[.30,.22,.04],[.4,0,-1.45],[.35,0,.12],[.3,0,.12],[.3,0,.15],[.2,0,.2],
      [[.80,.06,.40],[.3,0,1],[-1,0,0],[0,-1,.3]],[[.64,.19,.34],[.3,0,1],[1,0,0],[0,-1,.3]],
      [[-.22,.07,.04],[0,0,1],[1,0,0],[0,0,1]],[[-.25,.22,.0],[0,0,1],[1,0,0],[0,0,1]],[.45,.5,.35],'i'],
    [1,[.30,.22,.04],[.42,0,-1.5],[.38,0,.12],[.32,0,.12],[.35,0,.15],[.25,0,.25],
      [[.82,.06,.38],[.3,0,1],[-1,0,0],[0,-1,.3]],[[.62,.17,.36],[.4,0,1],[1,0,0],[0,-1,.3]],
      [[-.22,.07,.06],[0,0,1],[1,0,0],[0,0,1]],[[-.27,.20,-.02],[0,0,1],[1,0,0],[0,0,1]],[.5,.6,.4],'e']],
  tierra:[
    [.35,[0,.19,-.10],[PI/2,0,0],[-.16,0,0],[-.16,0,0],[.15,0,0],[.35,0,0],
      [[.32,.06,.55],[.2,0,1],[-1,0,0],[1,.2,0]],[[-.30,.065,.50],[-.2,0,1],[1,0,0],[-1,.2,0]],'S','S',[.4,.4,.3],'i'],
    [1,[0,.19,-.10],[PI/2,.1,.18],[-.16,0,.05],[-.15,0,.05],[0,0,0],[0,1.15,0],
      [[.40,.06,.48],[.3,0,1],[-1,0,0],[1,.2,0]],[[-.30,.065,.22],[-.1,0,-1],[-1,0,0],[-1,.3,0]],
      [[.42,.08,-.62],[.5,-.3,-.8],[.2,-.9,.3],[1,-.2,.3]],[[-.24,.075,-.98],[-.3,-.4,-.87],[-.12,-.9,.4],[-.3,-1,0]],[.5,.6,.4],'e']]
};
/* se arman una vez como poses */
const CLAVES_M={};
for(const tipo in MUERTES)CLAVES_M[tipo]=MUERTES[tipo].map(k=>{
  const p=nuevaPose(),v=a=>new V3(...a);
  p.pel.set(...k[1]);qE(p.pelQ,...k[2]);qE(p.col,...k[3]);qE(p.pec,...k[4]);qE(p.cue,...k[5]);qE(p.cab,...k[6]);
  for(let i=0;i<2;i++){const m=k[7+i],o=p.mano[i];o.p.set(...m[0]);qMano(o.q,i===0,v(m[1]),v(m[2]));o.polo.copy(v(m[3]).normalize());}
  const snap=[false,false];
  for(let i=0;i<2;i++){const f=k[9+i],o=p.pie[i];if(f==='S'){snap[i]=true;continue;}o.p.set(...f[0]);qBase(o.q,v(f[1]),v(f[2]));o.polo.copy(v(f[3]).normalize());}
  p.ded[0]=k[11][0];p.ded[1]=k[11][1];p.ded[2]=k[11][2];
  return {t:k[0],pose:p,snap,tramo:k[12]};});
/* índice de la clave en la que el cuerpo pega contra el piso (para el rebote) */
const IMPACTO={};for(const tipo in CLAVES_M)IMPACTO[tipo]=CLAVES_M[tipo].findIndex(c=>c.tramo==='i'&&c.pose.pel.y<.3);

function muerte(st,e,dt){
  const m=e.muerte;
  if(!st.muerto||st.mPedido!==m.tipo){
    /* arranca: foto de la pose viva y claves giradas según de dónde vino el tiro */
    if(!st.muerto)copiarPose(st.sp0,st.sp);
    st.muerto=true;st.mPedido=m.tipo;st.mTipo=MUERTES[m.tipo]?m.tipo:'derrumbe';st.mT=0;
    soltar(st);
    const dir=m.dir||0;let giro=0,espejo=false;
    if(st.mTipo==='atras')giro=clamp(dir,-.6,.6);
    else if(st.mTipo==='adelante')giro=clamp(envol(dir-PI),-.6,.6);
    else if(st.mTipo==='derrumbe')espejo=dir>0;           /* tiro desde la izquierda: cae hacia la derecha */
    const cl=CLAVES_M[st.mTipo];
    for(let i=0;i<cl.length;i++){const c=cl[i],o=st.mk[i];copiarPose(o,c.pose);if(espejo)espejarPose(o);girarPose(o,giro);
      for(let j=0;j<2;j++)if(c.snap[j]){const s=st.sp0.pie[j],d=o.pie[j];d.p.copy(s.p);d.q.copy(s.q);d.polo.copy(s.polo);o.punta[j]=st.sp0.punta[j];}}
  }
  const cl=CLAVES_M[st.mTipo],t=sat(m.t);st.mT=t;
  let j=0;while(j<cl.length-1&&t>cl[j].t)j++;
  const t0=j?cl[j-1].t:0,t1=cl[j].t,u=sat((t-t0)/Math.max(1e-4,t1-t0)),tr=cl[j].tramo;
  const w=tr==='i'?u*u:tr==='o'?1-(1-u)*(1-u):ease(u);
  mezclarPose(st.sp,j?st.mk[j-1]:st.sp0,st.mk[j],w);
  /* rebote al pegar contra el piso (fin del primer tramo que cae hasta abajo) */
  const ki=IMPACTO[st.mTipo];
  if(ki>=0){const tc=cl[ki].t,d=t-tc;if(d>0&&d<.14)st.sp.pel.y+=.035*Math.sin(PI*d/.14)*(1-d/.14);}
  resolverColumna(st,st.sp);resolverMiembros(st,st.sp);
}
/* reflejo en X de una rotación: (x,y,z,w) → (x,-y,-z,w) */
function ref(q){q.y=-q.y;q.z=-q.z;}
/* espejo izquierda-derecha de una pose (para que el derrumbe caiga hacia el otro lado) */
const _qs=new Q4();
function espejarPose(o){
  o.pel.x=-o.pel.x;ref(o.pelQ);ref(o.col);ref(o.pec);ref(o.cue);ref(o.cab);
  for(let j=0;j<2;j++){const par=j?o.pie:o.mano,a=par[0],b=par[1];
    _qs.copy(a.q);a.q.copy(b.q);b.q.copy(_qs);ref(a.q);ref(b.q);
    const px=a.p.x,py=a.p.y,pz=a.p.z;a.p.set(-b.p.x,b.p.y,b.p.z);b.p.set(-px,py,pz);
    const lx=a.polo.x,ly=a.polo.y,lz=a.polo.z;a.polo.set(-b.polo.x,b.polo.y,b.polo.z);b.polo.set(-lx,ly,lz);}
  const t=o.punta[0];o.punta[0]=o.punta[1];o.punta[1]=t;
}

/* ====================================================================================
   ACCESORIOS Y EFECTOS: arma suelta, cargador, corredera, bípode, granada en la mano, vainas,
   antena del jefe, linterna, láser, fogonazo y luz de la nuca. Todo con huesos: nada se crea.
   ==================================================================================== */
function soltar(st){
  if(st.armaSuelta)return;st.armaSuelta=true;st.caida=0;
  const W=st.arma,f=_v[0].set(0,0,1).applyQuaternion(W.q),r=st.azar;
  st.armaP0.copy(W.p);st.armaQ0.copy(W.q);
  const ya=Math.atan2(f.x,f.z)+(r()-.5)*.9;
  st.armaP1.set(W.p.x+f.x*.2+(r()-.5)*.25,.062,W.p.z+f.z*.2+(r()-.5)*.25);
  qE(st.armaQ1,0,ya,(r()<.5?1:-1)*PI/2);                   /* queda de costado */
}
function caidaArma(st,dt){
  st.caida+=dt;const t=sat(st.caida/.5),W=st.arma;
  W.p.x=lerp(st.armaP0.x,st.armaP1.x,1-(1-t)*(1-t));W.p.z=lerp(st.armaP0.z,st.armaP1.z,1-(1-t)*(1-t));
  W.p.y=lerp(st.armaP0.y,st.armaP1.y,t*t);
  const d=st.caida-.5;if(d>0&&d<.18)W.p.y+=.03*Math.sin(PI*d/.18);
  W.q.copy(st.armaQ0).slerp(st.armaQ1,sst(0,.8,t));
}
const _ac=new V3(),_ad=new V3(),_aq=new Q4(),_aq2=new Q4(),CERO=new V3(0,0,0),UNO=new V3(1,1,1);
function accesorios(st,e,dt){
  const P=st.P,Q=st.Q,S=st.Sc,fi=st.ficha,W=st.arma,r=st.azar;
  if(st.armaSuelta&&dt>0)caidaArma(st,dt);
  P[H.arma].copy(W.p);Q[H.arma].copy(W.q);
  /* corredera de la escopeta: bombea después de cada tiro (la mano izquierda va con ella) */
  if(st.bomba>=0){st.bomba+=dt/.42;if(st.bomba>=1)st.bomba=-1;
    if(st.bomba>.4&&!st.bombaVaina){st.bombaVaina=true;tirarVaina(st);}}
  st.bombaZ=st.bomba>=0?.075*curva(st.bomba,KC18):0;
  if(st.bombaEspera>0){st.bombaEspera-=dt;if(st.bombaEspera<=0){st.bomba=0;st.bombaVaina=false;}}
  if(fi.corredera){P[H.corredera].set(fi.corredera.x,fi.corredera.y,fi.corredera.z-st.bombaZ).applyQuaternion(W.q).add(W.p);Q[H.corredera].copy(W.q);}
  /* cargador: en el arma, en la mano izquierda o guardado */
  const esc=fi.tipo==='escopeta',enMano=st.cargEnMano&&!st.muerto&&e.recarga>=0;
  S[H.cargador].copy(esc?(enMano&&st.cargVis?UNO:CERO):(st.cargVis||st.muerto?UNO:CERO));
  if(enMano){_ac.set(-.037,-.09,0).applyQuaternion(Q[H.manoI]).add(P[H.manoI]);
    if(esc){P[H.cargador].copy(_ac);Q[H.cargador].copy(Q[H.manoI]).multiply(qE(_aq,0,0,PI/2));}
    else{Q[H.cargador].copy(W.q);_ad.set(0,-.1,.02).applyQuaternion(W.q);P[H.cargador].copy(_ac).sub(_ad);}}
  else{P[H.cargador].copy(fi.cargador).applyQuaternion(W.q).add(W.p);Q[H.cargador].copy(W.q);}
  /* bípode: se abre cuerpo a tierra */
  if(fi.bipode){const ab=st.muerto?0:sst(.75,.95,st.ti);P[H.bipode].copy(fi.bipode).applyQuaternion(W.q).add(W.p);Q[H.bipode].copy(W.q).multiply(qE(_aq,ab*1.5,0,0));}
  /* granada en la mano derecha */
  S[H.granada].copy(st.granVis&&!st.muerto?UNO:CERO);
  P[H.granada].set(.036,-.088,.004).applyQuaternion(Q[H.manoD]).add(P[H.manoD]);Q[H.granada].copy(Q[H.manoD]);
  /* vainas: vuelan a la derecha, rebotan y desaparecen */
  for(let i=0;i<2;i++){const v=st.vainas[i],b=H.vaina1+i;
    if(v.t>0&&dt>0){v.t-=dt;v.v.y-=9.8*dt;v.p.addScaledVector(v.v,dt);
      if(v.p.y<.008){v.p.y=.008;v.v.y=Math.abs(v.v.y)*.3;v.v.x*=.5;v.v.z*=.5;v.w*=.5;}
      v.a+=v.w*dt;}
    S[b].copy(v.t>0?UNO:CERO);P[b].copy(v.p);qE(Q[b],v.a,v.a*.7,PI/2);}
  /* antena del jefe: látigo con resorte, la sacude la aceleración del pecho */
  if(st.rol==='jefe'){
    aModelo(st,H.pecho,.06,.205,-.195,_ac);
    if(dt>0){const ax=((_ac.x-st.antP.x)/dt-st.antV.x)/dt,az=((_ac.z-st.antP.z)/dt-st.antV.z)/dt;
      st.antV.set((_ac.x-st.antP.x)/dt,0,(_ac.z-st.antP.z)/dt);
      const A=st.ant,w=7,z=.18,lim=40;
      A.vx+=(-w*w*A.x-2*z*w*A.vx-clamp(ax,-lim,lim)*.02+.15*Math.sin(st.t*1.7+st.fase0))*dt;A.x+=A.vx*dt;
      A.vz+=(-w*w*A.z-2*z*w*A.vz-clamp(az,-lim,lim)*.02+.12*Math.sin(st.t*1.3))*dt;A.z+=A.vz*dt;}
    st.antP.copy(_ac);
    /* tres tramos: cada uno se dobla un poco más; si la punta tocaría el piso, el tramo se acuesta */
    let b=H.antena1;P[b].copy(_ac);
    for(let j=0;j<3;j++){const f=(j+1)*.45;qE(_aq,-.12-st.ant.z*f*(j?1:.3),0,st.ant.x*f*(j?1:.3));
      _aq2.copy(j?Q[b+j-1]:Q[H.pecho]).multiply(_aq);
      if(j)P[b+j].copy(_ad);
      _ad.set(0,.34,0).applyQuaternion(_aq2);const y1=P[b+j].y+_ad.y*st.k;
      if(y1<.04){_ad.y=Math.max(_ad.y,(.04-P[b+j].y)/1);const h=Math.hypot(_ad.x,_ad.z)||1e-6,l=Math.sqrt(Math.max(0,.1156-_ad.y*_ad.y));_ad.x*=l/h;_ad.z*=l/h;
        _aq2.setFromUnitVectors(EJY,_ac.copy(_ad).normalize());_ac.copy(P[b]);}
      Q[b+j].copy(_aq2);_ad.add(P[b+j]);}
  }
  /* linterna */
  const luz=!!e.luz&&!!fi.luz;S[H.haz].copy(luz?UNO:CERO);
  if(fi.luz){P[H.haz].copy(fi.luz).applyQuaternion(W.q).add(W.p);Q[H.haz].copy(W.q);}
  /* fogonazo: ~50 ms por tiro, girado al azar */
  if(st.flashT>0){st.flashT-=dt;S[H.fogonazo].setScalar(st.flashEsc);}else S[H.fogonazo].copy(CERO);
  P[H.fogonazo].copy(fi.boca).applyQuaternion(W.q).add(W.p);Q[H.fogonazo].copy(W.q).multiply(qE(_aq,0,0,st.flashRoll));
  /* láser del tirador: del módulo hasta el punto (mundo → modelo) */
  if(fi.laser&&e.laser&&!st.armaSuelta){
    _ac.copy(fi.laser).applyQuaternion(W.q).add(W.p);P[H.laser].copy(_ac);
    const L=e.laser,dx=(L.x-st.px)/st.k,dz=(L.z-st.pz)/st.k;
    _ad.set(st.cy*dx-st.sy*dz,(L.y-st.py)/st.k,st.sy*dx+st.cy*dz);P[H.laserPunto].copy(_ad);
    _ad.sub(_ac);const d=_ad.length();
    if(d>.05){qBase(Q[H.laser],_ad,EJY);S[H.laser].set(1,1,d);S[H.laserPunto].setScalar(1);}
    else{S[H.laser].copy(CERO);S[H.laserPunto].copy(CERO);}
  }else{S[H.laser].copy(CERO);S[H.laserPunto].copy(CERO);}
  /* luz de la nuca: un destello corto cada 1,4 s */
  const fl=fr(st.t/1.4+st.fase0);S[H.led].setScalar(fl<.065?1:0);
  P[H.led].set(0,.137,st.rol==='tirador'?-.168:-.152).applyQuaternion(Q[H.cabeza]).add(P[H.cabeza]);Q[H.led].copy(Q[H.cabeza]);
  /* complexión: pecho y cadera un poco más anchos o angostos */
  S[H.pecho].set(st.kx,1,st.kz);S[H.cadera].set(st.kx*.5+.5,1,1);
}
function tirarVaina(st){
  const fi=st.ficha,W=st.arma,v=st.vainas[st.vainaI],r=st.azar;st.vainaI^=1;
  v.t=.9;v.p.copy(fi.eyeccion).applyQuaternion(W.q).add(W.p);
  v.v.set(-1.6-r()*.8,.9+r()*.6,-.3+r()*.4).applyQuaternion(W.q);v.a=r()*TAU;v.w=18+r()*14;
}

/* ====================================================================================
   CREAR UN SOLDADO
   ==================================================================================== */
const E_INICIAL=()=>({agach:0,tierra:0,apunta:0,mYaw:0,mPitch:0,asoma:0,recarga:-1,salto:-1,lanza:-1,lanzaSale:.55,
  senal:-1,senalTipo:'avanzar',culata:-1,radio:0,aturdido:0,muerte:null,luz:false,laser:null});
const _rs=new V3(),_ro=new V3(),_rd2=new V3(),_rm=new M4(),_rq2=new Q4(),_rv=new V3();
function crear(rol,op={}){
  if(!ROLES[rol])rol='asalto';
  materiales();const geo=geometriaDe(rol);
  const sem=op.semilla===undefined?(Math.random()*1e9)|0:op.semilla,azar=azarDe(sem*7919+13);
  const huesos=HUESOS.map(h=>{const b=new THREE.Bone();b.name=h[0];return b;});
  const esq=new THREE.Skeleton(huesos,INVERSAS);
  const malla=new THREE.SkinnedMesh(geo.cuerpo,MAT.cuerpo);malla.bind(esq,new M4());malla.castShadow=true;malla.receiveShadow=true;malla.name='UEM cuerpo';
  const fx=new THREE.SkinnedMesh(geo.fx,MAT.fx);fx.bind(esq,new M4());fx.frustumCulled=false;fx.renderOrder=3;fx.name='UEM efectos';
  const k=1+(azar()-.5)*.06,grupo=new THREE.Group();grupo.scale.setScalar(k);grupo.add(malla,fx,...huesos);
  const root=new THREE.Group();root.name='UE '+rol;root.add(grupo);
  const pie=()=>({w:new V3(),pos:new V3(),desde:new V3(),yaw:0,yawAct:0,desdeYaw:0,vuelo:false,modo:0,s:0,q0:0,ciclo:-9,dur:.3,alza:.1,alto:0,cab:0});
  const st={rol,ficha:geo.ficha,azar,k,kx:1+(azar()-.5)*.08,kz:1+(azar()-.5)*.06,ritmo:1+(azar()-.5)*.12,respira:.7+azar()*.6,fase0:azar(),
    P:HUESOS.map(()=>new V3()),Q:HUESOS.map(()=>new Q4()),Sc:HUESOS.map(()=>new V3(1,1,1)),huesos,
    t:azar()*10,nuevo:true,reubicar:true,prevX:0,prevZ:0,prevYaw:0,yaw:0,px:0,pz:0,py:0,cy:1,sy:0,dist:0,dyaw:0,vel:new V3(),rap:0,vlx:0,vlz:0,
    fase:azar(),faseR:0,pie:[pie(),pie()],rest:[new V3(),new V3()],restYaw:[0,0],errPie:[0,0],pausaPaso:0,
    ap:0,ag:0,ti:0,as:0,mYaw:0,mPitch:0,radio:0,aturd:0,yawPecho:0,
    sp:nuevaPose(),sp0:nuevaPose(),poseT:nuevaPose(),mk:[nuevaPose(),nuevaPose(),nuevaPose(),nuevaPose()],muerto:false,mTipo:'',mPedido:'',mT:0,
    arma:{p:new V3(),q:new Q4()},pAim:new V3(),qAim:new Q4(),pLow:new V3(),qLow:new Q4(),
    armaSuelta:false,caida:0,armaP0:new V3(),armaQ0:new Q4(),armaP1:new V3(),armaQ1:new Q4(),
    rp:0,rpv:0,rb:0,rbv:0,gp:0,gpv:0,gr:0,grv:0,golpeT:0,flashT:0,flashEsc:1,flashRoll:0,
    bomba:-1,bombaZ:0,bombaEspera:0,bombaVaina:false,cargVis:1,cargEnMano:0,granVis:0,saltoW:new V3(),saltoFijo:false,
    vainas:[{t:0,p:new V3(),v:new V3(),a:0,w:0},{t:0,p:new V3(),v:new V3(),a:0,w:0}],vainaI:0,
    ant:{x:0,z:0,vx:0,vz:0},antP:new V3(),antV:new V3()};
  const u={root,e:E_INICIAL(),rol,semilla:sem,_st:st,malla,efectos:fx};
  u.update=dt=>{
    dt=dt>0?Math.min(dt,.1):0;st.t+=dt;st.py=root.position.y;
    movimiento(st,root,dt);
    /* resortes: patada del arma y sacudones */
    if(dt>0){const n=Math.ceil(dt/.0085),h=dt/n;for(let i=0;i<n;i++){resorte(st,'rp','rpv',26,.55,h);resorte(st,'rb','rbv',30,.7,h);resorte(st,'gp','gpv',13,.42,h);resorte(st,'gr','grv',13,.42,h);}}
    st.golpeT=Math.max(0,st.golpeT-dt);
    if(u.e.muerte)muerte(st,u.e,dt);else{if(st.muerto)u.revivir();vivo(st,u.e,dt);}
    accesorios(st,u.e,dt);
    for(let i=0;i<NH;i++){const b=huesos[i];b.position.copy(st.P[i]);b.quaternion.copy(st.Q[i]);b.scale.copy(st.Sc[i]);}
  };
  u.disparo=()=>{const f=st.ficha.patada,r=azar;
    st.rpv+=2.4*f*(.85+.3*r());st.rbv+=.5*f;st.flashT=.055;st.flashRoll=r()*TAU;st.flashEsc=.8+.4*r();
    if(st.ficha.tipo==='escopeta'){st.bombaEspera=.14;}else tirarVaina(st);};
  u.golpe=(dir,f)=>{f=sat(f===undefined?1:f);const px=-Math.sin(dir||0),pz=-Math.cos(dir||0);
    st.gpv+=pz*f*6;st.grv+=-px*f*6;st.golpeT=Math.max(st.golpeT,.35*f);};
  const mundo=v=>{grupo.updateWorldMatrix(true,false);return v.applyMatrix4(grupo.matrixWorld);};
  u.boca=v3=>mundo(v3.copy(st.ficha.boca).applyQuaternion(st.arma.q).add(st.arma.p));
  u.ojos=v3=>mundo(v3.set(0,.10,.075).applyQuaternion(st.Q[H.cabeza]).add(st.P[H.cabeza]));
  u.mano=v3=>mundo(v3.set(.036,-.088,0).applyQuaternion(st.Q[H.manoD]).add(st.P[H.manoD]));
  const hit={t:0,parte:''};
  u.rayo=(o,d)=>{
    grupo.updateWorldMatrix(true,false);_rm.copy(grupo.matrixWorld).invert();
    _ro.copy(o).applyMatrix4(_rm);_rd2.copy(d).transformDirection(_rm);
    let best=Infinity,parte=null;
    for(const s of ESFERAS){_rs.copy(s.o).applyQuaternion(st.Q[s.b]).add(st.P[s.b]);
      _rv.subVectors(_ro,_rs);const b=_rv.dot(_rd2),c=_rv.lengthSq()-s.r*s.r,di=b*b-c;if(di<0)continue;
      const sq=Math.sqrt(di);let t=-b-sq;if(t<0)t=-b+sq;if(t>=0&&t<best){best=t;parte=s.parte;}}
    if(!parte)return null;hit.t=best*st.k;hit.parte=parte;return hit;};
  u.soltarArma=()=>soltar(st);
  u.revivir=()=>{st.muerto=false;st.armaSuelta=false;st.reubicar=true;st.mPedido='';u.e.muerte=null;st.bomba=-1;};
  u.dispose=()=>{if(root.parent)root.parent.remove(root);esq.dispose();};
  u.update(0);
  return u;
}

/* muestra de cada rol con todo prendido, para que el juego compile los shaders al cargar */
let MUESTRAS=null;
function calentar(scene,on){
  if(on){if(MUESTRAS)return MUESTRAS.length;MUESTRAS=[];
    Object.keys(ROLES).forEach((rol,i)=>{const u=crear(rol,{semilla:i+1});u.root.position.set(i*2,-60,0);
      u.e.luz=true;u.e.laser=new V3(i*2,-60,20);u.e.apunta=1;u.update(1/60);u._st.flashT=1;u.e.recarga=.3;u.e.lanza=.3;u.update(1/60);
      scene.add(u.root);MUESTRAS.push(u);});
    const g=granada();g.position.set(-2,-60,0);scene.add(g);MUESTRAS.push({dispose:()=>{if(g.parent)g.parent.remove(g);}});
    return MUESTRAS.length;}
  if(MUESTRAS){MUESTRAS.forEach(u=>u.dispose());MUESTRAS=null;}return 0;
}
function info(rol){const g=geometriaDe(rol);return {triangulos:g.tris,triangulosEfectos:g.trisFx,llamadas:2};}

return {ROLES,crear,granada,calentar,info,VERSION:'1.0',
  _interno:{Constructor,H,torso,brazo,mano,pierna,cabeza,fusil,escopeta,tirador,granadaGeo,armarFx,MUERTES,CLAVES_M}};
})();
