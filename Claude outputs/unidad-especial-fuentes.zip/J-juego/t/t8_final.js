// Prueba final de detalles: pasos y equipo, puntos y feed al matar, subtítulos, granada con la malla de UEM,
// y dos capturas: el retén en guardia con zoom (40 m) y el tirador con el láser encendido.
const H=require('../../harness.js'),fs=require('fs'),path=require('path');
const INST=require('./inst.js');
const F=(process.argv[2]&&process.argv[2].endsWith('.html'))?process.argv[2]:__dirname+'/../obelisco-mutante.html';
const DIR=path.join(__dirname,'..','capturas');const SIN=process.argv.includes('sin'),SOLO_LASER=process.argv.includes('laser');
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F,{width:640,height:360});lg('abierto');const R={};const ev=c=>h.ev(c);
  const camA=(x,y,z,lx,ly,lz,fov)=>`camera.position.set(${x},${y},${z});camera.lookAt(${lx},${ly},${lz});camera.fov=${fov};camera.updateProjectionMatrix();camera.updateMatrixWorld(true);lightsPre();window.__render(scene,camera);lightsPost();camera.fov=74;camera.updateProjectionMatrix();`;
  const foto=async(nombre,cam)=>{await ev(`(()=>{if(!${JSON.stringify(!!0)}){}let t=window.__simT+16;${cam?'':'renderer.render=window.__render;'}frame(t);window.__simT=t;${cam||''}renderer.render=()=>{};return 1;})()`);
    await h.page.screenshot({path:path.join(DIR,nombre)});lg('foto',nombre);};
  try{
    await h.start();await ev("RETEN.ir({bichos:false});1");await ev(INST);
    await ev(`(()=>{window.__S={pasos:0,equipo:0,cuerpo:0};const p0=UESND.pasos,e0=UESND.equipo,c0=UESND.cuerpo;
      UESND.pasos=(a,b)=>{__S.pasos++;p0(a,b);};UESND.equipo=a=>{__S.equipo++;e0(a);};UESND.cuerpo=a=>{__S.cuerpo++;c0(a);};SECG.A.visible=false;
      /* menos memoria en la primera pasada de dibujo (SwiftShader): sin sombras y sin lo que está a más de 150 m del retén */
      if(${JSON.stringify(process.argv.includes('liviano'))}){renderer.shadowMap.enabled=false;let n=0;SECG.B.traverse(o=>{if(o===SECG.B||!o.isMesh||o.isInstancedMesh)return;
        if(!o.geometry)return;if(!o.geometry.boundingSphere)o.geometry.computeBoundingSphere();const c=o.geometry.boundingSphere.center.clone().applyMatrix4(o.matrixWorld);
        if(Math.hypot(c.x+438,c.z-607)>150+o.geometry.boundingSphere.radius){o.visible=false;n++;}});window.__ocultos=n;}
      return 1;})()`);
    await h.step(1);
    /* 1. guardia vista desde 40 m con zoom (como con largavista): ¿se los ve? */
    await ev("P.pos.set(-398,floorAt(-398,607.5),607.5);P.vel.set(0,0,0);P.yaw=Math.PI/2;P.pitch=.02;1");
    if(SOLO_LASER)await foto('c0_calentar.png');          // la primera pasada (la que compila todo y más memoria usa) antes del combate
    if(!SIN&&!SOLO_LASER)await foto('c1z_guardia_zoom.png',camA(-398,'floorAt(-398,607.5)+1.7',607.5,-440,1.2,606.5,22));
    R.guardia=await ev("({pasos:__S.pasos,equipo:__S.equipo,sold:UE.soldados.map(s=>[s.nombre,s.estado,s.luz,+s.x.toFixed(1),+s.z.toFixed(1)])})");lg('guardia',JSON.stringify(R.guardia));
    /* 2. combate: se espera a que el tirador prenda el láser y se lo fotografía de costado */
    await ev("window.__inmortal=true;P.pos.set(-410,floorAt(-410,607),607);P.vel.set(0,0,0);P.yaw=Math.PI/2;1");
    let las=null;for(let k=0;k<280&&!las;k++){await h.step(.25,1/60,'__fich()');las=await ev("(()=>{const s=UE.soldados.find(q=>q.rol==='tirador'&&q.vivo&&q.laser);return s?[s.x,s.y,s.z,s.laser.x,s.laser.y,s.laser.z]:null})()");}
    R.laser=las;lg('laser',JSON.stringify(las));
    if(las&&!SIN)await foto('c5b_tirador_laser.png',camA(las[0]+10.5,las[1]+1.4,las[2]-7.5,las[0]+4.5,las[1]-.2,las[2]+.8,58));
    if(SOLO_LASER)throw new Error('fin (solo láser)');
    /* 3. matar a uno apuntando con la pistola: puntos, feed y caja */
    await ev("switchTo(0);1");await h.step(.6);
    R.kill=await ev(`(()=>{const s0=score,c0=pickups.length,f0=document.querySelectorAll('#feed div').length;return {s0,c0,f0}})()`);
    let muerto=null;
    for(let k=0;k<40&&!muerto;k++){
      const s=await ev("(()=>{const L=UE.soldados.filter(s=>s.vivo&&__ve(s)&&s.rol!=='tirador').sort((a,b)=>Math.hypot(a.x-P.pos.x,a.z-P.pos.z)-Math.hypot(b.x-P.pos.x,b.z-P.pos.z));return L[0]?L[0].id:null})()");
      if(s===null){await h.step(.5,1/60,'__fich()');continue;}
      for(let q=0;q<6;q++){await ev(`(()=>{const s=UE.soldados.find(x=>x.id===${s});if(!s||!s.vivo)return 0;__apuntar(s,s.tierra>.5?.25:s.agach>.5?1.05:1.5);aiming=true;fireCd=0;shotLatch=false;W[0].ammo=12;fire();return 1;})()`);await h.step(.2);}
      muerto=await ev(`(()=>{const s=UE.soldados.find(x=>x.id===${s});return s.vivo?null:{n:s.nombre,hp:s.hp}})()`);
    }
    await h.step(.3);
    R.kill2=await ev(`({muerto:${JSON.stringify(muerto)},score,cajas:pickups.length,feed:[...document.querySelectorAll('#feed div')].map(d=>d.textContent).slice(-3),kills,cuerpo:__S.cuerpo})`);
    lg('kill',JSON.stringify(R.kill),JSON.stringify(R.kill2));
    R.otros=await ev("({pasos:__S.pasos,equipo:__S.equipo,radioDom:document.querySelectorAll('#ueRadio .ue-rl').length,granadaUEM:GRAN.estado().mallaUEM,debug:!!UEB.debug(),T:+T.toFixed(1)})");
    lg('otros',JSON.stringify(R.otros));
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(path.join(__dirname,'t8.json'),JSON.stringify(R));
  await h.close();lg('cerrado');
})();
