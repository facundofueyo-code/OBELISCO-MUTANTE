/* =====================================================================================================
   sim/jugadores.js — jugadores automáticos para el simulador (escenarios a–f de la TAREA). JS puro.

     const JG = crearJugadores(M, UE);
     const bot = JG.parado({x,z}) | JG.asoma({...}) | JG.escondido({...}) | JG.sigilo({linterna}) | JG.rodeo({...}) | JG.decente({arma})
     cada cuadro, ANTES de M.paso(dt):  bot.paso(dt, eventosDelCuadroAnterior)
     bot.info → lo que midió el jugador (cuándo lo vieron, si se movió sin que lo vieran, etc.)

   Los jugadores «ven» a los soldados con rayos reales desde sus ojos (no saben dónde están si no los ven) y
   oyen la radio y ven las granadas y el láser como los vería alguien que juega.
   ===================================================================================================== */
function crearJugadores(M, UE) {
  const J = M.jugador, hyp = Math.hypot, G = M.grilla;
  const azar = M.azar, campana = () => azar() + azar() - 1;

  /* ---------- utilidades ---------- */
  const ojoJ = () => J.y + (J.agach ? 1.05 : 1.62);
  const pecho = s => s.y + (s.tierra > 0.5 ? 0.25 : s.agach > 0.5 ? 0.8 : 1.25);
  function veA(s, desdeAgach) {
    const oy = J.y + (desdeAgach ? 1.05 : 1.62);
    return M.lv(J.x, oy, J.z, s.x, pecho(s), s.z) || M.lv(J.x, oy, J.z, s.x, s.y + (s.tierra > 0.5 ? 0.32 : s.agach > 0.5 ? 1.12 : 1.66), s.z);
  }
  /* soldados a la vista. Como una persona, el jugador tarda 0,3 s en reaccionar a uno que aparece (vistoDesde) */
  const vistoDesde = new Map();
  function visibles(maxD, agach) {
    const v = [];
    for (const s of UE.soldados) {
      if (s.vivo && s.activo && hyp(s.x - J.x, s.z - J.z) < maxD && veA(s, agach)) { v.push(s); if (!vistoDesde.has(s)) vistoDesde.set(s, M.t); }
      else vistoDesde.delete(s);
    }
    return v;
  }
  const listo = s => vistoDesde.has(s) && M.t - vistoDesde.get(s) >= 0.3;
  const errorDe = (s, e) => e * (1 + 1.5 * Math.max(0, 1 - (M.t - (vistoDesde.get(s) || M.t) - 0.3) / 0.5));   // apunta mejor tras medio segundo
  function seguidor(cam) { return { cam, i: 0 }; }
  /* avanza por el camino; devuelve true al llegar */
  function andar(f, dt, vel, o) {
    if (!f || !f.cam || !f.cam.length) { M.moverJugador(0, 0, dt, o); return true; }
    let p = f.cam[f.i]; let d = hyp(p.x - J.x, p.z - J.z);
    while (d < 0.35 && f.i < f.cam.length - 1) { f.i++; p = f.cam[f.i]; d = hyp(p.x - J.x, p.z - J.z); }
    if (d < 0.25 && f.i >= f.cam.length - 1) { M.moverJugador(0, 0, dt, o); return true; }
    const v = Math.min(vel, d / dt);
    M.moverJugador((p.x - J.x) / d * v, (p.z - J.z) / d * v, dt, o);
    return false;
  }
  function tirarA(s, err, cabeza) {
    const y = cabeza ? s.y + (s.tierra > 0.5 ? 0.32 : 1.66 - 0.54 * s.agach) : pecho(s);
    const d = hyp(s.x - J.x, s.z - J.z), e = err * d;
    return M.dispararJugador(s.x + campana() * e, y + campana() * e * 0.6, s.z + campana() * e);
  }
  /* coberturas para el jugador: casilleros pasables pegados a algo de 1,4 m o más */
  const COBS = [];
  for (let z = 592; z <= 620; z++) for (let x = -446; x <= -352; x++) {
    const cx = x + 0.5, cz = z + 0.5; if (!M.libre(cx, cz)) continue;
    let alto = 0; for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const k = M.celda(cx + dx, cz + dz); if (k >= 0) alto = Math.max(alto, G.HR[k]); }
    if (alto >= 1.4) COBS.push({ x: cx, z: cz, alto });
  }
  const tapado = (c, tx, tz) => !M.lv(tx, 1.6, tz, c.x, 1.0, c.z);
  const tieneTiro = (c, tx, tz) => M.lv(c.x, 1.62, c.z, tx, 1.3, tz);

  /* ================================================================================================
     (a) parado al descubierto
     ================================================================================================ */
  function parado(o) {
    M.ponerJugador(o.x, o.z);
    return { info: {}, paso(dt) { M.moverJugador(0, 0, dt, {}); } };
  }

  /* ================================================================================================
     (b) a cubierto: se asoma 1 s cada 3 s y tira con puntería razonable (pistola)
     ================================================================================================ */
  function asoma(o) {
    M.ponerJugador(o.x, o.z); M.armaJugador(o.arma || 'pistola');
    let fase = 0, tTiro = 0;
    return {
      info: {},
      paso(dt) {
        fase = (fase + dt) % 3;
        const arriba = fase >= 2;
        M.moverJugador(0, 0, dt, { agach: !arriba });
        if (arriba && !o.noTira) {
          tTiro -= dt;
          if (tTiro <= 0) { const v = visibles(80, false).filter(listo); if (v.length) { v.sort((a, b) => hyp(a.x - J.x, a.z - J.z) - hyp(b.x - J.x, b.z - J.z)); if (tirarA(v[0], errorDe(v[0], 0.012), azar() < 0.2)) tTiro = 0.3; } }
        } else if (J.cargador[J.arma] < 6 && !J.recargando) M.recargarJugador();
      }
    };
  }

  /* ================================================================================================
     (c) escondido y quieto; a los 10 s se va 20 m sin que lo vean
     ================================================================================================ */
  function escondido(o) {
    M.ponerJugador(o.inicio.x, o.inicio.z);
    const info = { tEsconde: null, tMueve: null, tLlega: null, vistoMoviendo: false, nuevo: o.nuevo, viejo: o.escondite };
    let fase = 'mostrarse', f = null;
    return {
      info,
      paso(dt) {
        const enCombate = UE.escuadrones.some(e => e.activo && e.estado === 'combate');
        if (fase === 'mostrarse') { M.moverJugador(0, 0, dt, {}); if (enCombate) { fase = 'ir'; f = seguidor(M.camino(J.x, J.z, o.escondite.x, o.escondite.z)); } return; }
        if (fase === 'ir') { if (andar(f, dt, 6.2, {})) { fase = 'quieto'; info.tEsconde = M.t; } return; }
        if (fase === 'quieto') {
          M.moverJugador(0, 0, dt, { agach: true });
          if (M.t - info.tEsconde >= 10) {
            /* camino tapado: evita los casilleros que ve algún soldado vivo (los que el jugador sabe dónde están) */
            const vivos = UE.soldados.filter(s => s.vivo && s.activo);
            const costo = k => { const x = M.cX(k), z = M.cZ(k); for (const s of vivos) if (hyp(s.x - x, s.z - z) < 70 && M.lv(s.x, s.y + 1.6, s.z, x, 1.0, z)) return 30; return 0; };
            f = seguidor(M.camino(J.x, J.z, o.nuevo.x, o.nuevo.z, { costo, maxIt: 20000 })); fase = 'mover'; info.tMueve = M.t;
          }
          return;
        }
        if (fase === 'mover') {
          if (UE.soldados.some(s => s.vivo && s.ve)) info.vistoMoviendo = true;
          /* se mueve de a tramos: si el próximo punto se ve desde algún soldado (que él ve), espera agachado (hasta 4 s) */
          const p = f.cam && f.cam[Math.min(f.i + 1, f.cam.length - 1)];
          const visto = p && UE.soldados.some(s => s.vivo && s.activo && hyp(s.x - p.x, s.z - p.z) < 70 && M.lv(s.x, s.y + 1.6, s.z, p.x, 1.0, p.z) && M.lv(J.x, 1.05, J.z, s.x, s.y + 1.2, s.z));
          if (visto && (info._espera = (info._espera || 0) + dt) < 4) { M.moverJugador(0, 0, dt, { agach: true }); return; }
          if (!visto) info._espera = 0;
          if (andar(f, dt, 3.0, { agach: true })) { fase = 'nuevo'; info.tLlega = M.t; }
          return;
        }
        M.moverJugador(0, 0, dt, { agach: true });
      }
    };
  }

  /* ================================================================================================
     (d) sigilo: se acerca agachado por la vereda norte, con o sin linterna
     ================================================================================================ */
  function sigilo(o) {
    M.ponerJugador(o.inicio.x, o.inicio.z); M.linterna(!!o.linterna);
    const f = seguidor(M.camino(J.x, J.z, o.fin.x, o.fin.z));
    const info = { dSospecha: null, dContacto: null, quien: null, dBarricada: null };
    const dMin = () => { let m = 1e9; for (const s of UE.soldados) if (s.vivo) m = Math.min(m, hyp(s.x - J.x, s.z - J.z)); return m; };
    return {
      info,
      paso(dt, evs) {
        for (const e of evs || []) {
          if (e.tipo === 'evento' && e.nombre === 'sospecha' && info.dSospecha === null) info.dSospecha = e.datos.s ? hyp(e.datos.s.x - J.x, e.datos.s.z - J.z) : dMin();
          if (e.tipo === 'evento' && (e.nombre === 'contacto' || e.nombre === 'combate') && info.dContacto === null) {
            const s = e.datos.s; info.dContacto = s ? hyp(s.x - J.x, s.z - J.z) : dMin(); info.quien = s ? s.rol : '?'; info.dBarricada = J.x - (-438);   // la distancia al que lo detectó, y a la barricada
          }
        }
        if (info.dContacto !== null) { M.moverJugador(0, 0, dt, { agach: true }); return; }
        andar(f, dt, 3.0, { agach: true });
      }
    };
  }

  /* ================================================================================================
     (f) jugador decente: coberturas, ráfagas, se mueve con el aviso de granada, avanza cuando recargan
     ================================================================================================ */
  function decente(o) {
    o = o || {};
    if (o.inicio) M.ponerJugador(o.inicio.x, o.inicio.z);
    const base = o.arma !== 'fusil';
    M.armaJugador(base ? 'pistola' : 'fusil');
    const mem = new Map();          // soldados vistos: {x, z, y (ojo), t}
    const info = { muertes: 0, huidas: 0, avances: 0, asomadas: 0 };
    let fase = 'acercarse', f = null, cob = null, tFase = 0, dur = 0, hpAsoma = 100, tRafaga = 0, enRafaga = 0, ordenG = null, recargan = -99;
    let tLaser = -99, laserMio = false;
    const amenaza = () => {
      let x = 0, z = 0, n = 0;
      for (const [s, m] of mem) if (s.vivo && M.t - m.t < 25) { x += m.x; z += m.z; n++; }
      return n ? { x: x / n, z: z / n } : (o.amenaza || { x: -440, z: 608 });
    };
    function elegirCob(cerca, dMin, dMax, lejosDe) {
      const a = amenaza(); let m = null, mp = -1e9;
      for (const c of COBS) {
        const d = hyp(c.x - cerca.x, c.z - cerca.z); if (d < dMin || d > dMax) continue;
        const dA = hyp(c.x - a.x, c.z - a.z); if (dA < 8) continue;
        if (lejosDe && hyp(c.x - lejosDe.x, c.z - lejosDe.z) < 10) continue;
        let gr = false; for (const g of M.granadas) if (g.vivo && g.de !== 'jugador' && hyp(c.x - g.x, c.z - g.z) < 9) gr = true;   // nunca hacia una granada viva
        if (gr || (ordenG && M.t - ordenG.t < 4 && hyp(c.x - ordenG.x, c.z - ordenG.z) < 9)) continue;
        if (!tapado(c, a.x, a.z)) continue;
        let vista = false; for (const [s, m] of mem) if (s.vivo && M.t - m.t < 30 && M.lv(m.x, m.y, m.z, c.x, 1.0, c.z)) { vista = true; break; }   // tapado también de los que ya vio (el tirador en el techo)
        if (vista) continue;
        let p = -d * 0.4 - Math.abs(dA - (o.dist || 28)) * 0.15 + (tieneTiro(c, a.x, a.z) ? 4 : 0) + (c.alto > 2 ? 0.5 : 0);
        for (const s of UE.soldados) if (s.vivo && hyp(s.x - c.x, s.z - c.z) < 10) p -= 6;
        if (p > mp) { mp = p; m = c; }
      }
      return m;
    }
    function irACob(c, vel, agach) { const cam = M.camino(J.x, J.z, c.x, c.z); if (!cam || cam.length < 2 && hyp(c.x - J.x, c.z - J.z) > 1) return false; cob = c; f = seguidor(cam); fase = 'moverse'; tFase = M.t; info._vel = vel; info._agach = agach; return true; }
    function elegirArma(d) {
      if (!base) return;
      const q = d < 7 ? 'escopeta' : d < 18 ? 'uzi' : 'pistola';
      if (J.arma !== q && !J.recargando) M.armaJugador(q);
    }
    function disparar(dt, v) {
      v = v.filter(listo);
      if (!v.length) return false;
      let t = null;
      for (const s of v) if (s.laser) t = s;                                         // primero el que le apunta con el láser
      if (!t) { v.sort((a, b) => hyp(a.x - J.x, a.z - J.z) - hyp(b.x - J.x, b.z - J.z)); t = v[0]; }
      const d = hyp(t.x - J.x, t.z - J.z); elegirArma(d);
      tRafaga -= dt; if (tRafaga > 0) return true;
      const r = tirarA(t, errorDe(t, o.error || 0.011), azar() < 0.22);
      if (r) {
        enRafaga++;
        const A = J.arma; const larga = A === 'uzi' ? 5 : A === 'fusil' ? 4 : 1;
        if (enRafaga >= larga) { enRafaga = 0; tRafaga = A === 'pistola' ? 0.28 : A === 'escopeta' ? 0.8 : 0.35; }
      }
      return true;
    }
    function peligroGranada() {
      for (const g of M.granadas) if (g.vivo && g.de !== 'jugador' && hyp(g.x - J.x, g.z - J.z) < 9) return { x: g.x, z: g.z };
      if (ordenG && M.t - ordenG.t < 2.2 && hyp(ordenG.x - J.x, ordenG.z - J.z) < 9) return ordenG;
      return null;
    }
    return {
      info,
      paso(dt, evs) {
        if (!J.vivo) return;
        info.fase = fase; info.laserMio = laserMio;
        /* lo que ve y oye */
        const vis = visibles(75, J.agach);
        for (const s of vis) mem.set(s, { x: s.x, z: s.z, y: s.y + (s.tierra > 0.5 ? 0.3 : 1.5), t: M.t });
        for (const e of evs || []) {
          if (e.tipo === 'radio' && e.clave === 'granada' && e.s) ordenG = { x: J.x, z: J.z, t: M.t };          // oye «¡granada va!»: asume que va para él
          if (e.tipo === 'evento' && e.nombre === 'granada_aviso' && ordenG) { ordenG.x = e.datos.x; ordenG.z = e.datos.z; }   // y ve el gesto hacia dónde
          if (e.tipo === 'radio' && e.clave === 'recarga') recargan = M.t;
          if (e.tipo === 'laser' && e.on) tLaser = M.t;
          if (e.tipo === 'muerte' && e.a === 'jugador') return;
          if (e.tipo === 'evento' && e.nombre === 'baja' && e.datos.de === 'jugador') info.muertes++;
        }
        laserMio = UE.soldados.some(s => s.vivo && s.laser && hyp(s.laser.x - J.x, s.laser.z - J.z) < 1.5);
        const corre = laserMio && M.t - tLaser > 0.3;                                    // ve el punto rojo encima: no se queda quieto ni camina despacio
        /* 1. granada: se va de ahí corriendo */
        const pg = peligroGranada();
        if (pg && fase !== 'huir' && fase !== 'escapar') {
          const c = elegirCob({ x: J.x, z: J.z }, 4, 22, pg) || null;
          if (c && irACob(c, 9.6, false)) { fase = 'huir'; info.huidas++; }
          else { fase = 'escapar'; tFase = M.t; info._lejos = pg; info.huidas++; }       // sin cobertura a mano: corre derecho para el otro lado
        }
        if (fase === 'escapar') {
          const p = info._lejos, dx = J.x - p.x, dz = J.z - p.z, l = hyp(dx, dz) || 1;
          M.moverJugador(dx / l * 9.6, dz / l * 9.6, dt, { correr: true });
          if (M.t - tFase > 1.6 || l > 11) { fase = 'cubierto'; tFase = M.t; dur = 0.5; }
          return;
        }
        if (fase === 'acercarse') {
          if (!f) { const p = o.primera || { x: -390, z: 606 }, c = elegirCob(p, 0, 12) || { x: p.x, z: p.z }; cob = c; f = seguidor(M.camino(J.x, J.z, c.x, c.z)); }
          const cerca = hyp(cob.x - J.x, cob.z - J.z) < 25;
          if (vis.length && hyp(vis[0].x - J.x, vis[0].z - J.z) < 30) disparar(dt, vis);
          if (andar(f, dt, corre ? 9.6 : cerca ? 3.0 : 6.2, { agach: cerca && !corre, correr: corre })) { fase = 'cubierto'; tFase = M.t; dur = 1 + azar(); }
          return;
        }
        if (fase === 'moverse' || fase === 'huir') {
          const v2 = visibles(20, false); if (v2.length && fase === 'moverse') disparar(dt, v2);
          if (andar(f, dt, corre ? 9.6 : info._vel || 6.2, { agach: !!info._agach && !corre, correr: corre || (info._vel || 0) > 7 }) || M.t - tFase > 12) { fase = 'cubierto'; tFase = M.t; dur = 0.8 + azar(); }
          return;
        }
        if (fase === 'cubierto') {
          M.moverJugador(0, 0, dt, { agach: true });
          if (J.cargador[J.arma] < M.armas[J.arma].cargador * 0.4 && !J.recargando) M.recargarJugador();
          if (laserMio && M.t - tLaser > 0.3) { const c = elegirCob({ x: J.x, z: J.z }, 3, 16); if (c) { irACob(c, 9.6, false); return; } }   // agachado y todavía con el láser encima: esta cobertura no sirve
          const cercanos = visibles(14, true); if (cercanos.length) disparar(dt, cercanos);   // lo rodearon: tira desde donde está
          const a = amenaza(), dA = hyp(a.x - J.x, a.z - J.z);
          if (M.t - recargan < 1.6 && dA > 20 && !peligroGranada()) {                     // recargan: avanza
            const c = elegirCob({ x: J.x + (a.x - J.x) / dA * 9, z: J.z + (a.z - J.z) / dA * 9 }, 0, 8);
            if (c && hyp(c.x - a.x, c.z - a.z) < dA - 3 && irACob(c, 6.2, false)) { info.avances++; recargan = -99; return; }
          }
          if (M.t - tFase > dur && !J.recargando) { fase = 'asomado'; tFase = M.t; dur = (J.hp < 50 ? 0.8 : 1.2) + azar() * (J.hp < 50 ? 0.6 : 1.2); hpAsoma = J.hp; info.asomadas++; }
          return;
        }
        if (fase === 'asomado') {
          M.moverJugador(0, 0, dt, {});
          const v = visibles(75, false);
          disparar(dt, v);
          const golpeado = hpAsoma - J.hp > 18, laser = laserMio && M.t - tLaser > 0.4;
          if (M.t - tFase > dur || golpeado || laser || (J.recargando)) {
            fase = 'cubierto'; tFase = M.t; dur = (J.hp < 35 ? 2.2 : 0.9) + azar() * 1.2;
            /* le pegaron asomándose: lo están esperando ahí. Casi siempre cambia de cobertura */
            if (golpeado && azar() < 0.7) { const c = elegirCob({ x: J.x, z: J.z }, 4, 14); if (c) { irACob(c, 6.2, true); return; } }
            /* si desde acá no ve a nadie hace rato, busca otra cobertura con tiro */
            if (!v.length && M.t - (info._tVio || 0) > 7) { const c = elegirCob({ x: J.x, z: J.z }, 4, 14); if (c) irACob(c, 6.2, true); }
          }
          if (v.length) info._tVio = M.t;
        }
      }
    };
  }

  /* ================================================================================================
     (e) rodea por Hipólito Yrigoyen y aparece por San José (por detrás del retén); después pelea como (f)
     ================================================================================================ */
  function rodeo(o) {
    o = o || {};
    M.ponerJugador(-326, 606);
    const tramos = [[-321, 640], [-321, 669], [-452, 669], [-452, 632]];
    let ti = 0, f = null, pelea = null;
    const info = { detectadoAntes: false, llegoEsquina: null, muertes: 0 };
    return {
      info,
      paso(dt, evs) {
        if (pelea) { pelea.paso(dt, evs); info.muertes = pelea.info.muertes; return; }
        if (UE.escuadrones.some(e => e.activo && e.estado === 'combate')) info.detectadoAntes = true;
        if (!f) f = seguidor(M.camino(J.x, J.z, tramos[ti][0], tramos[ti][1]));
        if (andar(f, dt, ti < 3 ? 6.2 : 3.0, { agach: ti >= 3 })) {
          ti++; f = null;
          if (ti >= tramos.length) {
            info.llegoEsquina = M.t;
            pelea = decente({ arma: o.arma, amenaza: { x: -441, z: 609 }, dist: 16, primera: { x: -452, z: 620 } });
            pelea.info.muertes = 0;
          }
        }
      }
    };
  }

  return { parado, asoma, escondido, sigilo, decente, rodeo, COBS };
}
if (typeof module !== 'undefined') module.exports = { crearJugadores };
