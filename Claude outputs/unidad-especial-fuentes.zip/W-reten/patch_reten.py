# Parche W (retén): uso  python3 patch_reten.py entrada.html salida.html
# Aplica mod_reten.js en /*UE:modulos*/, los botones de prueba en la pantalla de inicio y los enganches
# (armar al construir la sección B, reset, start, efectos). Falla fuerte si un ancla no aparece las veces esperadas.
import sys, os
src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()
AQUI = os.path.dirname(os.path.abspath(__file__))

def rep(viejo, nuevo, n=1):
    global s
    c = s.count(viejo)
    assert c == n, f'ancla: esperaba {n}, hay {c}: {viejo[:80]!r}'
    s = s.replace(viejo, nuevo)

def antes(marca, codigo):            # inserta delante de un marcador y lo deja
    rep(marca, codigo + marca)

CSS = ('.ue-reten{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:14px}'
       '.btn.btn-sec{font-size:13px;padding:11px 22px;background:rgba(166,226,46,.14);color:var(--bile)}'
       '.btn.btn-sec:hover{background:rgba(166,226,46,.3)}'
       '.ue-prueba{flex-basis:100%;margin:2px 0 0;font-size:11px;letter-spacing:.08em;opacity:.6}\n')
HTML = ('<div class="ue-reten"><button class="btn btn-sec" id="btnReten" type="button">Ir al retén</button>'
        '<button class="btn btn-sec" id="btnRetenSB" type="button">Ir al retén sin bichos</button>'
        '<p class="ue-prueba">Prueba: arrancás en Av. de Mayo y Santiago del Estero, a 110 m del retén.</p></div>\n    ')

antes('/*UE:css*/', CSS)
antes('<!--UE:inicio-->', HTML)
antes('/*UE:modulos*/', open(os.path.join(AQUI, 'mod_reten.js'), encoding='utf-8').read() + '\n')
antes('/*UE:reset*/', 'RETEN.reset();')
antes('/*UE:start*/', 'RETEN.alEmpezar();')
antes('/*UE:fx*/', 'RETEN.fx(dt);')
# el retén se arma con la sección B, después de los autos y los frentes (así queda adentro de SECG.B y corre los autos ya puestos)
rep("FRENTES.build('B');", "FRENTES.build('B');RETEN.armar();/*UE:W*/")
open(dst, 'w', encoding='utf-8').write(s)
