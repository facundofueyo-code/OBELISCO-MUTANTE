  /* ====================================================================================================
     ESTADO GENERAL
     ==================================================================================================== */
  const soldados = [];          // todos, vivos y muertos
  const escuadrones = [];
  const defs = [];              // lo que se pidió con UE.escuadron / UE.refuerzo, para poder rehacerlo en reset()
  let peligros = [];            // ENV.peligros() de este cuadro
  let bichos = [];              // ENV.bichos() de este cuadro
  const trabajos = [];          // cola de trabajos pesados (A*, búsqueda de cobertura): UNO por cuadro
  const dialogos = [];          // respuestas de radio pendientes
  const partes = [];            // avisos de ruido que todavía no llegaron al escuadrón
  let idSig = 0;

  /* «red»: lo que sabe la unidad entera. Los escuadrones comparten la radio, así que el último lugar conocido,
     las fichas de ataque y el tope de daño son de todos. */
  const red = {
    uc: null,             // último lugar conocido: {x,y,z,vx,vz,t,tipo:'vista'|'oido',err,alto}
    tVisto: -99,          // última vez que alguien lo vio (ya avisada)
    tSenal: -99,          // última señal de cualquier tipo (vista u oído)
    tContacto: -99,       // cuándo empezó este combate
    ancla: null,          // {x,z,t0}: desde cuándo el lugar conocido no sale de un radio (condición de la granada)
    fichas: [],           // soldados con permiso de tirar a pegar
    tirador: null,        // el tirador con el tiro en curso (uno solo a la vez)
    dano: [],             // pares (hora, daño) de balas que le pegaron al jugador en el último segundo
    tGranada: -99,        // última granada lanzada
    muerto: false,        // el jugador está muerto
    refuerzo: null,       // escuadrón de refuerzo esperando que lo pidan
    refPedido: false, refEn: -1, refLlego: false,
    recJug: -99,          // última vez que alguien vio al jugador recargando
    bichosVistos: false
  };

  const nivelEsc = e => e.estado === 'combate' ? 2 : (e.estado === 'guardia' ? 0 : 1);
  const nivelDe = s => { const n = nivelEsc(s.esc); return s.alerta > n ? s.alerta : n; };
  const ojoDe = s => s.tierra > 0 ? T.ojoAgach + (T.ojoTierra - T.ojoAgach) * s.tierra : T.ojoPie + (T.ojoAgach - T.ojoPie) * s.agach;
  const vivosDe = e => { let n = 0; for (let i = 0; i < e.soldados.length; i++) if (e.soldados[i].vivo && e.soldados[i].activo) n++; return n; };

  /* ====================================================================================================
     SOLDADO: un objeto plano. Lo que «sabe» está separado de lo que «es».
     ==================================================================================================== */
  function nuevoSoldado(esc, rol, num, p) {
    const arma = rol === 'asalto' ? 'escopeta' : rol === 'tirador' ? 'tirador' : 'fusil';
    const s = {
      /* identidad */
      id: idSig++, nombre: esc.nombre + ' ' + num, num, rol, esc, voz: 0,
      activo: true, vivo: true, hp: T.vida, r: 0.4,
      /* cuerpo */
      x: p.x, y: 0, z: p.z, rumbo: p.rumbo || 0, vx: 0, vz: 0, dvx: 0, dvz: 0,
      elev: null,                 // {r,y}: está subido a algo (nido)
      post: 0,                    // postura que quiere: 0 de pie · 1 agachado · 2 cuerpo a tierra
      agach: 0, tierra: 0,        // mezcla real 0…1 (tardan lo que dice TUNE)
      /* estado */
      estado: 'puesto', tEst: 0, tarea: 'guardia', orden: null, alerta: 0,
      puesto: { x: p.x, z: p.z, rumbo: p.rumbo || 0 },
      /* movimiento */
      camino: null, ci: 0, esperaCamino: false, vel: 0, mov: false, llego: true, dest: null,
      salto: -1, sx0: 0, sz0: 0, sx1: 0, sz1: 0, sDur: 0.5,
      trabT: 0, trabX: p.x, trabZ: p.z, trabN: 0,
      /* cobertura */
      cob: null, esperaCob: false, enTiro: false, tSal: 0, tVentana: 0, tSinTiro: 0, moverPor: null,
      /* lo que sabe del jugador */
      sosp: 0, ve: false, veMedio: false, veDesde: -99, tVisto: -99, tConoce: -99,
      hist: [], hI: 0,            // últimas observaciones propias (anillo)
      estX: 0, estZ: 0, estT: -99,   // estímulo: hacia dónde vio u oyó algo
      /* arma */
      arma, balas: T[arma].cargador, recT: -1, raf: 0, rafT: 0, rafModo: null, rafLado: 1, rafOff: 1.2, pausaT: 0,
      nRaf: 0, avisoHecho: false, tDisparo: -99,
      asiento: 0, supr: 0, escondeT: 0, tSuprDijo: -99,
      apunta: 0, miraYaw: p.rumbo || 0, mPitch: 0, miraX: 0, miraY: 0, miraZ: 0, hayMira: false,
      granadas: rol === 'granadero' ? 3 : 1, lanzaT: -1, lanza: null, gritoT: -99,
      /* blanco */
      blanco: null,               // null | 'jugador' | 'bicho'
      bicho: null, bichoT: -99,   // {ref,x,y,z,r,d}
      /* tirador */
      tir: 'espera', tirT: 0, tirSig: 0, laser: null, lx: 0, ly: 0, lz: 0, tirDijo: -99,
      /* relojes y animación */
      tPerc: 0, tPens: 0, tPercAnt: 0, aturdido: 0, culT: -1, culCd: 0, culPego: false, radioT: 0, senalT: -1, senalTipo: 'avanzar',
      luz: false, muerte: null, tMuerte: -1, heridoDijo: false, herT: -99, herDir: 0,
      escaneo: azar() * PI2, tOcio: 0, espera: 0, ri: 0, bi: -1, tRadio0: -1,
      vista: null,
      /* interfaz de blanco para los bichos (UEB.objetivos) */
      herir: null
    };
    s.voz = s.id % 8;
    for (let i = 0; i < 10; i++) s.hist.push({ t: -99, x: 0, y: 0, z: 0, vx: 0, vz: 0, alto: 1.8, medio: false });
    s.herir = (dano, bicho) => herir(s, dano, null, 'torso', 'bicho', bicho);
    s.tPerc = azar() * T.tPercibir; s.tPens = azar() * T.tPensar;
    return s;
  }

  /* ====================================================================================================
     RADIO: una frase cada ~1,2 s por escuadrón como mucho; las de peligro pasan siempre.
     ==================================================================================================== */
  function decir(s, clave, n) {
    if (!s || !s.vivo || !s.activo) return false;
    const e = s.esc;
    if (!UE_URGENTES[clave] && ahora - e.tRadio < T.radioCada) return false;
    const lista = UE_FRASES[clave]; if (!lista) return false;
    let i = Math.floor(azar() * lista.length); if (i >= lista.length) i = lista.length - 1;
    if (lista.length > 1 && i === e.ultFrase[clave]) i = (i + 1) % lista.length;        // sin repetir la última
    e.ultFrase[clave] = i;
    let f = lista[i], resp = null; if (Array.isArray(f)) { resp = f[1]; f = f[0]; }
    f = f.replace('{N}', n !== undefined ? n : s.num);
    if (e.nombre !== 'Ceniza' && clave !== 'refuerzo_va' && clave !== 'refuerzo_llega') f = f.replace('Ceniza', e.nombre);
    e.tRadio = ahora; s.radioT = 1.1;
    ENV.radio(s, clave, f);
    if (resp) dialogos.push({ t: ahora + 1.7, e, de: s, clave, f: resp });
    return true;
  }
  function tickDialogos() {
    for (let i = dialogos.length - 1; i >= 0; i--) {
      const d = dialogos[i]; if (ahora < d.t) continue; dialogos.splice(i, 1);
      if (d.e.estado !== 'guardia') continue;
      const o = d.e.soldados.find(m => m.vivo && m.activo && m !== d.de); if (!o) continue;
      d.e.tRadio = ahora; o.radioT = 0.9; ENV.radio(o, d.clave, d.f);
    }
  }

  /* ====================================================================================================
     LO QUE SE SABE: último lugar conocido
     ==================================================================================================== */
  function ponerUC(x, y, z, vx, vz, t, tipo, err, alto) {
    const u = red.uc;
    if (tipo === 'oido' && u) {
      if (u.tipo === 'vista' && t - u.t < 1.2) { red.tSenal = Math.max(red.tSenal, t); return; }   // lo estamos viendo: el oído no agrega nada
      if (hyp(x - u.x, z - u.z) < err + 1.5 && u.err <= err) { red.tSenal = Math.max(red.tSenal, t); return; }   // sonó donde ya creíamos que estaba: no se mueve
    }
    if (u && t < u.t) return;
    if (!u) red.uc = { x, y, z, vx, vz, t, tipo, err, alto };
    else { u.x = x; u.y = y; u.z = z; u.vx = vx; u.vz = vz; u.t = t; u.tipo = tipo; u.err = err; u.alto = alto; }
    red.tSenal = Math.max(red.tSenal, t); if (tipo === 'vista') red.tVisto = Math.max(red.tVisto, t);
    /* ancla: ¿hace cuánto que no sale de un radio? (para la granada) */
    const a = red.ancla;
    if (!a || hyp(x - a.x, z - a.z) > T.granada.quietoRadio) red.ancla = { x, z, t0: t };
    expoCentrar(x, z);
  }
  /* la mejor posición que conoce ESTE soldado: la propia si es más nueva que la del escuadrón */
  const _uc = { x: 0, y: 0, z: 0, vx: 0, vz: 0, t: -99, tipo: 'vista', err: 0, alto: 1.8, propia: false };
  function conocido(s) {
    const h = s.hist[(s.hI + 9) % 10], u = red.uc;
    if (h.t > -90 && (!u || h.t > u.t)) { _uc.x = h.x; _uc.y = h.y; _uc.z = h.z; _uc.vx = h.vx; _uc.vz = h.vz; _uc.t = h.t; _uc.tipo = 'vista'; _uc.err = 0; _uc.alto = h.alto; _uc.propia = true; return _uc; }
    return u;
  }
  /* Lo que uno ve, el escuadrón lo sabe T.aviso segundos después: cada cuadro se entrega la observación más
     nueva de cada soldado VIVO que ya tenga esa antigüedad. Uno que muere antes de avisar, no avisa. */
  function entregarAvisos() {
    const lim = ahora - T.aviso;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      let m = null; for (let q = 0; q < 10; q++) { const h = s.hist[q]; if (h.t <= lim && h.t > -90 && (!m || h.t > m.t)) m = h; }
      if (m && (!red.uc || m.t > red.uc.t)) {
        const nuevo = red.tVisto < -90 || red.muerto;
        ponerUC(m.x, m.y, m.z, m.vx, m.vz, m.t, 'vista', 0, m.alto);
        for (let q = 0; q < escuadrones.length; q++) if (escuadrones[q].activo) entrarCombate(escuadrones[q], nuevo ? s : null);
      }
    }
    for (let i = partes.length - 1; i >= 0; i--) {
      const p = partes[i]; if (ahora < p.t) continue; partes.splice(i, 1);
      if (!p.s.vivo) continue;
      ponerUC(p.x, p.y, p.z, 0, 0, p.t0, 'oido', p.err, 1.8);
      for (let q = 0; q < escuadrones.length; q++) { const e = escuadrones[q]; if (!e.activo) continue; if (p.fuerte) entrarCombate(e, null); else entrarSospecha(e, p.s, p.x, p.z); }
    }
  }

  /* ====================================================================================================
     PERCEPCIÓN — el ÚNICO lugar donde la IA mira dónde está el jugador de verdad.
     ==================================================================================================== */
  function tDetectar(d) {
    const D = T.detectar; if (d <= D[0]) return D[1];
    for (let i = 2; i < D.length; i += 2) if (d <= D[i]) return D[i - 1] + (D[i + 1] - D[i - 1]) * (d - D[i - 2]) / (D[i] - D[i - 2]);
    const n = D.length; return D[n - 1] + (d - D[n - 2]) * (D[n - 1] - D[n - 3]) / (D[n - 2] - D[n - 4]);
  }
  /* rayo real entre dos puntos: ¿llega sin chocar con el mundo? */
  function rayoLibre(ax, ay, az, bx, by, bz) {
    const dx = bx - ax, dy = by - ay, dz = bz - az, d = Math.sqrt(dx * dx + dy * dy + dz * dz); if (d < 0.5) return true;
    return ENV.rayo(ax, ay, az, dx / d, dy / d, dz / d, d) >= d - 0.45;
  }
  function percibir(s) {
    const dtP = Math.min(0.4, ahora - s.tPercAnt); s.tPercAnt = ahora;
    const j = ENV.jugador(), nivel = nivelDe(s);
    let ve = false, medio = false, d = 1e9;
    if (j.vivo) {
      const dx = j.x - s.x, dz = j.z - s.z; d = hyp(dx, dz);
      const rumboJ = Math.atan2(dx, dz), desv = Math.abs(angN(rumboJ - s.miraYaw));
      const v2 = j.vx * j.vx + j.vz * j.vz, quieto = v2 < 1;
      /* iluminado: por los reflectores, por su propia linterna, o por la linterna de este soldado si le apunta de cerca */
      const luz = j.linterna || ENV.luz(j.x, j.z) > 0.5 || (s.luz && d < 16 && desv < 0.35);
      let alc = T.vistaDist; if (luz) alc *= T.vistaLuz; else if (j.agach > 0.5 && quieto) alc *= T.vistaQuieto; if (alc > T.vistaTope) alc = T.vistaTope;
      const cono = (nivel >= 2 ? T.conoCombate : nivel === 1 ? T.conoSospecha : T.conoGuardia) * RAD * 0.5;
      if (d <= alc && (desv <= cono || d < 1.6)) {
        const oy = s.y + ojoDe(s), yp = j.y + j.alto * 0.62, yc = j.y + j.alto - 0.12;
        let r = lv(s.x, oy, s.z, j.x, yp, j.z, s.elev); if (r === 2) r = rayoLibre(s.x, oy, s.z, j.x, yp, j.z) ? 1 : 0;
        if (r) ve = true;
        else { r = lv(s.x, oy, s.z, j.x, yc, j.z, s.elev); if (r === 2) r = rayoLibre(s.x, oy, s.z, j.x, yc, j.z) ? 1 : 0; if (r) { ve = true; medio = true; } }
      }
      if (nivel < 2) {
        /* en guardia no lo detecta de inmediato: la sospecha sube según distancia, luz, postura y movimiento */
        if (ve) {
          let r = 1 / tDetectar(d);
          if (luz) r *= T.detLuz; if (j.agach > 0.5) r *= T.detAgach; if (quieto) r *= T.detQuieto; else if (j.corriendo) r *= T.detCorre;
          if (medio) r *= T.detMedio; if (desv > cono * 0.6) r *= T.detBorde; if (nivel === 1 || s.esc.alertado) r *= T.detAlerta;
          s.sosp = Math.min(1, s.sosp + r * dtP);
          s.estX = j.x; s.estZ = j.z; s.estT = ahora;                 // vio «algo» ahí: hacia allá va a mirar
        } else s.sosp = Math.max(0, s.sosp - T.sospechaBaja * dtP);
        if (ve && s.sosp >= 1) contacto(s); else ve = false;         // hasta no confirmarlo no «lo ve»: ni tira ni avisa
      }
      /* oído: pasos corriendo cerca */
      if (!ve && j.corriendo && d < T.oidoPasos && ahora - s.estT > 0.5) {
        const e = 1.5 + d * 0.1; s.estX = j.x + campana() * e; s.estZ = j.z + campana() * e; s.estT = ahora;
        if (nivel < 2) { s.sosp = Math.max(s.sosp, 0.5); }
        partes.push({ t: ahora + T.aviso, t0: ahora, s, x: s.estX, y: j.y, z: s.estZ, err: e + 1, fuerte: nivel >= 2 });
      }
    } else if (!red.muerto) jugadorMurio(s);
    if (ve) {
      if (!s.ve && ahora - s.tVisto > 0.3) s.veDesde = ahora;
      s.ve = true; s.veMedio = medio; s.tVisto = ahora; if (s.tConoce < -90) s.tConoce = ahora;
      const h = s.hist[s.hI]; s.hI = (s.hI + 1) % 10;
      h.t = ahora; h.x = j.x; h.y = j.y; h.z = j.z; h.vx = j.vx; h.vz = j.vz; h.alto = j.alto; h.medio = medio;
      if (j.recargando) red.recJug = ahora;
    } else { s.ve = false; }
    percibirBichos(s);
  }
  /* la sospecha llegó a 1: contacto. El soldado ya está en combate; el escuadrón lo sabe en T.aviso segundos. */
  function contacto(s) {
    if (s.alerta < 2) { s.alerta = 2; s.tConoce = ahora; s.veDesde = ahora; decir(s, 'contacto'); ENV.evento('contacto', { s }); }
    s.sosp = 1;
  }
  function jugadorMurio(s) {
    red.muerto = true; red.fichas.length = 0;
    decir(s, 'muerto_jugador'); ENV.evento('jugador_muerto', { s });
    for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo) volverAGuardia(escuadrones[i], false);
  }
  /* mutantes: ve al más amenazante a menos de 30 m con línea de visión (o al que lo está mordiendo) */
  function percibirBichos(s) {
    if (!bichos.length) { if (s.bicho && ahora - s.bichoT > 0.6) s.bicho = null; return; }
    const oy = s.y + ojoDe(s); let mejor = null, mp = -1e9, md = 0;
    for (let i = 0; i < bichos.length; i++) {
      const b = bichos[i], d = hyp(b.x - s.x, b.z - s.z); if (d > T.vistaBicho) continue;
      let p = -d; if (s.bicho && s.bicho.ref === b.ref) p += 3;                    // no cambiar de blanco a cada rato
      if (p <= mp) continue;
      if (d > 2.5 && !lineaVista(s.x, oy, s.z, b.x, b.y, b.z, s.elev)) continue;
      mp = p; mejor = b; md = d;
    }
    if (mejor) {
      if (!s.bicho) s.bicho = { ref: null, x: 0, y: 0, z: 0, r: 0.5, d: 0 };
      const o = s.bicho; o.ref = mejor.ref; o.x = mejor.x; o.y = mejor.y; o.z = mejor.z; o.r = mejor.r || 0.5; o.d = md; s.bichoT = ahora;
      if (!red.bichosVistos) { red.bichosVistos = true; decir(s, 'bichos'); ENV.evento('bichos', { s }); }
      if (s.alerta < 1) s.alerta = 1;
    } else if (s.bicho && ahora - s.bichoT > 0.6) s.bicho = null;
  }

