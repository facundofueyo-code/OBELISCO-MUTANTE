#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Arma las copias de prueba (NO son entregables):
   t/juego_m.html  = v116/base.html + parche M (tal como quedaría el juego)
   t/base_det.html = v116/base.html + preludio determinista
   t/mod_det.html  = v116/base.html + parche M + preludio determinista
El preludio hace repetible una partida: azar con semilla desde antes de cargar el juego, ningún cuadro real
(requestAnimationFrame anulado: los cuadros los da la prueba), setTimeout/setInterval por tiempo simulado y
performance.now() falso (avanza un paso fijo por llamada). El reloj real queda en window.__realNow()."""
import os, subprocess, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
UE = os.path.abspath(os.path.join(AQUI, '..', '..'))
PRELUDIO = r'''<script>/* PRELUDIO DE PRUEBA: no va al juego */
(()=>{
  let s=20261003|0,n=0;
  Math.random=()=>{n++;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
  window.__rng={seed:v=>{s=v|0;n=0;},get n(){return n;}};
  window.requestAnimationFrame=()=>0;
  const real=performance.now.bind(performance);window.__realNow=real;
  let clk=1000;performance.now=()=>(clk+=.25);
  const Q=[];let now=0,seq=1;
  const add=(fn,ms,rep)=>{const id=seq++;Q.push({t:now+Math.max(0,+ms||0),fn,id,rep:rep?Math.max(1,+ms||1):0});return id;};
  window.setTimeout=(fn,ms)=>add(fn,ms,false);window.setInterval=(fn,ms)=>add(fn,ms,true);
  window.clearTimeout=window.clearInterval=id=>{const i=Q.findIndex(x=>x.id===id);if(i>=0)Q.splice(i,1);};
  window.__timers={adv(ms){now+=ms;for(let guard=0;guard<10000;guard++){let b=-1;for(let i=0;i<Q.length;i++)if(Q[i].t<=now&&(b<0||Q[i].t<Q[b].t||(Q[i].t===Q[b].t&&Q[i].id<Q[b].id)))b=i;if(b<0)break;
      const it=Q[b];if(it.rep)it.t+=it.rep;else Q.splice(b,1);it.fn();}},get n(){return Q.length;}};
})();
</script>
'''


def con_preludio(src, dst):
    s = open(src, encoding='utf-8').read()
    i = s.index('<script>')
    open(dst, 'w', encoding='utf-8').write(s[:i] + PRELUDIO + s[i:])


BASE = os.path.join(UE, 'v116', 'base.html')   # base actual: juego 1.16.0 + marcadores (antes: ue/base.html, 1.14.0)
subprocess.check_call([sys.executable, os.path.join(AQUI, '..', 'patch_bichos.py'), BASE, os.path.join(AQUI, 'juego_m.html')])
con_preludio(BASE, os.path.join(AQUI, 'base_det.html'))
con_preludio(os.path.join(AQUI, 'juego_m.html'), os.path.join(AQUI, 'mod_det.html'))
print('listo: juego_m.html, base_det.html, mod_det.html')
