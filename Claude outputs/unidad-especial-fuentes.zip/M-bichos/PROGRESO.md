# M-bichos · progreso

(Se actualiza a medida que avanza el trabajo. Si esto se corta, seguir desde «Falta».)

## Diseño decidido

- Código nuevo en `mod_bichos.js` (va en `/*UE:modulos*/`): estado `BCH`, perillas `BCH_TUNE`, funciones `bch*`,
  más las del contrato: `rayoBichos`, `bichosVivos`. No se usa `MB`/`mb*` porque el juego ya los usa (Metrobús).
- `fire()` NO se toca: `rayoBichos` repite la cuenta aparte.
- Ediciones al juego (todas marcadas `/*UE:M*/`), en `patch_bichos.py`:
  1. `updateEnemies`: variables de blanco `tg,tgx,tgz,tgy,distP` al principio del cuerpo del bucle; salto del bagayo; condición de `atkStart`; `dist`→`distP` en los dos sonidos del final.
  2. `enSteer`: si `e.tg`, usa `bchSteer` (línea recta con `enLine` o camino corto A* propio).
  3. `atkTick`: punto del golpe, envión y daño hacia el blanco; pisotón del Engendro en área.
  4. `spit` / `updateProjs`: el escupitajo apunta al blanco y les pega a los soldados.
  5. `damageEnemy(e,dm,dir,de)` / `killEnemy(e,de)`: sin puntos, combo ni frase si `de==='soldado'`.
  6. `carBoom`: `UEB.explosion(pos,8,70,'auto')`.
  7. `carHitsDynamic`: el auto que barre les pega a los soldados.
- Sin soldados (`UEB.objetivos()` vacío) no se ejecuta nada nuevo y no se consume `Math.random`.

## Base 1.16.0 (2026-10-10)

- La base ahora es `../v116/base.html`. `t/prep.py` arma las copias desde ahí; `t_sold.js` toma la cuenta de `fire()` de ahí.
- Ancla que fallaba (`updateProjs`, piso con `PISO.y`): ahora el ancla es la línea del jugador
  (`if(dx*dx+dy*dy+dz*dz<1.1*p.m.scale.x){hurtPlayer(p.dmg,true);hit=true;}`) y `bchProy` va detrás. Los 22 reemplazos anclados del parche aplican sobre 1.16.0.
- Alturas: todo lo propio se mide desde los pies (`e.gy` del bicho, `s.y` del soldado); nada supone piso en 0.
  `bchAuto` copia la cuenta nueva del jugador (`c.H+p.y+c.by`). Los soldados de prueba van con `y=floorAt(x,z)`.

## Decisiones de esta tanda

- Soltar a un soldado por trabarse: antes bastaba una revisión sin avanzar (`e.stk>0`), y la primera revisión después de un golpe
  da «trabado» en falso (la ventana de 1 s incluye el golpe). Ahora hacen falta dos seguidas (`e.stk>=2`).
- El escupidor no suelta a su soldado por trabarse ni por falta de camino mientras lo tenga a menos de 30 m (`bchATiro`), y en ese
  caso no busca camino corto: va con el rumbo directo (para acercarse, alejarse o rodearlo) y escupe. Con 24 m (primer intento)
  seguía fallando a 23 m: rodeándolo pasaba los 24 m, se trababa y lo soltaba.
- Si su soldado muere en medio de un golpe, termina el golpe en el lugar (ya no lo daña) y recién ahí elige otro blanco
  (antes giraba hacia el jugador y el envión podía salir hacia el jugador).

## Pruebas: qué estaba mal en las 6 que fallaban (1.14)

- `A bagayo: salta` / `la caída pega doble`: la prueba. Arranca a 10 m y llega al soldado antes de que se le cargue el salto
  (`leapCd` inicial 1–3 s); pegado al blanco (dist < 1,8) ya no salta. Igual con un jugador quieto. Nueva prueba A2 con control.
- `C (lista filtrada)`: el código (trabado en falso después del golpe → soltaba a B por 4 s). Ver arriba.
- `H 16 m / 23 m`: el código (el escupidor soltaba al soldado al trabarse rodeándolo). Ver arriba.
- `R bichosVivos`: la prueba. El baboso tarda 1,1 s en salir y la prueba miraba a los 1,2 s. Ahora mira a los 0,6 s.
- Además, por el mapa nuevo: B usa el taxi 784 y el sedán 786 (los autos de antes ya no están); Q mide la explosión en `c.by+0,8`.

## Hecho

- [x] Leída la SPEC, la tarea y el código (`updateEnemies`, navegación, `fire`, `atkTick`, `spit`, autos).
- [x] `mod_bichos.js` y `patch_bichos.py` (sobre 1.14), pruebas 74/80 en 1.14.
- [x] Parche pasado a 1.16.0; arreglos de arriba; F+M aplican juntos en los dos órdenes.
- [x] Regresión sin soldados sobre 1.16 con el código final: `t/reg_base116.bin` = `t/reg_mod116.bin` byte a byte (11 400 cuadros).
- [x] `t_sold.js` sobre 1.16: 83 OK, 0 FALLA (`t/t_sold116.log`).
- [x] Costo (`t/t_costo.js`, `t/t_costo_mod.log`).
- [x] `INFORME.md`.

## Falta

- Nada de lo pedido. Pendientes y dudas en `INFORME.md` §5.
