/* Desarma el mapa recortado (ver src/mapa.py): tramos «valor, largo» en base64 → Uint8Array.
   Devuelve el objeto que espera crearMundo: {X0,Z0,W,H,B,Hh,G,cars,sub,mh}. */
function desarmarMapa(c) {
  const n = c.W * c.H;
  const uno = txt => {
    const bin = typeof atob === 'function' ? atob(txt) : Buffer.from(txt, 'base64').toString('binary');
    const out = new Uint8Array(n); let i = 0, k = 0;
    while (i < bin.length) {
      const v = bin.charCodeAt(i++); let largo = 0, corr = 0, b;
      do { b = bin.charCodeAt(i++); largo |= (b & 127) << corr; corr += 7; } while (b & 128);
      out.fill(v, k, k + largo); k += largo;
    }
    if (k !== n) throw new Error('mapa roto: ' + k + ' de ' + n);
    return out;
  };
  return { X0: c.X0, Z0: c.Z0, W: c.W, H: c.H, B: uno(c.B), Hh: uno(c.Hh), G: uno(c.G),
    cars: c.cars.slice(), obs: [], sub: c.sub.slice(), mh: c.mh.slice() };
}
if (typeof module !== 'undefined') module.exports = { desarmarMapa };
