/* =====================================================================================================
   EL RETÉN DESDE ARRIBA — tablero 2D de la página de concepto de la Unidad Especial.
   Corre la IA real (crearUE, ue_ia.js) sobre el mundo simulado (crearMundo, sim/mundo.js) y el mapa real
   recortado (UE_MAPA_RECORTE, ver src/mapa.py). Modos:
     'reposo'  velo con JUGAR; de fondo, el retén en guardia (se ve todo)
     'juego'   lo maneja Facu con teclado y mouse; se ve solo lo que ve el jugador
     'mirar'   juega solo el jugador automático JG.decente (sim/jugadores.js) y la cámara lo sigue
   Paso fijo de 1/60 s con acumulador. Para las pruebas: window.UEPAG.
   Convenciones del juego: norte es −z (arriba en pantalla), este es +x; rumbo = atan2(dx, dz).
   ===================================================================================================== */
(function () {
'use strict';
const PI = Math.PI, TAU = PI * 2, hyp = Math.hypot, DT = 1 / 60;
const RVIS = 55;                       // m que ve el jugador de noche (niebla)
const NRAYOS = 180;                    // rayos de la línea de visión
const INICIO = { x: -326, z: 606 };    // el jugador entra por el este (Av. de Mayo y Santiago del Estero)
const CAM_REPOSO = { x: -421, z: 608 };
const $ = id => document.getElementById(id);
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const coma = (v, d) => v.toFixed(d === undefined ? 1 : d).replace('.', ',');
const reloj = s => { s = Math.max(0, Math.floor(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

/* ---------- colores: los de :root ---------- */
const raiz = getComputedStyle(document.documentElement);
const K = {};
for (const [k, n, f] of [['fondo', '--m-fondo', '#040507'], ['calle', '--m-calle', '#16181c'], ['vereda', '--m-vereda', '#232320'], ['plaza', '--m-plaza', '#1a1f1a'],
  ['edif', '--m-edif', '#0a0b0d'], ['alto', '--m-alto', '#121418'], ['obst', '--m-obst', '#2b2e34'], ['borde', '--m-borde', '#3a414b'], ['cordon', '--m-cordon', '#34332e'],
  ['texto', '--m-texto', '#6d7580'], ['auto', '--m-auto', '#25282e'], ['techo', '--m-techo', '#30343b'], ['taxi', '--m-taxi', '#3b3520'], ['furgon', '--m-furgon', '#08090b'],
  ['fbord', '--m-fbord', '#4b525c'], ['valla', '--m-valla', '#9aa0a8'], ['subte', '--m-subte', '#7fa35a'], ['niebla', '--m-niebla', '#020306'], ['luz', '--m-luz', '#ffb15a'],
  ['laser', '--m-laser', '#ff3a2c'], ['traza', '--m-traza', '#ffcf8a'], ['mia', '--m-mia', '#fff1c2'], ['bicho', '--m-bicho', '#8fd12a'], ['sangre', '--m-sangre', '#4f0d0b'],
  ['soldado', '--m-soldado', '#14161a'], ['yo', '--m-yo', '#ebe5d8'], ['saben', '--m-saben', '#ff6a4d'], ['camino', '--m-camino', '#8fb0cc'], ['cold', '--cold', '#a9bccd'],
  ['acc', '--acc', '#ffa23a'], ['warn', '--warn', '#e2574c'], ['bile', '--bile', '#a6e22e'], ['ink', '--ink', '#ebe5d8'], ['bg', '--bg', '#0b0d10'],
  ['hueco', '--m-hueco', '#0a0f09'], ['caido', '--m-caido', '#0f1013'], ['arma', '--m-arma', '#596270'], ['lente', '--m-lente', '#bed7f0'], ['granada', '--m-granada', '#1a1c20'],
  ['etiq', '--m-etiq', '#08090b'], ['raya', '--m-raya', '#0a0b0d'], ['linea', '--m-linea', '#4b525c'], ['sombra', '--m-sombra', '#000000'], ['nucleo', '--m-nucleo', '#141e06'], ['reflector', '--m-reflector', '#ffb466']])
  K[k] = (raiz.getPropertyValue(n) || '').trim() || f;
const FUENTE_HUD = (raiz.getPropertyValue('--hud') || '').trim() || 'system-ui,sans-serif';
const FUENTE_MONO = (raiz.getPropertyValue('--mono') || '').trim() || 'monospace';
function hexRGB(h) { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/./g, c => c + c); const n = parseInt(h, 16) || 0; return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
const RGB = {}; for (const k in K) if (K[k][0] === '#') RGB[k] = hexRGB(K[k]);
const rgba = (k, a) => { const c = RGB[k] || [255, 255, 255]; return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a.toFixed(3) + ')'; };

const tactil = !!(window.matchMedia && matchMedia('(hover: none) and (pointer: coarse)').matches);
const reduce = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
const SND = typeof PAG_SONIDO !== 'undefined' ? PAG_SONIDO : { iniciar() {}, disparo() {}, explosion() {}, radio() {}, activar() {}, activo: false };

/* =====================================================================================================
   MAPA: la base (1 píxel por casillero, sin suavizado: las calles del centro son rectas) y los bordes
   ===================================================================================================== */
const MAPA = desarmarMapa(UE_MAPA_RECORTE);
const MX0 = MAPA.X0, MZ0 = MAPA.Z0, MW = MAPA.W, MH = MAPA.H;
const BASE = armarBase();
function marcarRect(arr, cx, cz, a, hl, hw) {
  const ux = Math.sin(a), uz = Math.cos(a), r = hl + hw;
  for (let z = Math.floor(cz - r); z <= Math.floor(cz + r); z++) for (let x = Math.floor(cx - r); x <= Math.floor(cx + r); x++) {
    const i = x - MX0, j = z - MZ0; if (i < 0 || j < 0 || i >= MW || j >= MH) continue;
    const px = x + 0.5 - cx, pz = z + 0.5 - cz, p = px * ux + pz * uz, q = px * uz - pz * ux;
    if (Math.abs(p) <= hl && Math.abs(q) <= hw) arr[j * MW + i] = 1;
  }
}
function armarBase() {
  const N = MW * MH, B = MAPA.B, G = MAPA.G, auto = new Uint8Array(N);
  for (const c of MAPA.cars) marcarRect(auto, c.x, c.z, c.a, c.L / 2 + 0.4, c.W / 2 + 0.4);
  const cnv = document.createElement('canvas'); cnv.width = MW; cnv.height = MH;
  const g = cnv.getContext('2d'), img = g.createImageData(MW, MH), d = img.data;
  const cG = [K.vereda, K.calle, K.edif, K.plaza, K.hueco].map(hexRGB), cObst = hexRGB(K.obst), cAlto = hexRGB(K.alto);
  for (let k = 0; k < N; k++) {
    let c = cG[G[k]] || cG[2];
    if (!auto[k] && G[k] !== 4) { if (B[k] === 1) c = cObst; else if (B[k] === 2 && G[k] !== 2) c = cAlto; }
    d[k * 4] = c[0]; d[k * 4 + 1] = c[1]; d[k * 4 + 2] = c[2]; d[k * 4 + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  /* bordes: entre lo sólido y lo demás (edificios) y entre calle y vereda (cordón), unidos en tramos largos */
  const tipo = k => (B[k] === 2 && !auto[k] && G[k] !== 4) ? 2 : G[k] === 1 ? 1 : 0;
  const edif = [], cordon = [];
  for (let j = 1; j < MH; j++) {
    let ie = -1, ic = -1;
    for (let i = 0; i <= MW; i++) {
      let e = false, c = false;
      if (i < MW) { const a = tipo((j - 1) * MW + i), b = tipo(j * MW + i); e = (a === 2) !== (b === 2); c = !e && a !== 2 && b !== 2 && a !== b; }
      if (e && ie < 0) ie = i; if (!e && ie >= 0) { edif.push(MX0 + ie, MZ0 + j, MX0 + i, MZ0 + j); ie = -1; }
      if (c && ic < 0) ic = i; if (!c && ic >= 0) { cordon.push(MX0 + ic, MZ0 + j, MX0 + i, MZ0 + j); ic = -1; }
    }
  }
  for (let i = 1; i < MW; i++) {
    let je = -1, jc = -1;
    for (let j = 0; j <= MH; j++) {
      let e = false, c = false;
      if (j < MH) { const a = tipo(j * MW + i - 1), b = tipo(j * MW + i); e = (a === 2) !== (b === 2); c = !e && a !== 2 && b !== 2 && a !== b; }
      if (e && je < 0) je = j; if (!e && je >= 0) { edif.push(MX0 + i, MZ0 + je, MX0 + i, MZ0 + j); je = -1; }
      if (c && jc < 0) jc = j; if (!c && jc >= 0) { cordon.push(MX0 + i, MZ0 + jc, MX0 + i, MZ0 + j); jc = -1; }
    }
  }
  /* bocas del subte: el hueco de la escalera (G = 4) */
  const bocas = MAPA.sub.map(s => {
    let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
    for (let z = Math.floor(s.z) - 5; z <= Math.floor(s.z) + 5; z++) for (let x = Math.floor(s.x) - 7; x <= Math.floor(s.x) + 7; x++) {
      const i = x - MX0, j = z - MZ0; if (i < 0 || j < 0 || i >= MW || j >= MH || G[j * MW + i] !== 4) continue;
      x0 = Math.min(x0, x); x1 = Math.max(x1, x + 1); z0 = Math.min(z0, z); z1 = Math.max(z1, z + 1);
    }
    return x1 > x0 ? { x0, x1, z0, z1, x: s.x, z: s.z } : { x0: s.x - 3, x1: s.x + 3, z0: s.z - 1, z1: s.z + 1, x: s.x, z: s.z };
  });
  return { cnv, edif: new Float32Array(edif), cordon: new Float32Array(cordon), bocas };
}
/* nombres de calles (para ubicarse) */
const ROTULOS = [
  { t: 'AV. DE MAYO', x: -372, z: 607.2 }, { t: 'AV. DE MAYO', x: -500, z: 607.2 },
  { t: 'HIPÓLITO YRIGOYEN', x: -382, z: 671 }, { t: 'HIPÓLITO YRIGOYEN', x: -505, z: 671 },
  { t: 'RIVADAVIA', x: -390, z: 540.5 }, { t: 'RIVADAVIA', x: -505, z: 540.5 },
  { t: 'SAN JOSÉ', x: -451.5, z: 642, v: true }, { t: 'SAN JOSÉ', x: -451.5, z: 572, v: true },
  { t: 'SANTIAGO DEL ESTERO', x: -322.5, z: 642, v: true }, { t: 'SANTIAGO DEL ESTERO', x: -322.5, z: 570, v: true },
  { t: 'PASAJE BAROLO', x: -409.6, z: 643, v: true },
  { t: '← AL CONGRESO', x: -552, z: 603.2 }
];
/* la mancha cálida de los reflectores (M.zonaLuz), dibujada una vez, a 4 px por metro */
let LUZ = null;
function armarLuz(Z) {
  /* elipse cálida sobre la zona que alumbran los reflectores, más fuerte del lado de la barricada (oeste) */
  const e = 4, rx = (Z.x1 - Z.x0) / 2 + 9, rz = (Z.z1 - Z.z0) / 2 + 5, w = Math.ceil(2 * rx * e), h = Math.ceil(2 * rz * e);
  const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d');
  g.save(); g.translate(w / 2, h / 2); g.scale(1, rz / rx);
  const gr = g.createRadialGradient(-rx * e * 0.35, 0, 0, 0, 0, rx * e);
  gr.addColorStop(0, rgba('reflector', 0.95)); gr.addColorStop(0.3, rgba('reflector', 0.55)); gr.addColorStop(0.7, rgba('luz', 0.14)); gr.addColorStop(1, rgba('luz', 0));
  g.fillStyle = gr; g.beginPath(); g.arc(0, 0, rx * e, 0, TAU); g.fill(); g.restore();
  const cx = (Z.x0 + Z.x1) / 2, cz = (Z.z0 + Z.z1) / 2;
  LUZ = { c, x0: cx - rx, z0: cz - rz, w: 2 * rx, h: 2 * rz };
}

/* =====================================================================================================
   ESTADO
   ===================================================================================================== */
const stage = $('stage'), tablero = $('tablero'), cv = $('cv'), ctx = cv.getContext('2d');
let cw = 1, ch = 1, dpr = 1, PPD = 10, ox = 0, oz = 0, zoom = 1;
const cam = { x: CAM_REPOSO.x, z: CAM_REPOSO.z };
const sx = x => x * PPD + ox, sy = z => z * PPD + oz;
const raton = { sx: 0, sy: 0 };
let M = null, UE = null, bot = null, P = null, foto = null, est = null, evsPrev = [];
let modo = 'reposo', pausa = false, fin = null, verSaben = false, lenta = false, sucio = true, enPantalla = true;
const teclas = { w: false, a: false, s: false, d: false, c: false };
let correr = false, gatillo = false, pendiente = false, tPend = 0, ultimo = 0, acc = 0, congelado = false;
const ajustes = { fichas: 2, punteria: 1, dano: 1 };
let ajustesVivos = JSON.stringify(ajustes);
let semilla = (Date.now() % 9973) + 7;
const cuentas = { radio: 0, balasSold: 0, balasMias: 0, aciertos: 0, pegaronJugador: 0, bajas: 0, bajasMias: 0, granadas: 0, explosiones: 0, pasos: 0, errores: 0, saqueos: 0 };
const rayos = new Float32Array(NRAYOS);
const NOMBRE_ARMA = { pistola: 'PISTOLA', escopeta: 'ESCOPETA', uzi: 'UZI', fusil: 'FUSIL' };
const LETRA = { jefe: 'J', asalto: 'A', granadero: 'G', tirador: 'T' };
const PELIGRO = new Set(['granada', 'contacto', 'tirador_mira', 'orden_flanco', 'flanco_izq', 'flanco_der', 'recarga_jugador', 'auto_fuego', 'refuerzo_pide', 'refuerzo_va', 'refuerzo_llega', 'muerto_jugador']);
const FUENTE = { fusil: 'una ráfaga de fusil', escopeta: 'la escopeta del asalto', tirador: 'el tirador', granada: 'una granada', culata: 'un culatazo', bicho: 'un bicho', jugador: 'tu propia granada' };
const EST_ESC = { guardia: 'en guardia', sospecha: 'sospecha', combate: 'combate', busqueda: 'búsqueda' };
const EST_SOL = { puesto: 'en su puesto', ronda: 'hace la ronda', revisar: 'va a revisar', alerta: 'alerta', a_cubierto: 'va a cubrirse', cubierto: 'a cubierto',
  asomado: 'asomado', aturdido: 'aturdido', bicho: 'pelea con bichos', buscar: 'busca', culata: 'culatazo', esquivar: 'esquiva', flanquear: 'te rodea',
  lanzar: 'tira granada', llegando: 'llegando', muerto: 'caído', radio: 'habla por radio', recargar: 'recarga', tierra: 'cuerpo a tierra', volver: 'vuelve al puesto' };
const TAREA = { fijar: 'fija', avanzar: 'avanza', flanquear: 'rodea', replegar: 'se repliega', buscar: 'barre', tirador: 'tirador' };

/* =====================================================================================================
   MUNDO
   ===================================================================================================== */
function nuevoMundo(m) {
  semilla = (semilla * 48271) % 2147483647;
  M = crearMundo(MAPA, { semilla: semilla % 100000 });
  UE = crearUE(M.ENV, Object.assign({}, UE_TUNE, ajustes));
  M.conectar(UE); M.armarReten();
  if (!LUZ) armarLuz(M.zonaLuz);
  ajustesVivos = JSON.stringify(ajustes);
  const J = M.jugador;
  P = { cuerpos: new Map(), tieneFusil: m !== 'juego', limites: m === 'juego', res: { pistola: Infinity, escopeta: 10, uzi: 64, fusil: 0 }, carg: null,
    trazas: [], chispas: [], fogon: [], explos: [], marcas: [], golpes: [], radio: [], bajas: 0, tMuerte: null, golpe: '', ultExplo: null,
    rumboJ: -PI / 2, tRumbo: -9, visibles: new Set(), bichosVis: [], vistos: new Set(), tomadoEn: null, nota: '', notaHasta: 0, rojo: 0, fogKey: '', sonKey: '' };
  if (m === 'juego') {
    M.armas.escopeta.cargador = 2; J.cargador.escopeta = 2; J.cargador.fusil = 0; J.granadas = 0;        // las reservas del juego
    const rec0 = M.recargarJugador;
    M.recargarJugador = () => (P.limites && !(P.res[J.arma] > 0)) ? false : rec0();
  }
  if (m === 'reposo') J.hp = 1e9;                     // de fondo nadie juega: el testigo no cuenta
  bot = m === 'mirar' ? crearJugadores(M, UE).decente({ inicio: INICIO }) : null;
  P.carg = Object.assign({}, J.cargador);
  evsPrev = []; foto = M.foto(); est = UE.estado();
  correr = gatillo = pendiente = false; for (const k in teclas) teclas[k] = false;
  if (m === 'reposo') { cam.x = CAM_REPOSO.x; cam.z = CAM_REPOSO.z; } else { cam.x = J.x - 10; cam.z = J.z; }
  zoom = 1; radioDom(); avisoAjustes(); sucio = true;
}
function paso(dt) {
  const J = M.jugador;
  if (modo === 'juego' && J.vivo && !fin) controlar(dt);
  else if (modo === 'mirar' && bot && J.vivo) bot.paso(dt, evsPrev);
  M.paso(dt);
  const evs = M.sacarEventos();
  if (P.limites) reservas(J);
  procesar(evs); evsPrev = evs;
  if (modo === 'juego' && J.vivo) saquear(J);
  if (modo === 'mirar' && M.t - P.tRumbo > 0.6 && hyp(J.vx, J.vz) > 0.5) P.rumboJ = Math.atan2(J.vx, J.vz);
  envejecer(dt); revisarFin(); cuentas.pasos++;
}
let errLog = 0;
function pasoSeguro(dt) { try { paso(dt); } catch (e) { cuentas.errores++; if (errLog++ < 5) console.error('tablero: ' + (e && e.stack || e)); } }

/* ---------- el jugador: teclas, mouse, armas, granadas ---------- */
function controlar(dt) {
  const J = M.jugador;
  let vx = (teclas.d ? 1 : 0) - (teclas.a ? 1 : 0), vz = (teclas.s ? 1 : 0) - (teclas.w ? 1 : 0);
  const n = hyp(vx, vz), agach = teclas.c;
  if (n < 0.01 || agach) correr = false;
  const vel = agach ? 3 : correr ? 9.6 : 6.2;
  if (n > 0) { vx = vx / n * vel; vz = vz / n * vel; }
  M.moverJugador(vx, vz, dt, { agach, correr });
  const r = ratonMundo(), dx = r.x - J.x, dz = r.z - J.z;
  if (hyp(dx, dz) > 0.4) P.rumboJ = Math.atan2(dx, dz);
  if (pendiente && M.t - tPend > 0.35) pendiente = false;
  const auto = J.arma === 'uzi' || J.arma === 'fusil';
  if (auto ? gatillo : pendiente) {
    const p = puntoDeTiro(J, r.x, r.z);
    const res = M.dispararJugador(p.x, p.y, p.z);
    if (res) pendiente = false;
    else if (P.limites && J.cargador[J.arma] <= 0 && !(P.res[J.arma] > 0)) { pendiente = false; nota('Sin balas de ' + NOMBRE_ARMA[J.arma].toLowerCase() + '. Cambiá de arma.'); }
  }
}
/* altura del tiro: el mouse elige la dirección; si hay alguien visible sobre esa línea, el tiro va a la altura de su pecho */
function alturaPecho(s) { return (s.y || 0) + (s.postura === 'tierra' ? 0.25 : s.postura === 'agachado' ? 0.85 : 1.3); }
function puntoDeTiro(J, ax, az) {
  let dx = ax - J.x, dz = az - J.z, d = hyp(dx, dz);
  if (d < 0.4) { dx = Math.sin(P.rumboJ); dz = Math.cos(P.rumboJ); d = 1; }
  const ux = dx / d, uz = dz / d;
  let mejor = null, ma = 1e9;
  const prueba = (x, z, y) => { const rx = x - J.x, rz = z - J.z, a = rx * ux + rz * uz; if (a < 0.4 || a > 90) return; const p = Math.abs(rx * uz - rz * ux); if (p < 1.1 + a * 0.025 && a < ma) { ma = a; mejor = y; } };
  for (const s of foto.soldados) if (s.vivo && P.visibles.has(s.id)) prueba(s.x, s.z, alturaPecho(s));
  foto.bichos.forEach((b, i) => { if (P.bichosVis[i]) prueba(b.x, b.z, 0.85); });
  if (mejor !== null) return { x: J.x + ux * ma, y: mejor, z: J.z + uz * ma };
  const dd = Math.max(d, 8); return { x: J.x + ux * dd, y: 1.25, z: J.z + uz * dd };
}
function arma(n) {
  const J = M.jugador;
  if (n === 'fusil' && !P.tieneFusil) { nota('Todavía no tenés el fusil: levantalo de un soldado caído.'); return; }
  if (J.arma !== n) M.armaJugador(n);
}
function granada() {
  const J = M.jugador;
  if (!(J.granadas > 0)) { nota('No tenés granadas: se las sacás a los caídos.'); return; }
  const r = ratonMundo(); let dx = r.x - J.x, dz = r.z - J.z, d = hyp(dx, dz);
  if (d < 0.5) { dx = Math.sin(P.rumboJ); dz = Math.cos(P.rumboJ); d = 1; }
  const ux = dx / d, uz = dz / d;
  for (let L = clamp(d, 4, 28), i = 0; i < 9 && L >= 3; i++, L *= 0.85) if (M.lanzarGranadaJugador(J.x + ux * L, J.z + uz * L)) return;
  nota('No hay por dónde tirarla.');
}
/* reservas del juego: pistola sin límite, escopeta 2 + 10, Uzi 32 + 64, fusil lo que levantes */
function reservas(J) {
  for (const a in J.cargador) {
    const antes = P.carg[a], ahora = J.cargador[a];
    if (ahora > antes && P.res[a] !== Infinity) {
      const da = Math.min(ahora - antes, Math.max(0, P.res[a])); J.cargador[a] = antes + da; P.res[a] -= da;
      if (!(P.res[a] > 0) && J.arma === a && J.recT > 0) { J.recT = 0; J.recargando = false; }
    }
    P.carg[a] = J.cargador[a];
  }
}
/* botín: pasando por encima de un caído se levanta lo que soltó */
function saquear(J) {
  for (const c of P.cuerpos.values()) {
    if (c.vacio || hyp(J.x - c.x, J.z - c.z) > 1.7) continue;
    const m = [];
    if (!P.tieneFusil) { P.tieneFusil = true; J.cargador.fusil = 30; P.carg.fusil = 30; m.push('FUSIL (tecla 4)'); }
    if (c.balas) { P.res.fusil += c.balas; m.push('+' + c.balas + ' balas de fusil'); c.balas = 0; }
    if (c.granadas) { J.granadas += c.granadas; m.push('+' + c.granadas + (c.granadas > 1 ? ' granadas' : ' granada')); c.granadas = 0; }
    if (c.botiquin && J.hp < 100) { J.hp = Math.min(100, J.hp + 35); m.push('botiquín: +35 de salud'); c.botiquin = false; }
    c.vacio = !c.balas && !c.granadas && !c.botiquin;
    if (m.length) { nota(m.join(' · ')); cuentas.saqueos++; }
  }
}

/* ---------- eventos del mundo: efectos, radio, bajas, sonido ---------- */
function procesar(evs) {
  const J = M.jugador;
  for (const e of evs) {
    if (e.tipo === 'bala') {
      const mia = e.de === 'jugador';
      if (mia) { cuentas.balasMias++; if (e.pega === 'soldado' || e.pega === 'bicho') cuentas.aciertos++; } else cuentas.balasSold++;
      P.trazas.push({ ox: e.ox, oz: e.oz, hx: e.hx, hz: e.hz, t: 0, mia, modo: e.modo });
      const clave = (mia ? 'J' : (e.s && e.s.id)) + '@' + e.t.toFixed(3);
      if (clave !== P.fogKey) {
        P.fogKey = clave; P.fogon.push({ x: e.ox, z: e.oz, t: 0, mia });
        SND.disparo(mia ? J.arma : e.arma, mia ? 0 : hyp(e.ox - J.x, e.oz - J.z), mia, mia ? 'J' : 'S' + (e.s ? e.s.id : ''));
      }
      if (e.pega && e.pega !== 'nada') P.chispas.push({ x: e.hx, z: e.hz, t: 0, pega: e.pega, a: Math.atan2(e.ox - e.hx, e.oz - e.hz) });
      if (e.pega === 'jugador' && !mia) { golpe(e.ox, e.oz); cuentas.pegaronJugador++; }
      if (mia) { P.rumboJ = Math.atan2(e.hx - e.ox, e.hz - e.oz); P.tRumbo = M.t; }
    } else if (e.tipo === 'radio') {
      cuentas.radio++;
      const quien = e.s && e.s.nombre ? String(e.s.nombre).toUpperCase() : 'RADIO', pel = PELIGRO.has(e.clave);
      P.radio.push({ quien, texto: e.texto, pel, t: M.t }); if (P.radio.length > 3) P.radio.shift();
      radioDom(); SND.radio((e.s && e.s.voz) || (e.s && e.s.num) || 0, String(e.texto).length, pel);
    } else if (e.tipo === 'herida') {
      if (e.a === 'jugador') {
        P.golpe = e.fuente || P.golpe; P.rojo = Math.min(1, P.rojo + 0.25 + (e.dano || 0) / 60);
        if (e.fuente === 'granada' && P.ultExplo) golpe(P.ultExplo.x, P.ultExplo.z);
        else if (e.fuente === 'culata' && e.s) golpe(e.s.x, e.s.z);
      }
    } else if (e.tipo === 'granada') {
      cuentas.granadas++;
    } else if (e.tipo === 'explosion') {
      cuentas.explosiones++;
      P.ultExplo = e; P.explos.push({ x: e.x, z: e.z, r: e.r || 7, t: 0 }); P.marcas.push({ x: e.x, z: e.z, t: 0 });
      SND.explosion(hyp(e.x - J.x, e.z - J.z));
    } else if (e.tipo === 'evento') {
      if (e.nombre === 'baja' && e.datos && e.datos.s) baja(e.datos);
    }
  }
}
function baja(d) {
  const s = d.s; cuentas.bajas++;
  const mia = d.de === 'jugador' || (d.de === 'granada' && P.ultExplo && P.ultExplo.de === 'jugador');
  if (mia) { P.bajas++; cuentas.bajasMias++; }
  if (!P.cuerpos.has(s.id)) P.cuerpos.set(s.id, { id: s.id, x: s.x, z: s.z, balas: 20 + 5 * Math.floor(Math.random() * 3),
    granadas: s.rol === 'granadero' ? 2 : (Math.random() < 0.4 ? 1 : 0), botiquin: Math.random() < 0.3, vacio: false });
}
function golpe(x, z) { const J = M.jugador; P.golpes.push({ a: Math.atan2(x - J.x, z - J.z), t: 0 }); if (P.golpes.length > 6) P.golpes.shift(); }
function envejecer(dt) {
  const viejos = (arr, vida) => { let w = 0; for (let i = 0; i < arr.length; i++) { arr[i].t += dt; if (arr[i].t < vida) arr[w++] = arr[i]; } arr.length = w; };
  viejos(P.trazas, 0.08); viejos(P.fogon, 0.06); viejos(P.chispas, 0.16); viejos(P.explos, 0.8); viejos(P.marcas, 40); viejos(P.golpes, 1.4);
  P.rojo = Math.max(0, P.rojo - dt * 1.6);
}
function revisarFin() {
  if (modo === 'reposo' || fin) return;
  const J = M.jugador;
  if (!J.vivo) { if (P.tMuerte === null) P.tMuerte = M.t; if (M.t - P.tMuerte > 2.2) terminar('muerte'); return; }
  const e = UE.estado();
  if (e.quedan === 0 && e.refuerzo !== 'pedido') { if (P.tomadoEn === null) P.tomadoEn = M.t; if (M.t - P.tomadoEn > 1.5) terminar('tomado'); }
  else P.tomadoEn = null;
}
function terminar(tipo) {
  fin = { tipo, t: M.t }; gatillo = pendiente = false;
  const n = P.bajas, auto = modo === 'mirar', sold = n === 1 ? 'soldado' : 'soldados';
  $('finK').textContent = auto ? 'EL JUGADOR AUTOMÁTICO' : tipo === 'muerte' ? 'FIN DE LA PARTIDA' : 'GANASTE';
  const h = $('finT'); h.textContent = tipo === 'muerte' ? 'Testigo eliminado' : 'Retén tomado'; h.className = tipo === 'muerte' ? 'malo' : 'bueno';
  $('finP').textContent = tipo === 'muerte'
    ? (auto ? 'Duró ' : 'Duraste ') + reloj(P.tMuerte) + (auto ? ' y bajó ' : ' y bajaste ') + n + ' ' + sold + '.' + (P.golpe && FUENTE[P.golpe] ? ' Último golpe: ' + FUENTE[P.golpe] + '.' : '')
    : 'No quedó ninguno, refuerzo incluido. ' + (auto ? 'Bajó ' : 'Bajaste ') + n + ' ' + sold + ' en ' + reloj(M.t) + '.';
  $('finV').hidden = false; stage.classList.remove('vivo'); P.nota = ''; ver(H.nota, false);
}

/* =====================================================================================================
   VISTA: cámara, línea de visión y dibujo
   ===================================================================================================== */
function medir() {
  dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = Math.max(1, Math.round(cv.clientWidth * dpr)), h = Math.max(1, Math.round(cv.clientHeight * dpr));
  if (w !== cw || h !== ch) { cw = cv.width = w; ch = cv.height = h; sucio = true; vineta = null; }
}
function fijarCamara() {
  const base = cv.clientWidth < 700 ? 7 : 10;
  PPD = Math.max(3, Math.round(base * zoom * dpr));
  const mw = cw / 2 / PPD, mh = ch / 2 / PPD;
  const cx = MW > 2 * mw ? clamp(cam.x, MX0 + mw - 2, MX0 + MW - mw + 2) : MX0 + MW / 2;
  const cz = MH > 2 * mh ? clamp(cam.z, MZ0 + mh - 2, MZ0 + MH - mh + 2) : MZ0 + MH / 2;
  ox = Math.round(cw / 2 - cx * PPD); oz = Math.round(ch / 2 - cz * PPD);
}
function ratonMundo() { return { x: (raton.sx * dpr - ox) / PPD, z: (raton.sy * dpr - oz) / PPD }; }
function camara(dtR, salto) {
  const J = M.jugador; let tx = J.x, tz = J.z;
  if (modo === 'reposo') { tx = CAM_REPOSO.x; tz = CAM_REPOSO.z + ch / PPD * (cv.clientWidth < 700 ? 0.21 : 0.15); }    // el retén arriba del velo
  else if (modo === 'juego') {
    const base = (cv.clientWidth < 700 ? 7 : 10) * zoom;
    tx += clamp((raton.sx - cv.clientWidth / 2) / base, -60, 60) * 0.32; tz += clamp((raton.sy - cv.clientHeight / 2) / base, -40, 40) * 0.32;
  } else { tx += Math.sin(P.rumboJ) * 5; tz += Math.cos(P.rumboJ) * 5; }
  const k = salto ? 1 : Math.min(1, dtR * 4.5);
  cam.x += (tx - cam.x) * k; cam.z += (tz - cam.z) * k;
}
function calcVista(J) {
  const oy = J.ojoY || 1.62;
  for (let i = 0; i < NRAYOS; i++) {
    const a = (i + 0.5) / NRAYOS * TAU, t = M.rayo(J.x, oy, J.z, Math.sin(a), 0, Math.cos(a), RVIS);
    rayos[i] = t < RVIS ? Math.max(0.3, t) : RVIS;
  }
  P.visibles.clear();
  for (const s of foto.soldados) {
    if (hyp(s.x - J.x, s.z - J.z) > RVIS) continue;
    const alto = s.vivo ? (s.postura === 'tierra' ? 0.35 : s.postura === 'agachado' ? 1.0 : 1.55) : 0.3;
    if (M.lv(J.x, oy, J.z, s.x, (s.y || 0) + alto, s.z) || M.lv(J.x, oy, J.z, s.x, (s.y || 0) + alto * 0.5, s.z)) { P.visibles.add(s.id); if (!s.vivo) P.vistos.add(s.id); }
  }
  P.bichosVis = foto.bichos.map(b => hyp(b.x - J.x, b.z - J.z) <= RVIS && M.lv(J.x, oy, J.z, b.x, 0.9, b.z));
}
const enVista = (x, z, m) => { const X = sx(x), Y = sy(z), r = (m || 3) * PPD; return X > -r && Y > -r && X < cw + r && Y < ch + r; };
const angP = r => Math.atan2(Math.cos(r), Math.sin(r));                     // rumbo del juego → ángulo del canvas
const fichaR = () => Math.max(0.55 * PPD, 9.5 * dpr);
const parpadea = (id, per, on) => ((M.t + id * 0.37) % per) < on;

function dibujar() {
  fijarCamara();
  const g = ctx, J = M.jugador;
  g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1;
  g.fillStyle = K.fondo; g.fillRect(0, 0, cw, ch);
  g.imageSmoothingEnabled = false; g.drawImage(BASE.cnv, sx(MX0), sy(MZ0), MW * PPD, MH * PPD); g.imageSmoothingEnabled = true;
  lineas(BASE.cordon, K.cordon, 1); lineas(BASE.edif, K.borde, 1);
  dibBocas(); dibMarcas(); dibAutos(); dibReten();
  const niebla = modo !== 'reposo';
  if (niebla) { calcVista(J); dibNiebla(J); }
  dibRotulos();
  dibCaidos(niebla); dibBichos(niebla); dibSoldados(niebla);
  g.globalCompositeOperation = 'lighter'; dibLuces(J); g.globalCompositeOperation = 'source-over';
  dibGranadas(J);
  if (verSaben) dibSaben();
  dibJugador(J);
  if (modo !== 'reposo' && J.vivo) dibAlrededor(J);
  if (modo === 'juego' && !fin && !pausa) dibMira(J);
  dibVineta();
}
function lineas(arr, color, ancho) {
  const g = ctx, w = Math.max(1, Math.round(ancho * dpr)), o = w % 2 ? 0.5 : 0;
  g.strokeStyle = color; g.lineWidth = w; g.beginPath();
  const x0 = -ox / PPD - 1, x1 = (cw - ox) / PPD + 1, z0 = -oz / PPD - 1, z1 = (ch - oz) / PPD + 1;
  for (let i = 0; i < arr.length; i += 4) {
    const a = arr[i], b = arr[i + 1], c = arr[i + 2], d = arr[i + 3];
    if (Math.max(a, c) < x0 || Math.min(a, c) > x1 || Math.max(b, d) < z0 || Math.min(b, d) > z1) continue;
    g.moveTo(sx(a) + o, sy(b) + o); g.lineTo(sx(c) + o, sy(d) + o);
  }
  g.stroke();
}
function caminoRect(x, z, a, L, W) {
  const ux = Math.sin(a), uz = Math.cos(a), vx = uz, vz = -ux, hl = L / 2, hw = W / 2, g = ctx;
  g.beginPath();
  g.moveTo(sx(x + ux * hl + vx * hw), sy(z + uz * hl + vz * hw)); g.lineTo(sx(x + ux * hl - vx * hw), sy(z + uz * hl - vz * hw));
  g.lineTo(sx(x - ux * hl - vx * hw), sy(z - uz * hl - vz * hw)); g.lineTo(sx(x - ux * hl + vx * hw), sy(z - uz * hl + vz * hw)); g.closePath();
}
function dibAuto(x, z, a, L, W, id) {
  if (!enVista(x, z, L)) return;
  const g = ctx;
  caminoRect(x, z, a, L, W); g.fillStyle = id === 'taxi' ? K.taxi : K.auto; g.fill();
  g.strokeStyle = K.borde; g.lineWidth = Math.max(1, dpr); g.stroke();
  const largo = id === 'furgon' || id === 'ambulancia' || id === 'pickup' ? 0.72 : 0.48;
  caminoRect(x - Math.sin(a) * L * 0.04, z - Math.cos(a) * L * 0.04, a, L * largo, W * 0.8); g.fillStyle = K.techo; g.fill();
}
function dibAutos() { for (const c of MAPA.cars) dibAuto(c.x, c.z, c.a, c.L, c.W, c.id); }
function dibReten() {
  const g = ctx;
  for (const r of M.reten) {
    if (!enVista((r.x0 + r.x1) / 2, (r.z0 + r.z1) / 2, 8)) continue;
    const X0 = sx(r.x0), Z0 = sy(r.z0), w = (r.x1 - r.x0) * PPD, h = (r.z1 - r.z0) * PPD;
    if (r.tipo === 'auto') { dibAuto((r.x0 + r.x1) / 2, (r.z0 + r.z1) / 2, PI / 2, r.x1 - r.x0, r.z1 - r.z0, 'sedan'); continue; }
    if (r.tipo === 'valla') {
      g.fillStyle = rgba('valla', 0.85); g.fillRect(X0, Z0, Math.max(w, 2 * dpr), h);
      g.fillStyle = rgba('raya', 0.9); for (let z = r.z0 + 0.25; z < r.z1; z += 0.6) g.fillRect(X0, sy(z), Math.max(w, 2 * dpr), Math.max(1, 0.25 * PPD));
      continue;
    }
    g.fillStyle = K.furgon; g.fillRect(X0, Z0, w, h);
    g.strokeStyle = K.fbord; g.lineWidth = Math.max(1, 1.5 * dpr); g.strokeRect(X0 + 0.5, Z0 + 0.5, w - 1, h - 1);
    g.strokeStyle = rgba('linea', 0.5); g.lineWidth = Math.max(1, dpr); g.beginPath();
    if (r.tipo === 'furgon') { for (let z = r.z0 + 1.2; z < r.z1 - 0.8; z += 1.2) { g.moveTo(X0 + 0.25 * PPD, sy(z)); g.lineTo(X0 + w - 0.25 * PPD, sy(z)); } }
    else { g.moveTo(X0 + w * 0.3, Z0 + 0.3 * PPD); g.lineTo(X0 + w * 0.3, Z0 + h - 0.3 * PPD); }
    g.stroke();
  }
}
function dibBocas() {
  const g = ctx;
  for (const b of BASE.bocas) {
    if (!enVista(b.x, b.z, 8)) continue;
    g.strokeStyle = rgba('subte', 0.35); g.lineWidth = Math.max(1, dpr); g.beginPath();
    const largoX = (b.x1 - b.x0) >= (b.z1 - b.z0);
    if (largoX) for (let x = b.x0 + 0.5; x < b.x1; x += 0.6) { g.moveTo(sx(x), sy(b.z0) + 1); g.lineTo(sx(x), sy(b.z1) - 1); }
    else for (let z = b.z0 + 0.5; z < b.z1; z += 0.6) { g.moveTo(sx(b.x0) + 1, sy(z)); g.lineTo(sx(b.x1) - 1, sy(z)); }
    g.stroke();
  }
}
function dibMarcas() {
  const g = ctx;
  for (const m of P.marcas) {
    if (!enVista(m.x, m.z, 4)) continue;
    const a = 0.55 * (1 - m.t / 40), gr = g.createRadialGradient(sx(m.x), sy(m.z), 0, sx(m.x), sy(m.z), 3 * PPD);
    gr.addColorStop(0, rgba('sombra', a)); gr.addColorStop(1, rgba('sombra', 0)); g.fillStyle = gr; g.beginPath(); g.arc(sx(m.x), sy(m.z), 3 * PPD, 0, TAU); g.fill();
  }
}
function dibNiebla(J) {
  const g = ctx, X = sx(J.x), Y = sy(J.z);
  g.beginPath(); g.rect(0, 0, cw, ch);
  for (let i = 0; i < NRAYOS; i++) { const a = (i + 0.5) / NRAYOS * TAU, t = rayos[i]; const px = sx(J.x + Math.sin(a) * t), py = sy(J.z + Math.cos(a) * t); if (i) g.lineTo(px, py); else g.moveTo(px, py); }
  g.closePath(); g.fillStyle = rgba('niebla', 0.74); g.fill('evenodd');
  g.beginPath();
  for (let i = 0; i < NRAYOS; i++) { const a = (i + 0.5) / NRAYOS * TAU, t = rayos[i]; const px = sx(J.x + Math.sin(a) * t), py = sy(J.z + Math.cos(a) * t); if (i) g.lineTo(px, py); else g.moveTo(px, py); }
  g.closePath();
  const gr = g.createRadialGradient(X, Y, RVIS * PPD * 0.5, X, Y, RVIS * PPD);
  gr.addColorStop(0, rgba('niebla', 0)); gr.addColorStop(1, rgba('niebla', 0.7)); g.fillStyle = gr; g.fill();
}
function dibRotulos() {
  const g = ctx, f = Math.round(10.5 * dpr);
  g.font = '500 ' + f + 'px ' + FUENTE_MONO; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = rgba('texto', 0.9);
  if ('letterSpacing' in g) g.letterSpacing = Math.round(2 * dpr) + 'px';
  for (const r of ROTULOS) {
    if (!enVista(r.x, r.z, 30)) continue;
    if (r.v) { g.save(); g.translate(sx(r.x), sy(r.z)); g.rotate(-PI / 2); g.fillText(r.t, 0, 0); g.restore(); } else g.fillText(r.t, sx(r.x), sy(r.z));
  }
  for (const b of BASE.bocas) if (enVista(b.x, b.z, 10)) { g.fillStyle = rgba('subte', 0.75); g.fillText('SUBTE', sx((b.x0 + b.x1) / 2), sy(b.z1) + f); }
  if ('letterSpacing' in g) g.letterSpacing = '0px';
}
function dibCaidos(niebla) {
  const g = ctx;
  for (const s of foto.soldados) {
    if (s.vivo) continue;
    const seVe = !niebla || verSaben || P.visibles.has(s.id), recuerdo = P.vistos.has(s.id);
    if (!seVe && !recuerdo) continue;
    if (!enVista(s.x, s.z, 4)) continue;
    const r = fichaR(), X = sx(s.x), Y = sy(s.z), fx = Math.sin(s.rumbo), fy = Math.cos(s.rumbo);
    g.globalAlpha = seVe ? 1 : 0.55;
    g.fillStyle = rgba('sangre', 0.75); g.beginPath(); g.ellipse(X - fx * r * 0.3, Y - fy * r * 0.3, r * 1.25, r * 0.95, angP(s.rumbo), 0, TAU); g.fill();
    capsula(X, Y, fx, fy, r * 1.5, r * 0.55); g.fillStyle = K.caido; g.fill(); g.strokeStyle = rgba('cold', 0.3); g.lineWidth = Math.max(1, dpr); g.stroke();
    g.fillStyle = rgba('cold', 0.45); g.font = '700 ' + Math.round(r * 0.95) + 'px ' + FUENTE_HUD; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(LETRA[s.rol] || '?', X, Y + r * 0.05);
    const c = P.cuerpos.get(s.id);
    if (modo === 'juego' && c && !c.vacio) {
      const d = r * 0.5, y = Y - r * 1.5 - (reduce.matches ? 0 : Math.sin(M.t * 4) * dpr * 1.5);
      g.fillStyle = K.acc; g.beginPath(); g.moveTo(X, y - d); g.lineTo(X + d, y); g.lineTo(X, y + d); g.lineTo(X - d, y); g.closePath(); g.fill();
    }
    g.globalAlpha = 1;
  }
}
function capsula(X, Y, fx, fy, L, R) {
  const g = ctx, a = Math.atan2(fy, fx);
  g.beginPath(); g.arc(X + fx * L / 2, Y + fy * L / 2, R, a - PI / 2, a + PI / 2); g.arc(X - fx * L / 2, Y - fy * L / 2, R, a + PI / 2, a + PI * 1.5); g.closePath();
}
function dibBichos(niebla) {
  const g = ctx;
  foto.bichos.forEach((b, i) => {
    if (niebla && !verSaben && !P.bichosVis[i]) return;
    if (!enVista(b.x, b.z, 3)) return;
    const X = sx(b.x), Y = sy(b.z), r = Math.max(0.55 * PPD, 6 * dpr), w = reduce.matches ? 0 : M.t * 9 + i;
    g.fillStyle = rgba('bicho', 0.22); g.beginPath(); g.arc(X, Y, r * 1.7, 0, TAU); g.fill();
    g.fillStyle = rgba('bicho', 0.85);
    for (let q = 0; q < 3; q++) { const a = q * 2.1 + w * 0.35; g.beginPath(); g.arc(X + Math.cos(a) * r * 0.35, Y + Math.sin(a) * r * 0.35, r * (0.62 + 0.08 * Math.sin(w + q)), 0, TAU); g.fill(); }
    g.fillStyle = rgba('nucleo', 0.9); g.beginPath(); g.arc(X, Y, r * 0.3, 0, TAU); g.fill();
  });
}
function dibSoldados(niebla) {
  for (const s of foto.soldados) {
    if (!s.vivo) continue;
    const ve = !niebla || P.visibles.has(s.id);
    if (!ve && !verSaben) continue;
    if (!enVista(s.x, s.z, 3)) continue;
    dibSoldado(s, !ve);
  }
}
function dibSoldado(s, fantasma) {
  const g = ctx, X = sx(s.x), Y = sy(s.z), r = fichaR(), fx = Math.sin(s.rumbo), fy = Math.cos(s.rumbo), px = -fy, py = fx;
  g.save(); if (fantasma) { g.globalAlpha = 0.6; g.setLineDash([3 * dpr, 2 * dpr]); }
  const largo = s.rol === 'tirador' ? 2.5 : s.rol === 'asalto' ? 1.65 : 2.0;
  const pie = s.postura === 'pie', tierra = s.postura === 'tierra';
  g.strokeStyle = K.arma; g.lineWidth = Math.max(1.5, r * 0.26); g.lineCap = 'round';
  g.beginPath(); g.moveTo(X + px * r * 0.3, Y + py * r * 0.3); g.lineTo(X + px * r * 0.3 + fx * r * largo, Y + py * r * 0.3 + fy * r * largo); g.stroke();
  g.fillStyle = K.soldado; g.strokeStyle = K.cold; g.lineWidth = Math.max(1, r * 0.17);
  if (tierra) capsula(X - fx * r * 0.6, Y - fy * r * 0.6, fx, fy, r * 1.6, r * 0.62);
  else if (!pie) { const q = r * 0.86; g.beginPath(); g.moveTo(X + fx * q, Y + fy * q); g.lineTo(X + px * q, Y + py * q); g.lineTo(X - fx * q, Y - fy * q); g.lineTo(X - px * q, Y - py * q); g.closePath(); }
  else { g.beginPath(); g.arc(X, Y, r, 0, TAU); }
  g.fill(); g.stroke(); g.setLineDash([]);
  const rl = tierra ? r * 0.62 : pie ? r : r * 0.7;                        // lentes de la máscara (brillo frío) y luz roja de la nuca
  g.fillStyle = rgba('lente', 0.95);
  for (const sg of [-1, 1]) { g.beginPath(); g.arc(X + fx * rl * 0.78 + px * sg * rl * 0.38, Y + fy * rl * 0.78 + py * sg * rl * 0.38, Math.max(1, 1.1 * dpr), 0, TAU); g.fill(); }
  if (parpadea(s.id, 1.2, 0.16)) { const bx = tierra ? X - fx * r * 0.1 : X - fx * rl * 0.86, by = tierra ? Y - fy * r * 0.1 : Y - fy * rl * 0.86; g.fillStyle = K.laser; g.beginPath(); g.arc(bx, by, Math.max(1.2, 1.4 * dpr), 0, TAU); g.fill(); }
  g.fillStyle = K.cold; g.font = '700 ' + Math.round(r * (pie ? 1.05 : 0.95)) + 'px ' + FUENTE_HUD; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(LETRA[s.rol] || '?', tierra ? X - fx * r * 0.6 : X, (tierra ? Y - fy * r * 0.6 : Y) + r * 0.06);
  g.restore();
}
function dibJugador(J) {
  if (modo === 'reposo') return;
  const g = ctx, X = sx(J.x), Y = sy(J.z), r = fichaR(), fx = Math.sin(P.rumboJ), fy = Math.cos(P.rumboJ), px = -fy, py = fx;
  if (!J.vivo) { capsula(X, Y, fx, fy, r * 1.5, r * 0.55); g.fillStyle = rgba('yo', 0.35); g.fill(); return; }
  if (J.corriendo && !reduce.matches) {
    const v = hyp(J.vx, J.vz) || 1;
    for (let q = 1; q <= 3; q++) { g.fillStyle = rgba('yo', 0.12 / q); g.beginPath(); g.arc(X - J.vx / v * r * 0.9 * q, Y - J.vz / v * r * 0.9 * q, r * 0.85, 0, TAU); g.fill(); }
  }
  const rr = J.agach ? r * 0.78 : r;
  g.strokeStyle = rgba('yo', 0.32); g.lineWidth = Math.max(1, 1.5 * dpr); g.beginPath(); g.arc(X, Y, rr + 4 * dpr, 0, TAU); g.stroke();
  g.strokeStyle = K.ink; g.lineWidth = Math.max(1.5, r * 0.26); g.lineCap = 'round';
  g.beginPath(); g.moveTo(X + px * rr * 0.3, Y + py * rr * 0.3); g.lineTo(X + px * rr * 0.3 + fx * r * 1.7, Y + py * rr * 0.3 + fy * r * 1.7); g.stroke();
  g.beginPath(); g.arc(X, Y, rr, 0, TAU);
  g.fillStyle = K.yo; g.fill(); g.strokeStyle = K.bg; g.lineWidth = Math.max(1, 1.5 * dpr); g.stroke();
  g.fillStyle = K.bg; g.beginPath(); g.arc(X + fx * rr * 0.5, Y + fy * rr * 0.5, rr * 0.28, 0, TAU); g.fill();
  if (J.agach) { g.strokeStyle = K.bg; g.lineWidth = Math.max(1, dpr); g.beginPath(); g.arc(X, Y, rr * 0.62, 0, TAU); g.stroke(); }
}
/* ---------- luces: se ven siempre, aunque no veas a quien las lleva ---------- */
function haz(x, z, rumbo, largo, abre, k, alfa, y) {
  const g = ctx, X = sx(x), Y = sy(z), N = 12, pts = [];
  for (let i = 0; i <= N; i++) {
    const a = rumbo - abre + 2 * abre * i / N, dx = Math.sin(a), dz = Math.cos(a);
    const t = Math.min(largo, M.rayo(x, y, z, dx, 0, dz, largo)); pts.push(sx(x + dx * t), sy(z + dz * t));
  }
  const gr = g.createRadialGradient(X, Y, 0, X, Y, largo * PPD);
  gr.addColorStop(0, rgba(k, 0)); gr.addColorStop(0.12, rgba(k, 0)); gr.addColorStop(0.3, rgba(k, alfa)); gr.addColorStop(1, rgba(k, 0));
  g.fillStyle = gr; g.beginPath(); g.moveTo(X, Y); for (let i = 0; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]); g.closePath(); g.fill();
}
function brillo(X, Y, R, k, a) { const g = ctx, gr = g.createRadialGradient(X, Y, 0, X, Y, R); gr.addColorStop(0, rgba(k, a)); gr.addColorStop(1, rgba(k, 0)); g.fillStyle = gr; g.beginPath(); g.arc(X, Y, R, 0, TAU); g.fill(); }
function dibLuces(J) {
  const g = ctx;
  if (LUZ) { g.globalAlpha = 0.34; g.drawImage(LUZ.c, sx(LUZ.x0), sy(LUZ.z0), LUZ.w * PPD, LUZ.h * PPD); g.globalAlpha = 1; }
  for (const b of BASE.bocas) if (enVista(b.x, b.z, 8)) brillo(sx((b.x0 + b.x1) / 2), sy((b.z0 + b.z1) / 2), 5 * PPD, 'subte', 0.07 + (reduce.matches ? 0 : 0.02 * Math.sin(M.t * 7 + b.x)));
  for (const s of foto.soldados) if (s.vivo && s.luz && enVista(s.x, s.z, 18)) haz(s.x, s.z, s.rumbo, 16, 0.3, 'mia', 0.2, (s.y || 0) + 1.1);
  if (modo !== 'reposo' && J.vivo && J.linterna) haz(J.x, J.z, P.rumboJ, 18, 0.32, 'mia', 0.2, 1.2);
  for (const l of foto.laseres) {                                           // láser del tirador: se apaga cerca del arma
    const X0 = sx(l.ox), Y0 = sy(l.oz), X1 = sx(l.x), Y1 = sy(l.z), L = hyp(l.x - l.ox, l.z - l.oz) || 1;
    const gr = g.createLinearGradient(X0, Y0, X1, Y1); gr.addColorStop(0, rgba('laser', 0)); gr.addColorStop(Math.min(0.9, 4 / L), rgba('laser', 0.8)); gr.addColorStop(1, rgba('laser', 0.95));
    g.strokeStyle = gr; g.lineWidth = Math.max(1, 1.2 * dpr); g.beginPath(); g.moveTo(X0, Y0); g.lineTo(X1, Y1); g.stroke();
    brillo(X1, Y1, Math.max(5 * dpr, 0.5 * PPD), 'laser', 0.9);
  }
  for (const f of P.fogon) brillo(sx(f.x), sy(f.z), Math.max(10 * dpr, 2.4 * PPD) * (1 - f.t / 0.06 * 0.4), f.mia ? 'mia' : 'traza', 0.75 * (1 - f.t / 0.06));
  g.lineCap = 'round';
  for (const t of P.trazas) {
    const a = 1 - t.t / 0.08, deb = verSaben && !t.mia;
    g.strokeStyle = deb ? (t.modo === 'pegar' ? rgba('warn', a) : t.modo === 'aviso' ? rgba('cold', a * 0.9) : rgba('acc', a * 0.8)) : rgba(t.mia ? 'mia' : 'traza', a * 0.85);
    g.lineWidth = Math.max(1, (t.mia ? 1.2 : 1.5) * dpr); g.beginPath(); g.moveTo(sx(t.ox), sy(t.oz)); g.lineTo(sx(t.hx), sy(t.hz)); g.stroke();
  }
  for (const c of P.chispas) {
    const a = 1 - c.t / 0.16, X = sx(c.x), Y = sy(c.z), L = (0.25 + c.t * 3) * PPD, k = c.pega === 'jugador' ? 'warn' : c.pega === 'bicho' ? 'bicho' : c.pega === 'soldado' ? 'laser' : 'traza';
    g.strokeStyle = rgba(k, a); g.lineWidth = Math.max(1, dpr); g.beginPath();
    for (let q = -2; q <= 2; q++) { const an = angP(c.a) + q * 0.5; g.moveTo(X, Y); g.lineTo(X + Math.cos(an) * L, Y + Math.sin(an) * L); }
    g.stroke();
  }
  for (const e of P.explos) {
    const k = e.t / 0.8, X = sx(e.x), Y = sy(e.z);
    brillo(X, Y, e.r * PPD * (0.5 + 0.7 * k), 'luz', 0.9 * (1 - k));
    if (k < 0.25) brillo(X, Y, e.r * PPD * 0.4, 'mia', 1 - k * 4);
  }
  for (const gr of foto.granadas) {
    const per = gr.t < 1 ? 0.12 : 0.3;
    if ((gr.t % per) < per * 0.5 || reduce.matches) brillo(sx(gr.x), sy(gr.z), Math.max(9 * dpr, 1.1 * PPD), 'laser', 0.85);
  }
}
function dibGranadas(J) {
  const g = ctx;
  for (const gr of foto.granadas) {
    const X = sx(gr.x), Y = sy(gr.z);
    g.fillStyle = K.granada; g.strokeStyle = K.laser; g.lineWidth = Math.max(1, dpr); g.beginPath(); g.arc(X, Y, Math.max(3 * dpr, 0.25 * PPD), 0, TAU); g.fill(); g.stroke();
    if (modo === 'reposo' || hyp(gr.x - J.x, gr.z - J.z) > 12) continue;
    g.setLineDash([5 * dpr, 4 * dpr]); g.strokeStyle = rgba('warn', 0.75); g.lineWidth = Math.max(1, 1.5 * dpr);
    g.beginPath(); g.arc(X, Y, 7 * PPD, 0, TAU); g.stroke(); g.setLineDash([]);
    g.fillStyle = rgba('warn', 0.07); g.fill();
    etiqueta(coma(Math.max(0, gr.t)) + ' s', X, Y - Math.max(12 * dpr, 1.2 * PPD), K.warn, 12);
  }
}
/* dos renglones (nombre y estado) en el primer lugar libre alrededor del soldado */
function etiqueta2(l1, c1, l2, c2, X, Y, r, ocupados) {
  const g = ctx, f = Math.round(10.5 * dpr), pad = 3 * dpr;
  g.font = '500 ' + f + 'px ' + FUENTE_MONO;
  const w = Math.max(g.measureText(l1).width, g.measureText(l2).width) + 2 * pad, h = f * 2.5, m = 6 * dpr;
  const cand = [[X + r + m, Y - h / 2], [X - r - m - w, Y - h / 2], [X - w / 2, Y + r + m], [X - w / 2, Y - r - m - h], [X + r + m, Y + r], [X - r - m - w, Y - r - h]];
  const adentro = (cx, cy) => cx >= 2 && cy >= 2 && cx + w <= cw - 2 && cy + h <= ch - 2;
  let x = clamp(cand[0][0], 2, Math.max(2, cw - w - 2)), y = clamp(cand[0][1], 2, Math.max(2, ch - h - 2));
  for (const [cx, cy] of cand) { if (adentro(cx, cy) && !ocupados.some(o => cx < o[0] + o[2] + 2 && cx + w + 2 > o[0] && cy < o[1] + o[3] + 2 && cy + h + 2 > o[1])) { x = cx; y = cy; break; } }
  ocupados.push([x, y, w, h]);
  g.fillStyle = rgba('etiq', 0.84); g.fillRect(x, y, w, h);
  g.textAlign = 'left'; g.textBaseline = 'middle';
  g.fillStyle = c1; g.fillText(l1, x + pad, y + h * 0.28); g.fillStyle = c2; g.fillText(l2, x + pad, y + h * 0.72);
}
function etiqueta(txt, X, Y, color, tam, izq) {
  const g = ctx, f = Math.round(tam * dpr);
  g.font = '500 ' + f + 'px ' + FUENTE_MONO; g.textAlign = izq ? 'left' : 'center'; g.textBaseline = 'middle';
  const w = g.measureText(txt).width, x0 = izq ? X : X - w / 2;
  g.fillStyle = rgba('etiq', 0.82); g.fillRect(x0 - 3 * dpr, Y - f * 0.62, w + 6 * dpr, f * 1.24);
  g.fillStyle = color; g.fillText(txt, X, Y + dpr * 0.5);
}
/* ---------- «Ver lo que saben»: último lugar conocido, fichas, caminos, coberturas y estado de cada uno ---------- */
function dibSaben() {
  const g = ctx, ocupados = [], estEsc = {};
  for (const e of foto.escuadrones) estEsc[e.nombre] = e.estado;
  for (const e of foto.escuadrones) {
    if (!e.uc) continue;
    const X = sx(e.uc.x), Y = sy(e.uc.z), d = Math.max(7 * dpr, 0.7 * PPD);
    if (e.uc.err > 0.6) { g.strokeStyle = rgba('saben', 0.35); g.lineWidth = Math.max(1, dpr); g.beginPath(); g.arc(X, Y, e.uc.err * PPD, 0, TAU); g.stroke(); }
    g.strokeStyle = K.saben; g.lineWidth = Math.max(2, 2.5 * dpr); g.lineCap = 'round';
    g.beginPath(); g.moveTo(X - d, Y - d); g.lineTo(X + d, Y + d); g.moveTo(X + d, Y - d); g.lineTo(X - d, Y + d); g.stroke();
    const lt = e.nombre.toUpperCase() + ' · ' + (e.uc.tipo === 'oido' ? 'te oyó' : 'te vio') + ' hace ' + coma(e.uc.edad) + ' s';
    etiqueta(lt, X, Y + d + 11 * dpr, K.saben, 11);
    g.font = '500 ' + Math.round(11 * dpr) + 'px ' + FUENTE_MONO; const wl = g.measureText(lt).width;
    ocupados.push([X - wl / 2 - 4 * dpr, Y - d, wl + 8 * dpr, 2 * d + 20 * dpr]);
  }
  for (const s of foto.soldados) {
    if (!s.vivo) continue;
    const X = sx(s.x), Y = sy(s.z), r = fichaR();
    if (s.camino && s.camino.length) {
      g.strokeStyle = rgba('camino', 0.6); g.lineWidth = Math.max(1, 1.3 * dpr); g.setLineDash([4 * dpr, 4 * dpr]);
      g.beginPath(); g.moveTo(X, Y); for (const p of s.camino) g.lineTo(sx(p.x), sy(p.z)); g.stroke(); g.setLineDash([]);
    }
    if (s.cob) { const q = Math.max(4 * dpr, 0.45 * PPD); g.strokeStyle = rgba('camino', 0.85); g.lineWidth = Math.max(1, 1.3 * dpr); g.strokeRect(sx(s.cob.x) - q, sy(s.cob.z) - q, 2 * q, 2 * q); }
    if (s.ficha) { g.strokeStyle = K.warn; g.lineWidth = Math.max(2, 2.2 * dpr); g.beginPath(); g.arc(X, Y, r + 4.5 * dpr, 0, TAU); g.stroke(); }
    let txt = EST_SOL[s.estado] || s.estado || '';
    const ta = TAREA[s.tarea]; if (ta && txt.indexOf(ta) < 0 && s.tarea !== 'guardia') txt += ' · ' + ta;
    if (s.ve) txt += ' · te ve'; else if (s.sosp > 0.05 && s.sosp < 1 && estEsc[s.esc] !== 'combate') txt += ' · sospecha ' + Math.round(s.sosp * 100) + ' %';
    etiqueta2(s.nombre, K.ink, txt, s.ve ? K.saben : K.cold, X, Y, r, ocupados);
  }
}
/* ---------- alrededor del jugador: de dónde le pegan y desde dónde lo están viendo ---------- */
function dibAlrededor(J) {
  const g = ctx, X = sx(J.x), Y = sy(J.z), R = Math.max(2.6 * PPD, 26 * dpr);
  for (const h of P.golpes) {
    const a = angP(h.a), k = 1 - h.t / 1.4;
    g.strokeStyle = rgba('warn', 0.9 * k); g.lineWidth = Math.max(3, 4 * dpr); g.lineCap = 'butt';
    g.beginPath(); g.arc(X, Y, R, a - 0.42, a + 0.42); g.stroke();
  }
  if (est && est.sospecha > 0.02) {
    const a = angP(Math.atan2(est.x - J.x, est.z - J.z)), r0 = R + 7 * dpr, r1 = R + 17 * dpr, w = 0.16, k = est.combate ? 'warn' : 'acc';
    g.fillStyle = rgba(k, Math.max(0.4, Math.min(1, est.sospecha)));
    g.beginPath(); g.moveTo(X + Math.cos(a) * r1, Y + Math.sin(a) * r1); g.lineTo(X + Math.cos(a - w) * r0, Y + Math.sin(a - w) * r0); g.lineTo(X + Math.cos(a + w) * r0, Y + Math.sin(a + w) * r0); g.closePath(); g.fill();
  }
}
function dibMira(J) {
  const g = ctx, X = raton.sx * dpr, Y = raton.sy * dpr, r = 7 * dpr;
  g.strokeStyle = rgba('yo', 0.18); g.lineWidth = Math.max(1, dpr); g.setLineDash([2 * dpr, 6 * dpr]);
  g.beginPath(); g.moveTo(sx(J.x), sy(J.z)); g.lineTo(X, Y); g.stroke(); g.setLineDash([]);
  g.strokeStyle = rgba('yo', 0.9); g.lineWidth = Math.max(1, 1.5 * dpr);
  g.beginPath(); g.arc(X, Y, r, 0, TAU); g.moveTo(X - r * 1.7, Y); g.lineTo(X - r * 0.6, Y); g.moveTo(X + r * 0.6, Y); g.lineTo(X + r * 1.7, Y);
  g.moveTo(X, Y - r * 1.7); g.lineTo(X, Y - r * 0.6); g.moveTo(X, Y + r * 0.6); g.lineTo(X, Y + r * 1.7); g.stroke();
}
let vineta = null;
function dibVineta() {
  const g = ctx;
  if (!vineta) { vineta = g.createRadialGradient(cw / 2, ch / 2, Math.min(cw, ch) * 0.35, cw / 2, ch / 2, Math.hypot(cw, ch) * 0.6); vineta.addColorStop(0, rgba('sombra', 0)); vineta.addColorStop(1, rgba('sombra', 0.55)); }
  g.fillStyle = vineta; g.fillRect(0, 0, cw, ch);
  if (P.rojo > 0.01) {
    const gr = g.createRadialGradient(cw / 2, ch / 2, Math.min(cw, ch) * 0.3, cw / 2, ch / 2, Math.hypot(cw, ch) * 0.6);
    gr.addColorStop(0, rgba('warn', 0)); gr.addColorStop(1, rgba('warn', 0.45 * P.rojo)); g.fillStyle = gr; g.fillRect(0, 0, cw, ch);
  }
}

/* =====================================================================================================
   HUD (HTML encima del tablero)
   ===================================================================================================== */
const H = {}; for (const id of ['hEst', 'hReloj', 'hBajas', 'hQuedan', 'hRef', 'hModo', 'hLenta', 'det', 'detFlecha', 'detB', 'detT', 'nota', 'saben', 'radio', 'yo', 'yoVida', 'yoVidaB', 'yoVidaC',
  'yoArma', 'yoGran', 'fRec', 'fAgach', 'fCorre', 'fLint', 'velo', 'pausaV', 'finV', 'perAviso']) H[id] = $(id);
const txt = (el, s) => { if (el && el._t !== s) { el._t = s; el.textContent = s; } };
const ver = (el, b) => { if (el && el.hidden === !!b) el.hidden = !b; };
function nota(s, seg) { P.nota = s; P.notaHasta = performance.now() + (seg || 2.6) * 1000; txt(H.nota, s); ver(H.nota, true); }
function radioDom() {
  const caja = H.radio; if (!caja) return;
  caja.textContent = '';
  if (!P) return;
  P.radio.forEach((l, i) => {
    const p = document.createElement('p'); if (l.pel) p.className = 'pel';
    if (i < P.radio.length - 1 && P.radio.length > 1) p.classList.add('vieja');
    const b = document.createElement('b'); b.textContent = '◉ RADIO · ' + l.quien; p.append(b, ' · «' + l.texto + '»'); caja.append(p);
  });
}
let ultHud = 0;
function hud(forzar) {
  const ahora = performance.now();
  if (!forzar && ahora - ultHud < 80) return; ultHud = ahora;
  if (!M || !P) return;
  const J = M.jugador, e = est || UE.estado(), rep = modo === 'reposo';
  let et = 'EN GUARDIA', cl = 'st';
  if (e.combate) { et = 'COMBATE'; cl = 'st com'; } else if (e.busqueda) { et = 'BÚSQUEDA'; cl = 'st sos'; } else if (e.sospecha > 0.05) { et = 'SOSPECHA'; cl = 'st sos'; }
  txt(H.hEst, (rep ? 'RETÉN · ' : '') + et); if (H.hEst.className !== cl) H.hEst.className = cl;
  ver(H.hReloj, !rep); txt(H.hReloj, reloj(M.t));
  ver(H.hBajas, !rep); txt(H.hBajas, 'BAJAS ' + P.bajas);
  ver(H.hQuedan, !rep); txt(H.hQuedan, 'QUEDAN ' + e.quedan);
  ver(H.hRef, e.refuerzo !== 'no'); txt(H.hRef, e.refuerzo === 'pedido' ? 'TIZÓN EN ' + Math.ceil(e.refuerzoEn || 0) + ' s' : 'LLEGÓ TIZÓN');
  ver(H.hModo, modo === 'mirar'); ver(H.hLenta, lenta);
  const det = !rep && J.vivo && !fin && (e.combate || e.busqueda || e.sospecha > 0.02);
  ver(H.det, det);
  if (det) {
    const com = e.combate, k = com ? 1 : Math.min(1, e.sospecha);
    H.detB.style.transform = 'scaleX(' + k.toFixed(3) + ')';
    txt(H.detT, com ? 'TE VIERON' : e.busqueda ? 'TE BUSCAN' : 'SOSPECHAN');
    if (H.det.classList.contains('com') !== com) H.det.classList.toggle('com', com);
    const dx = e.x - J.x, dz = e.z - J.z; H.detFlecha.style.transform = 'rotate(' + Math.atan2(dx, -dz).toFixed(3) + 'rad)';
  }
  ver(H.yo, !rep);
  if (!rep) {
    const hp = Math.max(0, Math.min(100, J.hp));
    H.yoVidaB.style.transform = 'scaleX(' + (hp / 100).toFixed(3) + ')'; txt(H.yoVida, String(Math.ceil(hp)));
    if (H.yoVidaC.classList.contains('baja') !== (hp < 35)) H.yoVidaC.classList.toggle('baja', hp < 35);
    const r = P.limites ? P.res[J.arma] : Infinity, carg = J.cargador[J.arma] || 0;
    txt(H.yoArma, NOMBRE_ARMA[J.arma] + ' ' + carg + ' / ' + (r === Infinity ? '∞' : r));
    const sin = carg <= 0 && !(r > 0); if (H.yoArma.classList.contains('sin') !== sin) H.yoArma.classList.toggle('sin', sin);
    txt(H.yoGran, 'GRANADAS ' + (J.granadas || 0));
    ver(H.fRec, J.recargando); ver(H.fAgach, !!J.agach); ver(H.fCorre, !!J.corriendo); ver(H.fLint, !!J.linterna);
  }
  if (P.nota && ahora > P.notaHasta) { P.nota = ''; ver(H.nota, false); }
  if (P.radio.length && M.t - P.radio[0].t > 7) { P.radio.shift(); radioDom(); }
  ver(H.saben, verSaben && !rep);
  if (verSaben && !rep) panelSaben();
}
function panelSaben() {
  let h = '';
  for (const e of foto.escuadrones) {
    const p = [];
    p.push(e.uc ? (e.uc.tipo === 'oido' ? 'te oyeron' : 'te vieron') + ' hace ' + coma(e.uc.edad) + ' s' : 'no saben dónde estás');
    if (e.orden) p.push('orden: ' + e.orden);
    p.push('tiran a pegar: ' + e.fichas);
    if (e.flanco) p.push('rodea ' + e.flanco.nombre + ' por ' + (e.flanco.lado === 'der' ? 'derecha' : 'izquierda'));
    if (e.sinJefe) p.push('sin jefe: desorden');
    if (e.refuerzoEn != null) p.push('Tizón llega en ' + Math.ceil(e.refuerzoEn) + ' s');
    h += '<h4>' + esc(String(e.nombre).toUpperCase()) + ' · ' + esc(EST_ESC[e.estado] || e.estado) + '</h4><p>' + esc(p.join(' · ')) + '</p>';
  }
  h += '<p class="ley">✕ último lugar conocido · ◯ rojo: tira a pegar · ┄ camino · ▢ cobertura · trazadora roja: a pegar; naranja: para que no asomes</p>';
  if (H.saben._h !== h) { H.saben._h = h; H.saben.innerHTML = h; }
}
function avisoAjustes() { ver(H.perAviso, modo !== 'reposo' && JSON.stringify(ajustes) !== ajustesVivos); }

/* =====================================================================================================
   MODOS Y BOTONES
   ===================================================================================================== */
function empezar(m) {
  modo = m; fin = null; pausa = false; acc = 0; nuevoMundo(m);
  raton.sx = cv.clientWidth * 0.3; raton.sy = cv.clientHeight / 2;              // hasta que se mueva el mouse: mirando al oeste, hacia el retén
  camara(0, true);
  stage.classList.toggle('vivo', m === 'juego');
  ver(H.velo, false); ver(H.pausaV, false); ver(H.finV, false);
  $('bMirar').setAttribute('aria-pressed', String(m === 'mirar'));
  if (m === 'juego') { try { stage.focus({ preventScroll: true }); } catch (e) {} }
  sucio = true; hud(true);
}
function alInicio() {
  modo = 'reposo'; fin = null; pausa = false; acc = 0; nuevoMundo('reposo');
  stage.classList.remove('vivo');
  ver(H.velo, true); ver(H.pausaV, false); ver(H.finV, false);
  $('bMirar').setAttribute('aria-pressed', 'false');
  sucio = true; hud(true);
}
function pausar() {
  if (modo === 'reposo' || fin || pausa) return;
  pausa = true; gatillo = pendiente = false; for (const k in teclas) teclas[k] = false;
  ver(H.pausaV, true); stage.classList.remove('vivo'); sucio = true;
}
function seguir() {
  if (!pausa) return;
  pausa = false; acc = 0; ver(H.pausaV, false); stage.classList.toggle('vivo', modo === 'juego');
  if (modo === 'juego') { try { stage.focus({ preventScroll: true }); } catch (e) {} }
}
function alternarSaben() { verSaben = !verSaben; $('bSaben').setAttribute('aria-pressed', String(verSaben)); sucio = true; hud(true); }
$('bJugar').addEventListener('click', () => { SND.iniciar(); empezar('juego'); });
$('bMirarV').addEventListener('click', () => { SND.iniciar(); empezar('mirar'); });
$('bMirar').addEventListener('click', () => { SND.iniciar(); if (modo === 'mirar' && !fin) alInicio(); else empezar('mirar'); });
$('bBichos').addEventListener('click', () => { if (!M) return; M.soltarBichos(6, { cada: 0.35 }); nota('Salen 6 bichos del subte, detrás del retén.'); });
$('bSaben').addEventListener('click', alternarSaben);
$('bLenta').addEventListener('click', () => { lenta = !lenta; $('bLenta').setAttribute('aria-pressed', String(lenta)); hud(true); });
$('bSonido').addEventListener('click', () => { SND.activar(!SND.activo); $('bSonido').setAttribute('aria-pressed', String(SND.activo)); });
$('bInicio').addEventListener('click', alInicio);
$('bSeguir').addEventListener('click', seguir);
$('bInicioP').addEventListener('click', alInicio);
$('bOtra').addEventListener('click', () => { SND.iniciar(); empezar(modo === 'mirar' ? 'mirar' : 'juego'); });
/* pantalla completa: opcional, si el navegador no deja se avisa y listo */
(function () {
  const b = $('bPantalla'), pedir = tablero.requestFullscreen || tablero.webkitRequestFullscreen;
  if (!pedir || !(document.fullscreenEnabled || document.webkitFullscreenEnabled)) { b.hidden = true; return; }
  b.addEventListener('click', () => {
    try {
      if (document.fullscreenElement || document.webkitFullscreenElement) { const s = document.exitFullscreen || document.webkitExitFullscreen; const p = s && s.call(document); if (p && p.catch) p.catch(() => {}); }
      else { const p = pedir.call(tablero); if (p && p.catch) p.catch(() => nota('El navegador no dejó pasar a pantalla completa.')); }
    } catch (e) { nota('El navegador no dejó pasar a pantalla completa.'); }
  });
  const cambio = () => { b.setAttribute('aria-pressed', String(!!(document.fullscreenElement || document.webkitFullscreenElement))); medir(); };
  document.addEventListener('fullscreenchange', cambio); document.addEventListener('webkitfullscreenchange', cambio);
})();
/* perillas de dificultad: se aplican al reiniciar */
for (const grupo of document.querySelectorAll('.per')) {
  const k = grupo.dataset.k;
  grupo.addEventListener('click', ev => {
    const b = ev.target.closest('button'); if (!b) return;
    ajustes[k] = +b.dataset.v; for (const x of grupo.querySelectorAll('button')) x.setAttribute('aria-pressed', String(x === b)); avisoAjustes();
  });
}
/* teclado (solo con la partida en marcha; nada de Ctrl) */
const TECLA = { KeyW: 'w', KeyA: 'a', KeyS: 's', KeyD: 'd', KeyC: 'c' };
window.addEventListener('keydown', e => {
  if (modo === 'reposo' || e.ctrlKey || e.metaKey || e.altKey) return;
  const c = e.code;
  if (c === 'Escape') { if (!fin) { pausa ? seguir() : pausar(); e.preventDefault(); } return; }
  if (c === 'KeyT') { if (!e.repeat) alternarSaben(); e.preventDefault(); return; }
  if (modo !== 'juego' || pausa || fin) return;
  const J = M.jugador;
  if (TECLA[c]) { teclas[TECLA[c]] = true; e.preventDefault(); return; }
  if (e.repeat) { if (/^(Shift|Key[RGF]|Digit[1-4])/.test(c)) e.preventDefault(); return; }
  switch (c) {
    case 'ShiftLeft': case 'ShiftRight': correr = !correr; break;
    case 'KeyR': M.recargarJugador(); break;
    case 'Digit1': arma('pistola'); break;
    case 'Digit2': arma('escopeta'); break;
    case 'Digit3': arma('uzi'); break;
    case 'Digit4': arma('fusil'); break;
    case 'KeyG': granada(); break;
    case 'KeyF': M.linterna(!J.linterna); break;
    default: return;
  }
  e.preventDefault();
});
window.addEventListener('keyup', e => { if (TECLA[e.code]) teclas[TECLA[e.code]] = false; });
window.addEventListener('blur', () => { for (const k in teclas) teclas[k] = false; gatillo = false; if (modo === 'juego') pausar(); });
document.addEventListener('visibilitychange', () => { if (document.hidden && modo === 'juego') pausar(); });
/* mouse: apuntar, disparar (mantener para las automáticas), rueda para acercar */
function ponerRaton(e) { const r = cv.getBoundingClientRect(); raton.sx = e.clientX - r.left; raton.sy = e.clientY - r.top; }
cv.addEventListener('pointermove', ponerRaton);
cv.addEventListener('pointerdown', e => {
  if (modo !== 'juego' || pausa || fin || e.button !== 0 || e.pointerType === 'touch') return;
  ponerRaton(e); e.preventDefault(); try { stage.focus({ preventScroll: true }); } catch (x) {}
  gatillo = true; pendiente = true; tPend = M.t;
});
window.addEventListener('pointerup', () => { gatillo = false; });
cv.addEventListener('contextmenu', e => { if (modo === 'juego') e.preventDefault(); });
cv.addEventListener('wheel', e => { if (modo === 'reposo') return; e.preventDefault(); zoom = clamp(zoom * Math.pow(0.9985, e.deltaY), 0.55, 2.4); sucio = true; }, { passive: false });

/* =====================================================================================================
   ARRANQUE Y BUCLE
   ===================================================================================================== */
if (tactil) { ver($('bJugar'), false); ver($('veloTxt'), false); ver($('veloTactil'), true); $('bMirarV').className = 'play'; }
if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => { medir(); }).observe(stage); else window.addEventListener('resize', medir);
if (typeof IntersectionObserver !== 'undefined') new IntersectionObserver(en => { enPantalla = en[0].isIntersecting; if (!enPantalla && modo === 'juego') pausar(); }).observe(stage);
medir(); nuevoMundo('reposo'); camara(0, true);
function cuadro(ahora) {
  requestAnimationFrame(cuadro);
  const dtR = ultimo ? Math.min(0.1, Math.max(0, (ahora - ultimo) / 1000)) : 0; ultimo = ahora;
  if (!enPantalla || document.hidden || !M || congelado) return;
  const quieto = modo === 'reposo' && reduce.matches;
  if (!pausa && !quieto) {
    acc += dtR * (lenta ? 0.3 : 1);
    let n = 0; while (acc >= DT && n < 6) { pasoSeguro(DT); acc -= DT; n++; }
    if (n >= 6) acc = 0;
  }
  if ((!pausa && !quieto) || sucio) {
    foto = M.foto(); est = UE.estado(); camara(dtR, false);
    try { dibujar(); } catch (e) { cuentas.errores++; if (errLog++ < 5) console.error('dibujo: ' + (e && e.stack || e)); }
    sucio = false;
  }
  hud(false);
}
requestAnimationFrame(cuadro);

/* para las pruebas: adelantar el tiempo con el mismo paso, sin esperar */
window.UEPAG = {
  empezar, alInicio, alternarSaben, pausar, seguir,
  congelar(b) { congelado = !!b; },
  pantalla(x, z) { fijarCamara(); return { x: sx(x) / dpr, y: sy(z) / dpr }; },
  avanzar(seg) { const n = Math.round(seg / DT); for (let i = 0; i < n; i++) pasoSeguro(DT); foto = M.foto(); est = UE.estado(); camara(1, true); dibujar(); hud(true); return this.info(); },
  dibujar() { foto = M.foto(); est = UE.estado(); dibujar(); hud(true); },
  costo(n) { const t0 = performance.now(); for (let i = 0; i < n; i++) pasoSeguro(DT); const t1 = performance.now(); for (let i = 0; i < n; i++) { foto = M.foto(); est = UE.estado(); dibujar(); } const t2 = performance.now(); return { pasoMs: +((t1 - t0) / n).toFixed(3), dibujoMs: +((t2 - t1) / n).toFixed(3) }; },
  info() {
    const J = M.jugador;
    return { modo, fin: fin && fin.tipo, pausa, t: +M.t.toFixed(2), vivo: J.vivo, hp: Math.round(J.hp), x: +J.x.toFixed(2), z: +J.z.toFixed(2), agach: J.agach, corriendo: J.corriendo,
      linterna: J.linterna, arma: J.arma, cargador: J.cargador[J.arma], reserva: P.limites ? P.res[J.arma] : null, granadas: J.granadas, tieneFusil: P.tieneFusil,
      quedan: (est || UE.estado()).quedan, combate: (est || UE.estado()).combate, bajas: P.bajas, cuentas: Object.assign({}, cuentas), verSaben, lenta, ajustes: Object.assign({}, ajustes),
      radio: P.radio.map(l => l.quien + ': ' + l.texto) };
  },
  get M() { return M; }, get UE() { return UE; }, get P() { return P; }
};
})();
