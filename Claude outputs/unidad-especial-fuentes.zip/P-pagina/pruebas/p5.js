/* Prueba 5: que los avisos del HUD no se pisen (escritorio y celular), botones sueltos, y movimiento reducido. */
const path = require('path');
const H = require(path.join(__dirname, '../../harness.js'));
const PAG = path.join(__dirname, '../prueba.html');
const CAP = path.join(__dirname, '../cap/');
const quiero = process.argv.slice(2);
const ok = (c, m) => console.log((c ? 'OK   ' : 'FALLA') + ' ' + m);
const choques = () => {
  const vis = el => el && !el.hidden && el.getClientRects().length && getComputedStyle(el).display !== 'none';
  const caja = sel => { const el = document.querySelector(sel); if (!vis(el)) return null; const r = el.getBoundingClientRect(); return r.width && r.height ? { sel, x0: r.left, y0: r.top, x1: r.right, y1: r.bottom } : null; };
  const cs = ['.tl', '#det', '#nota', '#saben', '.dcha .chips', '#radio', '#yo'].map(caja).filter(Boolean);
  const st = document.getElementById('stage').getBoundingClientRect(), out = [];
  for (let i = 0; i < cs.length; i++) {
    const a = cs[i]; if (a.x0 < st.left - 0.5 || a.x1 > st.right + 0.5 || a.y0 < st.top - 0.5 || a.y1 > st.bottom + 0.5) out.push(a.sel + ' se sale del tablero');
    for (let j = i + 1; j < cs.length; j++) { const b = cs[j]; if (a.x0 < b.x1 - 1 && b.x0 < a.x1 - 1 && a.y0 < b.y1 - 1 && b.y0 < a.y1 - 1) out.push(a.sel + ' pisa ' + b.sel); }
  }
  return { cajas: cs.map(c => c.sel).join(' '), out };
};
async function nuevaPagina(browser, opc) {
  const ctx = await browser.newContext(opc); const pg = await ctx.newPage(); const errs = [];
  pg.on('pageerror', e => errs.push('PAGEERR ' + e.message)); pg.on('console', x => { if (x.type() === 'error' && !/Failed to load resource/.test(x.text())) errs.push('CONSOLE ' + x.text().slice(0, 300)); });
  await pg.route('**/*', r => { const u = r.request().url(); if (u.startsWith('file:')) r.continue(); else r.abort(); });
  await pg.goto('file://' + PAG, { waitUntil: 'load' }); await pg.waitForTimeout(700);
  return { ctx, pg, errs };
}
(async () => {
  const h = await H.openPage(PAG, { width: 1280, height: 800 });
  const p = h.page;
  try {
    await p.waitForTimeout(600);
    await p.click('#bMirarV'); await p.evaluate(() => UEPAG.congelar(true));
    await p.click('#bSaben'); await p.click('#bLenta'); await p.click('#bBichos');
    let peor = [];
    for (let i = 0; i < 12; i++) { await p.evaluate(() => UEPAG.avanzar(4)); const c = await p.evaluate(choques); if (c.out.length) peor = peor.concat(c.out); }
    ok(!peor.length, 'escritorio, 48 s mirando con todo prendido: avisos sin pisarse ' + (peor.length ? JSON.stringify([...new Set(peor)]) : ''));
    await p.click('#bSonido'); await p.click('#bSonido'); await p.click('#bPantalla'); await p.waitForTimeout(400);
    const fs = await p.evaluate(() => !!document.fullscreenElement);
    if (fs) await p.evaluate(() => document.exitFullscreen().catch(() => {}));
    ok(true, 'Sonido (dos clics) y Pantalla completa sin romper nada (pantalla completa: ' + (fs ? 'entró' : 'no entró') + ')');
    await p.click('#bInicio'); const r0 = await p.evaluate(() => ({ modo: UEPAG.info().modo, velo: !document.getElementById('velo').hidden }));
    ok(r0.modo === 'reposo' && r0.velo, 'Volver al inicio deja el velo con JUGAR');
    console.log('errores escritorio:', h.errors.length ? h.errors.slice(0, 5).join('\n') : 0);
    // celular
    const m = await nuevaPagina(h.browser, { viewport: { width: 400, height: 860 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    await m.pg.tap('#bMirarV'); await m.pg.evaluate(() => UEPAG.congelar(true)); await m.pg.tap('#bSaben'); await m.pg.tap('#bBichos');
    peor = [];
    for (let i = 0; i < 12; i++) { await m.pg.evaluate(() => UEPAG.avanzar(4)); const c = await m.pg.evaluate(choques); if (c.out.length) peor = peor.concat(c.out); }
    ok(!peor.length, 'celular, 48 s mirando con «lo que saben»: avisos sin pisarse ' + (peor.length ? JSON.stringify([...new Set(peor)]) : ''));
    const sw = await m.pg.evaluate(() => [document.documentElement.scrollWidth, innerWidth]);
    ok(sw[0] <= sw[1], 'celular: scrollWidth ' + sw[0] + ' ≤ innerWidth ' + sw[1]);
    if (quiero.includes('celu')) { await m.pg.evaluate(() => document.getElementById('stage').scrollIntoView({ block: 'start' })); await m.pg.screenshot({ path: CAP + '8-celular.png' }); }
    console.log('errores celular:', m.errs.length ? m.errs.slice(0, 5).join('\n') : 0);
    await m.ctx.close();
    // movimiento reducido: el reposo queda quieto pero dibujado
    const q = await nuevaPagina(h.browser, { viewport: { width: 1000, height: 700 }, reducedMotion: 'reduce' });
    await q.pg.waitForTimeout(1200);
    const rq = await q.pg.evaluate(() => { const c = document.getElementById('cv'), g = c.getContext('2d'), d = g.getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 0; i < d.length; i += 400) if (d[i] + d[i + 1] + d[i + 2] > 60) n++; return { t: UEPAG.info().t, claros: n }; });
    ok(rq.t === 0 && rq.claros > 50, 'movimiento reducido: reposo quieto (t ' + rq.t + ') y dibujado (' + rq.claros + ' muestras claras)');
    console.log('errores reducido:', q.errs.length ? q.errs.slice(0, 5).join('\n') : 0);
    await q.ctx.close();
  } finally { await h.close(); }
})();
