  /* ====================================================================================================
     MOVERSE: velocidad deseada y aceleración, seguimiento del camino, saltos de valla, anti-trabado
     ==================================================================================================== */
  let nTrab = 0;
  /* cola de trabajos pesados: cada pedido pisa al anterior del mismo soldado y la misma clave */
  function encolar(s, clave, fn) { const n = ++nTrab; s.pend[clave] = n; trabajos.push({ s, clave, n, fn }); }
  function procesarTrabajo() {
    while (trabajos.length) {
      const j = trabajos.shift();
      if (!j.s.vivo || j.s.pend[j.clave] !== j.n) continue;          // pedido viejo o de un muerto
      j.s.pend[j.clave] = 0; j.fn(); return;                         // uno solo por cuadro
    }
  }
  /* manda a s a un punto. op = {expo, agach, evita}. El camino llega en uno de los próximos cuadros. */
  function irA(s, x, z, vel, op) {
    s.vel = vel; s.llego = false; s.dest = s.dest || { x: 0, z: 0 }; s.dest.x = x; s.dest.z = z;
    const d = hyp(x - s.x, z - s.z);
    if (d < 0.3) { s.camino = null; s.llego = true; s.esperaCamino = false; return; }
    if (d < 2.2 && !s.elev && libreEn(x, z) && lineaLibre(s.x, s.z, x, z, -1, false)) {      // paso corto y derecho: sin A*
      s.camino = [{ x, z, salto: false }]; s.ci = 0; s.esperaCamino = false; s.pend.camino = 0; return;
    }
    s.esperaCamino = true;
    encolar(s, 'camino', () => {
      let c = aEstrella(s.x, s.z, x, z, op);
      if (!c && op && op.expo) c = aEstrella(s.x, s.z, x, z, null);
      s.esperaCamino = false;
      if (!c) { s.camino = null; s.sinCamino = (s.sinCamino || 0) + 1; s.llego = true; s.fallo = true; return; }
      s.camino = c; s.ci = 0; s.fallo = false; s.sinCamino = 0;
    });
  }
  function parar(s) { s.camino = null; s.dvx = s.dvz = 0; s.esperaCamino = false; s.pend.camino = 0; s.llego = true; }
  function empezarSalto(s, p) {
    let q = s.ci; while (q < p.length && p[q].salto) q++;
    if (q >= p.length) { s.camino = null; s.llego = true; return; }  // camino roto: termina acá
    s.salto = 0; s.sx0 = s.x; s.sz0 = s.z; s.sx1 = p[q].x; s.sz1 = p[q].z;
    s.sDur = Math.max(T.saltoT, hyp(s.sx1 - s.sx0, s.sz1 - s.sz0) / 3.4); s.ci = q + 1;
  }
  /* sigue el camino: deja en dvx,dvz la velocidad que quiere. */
  function seguir(s) {
    const p = s.camino;
    if (!p || s.ci >= p.length) { s.dvx = s.dvz = 0; if (p && !s.esperaCamino) { s.camino = null; s.llego = true; } return; }
    let tg = p[s.ci];
    if (tg.salto) { empezarSalto(s, p); return; }
    let d = hyp(tg.x - s.x, tg.z - s.z);
    const sig = s.ci + 1 < p.length ? p[s.ci + 1] : null;
    if (sig && d < (sig.salto ? 0.3 : 0.6)) { s.ci++; if (sig.salto) { empezarSalto(s, p); return; } tg = sig; d = hyp(tg.x - s.x, tg.z - s.z); }
    const ultimo = s.ci >= p.length - 1;
    if (ultimo && d < 0.22) { s.ci = p.length; s.camino = null; s.llego = true; s.dvx = s.dvz = 0; return; }
    let v = s.vel;
    if (s.tierra > 0.02) v = Math.min(v, 0.8); else if (s.agach > 0.6) v = Math.min(v, T.velAgach);
    if (ultimo) v *= clamp(d / 1.4, 0.25, 1);                         // frena al llegar
    else {
      const n2 = p[s.ci + 1];
      if (n2.salto) v *= clamp(d / 1.2, 0.45, 1);                     // llega despacio a la valla
      else if (d < 1.6) {                                             // y afloja en las curvas cerradas
        const ax = tg.x - s.x, az = tg.z - s.z, bx = n2.x - tg.x, bz = n2.z - tg.z, c = (ax * bx + az * bz) / ((d || 1) * (hyp(bx, bz) || 1));
        if (c < 0.5) v *= 0.6;
      }
    }
    s.dvx = (tg.x - s.x) / (d || 1) * v; s.dvz = (tg.z - s.z) / (d || 1) * v;
  }
  function mover(s, dt) {
    if (s.salto >= 0) {                                               // pasando una valla (o bajando del nido)
      s.salto += dt / s.sDur; const u = Math.min(1, s.salto);
      s.x = s.sx0 + (s.sx1 - s.sx0) * u; s.z = s.sz0 + (s.sz1 - s.sz0) * u;
      if (s.bajaDe > 0) s.y = s.bajaDe * (1 - u * u); else s.y = ENV.piso(s.x, s.z);
      if (s.salto >= 1) { s.salto = -1; s.bajaDe = 0; const l = hyp(s.sx1 - s.sx0, s.sz1 - s.sz0) || 1; s.vx = (s.sx1 - s.sx0) / l * 2; s.vz = (s.sz1 - s.sz0) / l * 2; }
      s.trabT = 0; s.trabX = s.x; s.trabZ = s.z;
      return;
    }
    if (s.elev) { s.vx = s.vz = 0; return; }                          // arriba del nido no camina
    /* separación: si se están por encimar, se corren un poco */
    let ex = 0, ez = 0;
    if (s.mov) for (let i = 0; i < soldados.length; i++) {
      const o = soldados[i]; if (o === s || !o.vivo || !o.activo || o.elev) continue;
      const dx = s.x - o.x, dz = s.z - o.z, d2 = dx * dx + dz * dz;
      if (d2 < 1.44 && d2 > 1e-4) { const d = Math.sqrt(d2), f = (1.2 - d) * 2.5; ex += dx / d * f; ez += dz / d * f; }
    }
    const ax = s.dvx + ex - s.vx, az = s.dvz + ez - s.vz, al = hyp(ax, az), m = T.acel * dt;
    if (al > m) { s.vx += ax / al * m; s.vz += az / al * m; } else { s.vx += ax; s.vz += az; }
    let nx = s.x + s.vx * dt, nz = s.z + s.vz * dt;
    if (!libreEn(nx, nz)) {                                           // se desliza contra lo que haya
      if (libreEn(nx, s.z)) { nz = s.z; s.vz = 0; } else if (libreEn(s.x, nz)) { nx = s.x; s.vx = 0; } else { nx = s.x; nz = s.z; s.vx = s.vz = 0; }
    }
    if (!libreEn(nx, nz)) {                                           // quedó adentro de algo (cambió la grilla): sale al libre más cercano
      const k = libreCerca(nx, nz, 4); if (k >= 0) { nx += (cX(k) - nx) * Math.min(1, dt * 10); nz += (cZ(k) - nz) * Math.min(1, dt * 10); if (!libreEn(nx, nz) && hyp(cX(k) - nx, cZ(k) - nz) < 0.75) { nx = cX(k); nz = cZ(k); } }
    }
    s.x = nx; s.z = nz; s.y = ENV.piso(nx, nz);
    /* anti-trabado: si quiere moverse y en 1 s no avanzó, replantea; a la tercera, se corre de costado */
    if (s.mov) {
      s.trabT += dt;
      if (s.trabT >= 1) {
        if (hyp(s.x - s.trabX, s.z - s.trabZ) < 0.45) {
          s.trabN++;
          if (s.dest && !s.esperaCamino) {
            if (s.trabN >= 3) { const k = libreCerca(s.x + campana() * 2, s.z + campana() * 2, 2); if (k >= 0) { s.camino = [{ x: cX(k), z: cZ(k), salto: false }]; s.ci = 0; } s.trabN = 0; s.replan = true; }
            else irA(s, s.dest.x, s.dest.z, s.vel, s.caminoOp);
          }
        } else s.trabN = 0;
        s.trabT = 0; s.trabX = s.x; s.trabZ = s.z;
      }
    } else { s.trabT = 0; s.trabX = s.x; s.trabZ = s.z; }
  }
  /* posturas: de pie ↔ agachado 0,25 s · agachado → tierra 0,6 s · tierra → agachado 0,9 s */
  function posturas(s, dt) {
    if (s.post === 2) { if (s.agach < 1) s.agach = Math.min(1, s.agach + dt / T.tAgach); else s.tierra = Math.min(1, s.tierra + dt / T.tATierra); }
    else if (s.tierra > 0) s.tierra = Math.max(0, s.tierra - dt / T.tDeTierra);
    else if (s.post === 1) s.agach = Math.min(1, s.agach + dt / T.tAgach);
    else s.agach = Math.max(0, s.agach - dt / T.tAgach);
  }
  function girarHacia(s, yaw, dt, vel) {
    const d = angN(yaw - s.miraYaw), m = (vel || T.giro) * dt;
    s.miraYaw = angN(s.miraYaw + clamp(d, -m, m));
  }
  const rumboA = (s, x, z) => Math.atan2(x - s.x, z - s.z);
  function ponerEstado(s, e) { if (s.estado !== e) { s.estado = e; s.tEst = ahora; } }

  /* ====================================================================================================
     ACTUAR: corre en cada cuadro. Relojes, postura, movimiento, giro, puntería, cadencia de tiro.
     ==================================================================================================== */
  function actuar(s, dt) {
    /* relojes */
    if (s.aturdido > 0) { s.aturdido -= dt; if (s.aturdido <= 0 && s.estado === 'aturdido') ponerEstado(s, s.cob ? 'volver' : 'alerta'); }
    if (s.radioT > 0) s.radioT -= dt;
    if (s.senalT >= 0) { s.senalT += dt / 1.4; if (s.senalT >= 1) s.senalT = -1; }
    if (s.culCd > 0) s.culCd -= dt;
    if (s.escondeT > 0) s.escondeT -= dt;
    if (s.supr > 0) s.supr = Math.max(0, s.supr - T.suprBaja * dt);
    /* puntería: se asienta mientras lo ve quieto; se pierde si deja de verlo, se mueve o lo suprimen */
    const v2 = s.vx * s.vx + s.vz * s.vz;
    if (s.ve && v2 < 2.6 && s.supr < T.suprEsconde && s.apunta > 0.8) s.asiento = Math.min(1, s.asiento + dt / T.asientoT);
    else s.asiento = Math.max(0, s.asiento - dt * (s.ve ? 1.5 : 3));
    /* recarga */
    if (s.recT >= 0) {
      const A = T[s.arma];
      if (s.arma === 'escopeta') { s.recT += dt; if (s.recT >= A.recargaCartucho) { s.recT = 0; s.balas++; if (s.balas >= A.cargador) s.recT = -1; } }
      else { s.recT += dt; if (s.recT >= A.recarga) { s.recT = -1; s.balas = A.cargador; } }
    }
    posturas(s, dt);

    /* ---- movimiento según el estado ---- */
    s.mov = false;
    const est = s.estado;
    if (s.aturdido > 0 || est === 'lanzar' || est === 'radio' || est === 'culata') { s.dvx = s.dvz = 0; }
    else if (s.retro > 0) {                                           // retrocede de un bicho que se le vino encima
      s.retro -= dt;
    } else if (s.camino || s.esperaCamino) {
      if (s.tierra > 0.02 && s.post !== 2 && s.vel > 1) { s.dvx = s.dvz = 0; }   // se está levantando: todavía no corre
      else { seguir(s); s.mov = !!(s.camino) && s.salto < 0; }
    } else { s.dvx = s.dvz = 0; }
    mover(s, dt);

    /* ---- hacia dónde mira ---- */
    let yaw = s.miraObj;
    if (s.mov && v2 > 3 && !s.miraFija) yaw = Math.atan2(s.vx, s.vz);  // corriendo sin nada que mirar: mira adonde va
    if (yaw !== undefined && yaw !== null) girarHacia(s, yaw, dt, s.aturdido > 0 ? 1 : T.giro);
    /* el cuerpo sigue a la mirada; corriendo, al movimiento */
    const cuerpo = (v2 > 6) ? Math.atan2(s.vx, s.vz) : s.miraYaw;
    { const d = angN(cuerpo - s.rumbo), m = T.giro * 1.5 * dt; s.rumbo = angN(s.rumbo + clamp(d, -m, m)); }
    /* arma arriba o abajo */
    const ap = s.apObj ? 1 : 0; s.apunta += clamp(ap - s.apunta, -dt * 4, dt * 4);

    /* ---- cosas con reloj propio ---- */
    if (s.lanzaT >= 0) tickLanzar(s, dt);
    if (s.culT >= 0) tickCulata(s, dt);
    if (s.rol === 'tirador') tickTirador(s, dt);
    else if (s.enTiro && puedeTirar(s)) gatillo(s, dt);
    else if (s.raf > 0) { s.raf = 0; s.pausaT = 0.3; }                // se le cortó la ráfaga (se agachó, lo aturdieron…)
    if (s.vista) escribirVista(s, dt);
  }

  /* gesto de lanzar: grito al empezar; la granada sale en el 55 % del gesto y nunca antes de T.granada.aviso */
  function tickLanzar(s, dt) {
    const G = T.granada, antes = s.lanzaT; s.lanzaT += dt / G.gesto;
    const L = s.lanza;
    if (L && !L.salio && s.lanzaT >= 0.55 && ahora - s.gritoT >= G.aviso) {
      L.salio = true;
      const hx = s.x + Math.sin(s.miraYaw) * 0.3, hy = s.y + 1.75, hz = s.z + Math.cos(s.miraYaw) * 0.3;
      const a = ENV.arco(hx, hy, hz, L.x, L.y, L.z);
      if (a && s.granadas > 0) { s.granadas--; red.tGranada = ahora; ENV.granada(s, hx, hy, hz, a.vx, a.vy, a.vz, G.mecha, 'frag'); ENV.evento('granada', { s, x: L.x, z: L.z, motivo: L.motivo }); }
      else red.tGranada = ahora - G.cada + 3;                         // no había arco: se guarda la granada y se prueba más tarde
    }
    if (s.lanzaT >= 1) { s.lanzaT = -1; s.lanza = null; if (s.estado === 'lanzar') { ponerEstado(s, s.cob ? 'volver' : 'alerta'); s.tSal = ahora + 0.4; } }
  }
  /* culatazo: 0,35 s de aviso (el golpe cae en la mitad del gesto de 0,7 s) */
  function tickCulata(s, dt) {
    const C = T.culata; s.culT += dt / (C.aviso * 2);
    if (!s.culPego && s.culT >= 0.5) {
      s.culPego = true;
      if (s.culBicho) { const b = s.bicho; if (b && b.d < C.dist + 0.6) ENV.herirBicho(b.ref, 25 * T.bichoDano, Math.sin(s.miraYaw), Math.cos(s.miraYaw)); }
      else {
        /* física del golpe: llega si el jugador sigue al alcance y adelante (se puede esquivar retrocediendo) */
        const j = ENV.jugador(), dx = j.x - s.x, dz = j.z - s.z, d = hyp(dx, dz);
        if (j.vivo && d < C.dist + 0.25 && Math.abs(angN(Math.atan2(dx, dz) - s.miraYaw)) < 1.0 && Math.abs(j.y - s.y) < 1.5) ENV.herirJugador(C.dano * T.dano, s.x, s.z, 'culata');
      }
    }
    if (s.culT >= 1) { s.culT = -1; s.culCd = C.cada; if (s.estado === 'culata') ponerEstado(s, s.cob ? 'volver' : 'alerta'); }
  }

  /* ---------------------------------------------------------------------------------------------------
     EL TIRADOR. Ciclo: «lo tengo en la mira» → láser prendido siguiendo al jugador (con atraso) durante
     T.tirador.laser segundos CONTINUOS de línea de visión → destello → tiro al punto donde está el láser.
     Si la línea se corta un solo cuadro, se cancela. Mientras apunta mira en cada cuadro (no cada 0,12 s).
     --------------------------------------------------------------------------------------------------- */
  function soltarLaser(s, fallo) {
    s.laser = null; if (red.tirador === s) red.tirador = null;
    if (s.tir !== 'espera') { s.tir = 'espera'; s.tirSig = Math.max(s.tirSig, ahora + 0.9); if (fallo && ahora - s.tirDijo > 4) { if (decir(s, 'tirador_fallo')) s.tirDijo = ahora; } }
  }
  function tickTirador(s, dt) {
    const R = T.tirador;
    if (red.muerto || s.blanco !== 'jugador' || !s.enTiro || !puedeTirar(s) || s.supr > T.suprEsconde || s.mov) { if (s.tir !== 'espera') soltarLaser(s, false); else s.laser = null; return; }
    const u = s.hist[(s.hI + 9) % 10], d = s.ve ? hyp(u.x - s.x, u.z - s.z) : 1e9;
    if (s.tir === 'espera') {
      if (!s.ve || ahora - s.veDesde < T.reaccion || ahora - s.tConoce < T.reaccion || s.balas <= 0) return;
      if (d <= R.cerca) {
        /* de cerca: rápido y mal, sin láser */
        if (ahora >= s.tirSig && puntoMira(s, T.miraAtraso, T.miraAdelanto)) {
          const modo = s.avisoHecho ? 'pegar' : 'aviso'; s.avisoHecho = true; s.nRaf++; s.balas--; s.tDisparo = ahora; s.tirSig = ahora + R.cercaCadencia;
          if (s.vista && s.vista.disparo) s.vista.disparo();
          let px = s.miraX, pz = s.miraZ; if (modo === 'aviso') { const ux = (px - s.x) / (d || 1), uz = (pz - s.z) / (d || 1); px += -uz * 1.3; pz += ux * 1.3; }
          tirarBala(s, px, s.miraY, pz, modo, 'tirador', R.cercaDisp * T.punteria, R.cercaDano, R.alcance, true);
        }
        return;
      }
      if (ahora < s.tirSig || (red.tirador && red.tirador !== s)) return;
      red.tirador = s; s.tir = 'mira'; s.tirT = 0;
      if (ahora - s.tirDijo > 6) { if (decir(s, 'tirador_mira')) s.tirDijo = ahora; }
      ENV.evento('tirador_mira', { s });
    }
    /* apuntando: mira en cada cuadro; si se corta la línea, se cancela */
    percibir(s); s.tPerc = ahora + T.tPercibir;
    if (!s.ve || !puntoMira(s, R.atraso, R.adelanto)) { soltarLaser(s, true); return; }
    s.lx = s.miraX; s.ly = s.miraY; s.lz = s.miraZ; s.laser = s._laser; s._laser.x = s.lx; s._laser.y = s.ly; s._laser.z = s.lz;
    s.tirT += dt;
    if (s.tir === 'mira') { if (s.tirT >= R.laser) { s.tir = 'destello'; s.tirT = 0; } return; }
    if (s.tirT < R.destello) return;
    /* tiro: adonde está el punto rojo. El primero de cada tirador es de aviso (regla 4). */
    const modo = s.avisoHecho ? 'laser' : 'aviso'; s.avisoHecho = true; s.nRaf++; s.balas--; s.tDisparo = ahora; s.esc.tFuego = ahora;
    if (s.vista && s.vista.disparo) s.vista.disparo();
    let px = s.lx, pz = s.lz;
    if (modo === 'aviso') { const dd = hyp(px - s.x, pz - s.z) || 1, ux = (px - s.x) / dd, uz = (pz - s.z) / dd, l = azar() < 0.5 ? -1 : 1; px += -uz * 0.9 * l; pz += ux * 0.9 * l; }
    const pega = tirarBala(s, px, s.ly, pz, modo, 'tirador', R.disp * T.punteria, R.dano, R.alcance, false);
    s.laser = null; red.tirador = null; s.tir = 'espera'; s.tirSig = ahora + Math.max(0.6, R.ciclo - R.laser - R.destello);
    if (pega !== 'jugador' && modo === 'laser' && ahora - s.tirDijo > 4) { if (decir(s, 'tirador_fallo')) s.tirDijo = ahora; }
    if (s.balas <= 0) { s.recT = 0; }
  }

  /* ---------------------------------------------------------------------------------------------------
     Entradas del modelo 3D (SPEC 4.2). Convenciones que asume la IA (avisadas en el informe):
       mYaw > 0 = el arma apunta hacia la izquierda del cuerpo (mismo sentido que rotation.y)
       mPitch > 0 = hacia arriba · asoma −1 izquierda, +1 derecha · laser = objeto plano {x,y,z}
     --------------------------------------------------------------------------------------------------- */
  function escribirVista(s, dt) {
    const u = s.vista, e = u.e;
    u.root.position.set(s.x, s.y, s.z); u.root.rotation.y = s.rumbo;
    e.agach = s.agach; e.tierra = s.tierra; e.apunta = s.apunta;
    e.mYaw = clamp(angN(s.miraYaw - s.rumbo), -1.3, 1.3); e.mPitch = clamp(s.mPitch, -0.9, 0.9);
    e.asoma = (s.enTiro && s.cob && s.cob.tiro) ? s.cob.tiro.lado : 0;
    e.recarga = s.recT >= 0 ? (s.arma === 'escopeta' ? s.recT / T.escopeta.recargaCartucho : s.recT / T[s.arma].recarga) : -1;
    e.salto = (s.salto >= 0 && !(s.bajaDe > 0)) ? Math.min(1, s.salto) : -1;
    e.lanza = s.lanzaT; e.senal = s.senalT; e.senalTipo = s.senalTipo; e.culata = s.culT;
    e.radio = s.radioT > 0 ? Math.min(1, s.radioT * 4) : 0; e.aturdido = s.aturdido > 0 ? 1 : 0;
    e.luz = s.luz; e.laser = s.laser; e.muerte = s.muerte;
    u.update(dt);
  }

