/* Prueba 9: apuntar con el mouse a un soldado visible y disparar: ¿pega? (la altura del tiro la elige la página) */
const path = require('path'); const H = require(path.join(__dirname, '../../harness.js'));
(async () => { const h = await H.openPage(path.join(__dirname, '../prueba.html'), { width: 1280, height: 800 }); const p = h.page;
  try { await p.waitForTimeout(500); await p.evaluate(() => document.getElementById('stage').scrollIntoView({ block: 'center' }));
    await p.click('#bJugar'); await p.evaluate(() => UEPAG.congelar(true));
    const res = [];
    for (const [arma, tecla, dist] of [['pistola', 'Digit1', 14], ['uzi', 'Digit3', 18], ['escopeta', 'Digit2', 8]]) {
      await p.keyboard.press(tecla);
      // el asalto hace la ronda; el jugador se pone a `dist` m al este de él, en la avenida
      const s = await p.evaluate(d => { const M = UEPAG.M, s = UEPAG.UE.soldados.find(x => x.rol === 'asalto' && x.vivo); M.ponerJugador(s.x + d, s.z); UEPAG.avanzar(0.05); return { x: s.x, z: s.z }; }, dist);
      const c0 = await p.evaluate(() => UEPAG.info().cuentas);
      const box = await p.evaluate(() => { const r = document.getElementById('cv').getBoundingClientRect(); return { x: r.x, y: r.y }; });
      for (let k = 0; k < 6; k++) {
        const q = await p.evaluate(() => { const s = UEPAG.UE.soldados.find(x => x.rol === 'asalto'); return s.vivo ? UEPAG.pantalla(s.x, s.z) : null; });
        if (!q) break;
        await p.mouse.move(box.x + q.x, box.y + q.y); await p.mouse.down(); await p.evaluate(() => UEPAG.avanzar(0.12)); await p.mouse.up(); await p.evaluate(() => UEPAG.avanzar(0.3));
      }
      const c1 = await p.evaluate(() => UEPAG.info());
      res.push(arma + ' a ' + dist + ' m: ' + (c1.cuentas.balasMias - c0.balasMias) + ' balas, ' + (c1.cuentas.aciertos - c0.aciertos) + ' pegaron, bajas ' + c1.bajas);
      await p.evaluate(() => { UEPAG.empezar('juego'); UEPAG.congelar(true); });
    }
    console.log(res.join('\n')); console.log('errores:', h.errors.length ? h.errors.slice(0, 3).join('\n') : 0);
  } finally { await h.close(); } })();
