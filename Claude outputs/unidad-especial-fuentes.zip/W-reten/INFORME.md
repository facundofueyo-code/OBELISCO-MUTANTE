# W · Retén — informe (base `v116/base.html`, juego 1.16.0)

## Archivos
- `W-reten/mod_reten.js` (432 líneas): módulo `RETEN`, va en `/*UE:modulos*/`.
- `W-reten/patch_reten.py`: `python3 patch_reten.py entrada.html salida.html`. Probado sobre `v116/base.html` limpio y compuesto con `F-fx/patch_fx.py` en los dos órdenes.
- `W-reten/capturas/final-*.png` (960×540) y `final-mosaico-a.png` / `final-mosaico-b.png` (cuatro vistas cada uno).
- `W-reten/t2/`: pruebas (`tfinal.js`, `t3.js` capturas y costo, `t7.js` composición con F) con sus registros (`tfinal.log`, `t3final.log`, `t3final2.log`), `grilla1.txt` (volcado de `enB` alrededor del retén) y `juego.html` (copia parcheada).
- `recon/` y `pruebas/` son de la 1.14.0: no se usan.

## Qué hay en el lugar
- **Barricada en x=−438**: dos furgones negro mate (modelo `ambulancia` sin ploteo ni patente, con defensa de caños), atravesados N-S: norte z 599,5–605,4 con la trompa al norte, sur z 608,6–614,5 con la trompa al sur. Las colas dan al paso del medio, que cierran dos vallas de 1,1 m. Hay vallas en las puntas hasta el cordón (z 597,95–599,5 y 614,5–617,2). Las veredas quedan abiertas como pide la tarea: son las vías de flanqueo.
- **Camioneta de mando** (`pickup` negra) en (−446,6; 609,6), con la trompa al oeste y la caja hacia la barricada. En la caja lleva cajones y un estuche, y tiene un mástil de antena con luz roja que parpadea. Hay un grupo electrógeno en (−447; 604,6) con cables hasta los trípodes.
- **Dos reflectores en trípode** (2,75 m) en (−440; 598,6) y (−440; 616,1). Apuntan al piso en (−405; 606,5) y (−405; 609), con 11° de apertura y 58 m de alcance. Cada uno tiene haz aditivo en la niebla, lente y destello que encandila de frente. La mancha de luz sobre el asfalto sale de una textura horneada con la sombra de los autos y se vuelve a hornear en cada `reset()`. El reflector sur titila de a ratos.
- **Balizas**: barra azul con doble destello en la cabina de cada furgón y halo azul en la niebla. Ámbar giratorio en las esquinas traseras.
- **Fila de autos detenidos**: ver «Autos tocados». Hay puertas abiertas con el hueco oscuro, balazos en el parabrisas y en la luneta, sangre en la chapa y charcos junto a las puertas.
- **Historia**: cinco bolsas negras con cuerpos contra la pared de la vereda sur, x −433,4…−426 (una corrida). Sigue un arrastre de sangre desde el paso del medio. Hay un tacho con fuego, humo y ropa quemada en (−443,4; 619), en la vereda sur detrás de la barricada, y casquillos y documentos en el piso.
- **Pintada «NO SON RESCATE»**: aerosol claro sobre una persiana baja propia, en la vereda norte, x=−397,5, 40 m antes de la barricada, como aviso para el que llega. Va apenas emisiva porque de noche una calcomanía común queda negra. Uso una persiana propia porque los frentes de FRENTES no salen iguales en todas las sesiones: en el mismo lugar vi locales distintos en dos corridas.

## `RETEN.datos` definitivo (verificado: los 16 puntos caen en `enB===0` y están conectados por casilleros libres, sin cortar esquinas)
```js
centro:{x:-438,z:607}, frente:{x:1,z:0},
puestos:[{x:-441,z:602.8,rumbo:1.57,rol:'jefe'},     // detrás del furgón norte
         {x:-433,z:607,rumbo:1.57,rol:'asalto'},     // = primer punto de la ronda
         {x:-441,z:611.2,rumbo:1.57,rol:'granadero'},// detrás del furgón sur
         {x:-437.8,z:602.8,rumbo:1.57,rol:'tirador'}],
ronda:[{-433,607},{-424.5,606.6},{-412.5,605.2},{-394.5,607.4},{-403.5,608.6},{-416.9,611.9},{-429,611.2}],  // cerrada
nido:{x:-437.8,z:602.8,y:2.59,rumbo:1.57,r:0.8},     // techo de la caja del furgón norte (y = techo real), entre el borde y el equipo de aire
reunion:{x:-447.5,z:613.3},
refuerzo:{sale:{x:-540,z:605.5},camino:[{-540,605.5},{-505,605.5},{-470,606.5},{-452,609},{-447.5,613.3}]},
luz:[{x0:-436,z0:599.75,x1:-430,z1:602.25},{x0:-436,z0:612.75,x1:-430,z1:615.25},{x0:-430,z0:599.75,x1:-424,z1:604.75},
     {x0:-430,z0:610.25,x1:-424,z1:615.25},{x0:-424,z0:599.75,x1:-418,z1:607.25},{x0:-424,z0:608.25,x1:-418,z1:615.25},
     {x0:-418,z0:600.25,x1:-412,z1:615.25},{x0:-412,z0:600.75,x1:-406,z1:614.75},{x0:-406,z0:600.75,x1:-400,z1:614.25},
     {x0:-400,z0:600.25,x1:-394,z1:615.25},{x0:-394,z0:600.25,x1:-388,z1:615.25}],
cuerpos:[5 bolsas en z≈619,4–620,2 (x −433,4…−426) + los 7 autos baleados o con puertas abiertas], pintada:{x:-397.5,z:590.77}, tris:21082
```
Notas: entre los dos haces, frente al centro de la barricada, queda una franja oscura: `luz(-428,606)=0`. La patrulla del asalto pasa por ahí con la linterna. `luz` está en 0,71 en x=−418, en 1 de −410 a −400, en 0,64 en −392 y en 0,16 en −385. Detrás de un auto da 0,26 (sombra).

## Contrato real y diferencias con 4.5
- `RETEN.armar()` devuelve `datos`. La llamo justo después de `FRENTES.build('B')` y no al final de `buildSectionB`: así la grilla del Shajar (`navInit`, que viene después) también toma las cajas nuevas. El grupo se agrega explícitamente a `SECG.B`.
- `RETEN.luz(x,z)` (0…1) mide a 1 m del piso e incluye la sombra de autos y cajas. No baja con el titileo: queda estable para la IA.
- `RETEN.reset()` va en `/*UE:reset*/`. Los autos vuelven solos por `UNDO`; `reset()` vuelve a hornear la mancha de luz (56 ms) y reinicia los efectos.
- `RETEN.ir({bichos})` llama a `startGame()`. El retén se aplica en `/*UE:start*/` con `RETEN.alEmpezar()`. Jugador en (−326; −0,15; 606), yaw π/2, paso abierto, `STAGE='B'`, `wave=5`, `bossCount=1`, escopeta 20 y Uzi 128 de reserva. Con bichos, `intermission=7`, y después arranca la oleada 6. Sin bichos, `intermission=1e9` y el cartel dice «sin bichos (prueba)». El modo se recuerda para «Otra vuelta». El botón normal lo borra con un listener en captura sobre `document`.
- Extras: `nido.r` (lo usa A), `datos.pintada`, `datos.tris`, `RETEN.fx(dt)` (en `/*UE:fx*/`), `RETEN.verificar()` (devuelve `{ok, puntos[], nidoSobreFurgon}`), `RETEN.avisos`, `RETEN.autos`, `RETEN.obs`, `RETEN.lamparas`, `RETEN.grupo`, `RETEN.piezas` (para pruebas).
- Los furgones **no son autos del juego**: son blindados. Son cajas de `obstacles` (cabina 2,15 m y caja 2,59 m), frenan balas y no explotan, así el nido no desaparece. El impacto saca el polvo genérico del juego, no chispas. Las vallas (1,1 m), la camioneta (1,57 m) y la fila de bolsas (0,28 m, se pisa) también son cajas. Trípodes, grupo electrógeno y tacho son círculos con `h`.

## Autos tocados (solo estos; se buscan por modelo y posición, no por índice; si falta uno queda en `RETEN.avisos`)
779 hatch3 (−436,23; 599,35)→(−428; 603,3) · 782 furgon (−407,19; 601,69)→(−408,6; 601,9) · 784 taxi (−400,14; 604,38)→(−399; 611,4) · 785 taxi (−380,38; 603,71)→(−390,2; 603,8), cruzado · 781 furgon (−412,47; 601,37)→(−372; 600,4) · 780 sedan (−402,7; 598,14)→(−355,5; 605). 786 y 787 quedan donde estaban, pero llevan puertas, balazos o sangre. Pasos de la fila de oeste a este: 11,1 · 8,3 · 9,6 · 8,8 · 8,5 · 9,7 m, alternando carriles. La separación mínima entre círculos de autos de la fila es 7,9 m. Ninguno pisa un árbol, farol, poste ni cantero (a menos de 0,15 m) y las 4 ruedas de cada uno caen en la calzada.
Cómo funciona: cambio `c.x/z/a/by/M/Mc` y muevo sus círculos con `circMove`, así siguen instanciados y no suman llamadas. Lo que les agrego va en mallas unidas, registrado en `c.rg`: `carBoom` lo esconde y `UNDO` lo devuelve. Si un bicho grande empuja uno (`c.dyn`), `fx` lo esconde.

## Anclas del parche
Marcadores compartidos: `/*UE:css*/`, `<!--UE:inicio-->`, `/*UE:modulos*/`, `/*UE:reset*/`, `/*UE:start*/`, `/*UE:fx*/`. Ancla propia: `FRENTES.build('B');` en `buildSectionB` (queda `FRENTES.build('B');RETEN.armar();/*UE:W*/`). F y M no la tocan, pero el integrador debería avisar si alguien edita esa línea. El módulo usa `FRENTES._ch`, que es interno, con `try` y `wallHit` de respaldo.

## Pruebas (registros en `t2/`; todo corrido)
1. Partida normal: 30 s con oleada en la zona A. Oleada 1 con 8 bichos, 0 autos de A movidos, 0 errores. De los 1263 de `VCARS` cambian solo 779, 780, 781, 782, 784 y 785. `armar` tarda 255 ms.
2. Datos: `verificar()` da 16 de 16 puntos libres y conectados, y el nido queda sobre el furgón. Caminando con W por z=606,8 desde el arranque, el jugador frena contra la valla del medio en x=−437,25. Con Espacio la salta y aterriza en x=−441,59. También salta la valla norte desde el este (llega a −440,07). Choques medidos con radio 0,45: furgones norte y sur en −436,50 (cara −436,94), valla norte desde el oeste en −438,75, valla sur en −437,25 y camioneta en −449,72.
3. Balas: con la Uzi contra el furgón 782 de la fila llega a 12 golpes y se prende en 1 s, y explota en menos de 2 s. Quedan 3 círculos muertos, 1 resto y su calcomanía escondida. Un rayo contra el furgón norte del retén para a 11,94 m en la caja y no llega a nada detrás. Con `resetGame()` todo vuelve: estado 0, misma posición, sin restos, calcomanía restaurada y `verificar` ok.
4. Bichos: con `RETEN.ir({bichos:true})` (385 ms), a los 20 s hay oleada 6, 13 bichos y 3 a menos de 4 m. Con el jugador en x=−416, 20 s después hay 18 bichos: 11 al este de la barricada, 8 a menos de 4 m y ninguno quieto en la barricada. En una corrida anterior, dos escupidores se quedaron a 22–24 m tirando desde atrás de la valla: es su distancia de ataque. `RETEN.ir({bichos:false})` tarda 3026 ms (incluye el precalentado) y en 15 s no sale ningún bicho. «Otra vuelta» vuelve al retén, y el botón normal vuelve a la 9 de Julio.
5. Costo, con 3 cuadros alternados con y sin retén y mediana. Arranque: 548→558 llamadas (+10) y +21.086 triángulos. A 50 m: 501→511 (+10) y +21.086. A 15 m: +9. Son 10 objetos propios en el pase principal: malla unida, haces, lentes, 2 destellos, mancha, calcomanías, pintada, brillos y humo, más 44 puntos. La malla unida proyecta sombra: suma 1 llamada en los cuadros en que un foco VLP actualiza una sombra que la abarca. Medido con un solo par de cuadros llegó a dar +20 por ese ruido. CPU: `fx` 12 µs por cuadro, `luz()` 2,7 µs por llamada.
6. Composición F+W: sin errores; 25 s con bichos y reinicio, con `verificar` ok.

## Capturas para mirar
- `final-mosaico-a.png`: arranque a 110 m (los reflectores y las balizas se ven), 50 m, 15 m en la fila y barricada de cerca.
- `final-mosaico-b.png`: lo que ve el soldado, bolsas y fuego, pintada y arco del Barolo.
- `final-arriba.png`: desde 44 m arriba.
- `final-arranque-sin.png` y `final-m50-sin.png`: las mismas vistas sin el retén.
- Las capturas fijan la cámara a mano y esperan a que destelle la baliza.

## Pendientes y dudas
- De lejos la baliza es un punto de 2,5 a 5 px. El destello del reflector es lo que más se lee a 110 m.
- Los reflectores no se pueden romper (`LAMP[i].on` existe, pero nada lo apaga). Faltan chispas y sonido cuando le pegan a un furgón.
- La compuerta de la camioneta no está bajada: «caja abierta» quedó como caja con carga a la vista.
- Los bichos grandes (mole, Engendro) no trepan las vallas (`enH` 11 > 9) y rodean por las veredas. No lo probé con un mole puntual.
- El titileo usa `Math.random` (solo visual).
- Ninguna captura la miré con el retén de noche en la PC real (todo es SwiftShader). Conviene que Facu revise el brillo de la mancha y del haz.
