/* posturas: agachado, a tierra con láser, transición, corriendo, asomarse a los dos lados, caminar, de costado */
const v=(rol,pose,t,az,el,txt,o={})=>Object.assign({rol,pose,t,az,el,dist:3.4,obj:[0,.9,0],txt},o);
module.exports={cols:4,vistas:[
  v('granadero','Agachado',1.6,.75,.1,'agachado apuntando',{obj:[0,.6,0],dist:2.9}),
  v('tirador','Cuerpo a tierra',2.6,1.05,.22,'tirador a tierra, bípode y láser',{laser:true,obj:[0,.25,.6],dist:3.2}),
  v('jefe','Cuerpo a tierra',.62,1.3,.12,'yendo al piso (transición)',{obj:[0,.5,0],dist:3.2}),
  v('asalto','Corre',1.6,0,.06,'corriendo',{seguir:true,relAz:Math.PI/2,dist:3.8}),
  v('jefe','Asoma',4.0,0,.06,'asoma a la izquierda',{dist:3.3}),v('jefe','Asoma',1.3,0,.06,'asoma a la derecha',{dist:3.3}),
  v('granadero','Camina',1.7,0,.08,'caminando con el arma lista',{seguir:true,relAz:Math.PI/2+.4}),
  v('tirador','De costado',1.0,.2,.08,'de costado, apuntando',{seguir:true})]};
