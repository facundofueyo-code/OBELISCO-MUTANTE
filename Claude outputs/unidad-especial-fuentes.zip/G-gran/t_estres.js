/* 2000 tiros al azar en la cuadra del retén con la física de verdad (GRAN._int.paso), arrancando siempre en la calle
   (sin pared entre el punto de partida y el medio de la avenida). Cuenta: cruces de pared, bajo el piso, dentro de autos,
   y granadas que terminan detrás de una pared respecto del medio de la avenida. */
const H=require('../harness.js'),fs=require('fs'),path=require('path');
/* copia de prueba: base + módulo con la física expuesta (GRAN._int) */
{const mod=fs.readFileSync(path.join(__dirname,'mod_gran.js'),'utf8').replace('return {lanzar,lista,','return {_int:{paso,locArmar,mkLoc},lanzar,lista,');
 const b=fs.readFileSync(path.join(__dirname,'../v116/base.html'),'utf8').replace('/*UE:modulos*/',mod+'\n/*UE:modulos*/').replace('/*UE:update*/','GRAN.update(dt);/*UE:update*/').replace('/*UE:fx*/','GRAN.fx(dt);/*UE:fx*/').replace('/*UE:reset*/','GRAN.reset();/*UE:reset*/');
 fs.writeFileSync(path.join(__dirname,'dbg.html'),b);}
(async()=>{const h=await H.open(__dirname+'/dbg.html');
 try{await h.start();await h.alReten();await h.step(.3);
  console.log('ESTRES',JSON.stringify(await h.ev(`(()=>{const I=GRAN._int,V=THREE.Vector3,R=GRAN.TUNE.R;let s=777;const rnd=(a,b)=>{s=(s*16807)%2147483647;return a+(b-a)*(s/2147483647);};
    const viol={pared:0,piso:0,auto:0,detras:0},ej=[];let pasos=0,quietas=0,tiros=0,piques=0,choques=0;const pv=new V(),d=new V(),C=new V();
    const libre=(a,b)=>{d.subVectors(b,a);const l=d.length();if(l<1e-6)return true;d.multiplyScalar(1/l);return rayWalls(a,d,l)>=l;};
    for(let k=0;k<2000;k++){const S=new V(rnd(-470,-330),0,rnd(590,623));if(isSolid(S.x,S.z))continue;S.y=floorAt(S.x,S.z)+rnd(.2,2.5);
      C.set(S.x,S.y,606);if(!libre(C,S))continue;
      if(VCARS.some(c=>c.st<3&&Math.hypot(S.x-c.x,S.z-c.z)<c.L*.5+.3))continue;tiros++;
      const sp=rnd(2,18),az=rnd(0,6.28),el=rnd(-.5,1.3);const g={p:S.clone(),v:new V(Math.cos(az)*Math.cos(el)*sp,Math.sin(el)*sp,Math.sin(az)*Math.cos(el)*sp),k:0,quieta:false,enPiso:false,mat:0};
      const L=I.mkLoc();let Lx=S.x,Lz=S.z;I.locArmar(L,S.x-12,S.z-12,S.x+12,S.z+12);
      for(let i=0;i<240;i++){if(Math.abs(g.p.x-Lx)>6||Math.abs(g.p.z-Lz)>6||g.k%30===29){I.locArmar(L,g.p.x-12,g.p.z-12,g.p.x+12,g.p.z+12);Lx=g.p.x;Lz=g.p.z;}
        pv.copy(g.p);const ev=I.paso(g,L);pasos++;if(ev===2)piques++;if(ev===1)choques++;const p=g.p;
        if(!libre(pv,p)){viol.pared++;if(ej.length<8)ej.push(['pared',k,i,pv.toArray().map(v=>+v.toFixed(3)),p.toArray().map(v=>+v.toFixed(3))]);}
        const fl=floorAt(p.x,p.z);if(p.y-R<fl-.003){viol.piso++;if(ej.length<8)ej.push(['piso',k,i,p.toArray().map(v=>+v.toFixed(3)),+fl.toFixed(3)]);}
        for(const c of L.ca){if(c.st>=3)continue;const rx=p.x-c.x,rz=p.z-c.z;if(rx*rx+rz*rz>c.L*c.L)continue;const ca=Math.cos(c.a),sa=Math.sin(c.a),lx=rx*ca-rz*sa,lz=rx*sa+rz*ca;
          if(Math.abs(lx)<c.W/2-.01&&Math.abs(lz)<c.L/2-.01){const top=c.crushed?c.by+c.H*.4:(MOV.carOK(c)?MOV.carTop(c,-lz):c.by+c.H*.97);if(p.y<top-.05){viol.auto++;if(ej.length<8)ej.push(['auto',k,i,VCARS.indexOf(c),p.toArray().map(v=>+v.toFixed(2)),+top.toFixed(2)]);}}}
        if(g.quieta){quietas++;break;}}
      C.set(g.p.x,Math.max(g.p.y,.5),606);if(!libre(C,new V(g.p.x,Math.max(g.p.y,.5),g.p.z))){viol.detras++;if(ej.length<8)ej.push(['detras',k,g.p.toArray().map(v=>+v.toFixed(2))]);}}
    return {tiros,pasos,quietas,piques,choques,viol,ej};})()`)));
 }catch(e){console.log('ERR',String(e.stack||e).slice(0,800));}
 finally{console.log('errors',JSON.stringify(h.errors.slice(0,5)));await h.close();}})();
