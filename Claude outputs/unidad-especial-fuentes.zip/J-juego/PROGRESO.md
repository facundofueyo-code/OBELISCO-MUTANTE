# J · integración (v1.17.0) — progreso

- [x] Leídos SPEC (0,1,2.1,3,4,5,7), INDICE v116 e informes de A, S, F, G, M, W.
- [x] Los cuatro parches de piezas (F, G, M, W) componen sobre `v116/base.html` sin tocar nada.
- [x] `mod_pegamento.js` + `patch_pegamento.py`
- [x] `armar_juego.py` + `rearmar.sh` (rearmar desde el original da el mismo archivo byte a byte; fallas con mensaje claro probadas)
- [x] Carga sin errores (t0)
- [x] Prueba 1 partida normal (t1) · 2 retén sin bichos (t2) · 3 modelo/IA (t3) · 4 con bichos (t4) · 5 muerte y otra vuelta (t5) · 6 costo (t6_costo, t6_cpu, t6_picos)
- [x] Prueba 7 capturas (c1–c6; la primera tarda ~4 min; dos corridas murieron por memoria a 854×480)
- [x] Arreglo del nido (r 0,8 → 3,5) y repetición de t2, t5, t6
- [x] Captura del láser (`c5b`), HUD sin «TE VIERON» contra bichos (t10), regresión final t0/t4/t5 sin errores
- [x] Entrega: archivos finales, INFORME y CHANGELOG-entrada con los números de la versión final


## Decisiones
- El tirador NO recibe puesto en `UE.escuadron` (solo `nido`): si tiene puesto, `poblar()` de la IA no lo sube al techo.
- Jefe y granadero no ven la avenida desde sus puestos (0 de 9 puntos): el pegamento corre al que menos se tenga que mover. Sale el jefe, de (−441; 602,8) a (−441; 606,3): 3,5 m al sur, del furgón norte al paso del medio detrás de las vallas; ve 5 de 9 puntos.
- `ENV.rayo` con grillas propias de cajas (8 m) y de autos (16 m, se rehace solo si algún auto se movió): 106 → 10 µs por rayo, mismo resultado que `rayCars` en 2000 rayos.
- `verModelos` sin `camera.updateMatrixWorld` (recorría el arma en primera persona: 0,37 ms por cuadro): cono horizontal desde `P.yaw`.
- Animación por distancia: cada cuadro a <15 m en pantalla, 1 de 2 hasta 40 m, 1 de 3 más lejos, 1 de 6 fuera de pantalla; nada a >170 m o con la sección B oculta.
- `nido.r` 0,8 → 3,5 (ver INFORME §4.0): sin eso el tirador no veía nada desde el techo.
- `GRAN.arco`: tope de 4 ms por cuadro (la IA vuelve a probar en su próxima vuelta) y una llamada de precalentado al reiniciar (la primera tarda ~26 ms).
- Perdigones: el daño de un disparo se junta por soldado y parte y se aplica una vez (así aturde como un golpe).
- Botín del tirador muerto en el techo: al piso libre más cercano.
