# Tarea W — el retén en el mapa real

Leé primero `../SPEC.md` entero (sobre todo 0, 1, 2, 3, 4.5, 6, 7 y 8). Tu carpeta es `W-reten/`.

## Qué tenés que lograr

El lugar donde pasa todo: un **retén de la unidad especial cortando Av. de Mayo a la altura del Palacio Barolo**, construido en el mapa real del juego, más los datos que necesita la IA para pararse ahí y un botón para ir directo a probarlo.

Tiene que contar la historia sin una línea de texto explicativo: acá pararon a la gente que quería salir de la zona y no dejaron pasar a nadie. Y tiene que ser un buen lugar para pelear: el jugador llega desde el este por una avenida ancha y necesita coberturas para acercarse; los soldados tienen que tener dónde cubrirse, por dónde flanquear y dónde poner al tirador.

Entregás un módulo `RETEN` (`mod_reten.js`) y un parche sobre `../base.html` (protocolo en 3.3). Contrato en 4.5.

## Antes de escribir

Mirá `../mapa-reten.png` y `../mapa-reten-zoom.png` (la zona vista desde arriba) y la sección 6 de la SPEC (medidas y disposición provisoria). Leé en `../base-view.txt`:

- Secciones del mapa (~1270–1285): todo lo que se agrega a la escena mientras se construye la sección B cae en `SECG.B` (se oculta sola de lejos). `buildSectionB()` (~7334).
- Autos (~3160–3360): `CARS` (fichas de los 11 modelos: `taxi, sedan, hatch3, hatch5, pickup, suv, rural, furgon, clasico, patrullero, ambulancia`), `vModel`, `bCars` (cómo se crea cada auto: los que tienen luces llevan malla propia; el resto va instanciado), `VCARS`, los tres círculos de choque de cada auto (`addCircle`, `q.brk={k:'car',c}`, `q.h`), `rayCars`, `carDamage`, `carBoom`, `killCircle`, y el mecanismo `UNDO` / `restoreProps()` que deja todo como estaba al reiniciar. Fijate cómo el juego pasa un auto instanciado a malla propia cuando lo empuja un bicho grande (buscá `dyn`): es el camino para tener autos propios puestos a mano. `VEH.car(S,…)` acepta estados de daño (`S.d`): puertas abiertas, vidrios rotos, balazos, sangre, pintada «AYUDA» (mirá `VEH` ~2593 y `TEX` ~2982).
- Colisiones (~1526–1575 y ~10743): `obstacles` (cajas), `WALLS` + `addWallRing`, `addCircle`. Navegación (~10762): `enDirty(x0,z0,x1,z1)` para que la grilla tome lo nuevo; `FLOORFN` (~2366) para pisos elevados.
- Luces falsas: cómo hace el juego los haces de los proyectores del Obelisco (buscá `OBL`, ~1597) y los brillos (`glowSprite`, `GL_AMB`, `GL_RED`): mallas aditivas y sprites, **sin luces reales**. Los tachos con fuego de la Casa Rosada (buscá `tacho`) y el fuego de los autos (`vSpawn('fire'…)`).
- Pintadas en paredes y piso de los edificios nuevos (buscá `NO SUBAN` o `QUIÉN PRENDE EL FARO`).
- Pantalla de inicio y `startGame()` (~11621), `resetGame()` (~11560), oleadas (`wave`, `intermission`, `startWave`, `updateWaves` ~11332), `openGate()`/`STAGE` (~1272 y ~7321), `resetWeapons()`.

## El retén

Partí de la disposición provisoria de la sección 6 y **ajustala sobre el mapa real** (tenés ±3 m de libertad; si cambiás más, justificá). Lo que tiene que haber:

1. **La barricada**: dos furgones negros sin patente ni identificación, atravesados, cerrando la calzada, con un paso en el medio cerrado con vallas. Elegí el modelo que mejor dé como «furgón táctico sin marcas»: el de la ambulancia (5,9 m de largo y 2,74 de alto) pintado de negro mate y sin ploteo es buen candidato; el `furgon` del juego es chico. Con balizas azules o ámbar destellando (a Facu le gustó el patrullero con balizas como toque de terror). Vallas en las puntas hasta el cordón.
2. **Camioneta de mando** detrás (una `pickup` negra), con la caja abierta: cajas, una antena.
3. **Dos reflectores** en trípode, en las puntas de la barricada, apuntando al este: haz visible en la niebla y una mancha de luz sobre el asfalto (malla aditiva o calcomanía, no luz real). Uno puede titilar. Tienen que **encandilar un poco** al que viene de frente: de lejos se ven las siluetas contra la luz.
4. **La fila de autos detenidos** al este de la barricada, a lo largo de unos 60 m: seis o siete autos civiles parados en dos carriles, algunos con puertas abiertas, vidrios rotos, balazos. Son la cobertura del jugador: que haya una cada 8 a 12 m, alternando carriles, para que se pueda avanzar de auto en auto, y que ninguna quede pegada a otra. Aprovechá los dos autos que ya existen en la zona (o sacalos si estorban) y **sacá los que caigan adentro de la barricada**.
5. **Lo que cuenta la historia**: bolsas negras con cuerpos en fila sobre la vereda sur, cerca de la barricada; un tacho o una pila ardiendo donde queman documentos y ropa; vainas en el piso; una pintada hecha por algún sobreviviente en una pared cercana, del lado este: **«NO SON RESCATE»**. Sobrio: nada de cartelería ni logos, ellos no dejan marcas.
6. **El nido del tirador**: el techo del furgón norte. Dejá el dato (`nido`, con `y` = altura real del techo). El piso del juego tiene un solo nivel, así que nadie camina hasta ahí: el tirador aparece en ese lugar.

**Colisiones y navegación**: todo lo que pongas choca con el jugador y con los bichos, frena balas y figura en la grilla (`enDirty`). Las vallas son trepables (1,1 m). Los furgones bloquean (más de 1,7 m). Los autos de la fila tienen que comportarse como cualquier auto del juego: frenan balas, se dañan, se prenden fuego, explotan, y vuelven a su estado al reiniciar la partida.

**Costo**: el retén entero, menos de 25 llamadas de dibujo y 70 mil triángulos a la vista. Medilo (`renderer.info`) antes y después.

**Cuándo se arma**: una vez, al construir la sección B (`RETEN.armar()` al final de `buildSectionB()`), para que quede adentro de `SECG.B`. `RETEN.reset()` en `/*UE:reset*/`.

## Los datos para la IA (`RETEN.datos`)

Con la forma de 4.5. Verificá **cada punto** contra la grilla real después de armar: los `puestos`, los puntos de la `ronda`, `reunion`, `refuerzo.sale` y cada punto del `camino` tienen que caer en casilleros libres (`enB===0`) y estar conectados caminando entre sí. Puestos: jefe y granadero detrás de la barricada, con cobertura; el asalto recorre la fila de autos con la linterna, revisándolos; el tirador en el nido. `luz`: los rectángulos realmente iluminados por los reflectores. Sumá también `RETEN.luz(x,z)` → 0…1 (1 de lleno en el haz, cayendo en los bordes).

## El botón para ir directo

En la pantalla de inicio, debajo del botón normal (`<!--UE:inicio-->`), dos botones con el mismo estilo pero secundarios, y una línea que aclare que es una prueba:

- **«Ir al retén»**: arranca la partida (`startGame()`), abre el paso y deja al jugador en Av. de Mayo y Santiago del Estero (`x≈-326, z≈606`), mirando al oeste, con las oleadas de bichos andando como en la partida normal de esa zona (que el contador de oleada no arranque de cero: como si ya hubiera pasado al Engendro) y munición razonable (escopeta 20, Uzi 128).
- **«Ir al retén sin bichos»**: igual, pero sin oleadas, para probar a los soldados solos.

Eso es `RETEN.ir({bichos})`. Tiene que funcionar también al reiniciar después de morir (el botón «Otra vuelta» de la pantalla de fin: si la partida era de retén, que vuelva al retén). En la partida normal, sin estos botones, el retén está igual en su lugar cuando el jugador llega caminando.

## Pruebas (con `../harness.js`)

1. Partida normal de 30 s con oleada en la zona A: sin errores, y los autos de la 9 de Julio como siempre.
2. `RETEN.ir({bichos:false})`: el jugador queda donde tiene que quedar. Volcá la grilla alrededor del retén y comprobá los datos (puntos libres y conectados). Caminá al jugador automático por la avenida hasta la barricada (`keys.KeyW`): choca contra autos, vallas y furgones, puede saltar las vallas.
3. Balas: tirale a un auto de la fila hasta prenderlo y que explote; a un furgón. Reiniciá: todo vuelve.
4. Bichos: con `RETEN.ir({bichos:true})`, 40 s: salen bichos y llegan al jugador sin trabarse en la barricada.
5. **Capturas** (960×540, mirá cada una): desde el arranque mirando al oeste (¿se ven las balizas y los reflectores a 110 m en la niebla?); desde 50 m; desde 15 m entre los autos de la fila; la barricada de cerca; desde atrás de la barricada mirando al este (lo que ve un soldado); las bolsas y el fuego; la pintada; desde el arco del Barolo; una desde arriba (subí la cámara 40 m mirando hacia abajo). Ajustá hasta que se lea bien y dé mala espina.
6. Costo: llamadas de dibujo y triángulos con y sin retén desde el arranque.

## Qué no hacer

- No agregues luces reales (ni `PointLight` ni `SpotLight`).
- No rompas el reinicio: después de `resetGame()` el retén tiene que estar entero otra vez.
- No pongas soldados: los pone el integrador con tus datos.
- No toques nada fuera de `W-reten/`.
