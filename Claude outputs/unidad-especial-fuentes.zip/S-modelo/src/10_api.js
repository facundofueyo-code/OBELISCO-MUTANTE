
/* ====================================================================================
   ACCESORIOS Y EFECTOS: arma suelta, cargador, corredera, bípode, granada en la mano, vainas,
   antena del jefe, linterna, láser, fogonazo y luz de la nuca. Todo con huesos: nada se crea.
   ==================================================================================== */
function soltar(st){
  if(st.armaSuelta)return;st.armaSuelta=true;st.caida=0;
  const W=st.arma,f=_v[0].set(0,0,1).applyQuaternion(W.q),r=st.azar;
  st.armaP0.copy(W.p);st.armaQ0.copy(W.q);
  const ya=Math.atan2(f.x,f.z)+(r()-.5)*.9;
  st.armaP1.set(W.p.x+f.x*.2+(r()-.5)*.25,.062,W.p.z+f.z*.2+(r()-.5)*.25);
  qE(st.armaQ1,0,ya,(r()<.5?1:-1)*PI/2);                   /* queda de costado */
}
function caidaArma(st,dt){
  st.caida+=dt;const t=sat(st.caida/.5),W=st.arma;
  W.p.x=lerp(st.armaP0.x,st.armaP1.x,1-(1-t)*(1-t));W.p.z=lerp(st.armaP0.z,st.armaP1.z,1-(1-t)*(1-t));
  W.p.y=lerp(st.armaP0.y,st.armaP1.y,t*t);
  const d=st.caida-.5;if(d>0&&d<.18)W.p.y+=.03*Math.sin(PI*d/.18);
  W.q.copy(st.armaQ0).slerp(st.armaQ1,sst(0,.8,t));
}
const _ac=new V3(),_ad=new V3(),_aq=new Q4(),_aq2=new Q4(),CERO=new V3(0,0,0),UNO=new V3(1,1,1);
function accesorios(st,e,dt){
  const P=st.P,Q=st.Q,S=st.Sc,fi=st.ficha,W=st.arma,r=st.azar;
  if(st.armaSuelta&&dt>0)caidaArma(st,dt);
  P[H.arma].copy(W.p);Q[H.arma].copy(W.q);
  /* corredera de la escopeta: bombea después de cada tiro (la mano izquierda va con ella) */
  if(st.bomba>=0){st.bomba+=dt/.42;if(st.bomba>=1)st.bomba=-1;
    if(st.bomba>.4&&!st.bombaVaina){st.bombaVaina=true;tirarVaina(st);}}
  st.bombaZ=st.bomba>=0?.075*curva(st.bomba,KC18):0;
  if(st.bombaEspera>0){st.bombaEspera-=dt;if(st.bombaEspera<=0){st.bomba=0;st.bombaVaina=false;}}
  if(fi.corredera){P[H.corredera].set(fi.corredera.x,fi.corredera.y,fi.corredera.z-st.bombaZ).applyQuaternion(W.q).add(W.p);Q[H.corredera].copy(W.q);}
  /* cargador: en el arma, en la mano izquierda o guardado */
  const esc=fi.tipo==='escopeta',enMano=st.cargEnMano&&!st.muerto&&e.recarga>=0;
  S[H.cargador].copy(esc?(enMano&&st.cargVis?UNO:CERO):(st.cargVis||st.muerto?UNO:CERO));
  if(enMano){_ac.set(-.037,-.09,0).applyQuaternion(Q[H.manoI]).add(P[H.manoI]);
    if(esc){P[H.cargador].copy(_ac);Q[H.cargador].copy(Q[H.manoI]).multiply(qE(_aq,0,0,PI/2));}
    else{Q[H.cargador].copy(W.q);_ad.set(0,-.1,.02).applyQuaternion(W.q);P[H.cargador].copy(_ac).sub(_ad);}}
  else{P[H.cargador].copy(fi.cargador).applyQuaternion(W.q).add(W.p);Q[H.cargador].copy(W.q);}
  /* bípode: se abre cuerpo a tierra */
  if(fi.bipode){const ab=st.muerto?0:sst(.75,.95,st.ti);P[H.bipode].copy(fi.bipode).applyQuaternion(W.q).add(W.p);Q[H.bipode].copy(W.q).multiply(qE(_aq,ab*1.5,0,0));}
  /* granada en la mano derecha */
  S[H.granada].copy(st.granVis&&!st.muerto?UNO:CERO);
  P[H.granada].set(.036,-.088,.004).applyQuaternion(Q[H.manoD]).add(P[H.manoD]);Q[H.granada].copy(Q[H.manoD]);
  /* vainas: vuelan a la derecha, rebotan y desaparecen */
  for(let i=0;i<2;i++){const v=st.vainas[i],b=H.vaina1+i;
    if(v.t>0&&dt>0){v.t-=dt;v.v.y-=9.8*dt;v.p.addScaledVector(v.v,dt);
      if(v.p.y<.008){v.p.y=.008;v.v.y=Math.abs(v.v.y)*.3;v.v.x*=.5;v.v.z*=.5;v.w*=.5;}
      v.a+=v.w*dt;}
    S[b].copy(v.t>0?UNO:CERO);P[b].copy(v.p);qE(Q[b],v.a,v.a*.7,PI/2);}
  /* antena del jefe: látigo con resorte, la sacude la aceleración del pecho */
  if(st.rol==='jefe'){
    aModelo(st,H.pecho,.06,.205,-.195,_ac);
    if(dt>0){const ax=((_ac.x-st.antP.x)/dt-st.antV.x)/dt,az=((_ac.z-st.antP.z)/dt-st.antV.z)/dt;
      st.antV.set((_ac.x-st.antP.x)/dt,0,(_ac.z-st.antP.z)/dt);
      const A=st.ant,w=7,z=.18,lim=40;
      A.vx+=(-w*w*A.x-2*z*w*A.vx-clamp(ax,-lim,lim)*.02+.15*Math.sin(st.t*1.7+st.fase0))*dt;A.x+=A.vx*dt;
      A.vz+=(-w*w*A.z-2*z*w*A.vz-clamp(az,-lim,lim)*.02+.12*Math.sin(st.t*1.3))*dt;A.z+=A.vz*dt;}
    st.antP.copy(_ac);
    /* tres tramos: cada uno se dobla un poco más; si la punta tocaría el piso, el tramo se acuesta */
    let b=H.antena1;P[b].copy(_ac);
    for(let j=0;j<3;j++){const f=(j+1)*.45;qE(_aq,-.12-st.ant.z*f*(j?1:.3),0,st.ant.x*f*(j?1:.3));
      _aq2.copy(j?Q[b+j-1]:Q[H.pecho]).multiply(_aq);
      if(j)P[b+j].copy(_ad);
      _ad.set(0,.34,0).applyQuaternion(_aq2);const y1=P[b+j].y+_ad.y*st.k;
      if(y1<.04){_ad.y=Math.max(_ad.y,(.04-P[b+j].y)/1);const h=Math.hypot(_ad.x,_ad.z)||1e-6,l=Math.sqrt(Math.max(0,.1156-_ad.y*_ad.y));_ad.x*=l/h;_ad.z*=l/h;
        _aq2.setFromUnitVectors(EJY,_ac.copy(_ad).normalize());_ac.copy(P[b]);}
      Q[b+j].copy(_aq2);_ad.add(P[b+j]);}
  }
  /* linterna */
  const luz=!!e.luz&&!!fi.luz;S[H.haz].copy(luz?UNO:CERO);
  if(fi.luz){P[H.haz].copy(fi.luz).applyQuaternion(W.q).add(W.p);Q[H.haz].copy(W.q);}
  /* fogonazo: ~50 ms por tiro, girado al azar */
  if(st.flashT>0){st.flashT-=dt;S[H.fogonazo].setScalar(st.flashEsc);}else S[H.fogonazo].copy(CERO);
  P[H.fogonazo].copy(fi.boca).applyQuaternion(W.q).add(W.p);Q[H.fogonazo].copy(W.q).multiply(qE(_aq,0,0,st.flashRoll));
  /* láser del tirador: del módulo hasta el punto (mundo → modelo) */
  if(fi.laser&&e.laser&&!st.armaSuelta){
    _ac.copy(fi.laser).applyQuaternion(W.q).add(W.p);P[H.laser].copy(_ac);
    const L=e.laser,dx=(L.x-st.px)/st.k,dz=(L.z-st.pz)/st.k;
    _ad.set(st.cy*dx-st.sy*dz,(L.y-st.py)/st.k,st.sy*dx+st.cy*dz);P[H.laserPunto].copy(_ad);
    _ad.sub(_ac);const d=_ad.length();
    if(d>.05){qBase(Q[H.laser],_ad,EJY);S[H.laser].set(1,1,d);S[H.laserPunto].setScalar(1);}
    else{S[H.laser].copy(CERO);S[H.laserPunto].copy(CERO);}
  }else{S[H.laser].copy(CERO);S[H.laserPunto].copy(CERO);}
  /* luz de la nuca: un destello corto cada 1,4 s */
  const fl=fr(st.t/1.4+st.fase0);S[H.led].setScalar(fl<.065?1:0);
  P[H.led].set(0,.137,st.rol==='tirador'?-.168:-.152).applyQuaternion(Q[H.cabeza]).add(P[H.cabeza]);Q[H.led].copy(Q[H.cabeza]);
  /* complexión: pecho y cadera un poco más anchos o angostos */
  S[H.pecho].set(st.kx,1,st.kz);S[H.cadera].set(st.kx*.5+.5,1,1);
}
function tirarVaina(st){
  const fi=st.ficha,W=st.arma,v=st.vainas[st.vainaI],r=st.azar;st.vainaI^=1;
  v.t=.9;v.p.copy(fi.eyeccion).applyQuaternion(W.q).add(W.p);
  v.v.set(-1.6-r()*.8,.9+r()*.6,-.3+r()*.4).applyQuaternion(W.q);v.a=r()*TAU;v.w=18+r()*14;
}

/* ====================================================================================
   CREAR UN SOLDADO
   ==================================================================================== */
const E_INICIAL=()=>({agach:0,tierra:0,apunta:0,mYaw:0,mPitch:0,asoma:0,recarga:-1,salto:-1,lanza:-1,lanzaSale:.55,
  senal:-1,senalTipo:'avanzar',culata:-1,radio:0,aturdido:0,muerte:null,luz:false,laser:null});
const _rs=new V3(),_ro=new V3(),_rd2=new V3(),_rm=new M4(),_rq2=new Q4(),_rv=new V3();
function crear(rol,op={}){
  if(!ROLES[rol])rol='asalto';
  materiales();const geo=geometriaDe(rol);
  const sem=op.semilla===undefined?(Math.random()*1e9)|0:op.semilla,azar=azarDe(sem*7919+13);
  const huesos=HUESOS.map(h=>{const b=new THREE.Bone();b.name=h[0];return b;});
  const esq=new THREE.Skeleton(huesos,INVERSAS);
  const malla=new THREE.SkinnedMesh(geo.cuerpo,MAT.cuerpo);malla.bind(esq,new M4());malla.castShadow=true;malla.receiveShadow=true;malla.name='UEM cuerpo';
  const fx=new THREE.SkinnedMesh(geo.fx,MAT.fx);fx.bind(esq,new M4());fx.frustumCulled=false;fx.renderOrder=3;fx.name='UEM efectos';
  const k=1+(azar()-.5)*.06,grupo=new THREE.Group();grupo.scale.setScalar(k);grupo.add(malla,fx,...huesos);
  const root=new THREE.Group();root.name='UE '+rol;root.add(grupo);
  const pie=()=>({w:new V3(),pos:new V3(),desde:new V3(),yaw:0,yawAct:0,desdeYaw:0,vuelo:false,modo:0,s:0,q0:0,ciclo:-9,dur:.3,alza:.1,alto:0,cab:0});
  const st={rol,ficha:geo.ficha,azar,k,kx:1+(azar()-.5)*.08,kz:1+(azar()-.5)*.06,ritmo:1+(azar()-.5)*.12,respira:.7+azar()*.6,fase0:azar(),
    P:HUESOS.map(()=>new V3()),Q:HUESOS.map(()=>new Q4()),Sc:HUESOS.map(()=>new V3(1,1,1)),huesos,
    t:azar()*10,nuevo:true,reubicar:true,prevX:0,prevZ:0,prevYaw:0,yaw:0,px:0,pz:0,py:0,cy:1,sy:0,dist:0,dyaw:0,vel:new V3(),rap:0,vlx:0,vlz:0,
    fase:azar(),faseR:0,pie:[pie(),pie()],rest:[new V3(),new V3()],restYaw:[0,0],errPie:[0,0],pausaPaso:0,
    ap:0,ag:0,ti:0,as:0,mYaw:0,mPitch:0,radio:0,aturd:0,yawPecho:0,
    sp:nuevaPose(),sp0:nuevaPose(),poseT:nuevaPose(),mk:[nuevaPose(),nuevaPose(),nuevaPose(),nuevaPose()],muerto:false,mTipo:'',mPedido:'',mT:0,
    arma:{p:new V3(),q:new Q4()},pAim:new V3(),qAim:new Q4(),pLow:new V3(),qLow:new Q4(),
    armaSuelta:false,caida:0,armaP0:new V3(),armaQ0:new Q4(),armaP1:new V3(),armaQ1:new Q4(),
    rp:0,rpv:0,rb:0,rbv:0,gp:0,gpv:0,gr:0,grv:0,golpeT:0,flashT:0,flashEsc:1,flashRoll:0,
    bomba:-1,bombaZ:0,bombaEspera:0,bombaVaina:false,cargVis:1,cargEnMano:0,granVis:0,saltoW:new V3(),saltoFijo:false,
    vainas:[{t:0,p:new V3(),v:new V3(),a:0,w:0},{t:0,p:new V3(),v:new V3(),a:0,w:0}],vainaI:0,
    ant:{x:0,z:0,vx:0,vz:0},antP:new V3(),antV:new V3()};
  const u={root,e:E_INICIAL(),rol,semilla:sem,_st:st,malla,efectos:fx};
  u.update=dt=>{
    dt=dt>0?Math.min(dt,.1):0;st.t+=dt;st.py=root.position.y;
    movimiento(st,root,dt);
    /* resortes: patada del arma y sacudones */
    if(dt>0){const n=Math.ceil(dt/.0085),h=dt/n;for(let i=0;i<n;i++){resorte(st,'rp','rpv',26,.55,h);resorte(st,'rb','rbv',30,.7,h);resorte(st,'gp','gpv',13,.42,h);resorte(st,'gr','grv',13,.42,h);}}
    st.golpeT=Math.max(0,st.golpeT-dt);
    if(u.e.muerte)muerte(st,u.e,dt);else{if(st.muerto)u.revivir();vivo(st,u.e,dt);}
    accesorios(st,u.e,dt);
    for(let i=0;i<NH;i++){const b=huesos[i];b.position.copy(st.P[i]);b.quaternion.copy(st.Q[i]);b.scale.copy(st.Sc[i]);}
  };
  u.disparo=()=>{const f=st.ficha.patada,r=azar;
    st.rpv+=2.4*f*(.85+.3*r());st.rbv+=.5*f;st.flashT=.055;st.flashRoll=r()*TAU;st.flashEsc=.8+.4*r();
    if(st.ficha.tipo==='escopeta'){st.bombaEspera=.14;}else tirarVaina(st);};
  u.golpe=(dir,f)=>{f=sat(f===undefined?1:f);const px=-Math.sin(dir||0),pz=-Math.cos(dir||0);
    st.gpv+=pz*f*6;st.grv+=-px*f*6;st.golpeT=Math.max(st.golpeT,.35*f);};
  const mundo=v=>{grupo.updateWorldMatrix(true,false);return v.applyMatrix4(grupo.matrixWorld);};
  u.boca=v3=>mundo(v3.copy(st.ficha.boca).applyQuaternion(st.arma.q).add(st.arma.p));
  u.ojos=v3=>mundo(v3.set(0,.10,.075).applyQuaternion(st.Q[H.cabeza]).add(st.P[H.cabeza]));
  u.mano=v3=>mundo(v3.set(.036,-.088,0).applyQuaternion(st.Q[H.manoD]).add(st.P[H.manoD]));
  const hit={t:0,parte:''};
  u.rayo=(o,d)=>{
    grupo.updateWorldMatrix(true,false);_rm.copy(grupo.matrixWorld).invert();
    _ro.copy(o).applyMatrix4(_rm);_rd2.copy(d).transformDirection(_rm);
    let best=Infinity,parte=null;
    for(const s of ESFERAS){_rs.copy(s.o).applyQuaternion(st.Q[s.b]).add(st.P[s.b]);
      _rv.subVectors(_ro,_rs);const b=_rv.dot(_rd2),c=_rv.lengthSq()-s.r*s.r,di=b*b-c;if(di<0)continue;
      const sq=Math.sqrt(di);let t=-b-sq;if(t<0)t=-b+sq;if(t>=0&&t<best){best=t;parte=s.parte;}}
    if(!parte)return null;hit.t=best*st.k;hit.parte=parte;return hit;};
  u.soltarArma=()=>soltar(st);
  u.revivir=()=>{st.muerto=false;st.armaSuelta=false;st.reubicar=true;st.mPedido='';u.e.muerte=null;st.bomba=-1;};
  u.dispose=()=>{if(root.parent)root.parent.remove(root);esq.dispose();};
  u.update(0);
  return u;
}

/* muestra de cada rol con todo prendido, para que el juego compile los shaders al cargar */
let MUESTRAS=null;
function calentar(scene,on){
  if(on){if(MUESTRAS)return MUESTRAS.length;MUESTRAS=[];
    Object.keys(ROLES).forEach((rol,i)=>{const u=crear(rol,{semilla:i+1});u.root.position.set(i*2,-60,0);
      u.e.luz=true;u.e.laser=new V3(i*2,-60,20);u.e.apunta=1;u.update(1/60);u._st.flashT=1;u.e.recarga=.3;u.e.lanza=.3;u.update(1/60);
      scene.add(u.root);MUESTRAS.push(u);});
    const g=granada();g.position.set(-2,-60,0);scene.add(g);MUESTRAS.push({dispose:()=>{if(g.parent)g.parent.remove(g);}});
    return MUESTRAS.length;}
  if(MUESTRAS){MUESTRAS.forEach(u=>u.dispose());MUESTRAS=null;}return 0;
}
function info(rol){const g=geometriaDe(rol);return {triangulos:g.tris,triangulosEfectos:g.trisFx,llamadas:2};}

return {ROLES,crear,granada,calentar,info,VERSION:'1.0',
  _interno:{Constructor,H,torso,brazo,mano,pierna,cabeza,fusil,escopeta,tirador,granadaGeo,armarFx,MUERTES,CLAVES_M}};
})();
