/* =====================================================================
   UNIDAD ESPECIAL · R — lo que el jugador gana al matarlos (v1.15.0)
   · el FUSIL en primera persona: cuarta arma (W[3], tecla 4). No se tiene hasta levantar uno.
   · las GRANADAS: el sistema GRAN (física, mecha, explosión), que también usan los soldados,
     y las del jugador (tecla G, gesto de la mano izquierda, contador en el HUD).
   · las CAJAS DE BOTÍN que sueltan los soldados al morir (UEB.botin).
   ===================================================================== */

/* ---------- 4 · fusil de asalto corto: aluminio anodizado, guardamanos con rieles, punto rojo, cargador curvo de 30, culata extensible ----------
   OJO: buildFusil y animFusil se llaman mientras se arma la tabla W, mucho antes de esta línea. Por eso son declaraciones
   de función (suben solas) y no usan ninguna constante de este módulo: solo lo que el juego ya tiene definido arriba de W. */
function buildFusil(){const g=new THREE.Group(),w={g},M=WM,O=[0,.006,-.02];
  const env=M.nitride.envMap||null;
  /* acabados propios: anodizado negro mate, vidrio del visor, punto rojo y lente de la linterna */
  const AN=new THREE.MeshStandardMaterial({color:0x202125,metalness:.68,roughness:.5,roughnessMap:M.nitride.roughnessMap,envMap:env,envMapIntensity:.45});
  const LENS=new THREE.MeshStandardMaterial({color:0x7d97aa,metalness:.9,roughness:.06,transparent:true,opacity:.16,depthWrite:false,side:THREE.DoubleSide,envMap:env,envMapIntensity:.9});
  const DOT=new THREE.MeshBasicMaterial({map:glowTex,color:0xff2a1c,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false,fog:false,toneMapped:false});
  const TL=new THREE.MeshStandardMaterial({color:0x2a3138,metalness:.9,roughness:.1,envMap:env,envMapIntensity:.8});
  /* perfil en el plano z-y (ancho y alto) estirado a lo largo del arma */
  const xExt=(pts,len,bev=.0012)=>{const ge=kExt(pts.map(p=>[-p[0],p[1]]),len,bev);ge.rotateY(Math.PI/2);return ge;};
  /* cilindro atravesado (eje de izquierda a derecha) */
  const zCyl=(r,len,m,x,y,z,p,seg=12)=>{const c=kCyl(r,r,len,m,x,y,z,p,seg);c.rotation.y=Math.PI/2;return c;};
  /* todo lo que cuelga de un grupo pasa a ser una sola malla por material: el fusil tiene muchas piezas chicas y así son pocas llamadas de dibujo */
  const bake=root=>{const by=new Map(),m4=new THREE.Matrix4();root.updateMatrixWorld(true);const inv=new THREE.Matrix4().copy(root.matrixWorld).invert();
    root.traverse(o=>{if(!o.isMesh)return;const ge=o.geometry.clone();ge.applyMatrix4(m4.multiplyMatrices(inv,o.matrixWorld));if(!by.has(o.material))by.set(o.material,[]);by.get(o.material).push([ge,null]);});
    while(root.children.length)root.remove(root.children[0]);
    const out=new Map();for(const [mat,list] of by){const me=new THREE.Mesh(vMerge(list,false,true),mat);root.add(me);out.set(mat,me);}return out;};

  const rc=kIn(g,g,O);
  /* cajón de arriba y riel corrido de punta a punta */
  kMesh(kExt([[-.108,-.014],[-.108,.027],[-.1,.034],[.11,.034],[.118,.029],[.118,-.014]],.042,.002),AN,0,0,0,rc);
  kBox(.458,.006,.0206,AN,.131,.037,0,rc);
  for(let i=0;i<46;i++)kBox(.0052,.0035,.0206,AN,-.0935+i*.01,.0415,0,rc);
  /* guardamanos octogonal con ranuras a los costados y abajo */
  kMesh(xExt([[-.0165,.034],[.0165,.034],[.0232,.024],[.0232,-.018],[.0145,-.0305],[-.0145,-.0305],[-.0232,-.018],[-.0232,.024]],.245,.0015),AN,.2405,0,0,rc);
  for(let i=0;i<5;i++){for(const s of [-1,1])kBox(.03,.0075,.0012,M.groove,.15+i*.043,.004,s*.0236,rc);kBox(.03,.0012,.0075,M.groove,.15+i*.043,-.0318,0,rc);}
  for(let i=0;i<5;i++)for(const s of [-1,1]){const v=kBox(.022,.0012,.006,M.groove,.154+i*.043,.0297,s*.0203,rc);v.rotation.x=s*.96;}
  kBox(.004,.066,.0468,M.groove,.119,.002,0,rc);
  /* caño y apagallamas de tres ranuras */
  kCyl(.0088,.0088,.1,M.nitride,.405,0,0,rc,16);
  kCyl(.0112,.0105,.05,M.nitride,.468,0,0,rc,16);kCyl(.0118,.0118,.006,M.nitride,.446,0,0,rc,16);
  for(let i=0;i<3;i++){const s=kBox(.028,.0034,.0005,M.groove,.474,0,0,rc),a=i/3*Math.PI*2+.5;s.position.y=Math.cos(a)*.0109;s.position.z=Math.sin(a)*.0109;s.rotation.x=a+Math.PI/2;}
  kDisc(.0036,M.bore,.4934,0,0,rc);kRing(.0036,.0105,M.bright,.4932,0,0,rc);
  /* cajón de abajo con el brocal del cargador, guardamonte y gatillo */
  kMesh(kExt([[-.108,-.014],[.106,-.014],[.106,-.046],[.101,-.086],[.036,-.08],[.03,-.057],[-.04,-.057],[-.054,-.049],[-.086,-.039],[-.108,-.035]],.038,.002),AN,0,0,0,rc);
  kMesh(kExt([[-.041,-.055],[-.041,-.087],[-.031,-.095],[.019,-.095],[.031,-.064],[.031,-.055]],.013,.001,[[[.025,-.058],[.015,-.09],[-.029,-.09],[-.036,-.084],[-.036,-.058]]]),AN,0,0,0,rc);
  kMesh(kExt([[.003,-.056],[.007,-.056],[.005,-.07],[0,-.08],[-.005,-.084],[-.007,-.082],[-.002,-.074],[.001,-.066]],.006,.0008),M.nitride,-.004,0,0,rc);
  /* empuñadura de polímero punteado */
  kMesh(kExt([[-.038,-.054],[-.042,-.084],[-.074,-.166],[-.126,-.156],[-.108,-.08],[-.094,-.038],[-.06,-.044]],.03,.004),M.poly,0,0,0,rc);
  kMesh(kExt([[-.07,-.168],[-.129,-.157],[-.131,-.163],[-.072,-.174]],.032,.0015),M.polyS,0,0,0,rc);
  /* tubo y culata extensible calada, con cantonera */
  kCyl(.0148,.0148,.172,AN,-.193,.004,0,rc,16);kCyl(.019,.019,.012,M.knurl,-.114,.004,0,rc,20);
  kMesh(kExt([[-.15,.03],[-.32,.03],[-.336,.022],[-.34,-.07],[-.325,-.092],[-.3,-.086],[-.262,-.03],[-.15,-.024]],.034,.003,[[[-.268,-.022],[-.3,-.068],[-.322,-.066],[-.322,-.012],[-.3,-.004]]]),M.polyS,0,0,0,rc);
  kMesh(kExt([[-.337,.026],[-.341,-.071],[-.326,-.095],[-.335,-.097],[-.349,-.073],[-.345,.024]],.036,.002),M.poly,0,0,0,rc);
  kBox(.03,.006,.012,M.nitride,-.2,-.027,0,rc);
  /* lado izquierdo, el que ve el jugador: ranura de la manija de carga, retén del cerrojo, selector y pernos */
  kBox(.086,.0072,.0012,M.groove,.05,.019,-.0214,rc);
  kBox(.011,.019,.0036,M.nitride,.048,-.012,-.0207,rc);kBox(.014,.008,.004,M.nitride,.046,-.0245,-.021,rc);
  for(let i=0;i<3;i++)kBox(.009,.0012,.0008,M.groove,.048,-.006-i*.0045,-.0228,rc);
  zCyl(.0054,.004,M.nitride,-.058,-.026,-.0205,rc);{const l=kBox(.017,.0036,.003,M.nitride,-.066,-.0235,-.0222,rc);l.rotation.z=-.3;}
  zCyl(.0016,.0006,M.dot,-.073,-.0155,-.0193,rc,8);
  for(const [x,y] of [[-.088,-.029],[.094,-.03]])zCyl(.0032,.0012,M.bright,x,y,-.0193,rc,10);
  /* lado derecho: ventana de expulsión con su tapa abierta, deflector y botón del cargador */
  kBox(.056,.02,.0006,M.groove,.038,.014,.0209,rc);kBox(.056,.018,.0025,AN,.038,-.005,.0226,rc);
  kMesh(kExt([[0,0],[.014,0],[0,.012]],.006,.001),AN,-.002,.006,.0235,rc);
  zCyl(.0045,.004,M.nitride,.018,-.03,.0205,rc,10);
  /* cerrojo: se ve por la ventana; se acorta hacia atrás cuando abre */
  const bolt=new THREE.Group();bolt.position.set(...kP(O,.01,.014,.0213));g.add(bolt);const bl=kIn(g,bolt,O);
  kBox(.05,.014,.0006,M.bright,.035,.014,.0213,bl);
  /* manija de carga del lado izquierdo: va y viene con cada tiro */
  const knob=new THREE.Group();knob.position.set(...kP(O,.084,.019,-.0215));g.add(knob);const kn=kIn(g,knob,O);
  kBox(.014,.009,.0045,M.nitride,.084,.019,-.0238,kn);zCyl(.0046,.016,M.nitride,.084,.019,-.033,kn);
  for(let i=0;i<3;i++)zCyl(.005,.0012,M.groove,.084,.019,-.029-i*.004,kn);
  /* visor de punto rojo sobre su montura, y miras de respaldo rebatidas */
  kBox(.05,.011,.03,AN,.03,.0485,0,rc);zCyl(.0062,.01,M.knurl,.03,.0475,-.019,rc,14);
  {const fr=kExt(kRR(.04,.04,.008),.06,.0012,[kRR(.0295,.0285,.0055)]);fr.rotateY(Math.PI/2);kMesh(fr,AN,.03,.074,0,rc);}
  kBox(.016,.005,.016,AN,.03,.0965,0,rc);zCyl(.0085,.007,M.knurl,.03,.074,.0235,rc,16);
  {const lg=new THREE.PlaneGeometry(.0295,.0285);lg.rotateY(-Math.PI/2);kMesh(lg,LENS,.056,.074,0,rc);}
  {const dg=new THREE.PlaneGeometry(.0085,.0085);dg.rotateY(-Math.PI/2);kMesh(dg,DOT,.0553,.074,0,rc);}
  kBox(.03,.0075,.02,M.nitride,-.082,.047,0,rc);kBox(.03,.0075,.02,M.nitride,.34,.047,0,rc);
  /* linterna al costado de abajo del guardamanos: de ahí sale el haz de la linterna del juego */
  kBox(.03,.012,.008,AN,.29,-.027,.0215,rc);
  kCyl(.0102,.0102,.07,AN,.283,-.0365,.0205,rc,14);kCyl(.0102,.0135,.012,AN,.324,-.0365,.0205,rc,14);kCyl(.0135,.0135,.02,M.knurl,.34,-.0365,.0205,rc,16);
  kCyl(.0095,.0102,.008,M.polyS,.244,-.0365,.0205,rc,14);kDisc(.0118,TL,.3503,-.0365,.0205,rc);
  /* cargador curvo de 30 */
  const mag=new THREE.Group();g.add(mag);const mg=kIn(g,mag,O);
  kMesh(kExt([[.097,-.03],[.1,-.085],[.108,-.14],[.124,-.19],[.146,-.236],[.084,-.243],[.062,-.195],[.047,-.14],[.04,-.085],[.038,-.03]],.0235,.0025),M.polyS,0,0,0,mg);
  for(const s of [-1,1]){const r=kBox(.004,.13,.0006,M.groove,.082,-.135,s*.0119,mg);r.rotation.z=.2;}
  kMesh(kExt([[.15,-.236],[.082,-.244],[.08,-.254],[.152,-.246]],.027,.002),M.poly,0,0,0,mg);
  kCyl(.0045,.0045,.034,M.brass,.064,-.0265,0,mg,10);kCyl(.0045,.0014,.014,M.brass,.088,-.0265,0,mg,10);
  /* marco de la empuñadura: de acá se cuelga la mano derecha (misma relación que en la pistola) */
  const grip=new THREE.Group();grip.position.set(...kP(O,-.07,-.0613,0));grip.rotation.x=-.33;g.add(grip);
  /* marco de la mano izquierda: lo mueven las recargas */
  const hand=new THREE.Group();g.add(hand);w.hr=[0,0,-.2];
  const B=bake(rc);bake(mg);bake(kn);bake(bl);
  Object.assign(w,{id:'fusil',name:'FUSIL',rc,grip,mag,knob,KZ:knob.position.z,bolt,hand,dot:B.get(DOT),dotM:DOT,
    idle:kP(O,.185,-.036,0),HD:[-.1,-.46,.06],muzzle:kP(O,.495,0,0),port:kP(O,.04,.016,.03),flashS:.6});
  /* puntos de la recarga: base del cargador y retén del cerrojo */
  w.MB={o:mag,v:kP(O,.112,-.2,-.006)};w.BC=kP(O,.05,-.016,-.03);w.BC0=kP(O,.045,-.04,-.085);
  return w;}

/* animación: t<0 = pose de reposo */
function animFusil(w){const t=w.rT;
  /* la manija queda atrás con el cargador vacío (cerrojo abierto) y va y viene con cada tiro */
  const back=t<0?(w.ammo===0?1:0):(w.lock?1:0),cyc=w.slideT>0?Math.sin(w.slideT/.09*Math.PI):0,bk=Math.max(back,cyc);
  w.knob.position.z=w.KZ+.062*bk;w.bolt.scale.z=1-.92*bk;
  if(t<0){w.g.rotation.set(0,0,0);w.g.position.set(0,0,0);w.mag.position.y=0;w.mag.visible=true;}
  else{const D=w.D,f=kf(t,[[0,0],[.24,1],[D-.42,1],[D-.06,0]]),s=w.lockR?kf(t,[[1.14,0],[1.36,1],[1.62,1],[D-.2,0]]):0;
    /* el arma se ladea y sube para mostrar el brocal; si hay que soltar el cerrojo vuelve un poco para dar el costado */
    w.g.rotation.set(.2*f,.1*f-.12*s,-.52*f+.2*s);w.g.position.set(-.08*f,.11*f,.05*f);
    w.mag.position.y=t<.52?kf(t,[[.3,0],[.34,-.03],[.52,-.27]]):kf(t,[[.8,-.5],[1.04,-.1],[1.14,0]]);}
  /* el punto rojo solo se ve mirando por el visor */
  w.dot.visible=aim>.25;w.dotM.opacity=Math.min(1,(aim-.25)*2.4);
  animHand(w);}
/* recarga: la izquierda saca el cargador, pone otro y, si el fusil quedó abierto, le pega al retén del cerrojo */
function reloadFusil(w){const E=w.ammo===0;w.lock=E;w.lockR=E;w.D=E?2.2:1.82;
  w.evs=[[.3,()=>sfx.magOut()],[.52,()=>dropMag(w)],[.8,()=>{w.mag.visible=true;}],
    [1.14,()=>{const tot=w.ammo+w.res;w.ammo=Math.min(w.cap,tot);w.res=tot-w.ammo;sfx.magIn();jolt=1;hudAmmo();}]];
  if(E)w.evs.push([1.5,()=>{w.lock=false;sfx.slide();jolt=.8;}]);
  const R=[.2,-.35,-.1];
  w.hs=[[.28,w.MB],[.52,w.MB,1],[.7,w.HD],[.8,w.MB],[1.14,w.MB,1],
    ...(E?[[1.4,w.BC0,0,R],[1.5,w.BC,0,R],[1.6,w.BC0,0,R]]:[]),[w.D-.1,w.idle],[w.D+1,w.idle,1]];}
/* siguiente arma que el jugador tiene, hacia adelante (1) o hacia atrás (-1): para la rueda y el botón ARMA */
function wCiclo(cur,dir){const n=W.length;for(let k=1;k<=n;k++){const i=((cur+dir*k)%n+n)%n;if(W[i].owned!==false)return i;}return cur;}

/* ---------- fusil: lo que pasa en plena partida (tenerlo o no, sonido, ráfaga de 3) ---------- */
const FUSIL=(()=>{
  const IDX=W.findIndex(x=>x.id==='fusil'),w=W[IDX],slot=$('#wslots').children[IDX];
  let shot0=SHOT_ID,pend=false,bT=9,molde=null;
  /* estampido seco y fuerte: más cuerpo que la Uzi y una cola corta */
  sfx.fusil=auOneShot(()=>{if(!AC||!auGate('s_fusil',3,6,150))return;try{
    noise(.19,'lowpass',6800,320,.85);noise(.04,'highpass',4300,0,.62);tone('sine',125,44,.1,.62);tone('square',310,95,.035,.11);noise(.26,'bandpass',1500,520,.15,1.4,.03);}catch(e){}});
  function hud(){if(slot)slot.hidden=!w.owned;}
  const sel=()=>{switchTo(IDX);return wi===IDX||switchTarget===IDX;};
  /* el jugador levanta un fusil: cargador lleno y a la mano */
  function dar(){w.owned=true;w.ammo=w.cap;w.rT=-1;w.lock=false;w.burst=0;hud();pend=!sel();hudAmmo();}
  function reset(){w.owned=false;w.burst=0;w.lock=false;pend=false;shot0=SHOT_ID;bT=9;hud();}
  function update(dt){
    if(pend)pend=w.owned&&!sel();
    /* ráfaga de 3 (tiro secundario): el primer tiro la arranca y los otros dos salen solos aunque se suelte el botón.
       wAuto() deja pasar los tiros mientras w.burst>0; acá se lleva la cuenta mirando SHOT_ID después de cada disparo */
    bT+=dt;
    if(SHOT_ID!==shot0){shot0=SHOT_ID;if(wi===IDX&&(w.alt||w.burst>0)){w.burst=w.burst>0?w.burst-1:2;bT=0;}}
    if(w.burst>0){
      if(wi!==IDX||w.rT>=0||switchT>0||w.ammo<=0||bT>.35)w.burst=0;
      else if(fireCd<=0&&!altHeld()&&!(mouseDown||touchFire)){w.alt=true;fire();
        if(SHOT_ID!==shot0){shot0=SHOT_ID;w.burst--;bT=0;}
        shotLatch=false;}}
  }
  /* el fusil como objeto del mundo (para la caja de botín): las mismas mallas del arma en primera persona */
  function maqueta(){if(molde)return molde;const o=new THREE.Group();
    for(const src of [w.rc,w.mag.children[0],w.knob.children[0]]){const h=new THREE.Group();kRel(w.g,src).decompose(h.position,h.quaternion,h.scale);
      for(const m of src.children)if(m.isMesh&&m.material!==w.dotM)h.add(new THREE.Mesh(m.geometry,m.material));o.add(h);}
    return molde=o;}
  w.burst=0;w.lock=false;hud();
  return{IDX,w,dar,reset,update,maqueta};})();

/* ---------- GRAN: sistema de granadas de mano (las del jugador y las de los soldados) ---------- */
const GRAN=(()=>{
  /* números: todos juntos para ajustarlos de un solo lugar */
  const TUNE={
    G:13,            // gravedad de la granada (m/s²). Más baja que la del jugador (22): el arco se alcanza a ver en el aire
    R:.05,           // radio de choque (m)
    eSuelo:.3,       // cuánto rebota contra el piso (0 nada · 1 todo)
    frSuelo:.55,     // cuánta velocidad de costado le queda después de cada pique
    vReb:1.1,        // con menos velocidad de caída que esta (m/s) ya no pica: rueda
    rodar:7,         // freno al rodar (m/s²)
    eMuro:.35,       // rebote contra paredes, autos y obstáculos
    frMuro:.8,       // velocidad que conserva al pegar contra algo vertical
    radio:7,         // radio de la explosión (m)
    dano:80,         // daño en el centro: cae parejo hasta 0 en el borde
    cobertura:.3,    // parte del daño que pasa si hay algo sólido entre la granada y el blanco
    danoBichos:2,    // los mutantes reciben el daño multiplicado por esto
    empuje:9,        // empujón al jugador en el centro (m/s)
    autoCerca:1.3,autoGolpes:12,  // auto pegado a la explosión (m): golpes que recibe (a los 12 humea, a los 20 se prende)
    autoLejos:3.5,autoGolpes2:5,  // auto un poco más lejos
    vidrios:5,       // rompe las mamparas de vidrio hasta esta distancia (m)
    vMax:21,         // velocidad máxima de lanzamiento que acepta arco() (m/s)
    tol:1.5,         // arco(): error máximo (m) entre donde queda la granada y el blanco para darlo por bueno
    mecha:3,         // mecha por omisión (s)
    vJug:17,subeJug:3.5,velJug:.5, // lanzamiento del jugador: velocidad hacia donde mira, empuje hacia arriba y cuánto hereda de su propia velocidad
    maxJug:4,        // granadas que puede llevar el jugador
    gesto:.62,sale:.3, // duración del gesto de lanzar y momento en que la granada deja la mano (s)
    humoR:5,humoT:14,  // granada de humo: radio de la nube (m) y duración (s)
    vivas:10         // fondo común: granadas en el aire a la vez
  };
  const H=1/60,R=TUNE.R;          // paso fijo de la física: el mismo para las granadas de verdad y para las de prueba de arco()
  const lista=[],humos=[],libres=[],todas=[];
  const N={x:0,y:1,z:0,m:0};      // normal del último choque y material (0 piedra · 1 chapa)

  /* ================= mundo: qué frena a una granada =================
     Muros (con su altura), obstáculos (cajas), autos (rectángulo con el perfil de la carrocería), postes y árboles, y el piso.
     Para no recorrer los ~1000 obstáculos y ~1300 autos en cada paso, cada granada lleva la lista de los que tiene cerca. */
  const mkLoc=()=>({ob:[],ca:[],cx:1e9,cz:1e9,k:0});
  function locArmar(L,x0,z0,x1,z1){L.ob.length=0;L.ca.length=0;
    for(const b of obstacles){if(b.x1<x0||b.x0>x1||b.z1<z0||b.z0>z1)continue;L.ob.push(b);}
    for(const c of VCARS){if(c.st>=3)continue;const r=c.L*.5+.4;if(c.x+r<x0||c.x-r>x1||c.z+r<z0||c.z-r>z1)continue;L.ca.push(c);}}
  /* altura de la carrocería de un auto a lo largo (X hacia la trompa): el mismo perfil por el que camina el jugador */
  const altoAuto=(c,X)=>c.crushed?c.H*.4:(MOV.carOK(c)?MOV.carTop(c,X):c.H*.97);
  /* primer choque del tramo o→o+d contra algo vertical (o el fondo de un saliente). Devuelve la fracción 0…1 (1 = nada) y deja la normal en N */
  function choque(ox,oy,oz,dx,dy,dz,L){let best=1;const x1=ox+dx,z1=oz+dz;
    /* muros */
    {const i0=Math.floor(Math.min(ox,x1)/HC),i1=Math.floor(Math.max(ox,x1)/HC),j0=Math.floor(Math.min(oz,z1)/HC),j1=Math.floor(Math.max(oz,z1)/HC);
     for(let i=i0;i<=i1;i++)for(let j=j0;j<=j1;j++){const a=allHash.get(hk(i,j));if(!a)continue;
       for(const idx of a){const w=WALLS_ALL[idx],ex=w[2]-w[0],ez=w[3]-w[1],den=dx*ez-dz*ex;if(den>-1e-12&&den<1e-12)continue;
         const tt=((w[0]-ox)*ez-(w[1]-oz)*ex)/den;if(tt<0||tt>=best)continue;
         const u=((w[0]-ox)*dz-(w[1]-oz)*dx)/den;if(u<0||u>1)continue;
         const y=oy+dy*tt;if(y<w[4]-.01||y>w[5])continue;
         best=tt;const l=Math.hypot(ex,ez)||1;let nx=ez/l,nz=-ex/l;if(nx*dx+nz*dz>0){nx=-nx;nz=-nz;}N.x=nx;N.y=0;N.z=nz;N.m=0;}}}
    /* postes, árboles y bolsas (los círculos de los autos no: el auto va como caja) */
    {const A=dx*dx+dz*dz;if(A>1e-12){const i0=Math.floor((Math.min(ox,x1)-1.2)/HC),i1=Math.floor((Math.max(ox,x1)+1.2)/HC),j0=Math.floor((Math.min(oz,z1)-1.2)/HC),j1=Math.floor((Math.max(oz,z1)+1.2)/HC);
     for(let i=i0;i<=i1;i++)for(let j=j0;j<=j1;j++){const cs=circHash.get(hk(i,j));if(!cs)continue;
       for(const c of cs){if(c.dead||(c.brk&&c.brk.k==='car'))continue;
         const fx=ox-c.x,fz=oz-c.z,C=fx*fx+fz*fz-c.r*c.r;if(C<=0)continue;const B=fx*dx+fz*dz;if(B>=0)continue;
         const Dq=B*B-A*C;if(Dq<0)continue;const t=(-B-Math.sqrt(Dq))/A;if(t<0||t>=best)continue;
         const h=c.h===undefined?99:c.low?Math.min(c.h,.7):c.h;if(oy+dy*t-R>=h)continue;
         best=t;N.x=(fx+dx*t)/c.r;N.y=0;N.z=(fz+dz*t)/c.r;N.m=0;}}}}
    /* obstáculos: cajas. Entrar por la tapa no cuenta acá: eso lo resuelve el piso */
    for(const b of L.ob){if(b.gl&&b.gl.dead)continue;let t0=0,t1=best,ax=-1,sg=0;
      if(dx>-1e-12&&dx<1e-12){if(ox<b.x0||ox>b.x1)continue;}else{let ta=(b.x0-ox)/dx,tb=(b.x1-ox)/dx,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=0;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}
      {const y0=b.y0||0;if(dy>-1e-12&&dy<1e-12){if(oy<y0||oy>b.y1)continue;}else{let ta=(y0-oy)/dy,tb=(b.y1-oy)/dy,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=1;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}}
      if(dz>-1e-12&&dz<1e-12){if(oz<b.z0||oz>b.z1)continue;}else{let ta=(b.z0-oz)/dz,tb=(b.z1-oz)/dz,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=2;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}
      if(ax<0||(ax===1&&sg>0))continue;
      best=t0;N.x=ax===0?sg:0;N.y=ax===1?sg:0;N.z=ax===2?sg:0;N.m=b.glass?2:0;}
    /* autos: el rectángulo de la planta; si llega más alto que la carrocería en ese punto, pasa por arriba */
    for(const c of L.ca){if(c.st>=3)continue;const ca=Math.cos(c.a),sa=Math.sin(c.a),rx=ox-c.x,rz=oz-c.z,lx=rx*ca-rz*sa,lz=rx*sa+rz*ca,ldx=dx*ca-dz*sa,ldz=dx*sa+dz*ca,hw=c.W/2,hl=c.L/2;
      let t0=0,t1=best,ax=-1,sg=0;
      if(ldx>-1e-12&&ldx<1e-12){if(lx<-hw||lx>hw)continue;}else{let ta=(-hw-lx)/ldx,tb=(hw-lx)/ldx,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=0;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}
      if(ldz>-1e-12&&ldz<1e-12){if(lz<-hl||lz>hl)continue;}else{let ta=(-hl-lz)/ldz,tb=(hl-lz)/ldz,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=1;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}
      if(ax<0)continue;
      if(oy+dy*t0-R>=altoAuto(c,-(lz+ldz*t0))-.02)continue;
      best=t0;const nlx=ax===0?sg:0,nlz=ax===1?sg:0;N.x=nlx*ca+nlz*sa;N.y=0;N.z=-nlx*sa+nlz*ca;N.m=1;}
    return best;}
  /* altura del piso bajo (x,z) para algo que está a la altura y: terreno, tapa de un obstáculo, carrocería de un auto o una terraza baja */
  let pisoM=0;
  function suelo(x,z,y,L){let g=floorAt(x,z);const lim=y+.3;pisoM=0;
    for(const b of L.ob){if(b.glass)continue;if(x>b.x0&&x<b.x1&&z>b.z0&&z<b.z1&&b.y1>g&&b.y1<=lim)g=b.y1;}
    for(const c of L.ca){if(c.st>=3)continue;const rx=x-c.x,rz=z-c.z;if(rx*rx+rz*rz>c.L*c.L*.3)continue;
      const ca=Math.cos(c.a),sa=Math.sin(c.a),lx=rx*ca-rz*sa,lz=rx*sa+rz*ca;if(lx>c.W/2||lx<-c.W/2||lz>c.L/2||lz<-c.L/2)continue;
      const h=altoAuto(c,-lz);if(h>g&&h<=lim){g=h;pisoM=1;}}
    if(isSolid(x,z)){const bh=bldH(x,z);if(bh>g&&bh<=lim)g=bh;}
    return g;}
  /* ¿hay algo sólido entre o y c? (para el descuento por cobertura). Vidrios, postes y bichos no cuentan */
  function tapado(o,c,L){const dx=c.x-o.x,dy=c.y-o.y,dz=c.z-o.z;
    {const i0=Math.floor(Math.min(o.x,c.x)/HC),i1=Math.floor(Math.max(o.x,c.x)/HC),j0=Math.floor(Math.min(o.z,c.z)/HC),j1=Math.floor(Math.max(o.z,c.z)/HC);
     for(let i=i0;i<=i1;i++)for(let j=j0;j<=j1;j++){const a=allHash.get(hk(i,j));if(!a)continue;
       for(const idx of a){const w=WALLS_ALL[idx],ex=w[2]-w[0],ez=w[3]-w[1],den=dx*ez-dz*ex;if(den>-1e-12&&den<1e-12)continue;
         const tt=((w[0]-o.x)*ez-(w[1]-o.z)*ex)/den;if(tt<0||tt>1)continue;const u=((w[0]-o.x)*dz-(w[1]-o.z)*dx)/den;if(u<0||u>1)continue;
         const y=o.y+dy*tt;if(y>=w[4]-.01&&y<=w[5])return true;}}}
    for(const b of L.ob){if(b.glass)continue;let t0=0,t1=1,ok=true;
      for(const [p,d,a,bb] of [[o.x,dx,b.x0,b.x1],[o.y,dy,b.y0||0,b.y1],[o.z,dz,b.z0,b.z1]]){if(d>-1e-12&&d<1e-12){if(p<a||p>bb){ok=false;break;}}else{let ta=(a-p)/d,tb=(bb-p)/d;if(ta>tb){const q=ta;ta=tb;tb=q;}if(ta>t0)t0=ta;if(tb<t1)t1=tb;if(t0>t1){ok=false;break;}}}
      if(ok)return true;}
    for(const cr of L.ca){if(cr.st>=3)continue;const ca=Math.cos(cr.a),sa=Math.sin(cr.a),rx=o.x-cr.x,rz=o.z-cr.z,lx=rx*ca-rz*sa,lz=rx*sa+rz*ca,ldx=dx*ca-dz*sa,ldz=dx*sa+dz*ca,hw=cr.W/2,hl=cr.L/2;
      let t0=0,t1=1,ok=true;
      for(const [p,d,h] of [[lx,ldx,hw],[lz,ldz,hl]]){if(d>-1e-12&&d<1e-12){if(p<-h||p>h){ok=false;break;}}else{let ta=(-h-p)/d,tb=(h-p)/d;if(ta>tb){const q=ta;ta=tb;tb=q;}if(ta>t0)t0=ta;if(tb<t1)t1=tb;if(t0>t1){ok=false;break;}}}
      if(!ok)continue;
      for(const t of [t0,(t0+t1)/2,t1])if(o.y+dy*t<altoAuto(cr,-(lz+ldz*t))-.03)return true;}
    return false;}

  /* ================= física =================
     Un paso de H segundos. Lo usan igual las granadas de verdad y las de prueba de arco(): por eso lo que arco() dice, pasa.
     Devuelve 0 nada · 1 pegó contra algo vertical · 2 picó contra el piso */
  function paso(g,L){const p=g.p,v=g.v;g.k++;
    if(g.rest){if((g.k&15)||suelo(p.x,p.z,p.y,L)>=p.y-R-.03)return 0;g.rest=false;}
    const y0=p.y;v.y-=TUNE.G*H;let ev=0;
    const dx=v.x*H,dy=v.y*H,dz=v.z*H,t=choque(p.x,p.y,p.z,dx,dy,dz,L);
    if(t<1){/* avanza hasta el choque, se separa un centímetro y rebota */
      p.x+=dx*t+N.x*.01;p.y+=dy*t+N.y*.01;p.z+=dz*t+N.z*.01;
      const vn=v.x*N.x+v.y*N.y+v.z*N.z;
      if(vn<0){const j=(1+TUNE.eMuro)*vn,f=TUNE.frMuro;v.x=(v.x-j*N.x)*f;v.z=(v.z-j*N.z)*f;v.y-=j*N.y;if(v.y>0)v.y*=f;}
      ev=1;g.mat=N.m;}
    else{p.x+=dx;p.y+=dy;p.z+=dz;}
    const yy=y0>p.y?y0:p.y,gy=suelo(p.x,p.z,yy,L),sm=pisoM,gy0=g.gy;g.gy=gy;
    if(p.y-R<=gy){
      if(v.y<-TUNE.vReb){/* llega con fuerza: pica, según la inclinación de lo que pisa (capó, parabrisas, escalinata) */
        const e=.06;let sx=(suelo(p.x+e,p.z,yy,L)-suelo(p.x-e,p.z,yy,L))/(2*e),sz=(suelo(p.x,p.z+e,yy,L)-suelo(p.x,p.z-e,yy,L))/(2*e);
        if(sx>1.6||sx<-1.6||sz>1.6||sz<-1.6){sx=0;sz=0;}
        const il=1/Math.sqrt(1+sx*sx+sz*sz),nx=-sx*il,ny=il,nz=-sz*il,vn=v.x*nx+v.y*ny+v.z*nz;
        if(vn<0){const j=(1+TUNE.eSuelo)*vn;v.x-=j*nx;v.y-=j*ny;v.z-=j*nz;
          const vb=v.x*nx+v.y*ny+v.z*nz,f=TUNE.frSuelo;v.x=(v.x-vb*nx)*f+vb*nx;v.y=(v.y-vb*ny)*f+vb*ny;v.z=(v.z-vb*nz)*f+vb*nz;}
        ev=2;g.mat=sm;}
      else if(g.gnd&&gy>gy0+.12){/* rodando contra un escalón: lo frena y lo devuelve */
        p.x-=dx;p.z-=dz;v.x*=-.3;v.z*=-.3;v.y=0;g.gy=gy0;p.y=gy0+R;return 1;}
      else{/* rueda y se va frenando */
        v.y=0;const sp=Math.hypot(v.x,v.z);
        if(sp<.15){v.x=0;v.z=0;g.rest=true;}else{const k=Math.max(0,sp-TUNE.rodar*H)/sp;v.x*=k;v.z*=k;}}
      p.y=gy+R;g.gnd=true;}
    else g.gnd=false;
    return ev;}

  /* ================= arco: solución de lanzamiento =================
     Prueba varios ángulos de elevación. Para cada uno simula el tiro con la física de arriba hasta que se acaba la mecha
     y corrige el punto de mira por lo que la granada pica y rueda, hasta que quede sobre el blanco.
     opt: {mecha (3 s), vmax (21 m/s), tol (1,5 m), alto (true: probar primero los tiros más bombeados)}
     Devuelve {vel, ok, t, err, fin, choca}: velocidad inicial · si queda sobre el blanco sin chocar antes · tiempo de vuelo hasta el primer pique ·
     error final en metros · dónde queda al explotar · si pegó contra algo en el aire. Guarda las últimas respuestas 0,4 s (es cara: ~0,3 ms). */
  const GH={p:new V3(),v:new V3(),k:0,rest:false,gnd:false,gy:0,mat:0},LA=mkLoc(),SIM={fin:new V3(),choca:false,t:0},_av=new V3();
  const ANG=[.8,.98,.6,1.13],ANG_ALTO=[1.05,1.18,.9,.75],CACHE=[];let cacheI=0;
  function simular(desde,vel,mecha,L,out){const g=GH;g.p.copy(desde);g.v.copy(vel);g.k=0;g.rest=false;g.gnd=false;g.gy=-1e9;
    const n=Math.ceil(mecha/H-1e-6);let choca=false,t1=-1;
    for(let i=0;i<n;i++){const ev=paso(g,L);if(t1<0){if(ev===1)choca=true;if(ev===2||g.gnd)t1=(i+1)*H;}if(g.rest)break;}
    out.fin.copy(g.p);out.choca=choca;out.t=t1<0?mecha:t1;return out;}
  function arco(desde,hasta,opt){opt=opt||{};const vmax=opt.vmax||TUNE.vMax,mecha=opt.mecha||TUNE.mecha,tol=opt.tol||TUNE.tol,alto=!!opt.alto;
    for(const c of CACHE){if(T-c.T<.4&&T>=c.T&&c.alto===alto&&c.mecha===mecha&&c.vmax===vmax&&c.tol===tol&&Math.abs(c.a.x-desde.x)+Math.abs(c.a.y-desde.y)+Math.abs(c.a.z-desde.z)<.3&&Math.abs(c.b.x-hasta.x)+Math.abs(c.b.y-hasta.y)+Math.abs(c.b.z-hasta.z)<.3)return c.r;}
    const res={vel:new V3(),ok:false,t:0,err:1e9,fin:new V3(),choca:false};
    locArmar(LA,Math.min(desde.x,hasta.x)-8,Math.min(desde.z,hasta.z)-8,Math.max(desde.x,hasta.x)+8,Math.max(desde.z,hasta.z)+8);
    const h=hasta.y+R-desde.y;
    for(const a of (alto?ANG_ALTO:ANG)){let ax=hasta.x,az=hasta.z;const ca=Math.cos(a),sa=Math.sin(a),ta=sa/ca;
      for(let it=0;it<4;it++){const dx=ax-desde.x,dz=az-desde.z,D=Math.hypot(dx,dz),den=D*ta-h;if(D<.4||den<.05)break;
        const v=Math.sqrt(TUNE.G*D*D/(2*ca*ca*den));if(v>vmax)break;
        _av.set(dx/D*v*ca,v*sa,dz/D*v*ca);simular(desde,_av,mecha,LA,SIM);
        const ex=hasta.x-SIM.fin.x,ez=hasta.z-SIM.fin.z,err=Math.hypot(ex,ez),ok=!SIM.choca&&err<=tol&&Math.abs(SIM.fin.y-R-hasta.y)<1.5;
        if((ok&&!res.ok)||(ok===res.ok&&err<res.err)){res.vel.copy(_av);res.ok=ok;res.t=SIM.t;res.err=err;res.fin.copy(SIM.fin);res.choca=SIM.choca;}
        if(SIM.choca||err<.3)break;
        ax+=ex*.9;az+=ez*.9;}
      if(res.ok&&res.err<tol*.5)break;}
    const c=CACHE[cacheI]||(CACHE[cacheI]={a:new V3(),b:new V3()});cacheI=(cacheI+1)%6;c.a.copy(desde);c.b.copy(hasta);c.T=T;c.alto=alto;c.mecha=mecha;c.vmax=vmax;c.tol=tol;c.r=res;
    return res;}
