#!/usr/bin/env python3
"""dibujar.py [mapa-reten.json] — dibuja mapa-reten.png (toda la ventana, 4 px/m) y mapa-reten-zoom.png
(x∈[-470,-300], z∈[585,625], 10 px/m) al lado del JSON. Arriba es el norte (z crece hacia abajo), x crece a la derecha."""
import json, math, os, sys
from PIL import Image, ImageDraw, ImageFont

SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mapa-reten.json')
OUT = os.path.dirname(os.path.abspath(SRC))
d = json.load(open(SRC))
X0, Z0, W, H = d['X0'], d['Z0'], d['W'], d['H']

SUELO = {0: (196, 190, 176), 1: (92, 94, 100), 2: (52, 44, 40), 3: (120, 168, 96), 4: (150, 110, 170)}
NOMBRE = {0: 'vereda', 1: 'calle', 2: 'edificio', 3: 'plaza / pasto', 4: 'suelo tipo 4 (bloqueado)'}
TREP = (255, 170, 40)    # enB=1 trepable
BLOQ = (230, 40, 40)     # enB=2 fuera de edificios
CIRC = {'tree': (40, 120, 40), 'lamp': (250, 230, 120), 'sema': (255, 120, 0), 'bag': (40, 40, 40), None: (0, 200, 220)}


def fnt(n, bold=False):
    for p in ('/usr/share/fonts/truetype/dejavu/DejaVuSans%s.ttf' % ('-Bold' if bold else ''),):
        if os.path.exists(p):
            return ImageFont.truetype(p, n)
    return ImageFont.load_default()


def mix(a, b, t):
    return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3))


def dibujar(x0, x1, z0, z1, s, out, zoom):
    ML, MT, MB = 44, 18, (64 if zoom else 58)
    mw, mh = int((x1 - x0) * s), int((z1 - z0) * s)
    img = Image.new('RGB', (ML + mw + 8, MT + mh + MB), (255, 255, 255))
    mapa = Image.new('RGB', (mw, mh), (255, 255, 255))  # se dibuja aparte para que lo que cae fuera de la ventana quede recortado
    px = mapa.load()
    # suelo + grilla de navegación, casillero por casillero
    for z in range(z0, z1):
        for x in range(x0, x1):
            if not (X0 <= x < X0 + W and Z0 <= z < Z0 + H):
                continue
            k = (z - Z0) * W + (x - X0)
            g, b, hh = d['G'][k], d['B'][k], d['Hh'][k]
            c = SUELO.get(g, (255, 0, 255))
            if b == 1:
                c = mix(c, TREP, .45 + min(.4, hh / 40))
            elif b == 2 and g != 2:
                c = mix(c, BLOQ, .55)
            X, Y = int((x - x0) * s), int((z - z0) * s)
            for yy in range(Y, Y + int(s)):
                for xx in range(X, X + int(s)):
                    px[xx, yy] = c
    dr = ImageDraw.Draw(mapa)
    P = lambda x, z: ((x - x0) * s, (z - z0) * s)
    inside = lambda x, z, m=0: x0 - m <= x <= x1 + m and z0 - m <= z <= z1 + m
    # canteros (zoom)
    if zoom:
        for c in d.get('canteros', []):
            if not inside(c['x'], c['z'], 2):
                continue
            h = c['size'] / 2; nx, nz = c['nx'], c['nz']; tx, tz = nz, -nx
            pts = [P(c['x'] + tx * a + nx * b, c['z'] + tz * a + nz * b) for a, b in ((-h, -h), (h, -h), (h, h), (-h, h))]
            dr.polygon(pts, outline=(90, 60, 20), fill=(130, 95, 50))
    # cuadrícula cada 10 m (las coordenadas se escriben en el margen, más abajo)
    XS = [x for x in range((x0 // 10) * 10, x1 + 1, 10) if x >= x0]
    ZS = [z for z in range((z0 // 10) * 10, z1 + 1, 10) if z >= z0]
    for x in XS:
        dr.line([P(x, z0), P(x, z1)], fill=(255, 255, 255), width=1)
    for z in ZS:
        dr.line([P(x0, z), P(x1, z)], fill=(255, 255, 255), width=1)
    # círculos de choque que no son autos (solo los volcados: x∈[-470,-300], z∈[590,622])
    if zoom:
        for c in d.get('circ', []):
            if not inside(c['x'], c['z'], 1):
                continue
            cx, cy = P(c['x'], c['z']); r = max(2, c['r'] * s)
            col = CIRC.get(c.get('k'), CIRC[None])
            dr.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(0, 0, 0), fill=col)
    # autos: rectángulo orientado, frente marcado, índice en VCARS
    fa = fnt(12 if zoom else 9, True)
    for c in d['cars']:
        if not inside(c['x'], c['z'], 6):
            continue
        sa, ca = math.sin(c['a']), math.cos(c['a'])
        L2, W2 = c['L'] / 2, c['W'] / 2
        ax, az = sa, ca          # eje largo (z local) en el mundo
        bx, bz = ca, -sa         # eje ancho (x local) en el mundo
        pts = [P(c['x'] + ax * l + bx * w, c['z'] + az * l + bz * w) for l, w in ((-L2, -W2), (-L2, W2), (L2, W2), (L2, -W2))]
        fill = (70, 130, 230) if c['malla'] == 'instanciada' else (230, 70, 200)
        if zoom:  # sus tres círculos de choque, debajo
            for q in c.get('cs', []):
                cx, cy = P(q[0], q[1]); r = q[2] * s
                dr.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(20, 40, 120))
        dr.polygon(pts, outline=(255, 255, 255), fill=fill)
        # frente (z local negativo): franja clara
        fr = [P(c['x'] - ax * L2 + bx * w, c['z'] - az * L2 + bz * w) for w in (-W2, W2)]
        dr.line(fr, fill=(255, 255, 140), width=3 if zoom else 2)
        t = str(c['vi']); cx, cy = P(c['x'], c['z']); w = dr.textlength(t, font=fa)
        dr.text((cx - w / 2, cy - (7 if zoom else 5)), t, fill=(255, 255, 255), font=fa, stroke_width=2, stroke_fill=(0, 0, 0))
    # bocas de subte y alcantarillas
    for sb in d['sub']:
        if inside(sb['x'], sb['z'], 2):
            cx, cy = P(sb['x'], sb['z']); r = 1.6 * s
            dr.rectangle([cx - r, cy - r, cx + r, cy + r], outline=(255, 255, 255), fill=(30, 60, 200), width=2)
            dr.text((cx - 4, cy - 7), 'S', fill=(255, 255, 255), font=fnt(12, True))
    for m in d['mh']:
        if inside(m['x'], m['z'], 2):
            cx, cy = P(m['x'], m['z']); r = max(4, .8 * s)
            dr.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(0, 0, 0), fill=(0, 230, 120), width=2)
    # pegar el mapa y escribir coordenadas y leyenda en el margen
    img.paste(mapa, (ML, MT)); dr = ImageDraw.Draw(img)
    f = fnt(11 if zoom else 10)
    for x in XS:
        t = str(x); w = dr.textlength(t, font=f); dr.text((ML + (x - x0) * s - w / 2, 3), t, fill=(0, 0, 0), font=f)
    for z in ZS:
        t = str(z); w = dr.textlength(t, font=f); dr.text((ML - 4 - w, MT + (z - z0) * s - 6), t, fill=(0, 0, 0), font=f)
    fl = fnt(11); y = MT + mh + 20; x = ML
    items = [(SUELO[k], NOMBRE[k]) for k in (0, 1, 2, 3, 4)] + [(mix(SUELO[0], TREP, .6), 'trepable (enB=1)'), (mix(SUELO[0], BLOQ, .55), 'bloqueado (enB=2)'),
             ((70, 130, 230), 'auto instanciado'), ((230, 70, 200), 'auto con malla propia'), ((30, 60, 200), 'boca de subte'), ((0, 230, 120), 'alcantarilla')]
    if zoom:
        items += [((130, 95, 50), 'cantero'), (CIRC['tree'], 'árbol'), (CIRC['lamp'], 'farol'), (CIRC['sema'], 'semáforo'), (CIRC['bag'], 'bolsas'), (CIRC[None], 'otros círculos')]
    for col, name in items:
        w = 16 + dr.textlength(name, font=fl) + 12
        if x + w > img.width - 4:
            x = ML; y += 18
        dr.rectangle([x, y, x + 12, y + 12], fill=col, outline=(0, 0, 0)); dr.text((x + 16, y - 1), name, fill=(0, 0, 0), font=fl); x += w
    tit = f'x∈[{x0},{x1}] z∈[{z0},{z1}] · {s} px/m · arriba el norte · número = índice en VCARS · franja amarilla = frente del auto · v1.16.0'
    dr.text((ML, MT + mh + 3), tit, fill=(0, 0, 0), font=fl)
    img.save(out)
    print(out, img.size)


dibujar(X0, X0 + W, Z0, Z0 + H, 4, os.path.join(OUT, 'mapa-reten.png'), False)
dibujar(-470, -300, 585, 625, 10, os.path.join(OUT, 'mapa-reten-zoom.png'), True)
