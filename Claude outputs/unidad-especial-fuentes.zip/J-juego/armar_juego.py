#!/usr/bin/env python3
"""armar_juego.py entrada.html salida.html

Arma Obelisco Mutante 1.17.0 (unidad especial) sobre un juego que ya tiene los marcadores /*UE:…*/
(la salida de v116/marcar.py). Aplica los parches de las piezas en este orden:

  1. F  efectos, sonido, avisos y vista táctica   F-fx/patch_fx.py
  2. G  granadas                                   G-gran/patch_gran.py
  3. M  bichos contra soldados                     M-bichos/patch_bichos.py
  4. W  retén (escenografía, datos, botones)       W-reten/patch_reten.py
  5. J  pegamento: modelo + IA + enganches         J-juego/patch_pegamento.py

y sube la versión a 1.17.0 en <title>, GAME_VERSION y #ver. Cada parche falla si un ancla no está
exactamente donde la espera; acá eso se corta con un mensaje que dice qué parche y qué ancla.
No escribe la salida si algo falla.
"""
import sys, os, re, subprocess, tempfile, shutil

VERSION = '1.17.0'
AQUI = os.path.dirname(os.path.abspath(__file__))
UE = os.path.dirname(AQUI)
PARCHES = [
    ('F · efectos, sonido, avisos y vista táctica', 'F-fx/patch_fx.py'),
    ('G · granadas', 'G-gran/patch_gran.py'),
    ('M · bichos contra soldados', 'M-bichos/patch_bichos.py'),
    ('W · retén', 'W-reten/patch_reten.py'),
    ('J · pegamento (modelo, IA y enganches)', 'J-juego/patch_pegamento.py'),
]
MARCADORES = ['/*UE:css*/', '<!--UE:hud-->', '<!--UE:capas-->', '<!--UE:ayuda-->', '<!--UE:inicio-->',
              '/*UE:modulos*/', '/*UE:update*/', '/*UE:fx*/', '/*UE:reset*/', '/*UE:start*/', '/*UE:fin*/',
              '/*UE:pausa*/', '/*UE:teclas*/', '/*UE:warm-on*/', '/*UE:warm-off*/', '/*UE:brujula*/',
              '/*UE:rayo-jugador*/']


def corta(msg):
    sys.stderr.write('armar_juego: ' + msg + '\n')
    sys.exit(1)


def marcadores(txt, cuando):
    falta = [m for m in MARCADORES if txt.count(m) != 1]
    if falta:
        corta(f'{cuando}: estos marcadores no están exactamente una vez: {", ".join(falta)}.'
              + (' ¿La entrada pasó por v116/marcar.py?' if cuando == 'entrada' else ''))


def version(txt):
    """Cambia la versión en los tres lugares; tienen que existir y decir lo mismo."""
    pats = [(r'<title>Obelisco Mutante v(\d+\.\d+\.\d+)</title>', '<title>Obelisco Mutante v{}</title>'),
            (r'const GAME_VERSION="(\d+\.\d+\.\d+)";', 'const GAME_VERSION="{}";'),
            (r'<div id="ver">v(\d+\.\d+\.\d+)</div>', '<div id="ver">v{}</div>')]
    vistas = []
    for p, nuevo in pats:
        m = re.findall(p, txt)
        if len(m) != 1:
            corta(f'versión: esperaba una vez {p!r}, hay {len(m)}')
        vistas.append(m[0])
        txt = re.sub(p, nuevo.format(VERSION), txt)
    if len(set(vistas)) != 1:
        corta(f'versión: los tres lugares no dicen lo mismo: {vistas}')
    return txt, vistas[0]


def main():
    if len(sys.argv) != 3:
        corta('uso: python3 armar_juego.py entrada.html salida.html')
    entrada, salida = sys.argv[1], sys.argv[2]
    txt = open(entrada, encoding='utf-8').read()
    marcadores(txt, 'entrada')
    if 'const UEG=' in txt or 'function crearUE' in txt:
        corta('la entrada ya tiene la unidad especial adentro: partí de un juego con marcadores y sin parches')
    tmp = tempfile.mkdtemp(prefix='.armar_ue_', dir=os.path.dirname(os.path.abspath(salida)))
    try:
        actual = os.path.join(tmp, '0.html')
        shutil.copyfile(entrada, actual)
        for n, (nombre, rel) in enumerate(PARCHES, 1):
            script = os.path.join(UE, rel)
            if not os.path.exists(script):
                corta(f'no encuentro el parche {nombre}: {script}')
            sig = os.path.join(tmp, f'{n}.html')
            r = subprocess.run([sys.executable, script, actual, sig], capture_output=True, text=True)
            if r.returncode != 0 or not os.path.exists(sig):
                err = [l.strip() for l in (r.stderr or r.stdout or 'sin salida').strip().splitlines() if l.strip()]
                causa = next((l for l in reversed(err) if l.startswith(('AssertionError', 'FileNotFoundError', 'Error'))), err[-1])
                corta(f'falló el parche {nombre} ({rel}): {causa}\n'
                      '  (un ancla del juego cambió: hay que adaptar ese parche a la versión nueva)')
            actual = sig
        txt = open(actual, encoding='utf-8').read()
        marcadores(txt, 'salida')
        txt, antes = version(txt)
        open(salida, 'w', encoding='utf-8').write(txt)
        print(f'armar_juego: {entrada} (v{antes}) → {salida} (v{VERSION}), {len(txt.encode("utf-8")):,} bytes')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    main()
