// Perfil de CPU (CDP) de 20 s de combate con 8 soldados: en qué funciones se va el tiempo.
const H=require('../../harness.js'),fs=require('fs');
const INST=require('./inst.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto');const ev=c=>h.ev(c);
  try{
    await h.start();await ev("RETEN.ir({bichos:false});1");await ev(INST);await h.step(.5);
    await ev("window.__inmortal=true;P.pos.set(-410,floorAt(-410,607),607);P.vel.set(0,0,0);P.yaw=Math.PI/2;UE.T.refuerzoCombate=1;UE.T.refuerzoLlega=4;1");
    for(let k=0;k<40;k++){await h.step(1,1/60,"__fich()");if(await ev("UE.estado().refuerzo")==='llego')break;}
    await ev("P.pos.set(-420,floorAt(-420,607),607);P.vel.set(0,0,0);UEG.medirReset();1");
    const cdp=await h.page.context().newCDPSession(h.page);
    await cdp.send('Profiler.enable');await cdp.send('Profiler.setSamplingInterval',{interval:200});await cdp.send('Profiler.start');
    for(let k=0;k<4;k++)await h.step(5,1/60,"__fich()");
    const {profile}=await cdp.send('Profiler.stop');
    const med=await ev("({ia:+(UEG.MED.ia/UEG.MED.n).toFixed(3),mod:+(UEG.MED.mod/UEG.MED.n).toFixed(3),n:UEG.MED.n})");lg('med',JSON.stringify(med));
    /* tiempo propio por función y tiempo total bajo UEG.update */
    const nodes=new Map();for(const n of profile.nodes)nodes.set(n.id,n);
    const par=new Map();for(const n of profile.nodes)for(const c of (n.children||[]))par.set(c,n.id);
    const self=new Map();const dts=profile.timeDeltas;let tot=0;
    for(let i=0;i<profile.samples.length;i++){const id=profile.samples[i],dt=dts[i]||0;tot+=dt;self.set(id,(self.get(id)||0)+dt);}
    const nombre=n=>`${n.callFrame.functionName||'(anon)'}:${n.callFrame.lineNumber}`;
    const porF=new Map();for(const [id,t] of self){const n=nodes.get(id);const k=nombre(n);porF.set(k,(porF.get(k)||0)+t);}
    /* tiempo «bajo» una función: suma de las muestras cuyo camino pasa por ella */
    const bajo=(fn)=>{let s=0;for(const [id,t] of self){let x=id;while(x!==undefined){const n=nodes.get(x);if(n.callFrame.functionName===fn){s+=t;break;}x=par.get(x);}}return s;};
    const ms=v=>+(v/1000).toFixed(1);
    console.log('total muestreado ms',ms(tot),'frame',ms(bajo('frame')),'UEG.update',ms(bajo('update')),'gc',ms(porF.get('(garbage collector):-1')||0));
    for(const fn of ['procesarTrabajo','percibir','pensar','actuar','cerebro','escribirVista','tirarBala','resolverBala','rayo','lv','aEstrella','buscarCobertura','repartirFichas','updateEnemies','updateWeapon','vehUpdate','renderer'])console.log('bajo',fn,ms(bajo(fn)));
    /* quién llama a updateMatrixWorld (primer padre que no sea de three) */
    const quien=new Map();for(const [id,t] of self){const n=nodes.get(id);if(n.callFrame.functionName!=='updateMatrixWorld')continue;let x=par.get(id);
      while(x!==undefined&&nodes.get(x).callFrame.lineNumber===362)x=par.get(x);const k=x!==undefined?nombre(nodes.get(x)):'?';quien.set(k,(quien.get(k)||0)+t);}
    console.log('updateMatrixWorld por quien',JSON.stringify([...quien.entries()].sort((a,b)=>b[1]-a[1]).slice(0,8).map(([k,t])=>[k,ms(t)])));
    for(const fn of ['verModelos','mundo','u.update','u.boca','u.ojos','u.rayo','pasos','vaciar','UEB.estado','estado','debug','tickDialogos'])console.log('bajo',fn,ms(bajo(fn)));
    const top=[...porF.entries()].sort((a,b)=>b[1]-a[1]).slice(0,30);
    for(const [k,t] of top)console.log('propio',ms(t),k);
  }catch(e){lg('EXC',e.message.slice(0,600));}
  lg('errores',JSON.stringify(h.errors.slice(0,5)));
  await h.close();lg('cerrado');
})();
