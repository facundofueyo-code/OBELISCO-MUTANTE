#!/bin/sh
# Rearma obelisco-mutante.html (1.17.0) desde el juego original sin marcadores: sh rearmar.sh [original.html] (por omisión, el de Dev_Videogame)
d=$(cd "$(dirname "$0")" && pwd); python3 "$d/../v116/marcar.py" "${1:-/mnt/user-data/uploads/Dev_Videogame/obelisco-mutante.html}" "$d/.marcado.html" && python3 "$d/armar_juego.py" "$d/.marcado.html" "$d/obelisco-mutante.html"; r=$?; rm -f "$d/.marcado.html"; exit $r
