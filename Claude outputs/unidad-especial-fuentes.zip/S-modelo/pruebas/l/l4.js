/* primeros planos: cabeza, manos, velo, espalda del jefe y armas solas */
const v=(rol,pose,t,az,el,txt,o={})=>Object.assign({rol,pose,t,az,el,dist:.8,obj:[0,1.62,0],txt},o);
/* deja solo el arma (los huesos del cuerpo se achican a cero) y la acuesta frente a la cámara */
const soloArma=function(I){const s=I.soldados[0],u=s.u,b=u.malla.skeleton.bones;
  for(let i=0;i<b.length;i++){const n=b[i].name;if(!['arma','cargador','corredera','bipode','haz'].includes(n))b[i].scale.set(0,0,0);}
  const W=b.find(x=>x.name==='arma');const q=new THREE.Quaternion();
  const p0=W.position.clone(),q0=W.quaternion.clone(),inv=q0.clone().invert();
  for(const n of ['arma','cargador','corredera','bipode']){const x=b.find(y=>y.name===n);const rel=x.position.clone().sub(p0).applyQuaternion(inv);
    x.quaternion.premultiply(inv).premultiply(q);x.position.copy(rel.applyQuaternion(q)).add(new THREE.Vector3(0,.95,-.55));}
  const g0=I.scene.getObjectByName('UEM granada');if(g0)I.scene.remove(g0);
  if(s.rol==='jefe'){const g=UEM.granada();g.position.set(0,1.2,-.62);g.scale.setScalar(1.6);I.scene.add(g);}};
/* saca la granada de muestra si quedó de una vista anterior */
const limpiar=function(I){const g0=I.scene.getObjectByName('UEM granada');if(g0)I.scene.remove(g0);};
module.exports.limpiar=limpiar;
module.exports=Object.assign(module.exports||{},{cols:4,vistas:[
  v('jefe','Apunta',1.5,.5,.05,'cabeza 3/4 (noche)',{fn2:I=>{I.soldados[0].u.root.rotation.y=.35;}}),
  v('jefe','De pie',1.5,0,.03,'cabeza de frente (luz plena)',{plena:true}),
  v('granadero','De pie',1.5,1.57,.03,'cabeza de perfil (luz plena)',{plena:true}),
  v('jefe','Apunta',1.5,-.6,-.05,'manos en el fusil',{plena:true,obj:[-.1,1.38,.35],dist:.75}),
  v('tirador','De pie',1.5,.6,.05,'velo del tirador',{plena:true,obj:[0,1.55,0],dist:1.1}),
  v('jefe','De pie',1.5,3.4,.2,'espalda del jefe',{obj:[0,1.3,0],dist:2.4}),
  v('jefe','De pie',.5,1.57,.0,'fusil y granada',{plena:true,obj:[0,1.0,0],dist:1.35,fn2:soloArma}),
  v('tirador','De pie',.5,1.57,.0,'fusil de tirador',{plena:true,obj:[0,1.0,0],dist:1.55,fn2:soloArma})]});
