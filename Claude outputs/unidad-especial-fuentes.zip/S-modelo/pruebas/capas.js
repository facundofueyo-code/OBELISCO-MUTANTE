/* capas y muertes: manos agarradas, nada debajo del piso, sin NaN */
const THREE=require('../../three.r128.min.js');global.THREE=THREE;const fs=require('fs');
const UEM=new Function('THREE',fs.readFileSync(__dirname+'/../ue_modelo.js','utf8')+'\nreturn UEM;')(THREE);
const V3=THREE.Vector3,H=UEM._interno.H;
function piel(u){u.root.updateMatrixWorld(true);const g=u.malla.geometry,pos=g.attributes.position,si=g.attributes.skinIndex,sw=g.attributes.skinWeight,
  bones=u.malla.skeleton.bones,inv=u.malla.skeleton.boneInverses,M=bones.map((b,i)=>new THREE.Matrix4().multiplyMatrices(b.matrixWorld,inv[i]));
  let m=1e9,mb='',v=new V3(),a=new V3();
  for(let i=0;i<pos.count;i++){const b0=si.getX(i);if(bones[b0].scale.x<1e-3)continue;v.fromBufferAttribute(pos,i);let y=0;
    for(let j=0;j<2;j++){const w=j?sw.getY(i):sw.getX(i);if(w<=0)continue;a.copy(v).applyMatrix4(M[j?si.getY(i):si.getX(i)]);y+=a.y*w;}
    if(y<m){m=y;mb=bones[b0].name;}}
  return [m,mb];}
const nan=u=>{for(const b of u.malla.skeleton.bones)for(const x of b.matrixWorld.elements)if(!isFinite(x))return b.name;return null;};
function capa(nombre,rol,campo,dur,e0={},extra){
  const u=UEM.crear(rol,{semilla:9});Object.assign(u.e,e0);for(let i=0;i<60;i++)u.update(1/60);
  let maxI=0,maxD=0,minY=9,mb='',N=Math.round(dur*60);const st=u._st;
  for(let i=0;i<=N;i++){u.e[campo]=i/N;if(extra)extra(u,i/N);u.update(1/60);
    const eI=st.P[H.manoI].distanceTo(st.sp.mano[0].p),eD=st.P[H.manoD].distanceTo(st.sp.mano[1].p);maxI=Math.max(maxI,eI);maxD=Math.max(maxD,eD);
    if(i%6===0){const [m,b]=piel(u);if(m<minY){minY=m;mb=b;}}}
  console.log(nombre.padEnd(26),rol.padEnd(9),'manoI máx',(maxI*100).toFixed(1),'cm · manoD máx',(maxD*100).toFixed(1),'cm · minY',minY.toFixed(3),mb,nan(u)||'');
}
for(const r of ['jefe','asalto','tirador'])capa('recarga',r,'recarga',2.4,{apunta:1});
capa('recarga agachado','granadero','recarga',2.4,{apunta:1,agach:1});
capa('recarga a tierra','jefe','recarga',2.4,{apunta:1,tierra:1});
capa('granada','granadero','lanza',1.3,{apunta:.4});
capa('granada agachado','granadero','lanza',1.3,{agach:1});
for(const t of ['avanzar','izq','der','alto'])capa('seña '+t,'jefe','senal',1.6,{senalTipo:t});
capa('culatazo','asalto','culata',1,{apunta:.5});
capa('culatazo','jefe','culata',1,{apunta:.5});
capa('salto','asalto','salto',1.1,{},(u,t)=>{u.root.position.z=t*1.6;});
capa('a tierra (bajando)','tirador','tierra',1.4,{apunta:1});
capa('se para (agachado)','jefe','agach',.5,{apunta:1});
for(const tipo of ['atras','adelante','derrumbe','tierra'])
  capa('muere '+tipo,'jefe','__',1.3,tipo==='tierra'?{tierra:1,apunta:1}:{apunta:1},(u,t)=>{u.e.muerte=u.e.muerte||{tipo,t:0,dir:.3};u.e.muerte.t=t;});
