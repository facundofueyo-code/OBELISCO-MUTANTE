const H=require('../../harness.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
(async()=>{const h=await H.open(F);
  try{await h.start();await h.ev("RETEN.ir({bichos:false});1");await h.step(.5);
    console.log(JSON.stringify(await h.ev(`(()=>{const a=new V3(),b=new V3(),out=[];let s=7;const r=()=>{s=(s*16807)%2147483647;return s/2147483647;};
      for(let k=0;k<40;k++){T+=1.1;const ox=-441+r()*4,oz=603+r()*8,hx=-430+r()*25,hz=598+r()*18;a.set(ox,floorAt(ox,oz)+1.75,oz);b.set(hx,floorAt(hx,hz),hz);
        const t0=performance.now();const q=GRAN.arco(a,b);const ms=performance.now()-t0;const t1=performance.now();GRAN.arco(a,b);const ms2=performance.now()-t1;out.push([+ms.toFixed(1),+ms2.toFixed(1),q.ok?1:0]);}
      const c=out.map(o=>o[0]).sort((x,y)=>x-y);return {frio:{med:c[20],p90:c[36],max:c[39]},cache:Math.max(...out.map(o=>o[1])),ok:out.filter(o=>o[2]).length,muestras:out.slice(0,12)};})()`)));
  }catch(e){console.log('EXC',e.message.slice(0,300));}
  console.log('errores',JSON.stringify(h.errors.slice(0,3)));await h.close();})();
