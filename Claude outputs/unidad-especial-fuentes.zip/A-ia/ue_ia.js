/* =====================================================================================================
   UNIDAD ESPECIAL — IA de escuadrón (módulo UE)                                  Obelisco Mutante v1.15
   -----------------------------------------------------------------------------------------------------
   JavaScript puro: no usa Three.js ni DOM. Todo lo que la IA sabe del mundo entra por ENV (SPEC 4.7).

   La idea rectora: un escuadrón parece inteligente y a la vez justo no por tener muchas reglas, sino
   porque SE COORDINA y AVISA lo que va a hacer. Las reglas de juego limpio (SPEC 1.3) están escritas
   acá como mecanismos, no como buenas intenciones:

     1. Un cerebro por escuadrón reparte tareas (base de fuego, flanqueo, tirador) y permisos de moverse.
     2. Nadie lee la posición real del jugador para decidir: `percibir()` es el ÚNICO lugar que mira a
        ENV.jugador() para saber algo. Todo lo demás trabaja con el «último lugar conocido» (uc).
        (La otra lectura de ENV.jugador() está en `resolverBala()`: es física —si la bala lo toca o no—
        y nunca vuelve como conocimiento.)
     3. Granada: grito + gesto antes de soltarla. Tirador: láser continuo antes del tiro.
     4. Fichas de ataque: como mucho TUNE.fichas tiran a pegar; los demás suprimen (erran a propósito).
        La primera ráfaga de cada soldado es de aviso.
     5. Tiempos humanos: reacción, recarga, posturas, supresión.
     6. Cada bala se resuelve con un rayo real (ENV.rayo): nunca atraviesa nada.
     7. Tope de daño por segundo de fusil y escopeta.
     8. Corren más lento que el jugador.

   CONTRATO (SPEC 4.7, con lo que se agregó; detalle en INFORME.md)
     crearUE(ENV, TUNE) → UE                        TUNE se mezcla con UE_TUNE campo por campo (acepta `daño` o `dano`)
     UE.escuadron({nombre, roles, puestos, ronda, nido, reunion}) → esc
         roles: ['jefe','asalto','granadero','tirador'] · puestos: {rol:{x,z,rumbo}} o [{x,z,rumbo}] alineado con roles
         ronda: [{x,z}] (la camina el asalto) · nido: {x,z,y,rumbo,r} (techo; y = altura del techo, r = tope de la plataforma)
         reunion: {x,z}. rumbo = atan2(dx,dz) (π/2 = mirando al este)
     UE.refuerzo({nombre, roles, sale:{x,z}, camino:[{x,z}]})   sus soldados se crean recién cuando llegan
     UE.update(dt) · UE.reset() (llama vista.dispose() y rehace lo pedido)
     UE.soldados: todos, vivos y muertos (objetos planos; ver nuevoSoldado)
     UE.rayo(o, d, maxT) → null | {s, t, parte}     o, d: {x,y,z} (d unitario). parte: 'cabeza' | 'torso' | 'pierna'
     UE.herir(s, daño, dir, parte, de)              dir: {x,y,z} hacia donde iba la bala · de: 'jugador'|'bicho'|'granada'|'auto'
     UE.balaCerca(o, d, t) · UE.ruido(pos, tipo, fuerza) · UE.explosion(pos, radio, daño, de)
         ruido: pos = pies de quien lo hizo. Solo 'disparo', 'pasos' y 'jugador' dicen dónde está el testigo;
                'explosion', 'impacto' u otro alarman y hacen mirar, pero no lo ubican.
     UE.objetivos() → soldados vivos (tienen x,y,z,r,vivo,herir(daño,bicho))
     UE.estado() → {sospecha, x, z, angulo, combate, busqueda, quedan, refuerzo:'no'|'pedido'|'llego', refuerzoEn}
     UE.debug() → lo de la SPEC + (y, tarea, vivo, sosp, laser, luz) por soldado y (fase, flanco) por escuadrón
     ENV como en la SPEC, más: peligros() puede traer {de, tipo:'granada'|'auto'} · bala(ev) trae además
     {modo:'pegar'|'suprimir'|'aviso'|'bicho'|'laser', ficha, raf, px,py,pz} y el objeto ev SE REUSA (copiarlo si se guarda) ·
     radio(s, …): para «Tizón en camino» s es una voz virtual {virtual:true, nombre} (el refuerzo todavía no existe) ·
     evento(nombre, datos): contacto, combate, sospecha, nada, perdido, busqueda, limpio, guardia, jugador_muerto, baja,
     jefe_caido, herido, refuerzo{fase:pide|pedido|interrumpido|entra|llega}, granada_orden, granada_aviso, granada,
     flanco, flanco_sale, flanco_llego, flanco_fin, flanco_no, avance, empuje, recarga, bichos, tirador_mira.

   Cómo está armado (de arriba hacia abajo):
     UE_TUNE ........ todos los números, comentados
     FRASES ......... lo que dicen por radio (SPEC 9)
     crearUE() ...... grilla y línea de visión · A* · coberturas · soldado · percepción · armas ·
                      estados del soldado · cerebro del escuadrón · API pública
   ===================================================================================================== */

const UE_TUNE = {
  /* ---------- las tres perillas simples (para Facu) ---------- */
  fichas: 2,            // cuántos soldados pueden «tirar a pegar» al mismo tiempo (el tirador va aparte). 1 = fácil, 3 = brutal
  punteria: 1,          // multiplica la dispersión de todas sus armas: 1.5 = tiran peor, 0.7 = tiran mejor
  dano: 1,              // multiplica el daño que le hacen al jugador (también se acepta escrito `daño`)

  /* ---------- cuerpo ---------- */
  vida: 100,            // salud de cada soldado
  multCabeza: 2.2,      // un tiro en la cabeza saca 2,2 veces
  multTorso: 0.85,      // el chaleco para algo
  multMiembro: 0.7,     // brazo o pierna
  velRonda: 1.6,        // m/s caminando la ronda
  velAgach: 3.2,        // m/s avanzando agachado (flanqueo, búsqueda)
  velCorrer: 5.6,       // m/s corriendo de cobertura a cobertura (el jugador corre a 9,6: siempre se les escapa)
  velEscapar: 6.6,      // m/s escapando de una granada
  acel: 14,             // m/s²: no cambian de dirección de golpe
  tAgach: 0.25,         // s de pie ↔ agachado
  tATierra: 0.6,        // s agachado → cuerpo a tierra
  tDeTierra: 0.9,       // s cuerpo a tierra → agachado (mientras se levanta no puede tirar ni correr)
  ojoPie: 1.62, ojoAgach: 1.05, ojoTierra: 0.30,   // altura de los ojos en cada postura (m)
  giro: 4,              // rad/s que gira el cuerpo
  reaccion: 0.45,       // s desde que lo ve hasta que puede tirar
  reaccionCerca: 18,    // m: si lo ve más cerca que esto al reaccionar, primero devuelve el fuego y después se cubre
  reaccionEspera: 0.36, // s si reaparece donde se escondió hace menos de esperaT (lo estaban esperando)
  esperaT: 4,           // s que un soldado quieto sigue «esperando» al jugador donde lo vio esconderse
  asientoEspera: 0.2,   // cuánta puntería pierde por segundo mientras lo espera (sin esperar: 3 por segundo)
  heridoBajo: 0.35,     // por debajo de esta fracción de vida se repliega y dice «herido»
  aturdeDano: 34,       // un golpe de este daño o más (escopeta de cerca) lo deja aturdido
  aturdeT: 0.5,         // s aturdido

  /* ---------- vista y oído ---------- */
  conoGuardia: 110,     // grados del cono de visión en guardia
  conoSospecha: 150,    // cuando ya sospechan o buscan
  conoCombate: 200,     // en combate
  vistaDist: 45,        // m que ven de noche
  vistaLuz: 1.5,        // × si el jugador está en zona iluminada o con la linterna prendida
  vistaQuieto: 0.6,     // × si el jugador está agachado, quieto y a oscuras
  vistaTope: 80,        // m: nunca más lejos que esto
  detectar: [8, 0.35, 15, 0.9, 30, 2, 45, 4],   // pares (distancia m, segundos para detectarlo en guardia)
  detLuz: 1.6,          // la sospecha sube × esto si está iluminado o con linterna
  detAgach: 0.6,        // × si está agachado
  detQuieto: 0.7,       // × si está quieto
  detMedio: 0.5,        // × si solo se le ve la cabeza
  detCorre: 1.3,        // × si corre
  detBorde: 0.6,        // × si lo ve con el rabillo del ojo (fuera del 60 % central del cono)
  detAlerta: 2.2,       // × cuando el escuadrón ya sospecha, busca o volvió de un combate
  sospechaBaja: 0.25,   // la sospecha baja esto por segundo si deja de verlo
  sospechaMira: 0.4,    // a partir de acá gira, alumbra y avisa «sospecha»
  oidoDisparo: 120,     // m a los que oyen un disparo del jugador
  oidoPasos: 14,        // m a los que oyen pasos corriendo
  oidoImpacto: 3,       // m a los que notan un impacto de bala
  oidoExplosion: 150,   // m a los que oyen una explosión
  vistaBicho: 30,       // m a los que ven mutantes
  aviso: 0.5,           // s desde que uno lo ve hasta que lo sabe el escuadrón (lo dice por radio)
  tPercibir: 0.12,      // cada cuánto mira cada soldado (s)
  tPensar: 0.125,       // cada cuánto decide cada soldado (s): 8 veces por segundo
  tCerebro: 0.4,        // cada cuánto decide el escuadrón (s)
  lejos: 160,           // si el jugador está más lejos que esto y están en guardia, casi no gastan

  /* ---------- fichas de ataque y puntería ---------- */
  fichaMin: 1.6,        // s mínimos que un soldado conserva la ficha
  fichaMax: 5.5,        // s tras los cuales la cede si otro la está esperando
  asientoT: 1.0,        // s que tarda en asentar la puntería viéndolo sin parar
  miraAtraso: 0.18,     // s de atraso del punto de mira respecto del jugador
  miraAdelanto: 0.5,    // cuánto del atraso compensa adelantando (0.5 = la mitad: de costado y corriendo, erra)
  supOffMin: 0.9, supOffMax: 1.5,   // tirar a suprimir: a cuántos metros del jugador apuntan a propósito
  topeDano: 32,         // salud por segundo como máximo con balas de fusil y escopeta

  /* ---------- armas ---------- */
  fusil: {
    rafMin: 3, rafMax: 5,     // balas por ráfaga
    cadencia: 0.095,          // s entre balas
    pausaMin: 0.6, pausaMax: 1.2,   // s entre ráfagas
    dano: 7,                  // por bala
    disp: 0.011,              // rad de dispersión con la puntería asentada
    suelto: 3.2,              // × sin asentar
    cargador: 30, recarga: 2.4,
    alcance: 110
  },
  escopeta: {
    perdigones: 8, dano: 5,   // 8 perdigones de 5
    disp: 0.05,
    cadencia: 0.95,           // s entre tiros
    lleno: 10,                // hasta acá el perdigón pega entero
    util: 16,                 // a esta distancia todavía sirve (pega ~2/3)
    nada: 28,                 // de acá en más no hace nada
    cargador: 6, recargaCartucho: 0.55,
    alcance: 40
  },
  tirador: {
    dano: 48,
    laser: 1.3,               // s de láser continuo sobre el jugador antes del destello
    destello: 0.25,           // s de destello antes del tiro
    ciclo: 3.2,               // s mínimos entre tiros
    atraso: 0.22,             // s de atraso del punto rojo
    adelanto: 0.6,            // adelanta el 60 %: corriendo de costado te erra
    disp: 0.0018,
    cadencia: 1.2,            // s entre tiros cuando se defiende de un bicho (sin láser: no es contra el testigo)
    cerca: 12,                // a menos de esto tira rápido y mal, sin láser
    cercaDano: 24, cercaDisp: 0.05, cercaCadencia: 1.2,
    cargador: 5, recarga: 3.0,
    distMin: 28, distMax: 75, // a qué distancia del jugador busca puesto
    alcance: 140
  },
  culata: { dano: 15, dist: 1.8, aviso: 0.35, cada: 2.5 },

  /* ---------- supresión sobre el soldado ---------- */
  suprCerca: 1.2,       // m: una bala del jugador que pasa a menos de esto lo suprime
  suprSuma: 0.35,       // cuánto suma cada bala
  suprBaja: 0.5,        // cuánto baja por segundo
  suprEsconde: 0.6,     // por encima de esto se esconde y pierde la puntería
  suprTMin: 0.8, suprTMax: 1.5,   // s que se queda escondido

  /* ---------- granadas ---------- */
  granada: {
    mecha: 3,             // s desde que sale de la mano
    aviso: 0.65,          // s entre el grito y soltarla (mínimo)
    gesto: 1.3,           // s que dura el gesto de lanzar (la suelta en el 55 %)
    radio: 7, dano: 80,   // m y daño en el centro (el daño real lo aplica el sistema de granadas del juego)
    cobertura: 0.3,       // × detrás de cobertura
    cada: 11,             // s entre granadas del escuadrón
    distMin: 8, distMax: 30,
    quieto: 3.5,          // s que el jugador lleva quieto o cubierto…
    quietoRadio: 2.5,     // …en este radio, para que se la tiren
    amigos: 8,            // m: ningún compañero más cerca que esto del blanco
    bichos: 3,            // cuántos bichos juntos justifican una
    bichosRadio: 4.5
  },

  /* ---------- escuadrón ---------- */
  flancoCada: 14,       // s mínimos entre órdenes de flanqueo
  flancoMinVivos: 3,    // con menos, no se flanquea: aguantan
  flancoDist: 12,       // m del jugador a los que busca quedar el que flanquea
  perdidoT: 2.5,        // s sin verlo: «lo perdí» y fuego sobre el último lugar
  perdidoAccion: 7,     // s: granada o avance
  perdidoBarrido: 12,   // s: empieza el barrido
  barridoT: 30,         // s que dura el barrido
  jefeCaidoT: 7,        // s de desorden al caer el jefe
  refuerzoVivos: 2,     // con esta cantidad o menos piden refuerzo
  refuerzoCombate: 45,  // o a los tantos segundos de combate
  refuerzoPedir: 3,     // s que tarda en pedirlo por radio
  refuerzoLlega: 25,    // s que tarda en llegar
  radioCada: 1.2,       // s mínimos entre frases de un mismo escuadrón (las de peligro pasan siempre)
  separacion: 3,        // m: no comparten cobertura (a menos de esto son blanco de una sola granada)
  moverSinVer: 2,       // s sin que nadie vea al jugador para moverse sin pedir fuego de cobertura
  ventanaMin: 1.2, ventanaMax: 2.5,   // s que se queda asomado tirando
  cubiertoMin: 0.5, cubiertoMax: 1.4, // s que se queda cubierto entre asomadas
  distJefe: 30, distGranadero: 22, distAsalto: 12,   // m del jugador que prefiere cada rol

  /* ---------- bichos ---------- */
  bichoManda: 7,        // m: un bicho más cerca que esto pasa a ser el blanco sí o sí
  bichoRetro: 4.5,      // m: si se le viene encima, retrocede tirando
  bichoDano: 1,         // multiplica el daño de sus balas a los bichos

  /* ---------- camino ---------- */
  costoExpo: 2.6,       // un casillero que el jugador ve cuesta (1 + esto) veces: salen solos los flanqueos tapados
  costoSalto: 3,        // costo extra de saltar una valla (≈ medio segundo)
  saltoMax: 12,         // dm: hasta 1,2 m se salta; lo más alto se rodea
  saltoT: 0.5,          // s que tarda en pasar una valla
  perfil: false,        // (solo para medir) true cronometra los trabajos pesados: UE.interno.prof
  aMaxIt: 3000,         // casilleros que mira como mucho un A* (si no llega, usa el tramo que más se acercó)
  presuLineas: 500      // líneas de visión nuevas (exposición, línea de fuego) que puede calcular un trabajo pesado por cuadro
};

/* Frases de radio (SPEC 9). Una entrada puede ser un diálogo [«pregunta», «respuesta»]: la segunda la dice otro. */
const UE_FRASES = {
  ocioso: ['Central, retén Mayo sin novedad.', ['¿Cuántos van?', 'Once.'], 'Media hora para el relevo.', 'Nadie sale de la zona. Nadie.'],
  sospecha: ['Vi algo. Voy a mirar.', '¿Escucharon eso?', 'Movimiento al este.'],
  nada: ['Nada. Falsa alarma.', 'Sin novedad.'],
  contacto: ['Contacto. Testigo al frente.', 'Lo veo. Detrás del auto.', 'Testigo a la vista.'],
  fijar: ['Fuego de cobertura.', 'Lo tengo fijado.'],
  muevo: ['Me muevo.', 'Cambio de posición.', 'Cubrime.'],
  tecubro: ['Te cubro.', 'Dale, andá.'],
  orden_flanco: ['Ceniza {N}, rodealo.'],
  flanco_izq: ['Voy por izquierda.'],
  flanco_der: ['Voy por derecha.'],
  granada: ['¡Granada va!'],
  granada_enemiga: ['¡Granada! ¡Al piso!'],
  recarga: ['Recargando.', 'Cambio cargador.'],
  recarga_jugador: ['Está recargando. ¡Voy!'],
  herido: ['Me dieron.', 'Estoy herido.'],
  suprimido: ['¡Me tiene clavado!'],
  flanqueado: ['¡Nos rodeó!', '¡Por el costado!'],
  baja: ['Hombre caído.', 'Cayó Ceniza {N}.'],
  jefe_caido: ['Cayó el jefe. Tomo el mando.'],
  perdido: ['Lo perdí.', 'Sin visual.'],
  tirador_listo: ['Tirador en posición.'],
  tirador_mira: ['Lo tengo en la mira.'],
  tirador_fallo: ['Se me movió.'],
  bichos: ['¡Bichos!', 'Bichos por atrás.', 'Contacto hostil, no humano.'],
  auto_fuego: ['¡Ese auto va a volar! ¡Salgan!'],
  busqueda: ['Barriendo el sector.', 'Revisen los autos.'],
  limpio: ['Sector limpio. Volvemos al retén.'],
  refuerzo_pide: ['Central, contacto en el retén Mayo. Pedimos apoyo.'],
  refuerzo_va: ['Tizón en camino. Treinta segundos.'],
  refuerzo_llega: ['Tizón en posición.'],
  muerto_jugador: ['Testigo eliminado.', 'Central, uno menos.']
};
/* frases de peligro: pasan siempre, aunque el escuadrón haya hablado recién */
const UE_URGENTES = { granada: 1, granada_enemiga: 1, auto_fuego: 1, contacto: 1, jefe_caido: 1 };
/* frases que avisan algo al jugador (regla 3): si la radio está ocupada, esperan su turno en vez de perderse */
const UE_IMPORTANTES = { orden_flanco: 1, flanco_izq: 1, flanco_der: 1, recarga: 1, perdido: 1, refuerzo_pide: 1, refuerzo_va: 1, refuerzo_llega: 1,
  recarga_jugador: 1, baja: 1, busqueda: 1, limpio: 1, herido: 1, tirador_mira: 1, muerto_jugador: 1, fijar: 1, flanqueado: 1 };

function crearUE(ENV, TUNE) {
  /* ---------- números: los de UE_TUNE, pisados por lo que venga en TUNE (las armas se mezclan campo por campo) ---------- */
  const T = {};
  for (const k in UE_TUNE) { const v = UE_TUNE[k]; T[k] = (v && typeof v === 'object' && !Array.isArray(v)) ? Object.assign({}, v) : v; }
  if (TUNE) for (const k in TUNE) {
    const v = TUNE[k];
    if (k === 'daño') { T.dano = v; continue; }
    if (v && typeof v === 'object' && !Array.isArray(v) && T[k] && typeof T[k] === 'object') Object.assign(T[k], v); else T[k] = v;
  }

  /* ====================================================================================================
     UTILIDADES
     ==================================================================================================== */
  const PI = Math.PI, PI2 = PI * 2, RAD = PI / 180;
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const hyp = Math.hypot;
  const angN = a => { a = a % PI2; if (a > PI) a -= PI2; else if (a < -PI) a += PI2; return a; };   // deja el ángulo en (−π, π]
  const azar = () => ENV.azar();
  const entre = (a, b) => a + (b - a) * ENV.azar();
  /* desvío acotado con forma de campana (triángulo): entre −1 y 1, casi siempre cerca de 0 */
  const campana = () => ENV.azar() + ENV.azar() - 1;
  let ahora = 0;        // reloj del juego (s), se lee una vez por cuadro
  let cuadro = 0;       // contador de cuadros

  /* ====================================================================================================
     GRILLA (SPEC 2.3): B 0 libre · 1 trepable (H en dm) · 2 bloqueado. Casillero de 1 m.
     Se relee de ENV en cada cuadro por si el juego reemplazó los arreglos.
     ==================================================================================================== */
  let B = ENV.B, H = ENV.H, EW = ENV.EW, EH = ENV.EH, EX0 = ENV.EX0, EZ0 = ENV.EZ0;
  function leerGrilla() { B = ENV.B; H = ENV.H; EW = ENV.EW; EH = ENV.EH; EX0 = ENV.EX0; EZ0 = ENV.EZ0; }
  const celda = (x, z) => { const i = Math.floor(x - EX0), j = Math.floor(z - EZ0); return (i < 0 || j < 0 || i >= EW || j >= EH) ? -1 : j * EW + i; };
  const cX = k => EX0 + (k % EW) + 0.5, cZ = k => EZ0 + ((k / EW) | 0) + 0.5;
  const esLibre = k => k >= 0 && B[k] === 0;
  const libreEn = (x, z) => { const k = celda(x, z); return k >= 0 && B[k] === 0; };
  /* altura de lo que hay en un casillero, en metros (lo bloqueado cuenta como pared) */
  const altoDe = k => k < 0 ? 99 : B[k] === 2 ? 99 : B[k] === 1 ? H[k] * 0.1 : 0;
  const D8I = [1, -1, 0, 0, 1, -1, 1, -1], D8J = [0, 0, 1, -1, 1, 1, -1, -1];

  /* casillero libre más cercano a un punto (para arrancar un camino o sacar a alguien de adentro de algo) */
  function libreCerca(x, z, radio) {
    const k0 = celda(x, z); if (esLibre(k0)) return k0;
    const i0 = Math.floor(x - EX0), j0 = Math.floor(z - EZ0); let mejor = -1, md = 1e9;
    for (let dj = -radio; dj <= radio; dj++) for (let di = -radio; di <= radio; di++) {
      const i = i0 + di, j = j0 + dj; if (i < 0 || j < 0 || i >= EW || j >= EH) continue;
      const k = j * EW + i; if (B[k] !== 0) continue;
      const ddx = EX0 + i + 0.5 - x, ddz = EZ0 + j + 0.5 - z, d = ddx * ddx + ddz * ddz; if (d < md) { md = d; mejor = k; }
    }
    return mejor;
  }

  /* ----------------------------------------------------------------------------------------------------
     Línea de visión rápida: la grilla como campo de alturas. Recorre exactamente los casilleros que cruza la recta
     entre a y b (en vez de muestrear de a 0,5 m, que se salteaba las esquinas de los autos); si lo que hay en el
     casillero es más alto que el rayo en ese tramo, tapa. Saltea los primeros y los últimos 0,6 m (el que
     mira y el mirado pueden estar pegados a su cobertura).
     Devuelve 1 (se ve), 0 (tapado) o 2 (tapado solo en el último tramo: «dudoso»).
       · «dudoso» existe porque la grilla entra inflada 0,3 m: un jugador pegado a una pared queda ADENTRO
         de un casillero bloqueado y la grilla lo daría por invisible. La percepción resuelve ese caso con un
         rayo real (ENV.rayo); todo lo demás lo toma como tapado.
       · plat = {r, y}: el que mira está subido a algo (el nido del tirador): los casilleros ocupados seguidos desde
         sus pies (hasta r metros) son su propia plataforma y solo tapan si el rayo baja de y.
     ---------------------------------------------------------------------------------------------------- */
  function lv(ax, ay, az, bx, by, bz, plat) {
    const dx = bx - ax, dz = bz - az, d = Math.sqrt(dx * dx + dz * dz);
    if (d < 1.3) return 1;
    /* recorrido exacto casillero por casillero (DDA), medido en metros horizontales desde a; se mira el tramo [0,6 ; d−0,6] */
    const ux = dx / d, uz = dz / d, gy = (by - ay) / d, s0 = 0.6, s1 = d - 0.6;
    let i = Math.floor(ax - EX0), j = Math.floor(az - EZ0);
    const si = ux > 0 ? 1 : -1, sj = uz > 0 ? 1 : -1;
    const tdx = Math.abs(ux) > 1e-9 ? 1 / Math.abs(ux) : Infinity, tdz = Math.abs(uz) > 1e-9 ? 1 / Math.abs(uz) : Infinity;
    let tmx = Math.abs(ux) > 1e-9 ? (ux > 0 ? EX0 + i + 1 - ax : ax - (EX0 + i)) * tdx : Infinity;
    let tmz = Math.abs(uz) > 1e-9 ? (uz > 0 ? EZ0 + j + 1 - az : az - (EZ0 + j)) * tdz : Infinity;
    let t0 = 0, enPlat = !!plat;
    while (t0 < s1) {
      const t1 = tmx < tmz ? (tmx < s1 ? tmx : s1) : (tmz < s1 ? tmz : s1);
      if (t1 > s0) {
        if (i < 0 || j < 0 || i >= EW || j >= EH) return 0;
        const k = j * EW + i, b = B[k];
        if (b === 0) enPlat = false;
        else {
          const ta = t0 > s0 ? t0 : s0, ya = ay + gy * ta, yb = ay + gy * t1, ym = ya < yb ? ya : yb;
          /* subido a algo (nido): los casilleros ocupados seguidos desde sus pies son su plataforma; solo tapan si el rayo baja del techo */
          if (enPlat && ta < plat.r) { if (ym < plat.y - 0.02) return 0; }
          else { enPlat = false; if (b === 2 || ym < H[k] * 0.1) return (d - ta <= 1.7) ? 2 : 0; }
        }
      }
      if (tmx < tmz) { i += si; t0 = tmx; tmx += tdx; } else { j += sj; t0 = tmz; tmz += tdz; }
    }
    return 1;
  }
  const lineaVista = (ax, ay, az, bx, by, bz, plat) => lv(ax, ay, az, bx, by, bz, plat) === 1;

  /* Camino recto por casilleros libres (para suavizar caminos y para pasos cortos). Muestrea cada 0,4 m.
     Con esc ≥ 0 además limita cuántos metros del tramo pueden quedar a la vista del último lugar conocido. */
  function lineaLibre(ax, az, bx, bz, exMax, agach) {
    const dx = bx - ax, dz = bz - az, d = Math.sqrt(dx * dx + dz * dz), n = Math.max(1, Math.ceil(d / 0.4));
    let ex = 0;
    for (let q = 1; q <= n; q++) {
      const u = q / n, k = celda(ax + dx * u, az + dz * u);
      if (k < 0 || B[k] !== 0) return false;
      if (exMax >= 0 && expuesta(k, agach)) { ex += d / n; if (ex > exMax + 0.6) return false; }
    }
    return true;
  }

  /* El punto desde donde «mira» una amenaza: si el lugar conocido cae adentro de un casillero no libre
     (el jugador pegado a un auto o a una pared, por la grilla inflada), se usa el casillero libre más cercano. */
  const _ol = { x: 0, z: 0 };
  function origenLibre(x, z) {
    const k = libreCerca(x, z, 2);
    if (k < 0 || k === celda(x, z)) { _ol.x = x; _ol.z = z; } else { _ol.x = cX(k); _ol.z = cZ(k); }
    return _ol;
  }

  /* ====================================================================================================
     EXPOSICIÓN: qué casilleros ve el jugador desde su último lugar conocido.
     Se calcula una sola vez para todos (a pedido, casillero por casillero) y se comparte mientras el lugar
     conocido no cambie. La usan el A* (flanqueos tapados) y el suavizado de caminos.
     ==================================================================================================== */
  const XW = 128, XN = XW * XW;
  const xDat = new Uint8Array(XN), xSel = new Uint32Array(XN);
  let xSello = 1, xI0 = 0, xJ0 = 0, xOx = 1e9, xOz = 1e9, xVx = 0, xVz = 0, xOk = false, xCalc = 0;
  let xPresu = 1e9;     // cuántas líneas nuevas puede calcular el trabajo en curso (lo pone procesarTrabajo): acota el peor cuadro
  function expoCentrar(x, z) {
    if (xOk && Math.abs(x - xOx) < 1 && Math.abs(z - xOz) < 1) return;
    const o = origenLibre(x, z); xOx = x; xOz = z; xVx = o.x; xVz = o.z; xSello++; xOk = true;
    xI0 = Math.floor(o.x - EX0) - (XW >> 1); xJ0 = Math.floor(o.z - EZ0) - (XW >> 1);
  }
  /* ¿se ve el casillero k desde el último lugar conocido? agach: el que pasa va agachado (se lo ve menos) */
  function expuesta(k, agach) {
    if (!xOk) return 0;
    const i = (k % EW) - xI0, j = ((k / EW) | 0) - xJ0;
    if (i < 0 || j < 0 || i >= XW || j >= XW) return 0;            // lejos: no cuenta
    const l = j * XW + i; let v = xSel[l] === xSello ? xDat[l] : 0;
    const bitC = agach ? 1 : 4, bitV = agach ? 2 : 8;
    if (!(v & bitC)) {
      if (xPresu-- <= 0) return 1;                                     // sin presupuesto: se la supone a la vista (camino más prudente)
      xCalc++;
      const ve = lv(xVx, 1.6, xVz, cX(k), agach ? 1.0 : 1.6, cZ(k)) === 1;
      v |= bitC | (ve ? bitV : 0); xDat[l] = v; xSel[l] = xSello;
    }
    return (v & bitV) ? 1 : 0;
  }
  /* ¿hay línea de fuego entre el pecho del jugador (en el último lugar conocido) y el arma de alguien parado (o agachado)
     en el casillero k? Mismo caché que la exposición (bits 16…128). La usa la búsqueda de coberturas para descartar barato. */
  function lineaFuego(k, agach) {
    if (!xOk) return 0;
    const i = (k % EW) - xI0, j = ((k / EW) | 0) - xJ0;
    if (i < 0 || j < 0 || i >= XW || j >= XW) return 0;
    const l = j * XW + i; let v = xSel[l] === xSello ? xDat[l] : 0;
    const bitC = agach ? 16 : 64, bitV = agach ? 32 : 128;
    if (!(v & bitC)) {
      if (xPresu-- <= 0) return 0;                                     // sin presupuesto: se la descarta
      xCalc++;
      const ve = lv(xVx, 1.1, xVz, cX(k), agach ? 0.98 : 1.56, cZ(k)) === 1;
      v |= bitC | (ve ? bitV : 0); xDat[l] = v; xSel[l] = xSello;
    }
    return (v & bitV) ? 1 : 0;
  }

  /* ====================================================================================================
     A* sobre la grilla de 1 m, en una ventana de 144 × 144 m que contiene al que camina.
     · pasa por casilleros libres; las vallas y cosas de hasta 1,2 m se saltan con costo; los autos se rodean
     · con op.expo, pasar por donde el último lugar conocido tiene línea de visión cuesta (1+costoExpo) veces:
       de ahí salen solos los caminos tapados y los flanqueos por donde no se los ve
     · op.evita = [{x,z,r,c}]: zonas con costo extra (granadas, autos por explotar)
     Devuelve una lista de puntos {x,z,salto} ya suavizada, o null. Si no llega, devuelve el tramo que más
     se acerca (camino.parcial = true): nunca deja a nadie sin camino por un destino difícil.
     ==================================================================================================== */
  const AMAX = 144, AN = AMAX * AMAX;
  const aG = new Float32Array(AN), aDe = new Int32Array(AN), aAb = new Uint32Array(AN), aCe = new Uint32Array(AN);
  const HCAP = AN * 4, hF = new Float32Array(HCAP), hK = new Int32Array(HCAP);
  let aSello = 0, hN = 0, aCuenta = 0, aIt = 0;
  function hPush(f, k) {
    if (hN >= HCAP) return;
    let a = hN++; hF[a] = f; hK[a] = k;
    while (a > 0) { const p = (a - 1) >> 1; if (hF[p] <= hF[a]) break; const f0 = hF[p], k0 = hK[p]; hF[p] = hF[a]; hK[p] = hK[a]; hF[a] = f0; hK[a] = k0; a = p; }
  }
  function hPop() {
    const k = hK[0]; hN--;
    if (hN > 0) {
      hF[0] = hF[hN]; hK[0] = hK[hN]; let a = 0;
      for (;;) { const L = 2 * a + 1, R = L + 1; let m = a; if (L < hN && hF[L] < hF[m]) m = L; if (R < hN && hF[R] < hF[m]) m = R; if (m === a) break;
        const f0 = hF[m], k0 = hK[m]; hF[m] = hF[a]; hK[m] = hK[a]; hF[a] = f0; hK[a] = k0; a = m; }
    }
    return k;
  }
  function aEstrella(sx, sz, tx, tz, op) {
    aCuenta++;
    const expo = !!(op && op.expo) && xOk, agach = !!(op && op.agach), evita = (op && op.evita) || null;
    let s0 = celda(sx, sz); if (s0 < 0) return null;
    if (B[s0] !== 0) { s0 = libreCerca(sx, sz, 3); if (s0 < 0) return null; }
    const si = s0 % EW, sj = (s0 / EW) | 0, ti = Math.floor(tx - EX0), tj = Math.floor(tz - EZ0);
    /* ventana centrada entre el origen y el destino; el origen queda siempre adentro, con margen */
    let i0 = ((si + ti) >> 1) - (AMAX >> 1), j0 = ((sj + tj) >> 1) - (AMAX >> 1);
    if (si - i0 < 8) i0 = si - 8; if (i0 + AMAX - 1 - si < 8) i0 = si + 9 - AMAX;
    if (sj - j0 < 8) j0 = sj - 8; if (j0 + AMAX - 1 - sj < 8) j0 = sj + 9 - AMAX;
    const gk = l => (j0 + ((l / AMAX) | 0)) * EW + i0 + (l % AMAX);
    const enGrilla = (i, j) => { const gi = i0 + i, gj = j0 + j; return gi >= 0 && gj >= 0 && gi < EW && gj < EH; };
    /* destino: adentro de la ventana y en un casillero libre (si no, el libre más cercano) */
    let li = clamp(ti - i0, 1, AMAX - 2), lj = clamp(tj - j0, 1, AMAX - 2), corrido = (li !== ti - i0 || lj !== tj - j0);
    if (!enGrilla(li, lj) || B[gk(lj * AMAX + li)] !== 0) {
      let bl = -1, bd = 1e9;
      for (let dj = -4; dj <= 4; dj++) for (let di = -4; di <= 4; di++) {
        const ni = li + di, nj = lj + dj; if (ni < 1 || nj < 1 || ni >= AMAX - 1 || nj >= AMAX - 1 || !enGrilla(ni, nj)) continue;
        if (B[gk(nj * AMAX + ni)] !== 0) continue; const dd = di * di + dj * dj; if (dd < bd) { bd = dd; bl = nj * AMAX + ni; }
      }
      if (bl < 0) return null; li = bl % AMAX; lj = (bl / AMAX) | 0; corrido = true;
    }
    const s = (sj - j0) * AMAX + (si - i0), t = lj * AMAX + li;
    const heur = l => { const dx = Math.abs((l % AMAX) - li), dz = Math.abs(((l / AMAX) | 0) - lj); return dx + dz - 0.586 * (dx < dz ? dx : dz); };
    aSello++; hN = 0; aG[s] = 0; aAb[s] = aSello; aDe[s] = -1; hPush(heur(s), s);
    const maxIt = (op && op.maxIt) || T.aMaxIt, salMax = T.saltoMax;
    let it = 0, ok = false, mejor = s, mejorH = heur(s);
    while (hN > 0 && it++ < maxIt) {
      const k = hPop(); if (aCe[k] === aSello) continue; aCe[k] = aSello; aIt++;
      if (k === t) { ok = true; break; }
      const hk = heur(k); if (hk < mejorH) { mejorH = hk; mejor = k; }
      const i = k % AMAX, j = (k / AMAX) | 0, gK = gk(k), bK = B[gK];
      for (let q = 0; q < 8; q++) {
        const di = D8I[q], dj = D8J[q], ni = i + di, nj = j + dj;
        if (ni < 0 || nj < 0 || ni >= AMAX || nj >= AMAX) continue;
        const gi = i0 + ni, gj = j0 + nj; if (gi < 0 || gj < 0 || gi >= EW || gj >= EH) continue;
        const n = nj * AMAX + ni; if (aCe[n] === aSello) continue;
        const gN = gj * EW + gi, bN = B[gN];
        if (bN === 2 || (bN === 1 && H[gN] > salMax)) continue;
        if (di !== 0 && dj !== 0) {                                   // en diagonal no se cortan esquinas ni se salta
          if (bN !== 0 || bK !== 0 || B[gK + di] !== 0 || B[gK + dj * EW] !== 0) continue;
        }
        let c = (di !== 0 && dj !== 0) ? 1.4142 : 1;
        if (bN === 1) c += (bK === 1) ? 0.6 : T.costoSalto;
        if (expo && expuesta(gN, agach)) c *= 1 + T.costoExpo;
        if (evita) for (let m = 0; m < evita.length; m++) { const e = evita[m], ex = EX0 + gi + 0.5 - e.x, ez = EZ0 + gj + 0.5 - e.z; if (ex * ex + ez * ez < e.r * e.r) c += e.c; }
        const ng = aG[k] + c;
        if (aAb[n] !== aSello || ng < aG[n]) { aAb[n] = aSello; aG[n] = ng; aDe[n] = k; hPush(ng + heur(n), n); }
      }
    }
    const fin = ok ? t : mejor;
    if (!ok && mejorH >= heur(s) - 1.5) return null;                // no se acercó nada: sin camino
    const pts = []; let nEx = 0;
    for (let k = fin; k !== -1; k = aDe[k]) { const g = gk(k), e = expo ? expuesta(g, agach) : 0; nEx += e; pts.push({ x: cX(g), z: cZ(g), salto: B[g] === 1, ex: e }); }
    pts.reverse();
    const ult = pts[pts.length - 1];
    if (ok && !corrido && !ult.salto && (Math.abs(tx - ult.x) > 0.05 || Math.abs(tz - ult.z) > 0.05) && libreEn(tx, tz)) pts.push({ x: tx, z: tz, salto: false, ex: ult.ex });
    /* suavizado: atajos rectos por casilleros libres. No se ataja a través de un salto, y con exposición
       no se ataja por un tramo más a la vista que el original (si no, el A* tapado no serviría de nada). */
    const out = []; let a = 0;
    while (a < pts.length - 1) {
      let elegido = a + 1;
      if (!pts[a].salto) {
        for (let b = Math.min(pts.length - 1, a + 12); b > a + 1; b--) {
          if (pts[b].salto) continue;
          let hay = false, exN = 0; for (let m = a + 1; m < b; m++) { if (pts[m].salto) { hay = true; break; } exN += pts[m].ex; }
          if (hay) continue;
          if (lineaLibre(pts[a].x, pts[a].z, pts[b].x, pts[b].z, expo ? exN : -1, agach)) { elegido = b; break; }
        }
      }
      out.push(pts[elegido]); a = elegido;
    }
    if (!out.length) out.push(pts[pts.length - 1]);
    out.costo = aG[fin]; out.expuestos = nEx; out.largo = pts.length; out.parcial = !ok;
    return out;
  }

  /* ====================================================================================================
     COBERTURAS
     Candidatas: casilleros libres pegados a algo de 1 m o más.
       baja (1 a 1,5 m: un auto): se cubre agachado.     alta (pared, furgón, columna): se cubre de pie.
     Para tirar se asoma a un «puesto de tiro»: un casillero vecino (0,7 a 1,4 m) con línea de visión al
     último lugar conocido, o el mismo casillero parándose si la cobertura es baja (hasta 1,5 m: tira por arriba del auto).
     ==================================================================================================== */
  const _cand = [];      // se reutiliza
  function vecinoAlto(k) {
    let h = 0, a;
    a = altoDe(k - 1); if (a > h) h = a; a = altoDe(k + 1); if (a > h) h = a;
    a = altoDe(k - EW); if (a > h) h = a; a = altoDe(k + EW); if (a > h) h = a;
    return h;
  }
  /* ¿hay otro soldado (o su cobertura reservada) a menos de r de este punto? */
  function ocupado(s, x, z, r) {
    const r2 = r * r;
    for (let i = 0; i < soldados.length; i++) {
      const o = soldados[i]; if (o === s || !o.vivo || !o.activo) continue;
      let ox = o.x, oz = o.z; if (o.cob) { ox = o.cob.x; oz = o.cob.z; }
      const dx = ox - x, dz = oz - z; if (dx * dx + dz * dz < r2) return true;
      if (o.cob) { const ex = o.x - x, ez = o.z - z; if (ex * ex + ez * ez < 1.5) return true; }
    }
    return false;
  }
  function enPeligro(x, z, margen) {
    for (let i = 0; i < peligros.length; i++) { const p = peligros[i], dx = p.x - x, dz = p.z - z, r = p.r + margen; if (dx * dx + dz * dz < r * r) return p; }
    return null;
  }
  const _idx = [];
  /* ¿algún vecino libre de k está a la vista del lugar conocido (de pie o agachado)? Barato: usa el mapa de exposición */
  function tiroProbable(k) {
    if (lineaFuego(k, false)) return true;                                           // por arriba (cobertura baja)
    for (let q = 0; q < 8; q++) { const m = k + D8J[q] * EW + D8I[q]; if (esLibre(m) && (lineaFuego(m, true) || lineaFuego(m, false))) return true; }
    return false;
  }
  /* puesto de tiro de una cobertura contra una amenaza en (ax,az). Devuelve {x,z,post,lado} o null.
     post: 0 de pie · 1 agachado.  lado: −1 se asoma por su izquierda · +1 por su derecha · 0 por arriba */
  function puestoDeTiro(s, x, z, k, ax, az, hmax) {
    const fx = ax - x, fz = az - z, fl = hyp(fx, fz) || 1, ux = fx / fl, uz = fz / fl;
    if (hmax <= 1.5 && lineaVista(x, 1.58, z, ax, 1.1, az)) return { x, z, post: 0, lado: 0 };   // baja de verdad (un auto): se para y tira por arriba
    let mejor = null, mp = 1e9;
    for (let q = 0; q < 8; q++) {
      const n = k + D8J[q] * EW + D8I[q]; if (!esLibre(n)) continue;
      if (q >= 4 && (B[k + D8I[q]] === 2 || B[k + D8J[q] * EW] === 2)) continue;       // no se asoma cortando una esquina de pared
      const nx = cX(n), nz = cZ(n);
      const lat = Math.abs(D8I[q] * ux + D8J[q] * uz);                                   // 0 = bien de costado
      let post = -1;
      if (lineaVista(nx, 0.98, nz, ax, 1.1, az)) post = 1; else if (lineaVista(nx, 1.56, nz, ax, 1.1, az)) post = 0;
      if (post < 0) continue;
      if (ocupado(s, nx, nz, 1.2)) continue;
      const p = lat * 2 + (q >= 4 ? 0.4 : 0) + (post === 0 ? 0.3 : 0);
      if (p < mp) { mp = p; mejor = { x: nx, z: nz, post, lado: ((nx - x) * (-uz) + (nz - z) * ux) >= 0 ? 1 : -1 }; }
    }
    return mejor;
  }
  /* ¿la cobertura c sigue tapando contra una amenaza en (ax,az)? */
  function tapa(c, ax, az) {
    const o = origenLibre(ax, az);
    return !lineaVista(o.x, 1.6, o.z, c.x, c.tipo === 'alta' ? 1.7 : 1.1, c.z);
  }
  /* Busca la mejor cobertura para s contra una amenaza en (ax,az).
     op = { cx,cz,radio: dónde buscar · dMin,dMax,dIdeal: distancia a la amenaza · tiro: exigir puesto de tiro ·
            atras: tiene que quedar más lejos de la amenaza que ahora · bx,bz,angMin,lado: flanqueo (ángulo mínimo
            respecto de la base de fuego vista desde la amenaza, y de qué lado) · reunion:{x,z} }  */
  function buscarCobertura(s, ax, az, op) {
    const o = origenLibre(ax, az), ox = o.x, oz = o.z;
    const ccx = op.cx !== undefined ? op.cx : s.x, ccz = op.cz !== undefined ? op.cz : s.z, R = op.radio || 22;
    const i0 = Math.floor(ccx - EX0), j0 = Math.floor(ccz - EZ0);
    const dAhora = hyp(s.x - ax, s.z - az);
    let bux = 0, buz = 0; if (op.angMin) { const l = hyp(op.bx - ax, op.bz - az) || 1; bux = (op.bx - ax) / l; buz = (op.bz - az) / l; }
    let n = 0;
    for (let dj = -R; dj <= R; dj++) for (let di = -R; di <= R; di++) {
      const i = i0 + di, j = j0 + dj; if (i < 1 || j < 1 || i >= EW - 1 || j >= EH - 1) continue;
      const k = j * EW + i; if (B[k] !== 0) continue;
      const hmax = vecinoAlto(k); if (hmax < 1) continue;
      const x = EX0 + i + 0.5, z = EZ0 + j + 0.5, dA = hyp(x - ax, z - az);
      if (dA < op.dMin || dA > op.dMax) continue;
      if (op.atras && dA < dAhora + 5) continue;
      let ang = 0;
      if (op.angMin) {
        const vx = (x - ax) / dA, vz = (z - az) / dA; ang = Math.acos(clamp(vx * bux + vz * buz, -1, 1));
        if (ang < op.angMin) continue;
        if (op.lado && ((vx * buz - vz * bux) > 0 ? 1 : -1) !== op.lado) continue;
      }
      if (ocupado(s, x, z, T.separacion)) continue;
      if (enPeligro(x, z, 1.5)) continue;
      const dS = hyp(x - s.x, z - s.z);
      let p = -Math.abs(dA - op.dIdeal) * 0.25 - dS * (op.pesoCamino || 0.16);
      if (hmax >= 1.6) p += 0.6;
      if (s.cob && Math.abs(s.cob.x - x) < 0.1 && Math.abs(s.cob.z - z) < 0.1) p += 2.5;       // histéresis: no cambiar por cambiar
      if (op.angMin) p -= Math.abs(ang - 1.75) * 2.2;                                            // lo mejor: de costado y un poco de atrás
      if (op.reunion) p -= hyp(x - op.reunion.x, z - op.reunion.z) * 0.12;
      let c = _cand[n]; if (!c) c = _cand[n] = { k: 0, x: 0, z: 0, p: 0, h: 0, dA: 0 };
      c.k = k; c.x = x; c.z = z; c.p = p; c.h = hmax; c.dA = dA; n++;
    }
    if (!n) return null;
    /* los mejores por puntaje barato primero; a esos se les mira lo caro: que tape, que tenga tiro, que no esté flanqueada */
    let mejor = null, mp = -1e9, vistos = 0, saltados = 0;
    /* Con op.tiro se descartan barato las que no tienen ningún vecino a la vista del lugar conocido (mapa de exposición,
       compartido): así una barricada ciega no tapa a las coberturas buenas que están más adelante. */
    if (op.tiro) expoCentrar(ax, az);
    const usaExpo = op.tiro && xOk;
    for (let q = 0; q < n; q++) _idx[q] = q;
    _idx.length = n; _idx.sort((a, b) => _cand[b].p - _cand[a].p);
    for (let w = 0; w < n && vistos < 14; w++) {
      const b = _idx[w], bp = _cand[b].p;
      if (mejor && bp + 9.5 < mp) break;                               // ya no puede ganarle nadie
      const c = _cand[b], tipo = c.h >= 1.6 ? 'alta' : 'baja', yT = tipo === 'alta' ? 1.7 : 1.1;
      if (usaExpo) { if (saltados > 500) break; if (!tiroProbable(c.k)) { saltados++; continue; } }
      if (lineaVista(ox, 1.6, oz, c.x, yT, c.z)) continue;             // no tapa: no sirve (y no cuenta como vista)
      vistos++;
      let p = c.p;
      const tiro = puestoDeTiro(s, c.x, c.z, c.k, ox, oz, c.h); if (_estCob.lista) _estCob.lista.push([c.x, c.z, c.h, !!tiro, +c.p.toFixed(1)]);
      if (tiro) p += 6; else if (op.tiro) continue;
      /* robusta: que siga tapando si el jugador se corre 3 m para cada lado */
      const px = -(c.z - oz) / c.dA, pz = (c.x - ox) / c.dA;
      if (!lineaVista(ox + px * 3, 1.6, oz + pz * 3, c.x, yT, c.z)) p += 1.2;
      if (!lineaVista(ox - px * 3, 1.6, oz - pz * 3, c.x, yT, c.z)) p += 1.2;
      /* separación cómoda de los compañeros */
      for (let q = 0; q < soldados.length; q++) { const m = soldados[q]; if (m === s || !m.vivo || !m.activo) continue; const mx = m.cob ? m.cob.x : m.x, mz = m.cob ? m.cob.z : m.z, dm = hyp(mx - c.x, mz - c.z); if (dm < 6) p -= (6 - dm) * 0.7; }
      if (p > mp) { mp = p; mejor = { x: c.x, z: c.z, k: c.k, tipo, h: c.h, tiro, ax, az, p }; }
    }
    _estCob.n = n; _estCob.saltados = saltados; _estCob.vistos = vistos; _estCob.expo = usaExpo;
    return mejor;
  }
  const _estCob = { n: 0, saltados: 0, vistos: 0, expo: false };
  /* Puesto para el tirador cuando no tiene nido (o lo sacaron de ahí): lejos, cuerpo a tierra si desde el
     piso hay línea; si no, agachado. Devuelve una «cobertura» con tiro en el mismo lugar. */
  function buscarPuestoTirador(s, ax, az) {
    const o = origenLibre(ax, az), ox = o.x, oz = o.z, i0 = Math.floor(s.x - EX0), j0 = Math.floor(s.z - EZ0), R = 30;
    let mejor = null, mp = -1e9;
    for (let dj = -R; dj <= R; dj += 2) for (let di = -R; di <= R; di += 2) {
      const i = i0 + di, j = j0 + dj; if (i < 1 || j < 1 || i >= EW - 1 || j >= EH - 1) continue;
      const k = j * EW + i; if (B[k] !== 0) continue;
      const x = EX0 + i + 0.5, z = EZ0 + j + 0.5, dA = hyp(x - ox, z - oz);
      if (dA < T.tirador.distMin || dA > T.tirador.distMax) continue;
      if (ocupado(s, x, z, T.separacion) || enPeligro(x, z, 1.5)) continue;
      let p = -Math.abs(dA - 45) * 0.08 - hyp(x - s.x, z - s.z) * 0.2 + (vecinoAlto(k) >= 1 ? 1.5 : 0);
      if (p + 4 < mp) continue;
      let post = -1;
      if (lineaVista(x, 0.35, z, ox, 1.1, oz)) { post = 2; p += 4; } else if (lineaVista(x, 1.0, z, ox, 1.1, oz)) post = 1;
      if (post < 0) continue;
      if (p > mp) { mp = p; mejor = { x, z, k, tipo: 'tirador', h: 0, tiro: { x, z, post, lado: 0 }, ax, az, p }; }
    }
    return mejor;
  }

  /* ====================================================================================================
     ESTADO GENERAL
     ==================================================================================================== */
  const soldados = [];          // todos, vivos y muertos
  const escuadrones = [];
  const defs = [];              // lo que se pidió con UE.escuadron / UE.refuerzo, para poder rehacerlo en reset()
  let peligros = [];            // ENV.peligros() de este cuadro
  let bichos = [];              // ENV.bichos() de este cuadro
  const trabajos = [];          // cola de trabajos pesados (A*, búsqueda de cobertura): UNO por cuadro
  const dialogos = [];          // respuestas de radio pendientes
  const partes = [];            // avisos de ruido que todavía no llegaron al escuadrón
  let idSig = 0;

  /* «red»: lo que sabe la unidad entera. Los escuadrones comparten la radio, así que el último lugar conocido,
     las fichas de ataque y el tope de daño son de todos. */
  const red = {
    uc: null,             // último lugar conocido: {x,y,z,vx,vz,t,tipo:'vista'|'oido',err,alto}
    tVisto: -99,          // última vez que alguien lo vio (ya avisada)
    tSenal: -99,          // última señal de cualquier tipo (vista u oído)
    tContacto: -99,       // cuándo empezó este combate
    ancla: null,          // {x,z,t0}: desde cuándo el lugar conocido no sale de un radio (condición de la granada)
    fichas: [],           // soldados con permiso de tirar a pegar
    tirador: null,        // el tirador con el tiro en curso (uno solo a la vez)
    dano: [],             // pares (hora, daño) de balas que le pegaron al jugador en el último segundo
    tGranada: -99,        // última granada lanzada
    muerto: false,        // el jugador está muerto
    refuerzo: null,       // escuadrón de refuerzo esperando que lo pidan
    refPedido: false, refEn: -1, refLlego: false,
    recJug: -99,          // última vez que alguien vio al jugador recargando
    bichosVistos: false
  };

  const nivelEsc = e => e.estado === 'combate' ? 2 : (e.estado === 'guardia' ? 0 : 1);
  const nivelDe = s => { const n = nivelEsc(s.esc); return s.alerta > n ? s.alerta : n; };
  const ojoDe = s => s.tierra > 0 ? T.ojoAgach + (T.ojoTierra - T.ojoAgach) * s.tierra : T.ojoPie + (T.ojoAgach - T.ojoPie) * s.agach;
  const vivosDe = e => { let n = 0; for (let i = 0; i < e.soldados.length; i++) if (e.soldados[i].vivo && e.soldados[i].activo) n++; return n; };

  /* ====================================================================================================
     SOLDADO: un objeto plano. Lo que «sabe» está separado de lo que «es».
     ==================================================================================================== */
  function nuevoSoldado(esc, rol, num, p) {
    const arma = rol === 'asalto' ? 'escopeta' : rol === 'tirador' ? 'tirador' : 'fusil';
    const s = {
      /* identidad */
      id: idSig++, nombre: esc.nombre + ' ' + num, num, rol, esc, voz: 0,
      activo: true, vivo: true, hp: T.vida, r: 0.4,
      /* cuerpo */
      x: p.x, y: 0, z: p.z, rumbo: p.rumbo || 0, vx: 0, vz: 0, dvx: 0, dvz: 0,
      elev: null,                 // {r,y}: está subido a algo (nido)
      post: 0,                    // postura que quiere: 0 de pie · 1 agachado · 2 cuerpo a tierra
      agach: 0, tierra: 0,        // mezcla real 0…1 (tardan lo que dice TUNE)
      /* estado */
      estado: 'puesto', tEst: 0, tarea: 'guardia', alerta: 0,
      puesto: { x: p.x, z: p.z, rumbo: p.rumbo || 0 },
      /* movimiento */
      camino: null, ci: 0, esperaCamino: false, vel: 0, mov: false, llego: true, dest: null,
      salto: -1, sx0: 0, sz0: 0, sx1: 0, sz1: 0, sDur: 0.5,
      trabT: 0, trabX: p.x, trabZ: p.z, trabN: 0,
      /* cobertura */
      cob: null, esperaCob: false, enTiro: false, tSal: 0, tVentana: 0, tSinTiro: 0, moverPor: null,
      /* lo que sabe del jugador */
      sosp: 0, ve: false, veMedio: false, veDesde: -99, tVisto: -99, tConoce: -99,
      hist: [], hI: 0,            // últimas observaciones propias (anillo)
      estX: 0, estZ: 0, estT: -99,   // estímulo: hacia dónde vio u oyó algo
      /* arma */
      arma, balas: T[arma].cargador, recT: -1, raf: 0, rafT: 0, rafModo: null, rafLado: 1, rafOff: 1.2, pausaT: 0,
      nRaf: 0, avisoHecho: false, tDisparo: -99,
      asiento: 0, supr: 0, escondeT: 0, tSuprDijo: -99,
      apunta: 0, miraYaw: p.rumbo || 0, mPitch: 0, miraX: 0, miraY: 0, miraZ: 0, hayMira: false,
      granadas: rol === 'granadero' ? 3 : 1, lanzaT: -1, lanza: null, gritoT: -99,
      /* blanco */
      blanco: null,               // null | 'jugador' | 'bicho'
      bicho: null, bichoT: -99,   // {ref,x,y,z,r,d}
      /* tirador */
      tir: 'espera', tirT: 0, tirSig: 0, laser: null, lx: 0, ly: 0, lz: 0, tirDijo: -99,
      /* relojes y animación */
      tPerc: 0, tPens: 0, tPercAnt: 0, aturdido: 0, culT: -1, culCd: 0, culPego: false, radioT: 0, senalT: -1, senalTipo: 'avanzar',
      luz: false, muerte: null, tMuerte: -1, heridoDijo: false, herT: -99, herDir: 0,
      escaneo: azar() * PI2, tOcio: 0, espera: 0, ri: 0, bi: -1, tRadio0: -1,
      vista: null,
      /* campos que usan pensar/actuar (inicializados para que el objeto tenga siempre la misma forma) */
      pend: {}, _laser: { x: 0, y: 0, z: 0 }, miraObj: null, apObj: false, miraFija: false, retro: 0, bajaDe: 0, subeA: 0,
      cubreHasta: 0, ficha: false, fichaT: 0, fichaCd: 0, replegado: false, sinCob: -99, tCob: 0, moverPor: null, pinned: false,
      pelVisto: null, pelT: 0, escK: -1, dijoListo: false, rondaYendo: false, rondaYaw: 0, tEsp0: 0, miraPie: 0, miraAlto: 1.8,
      tChkTiro: 0, tReval: 0, pidioT: 0, sinCamino: 0, fallo: false, replan: false, caminoOp: null, culBicho: false, wi: 0,
      orden: null, tMov: 0, mx0: 0, mz0: 0,
      /* interfaz de blanco para los bichos (UEB.objetivos) */
      herir: null
    };
    s.voz = s.id % 8;
    for (let i = 0; i < 10; i++) s.hist.push({ t: -99, x: 0, y: 0, z: 0, vx: 0, vz: 0, alto: 1.8, medio: false });
    s.herir = (dano, bicho) => herir(s, dano, null, 'torso', 'bicho', bicho);
    s.tPerc = azar() * T.tPercibir; s.tPens = azar() * T.tPensar;
    return s;
  }

  /* ====================================================================================================
     RADIO: una frase cada ~1,2 s por escuadrón como mucho; las de peligro pasan siempre.
     ==================================================================================================== */
  function decir(s, clave, n, intento, t0) {
    if (!s || !s.vivo || !s.activo) return false;
    const e = s.esc;
    if (!UE_URGENTES[clave] && ahora - e.tRadio < T.radioCada) {
      /* las que avisan algo (flanqueo, recarga, pérdida de contacto, refuerzo…) no se pierden: esperan su turno */
      if (UE_IMPORTANTES[clave] && (intento || 0) < 3) { dialogos.push({ t: e.tRadio + T.radioCada + 0.05, t0: t0 !== undefined ? t0 : ahora, e, quien: s, clave, n, intento: (intento || 0) + 1 }); return true; }
      return false;
    }
    const lista = UE_FRASES[clave]; if (!lista) return false;
    let i = Math.floor(azar() * lista.length); if (i >= lista.length) i = lista.length - 1;
    if (lista.length > 1 && i === e.ultFrase[clave]) i = (i + 1) % lista.length;        // sin repetir la última
    e.ultFrase[clave] = i;
    let f = lista[i], resp = null; if (Array.isArray(f)) { resp = f[1]; f = f[0]; }
    f = f.replace('{N}', n !== undefined ? n : s.num);
    if (e.nombre !== 'Ceniza' && clave !== 'refuerzo_va' && clave !== 'refuerzo_llega') f = f.replace('Ceniza', e.nombre);
    e.tRadio = ahora; s.radioT = 1.1;
    ENV.radio(s, clave, f);
    if (resp) dialogos.push({ t: ahora + 1.7, e, de: s, clave, f: resp });
    return true;
  }
  function tickDialogos() {
    for (let i = dialogos.length - 1; i >= 0; i--) {
      const d = dialogos[i]; if (ahora < d.t) continue; dialogos.splice(i, 1);
      if (d.quien) {                                                    // frase de alguien en particular (respuesta, baja, frase demorada)
        if (!d.quien.vivo || !d.quien.activo) continue;
        if (d.intento && ahora - d.t0 > 2.5) continue;                 // una frase demorada que ya no viene al caso
        if (d.forzar && d.quien.esc) d.quien.esc.tRadio = -99;
        decir(d.quien, d.clave, d.n, d.intento || 0, d.t0); continue;
      }
      if (d.e.estado !== 'guardia') continue;
      const o = d.e.soldados.find(m => m.vivo && m.activo && m !== d.de); if (!o) continue;
      d.e.tRadio = ahora; o.radioT = 0.9; ENV.radio(o, d.clave, d.f);
    }
  }

  /* ====================================================================================================
     LO QUE SE SABE: último lugar conocido
     ==================================================================================================== */
  function ponerUC(x, y, z, vx, vz, t, tipo, err, alto) {
    const u = red.uc;
    if (tipo === 'oido' && u) {
      if (u.tipo === 'vista' && t - u.t < 1.2) { red.tSenal = Math.max(red.tSenal, t); return; }   // lo estamos viendo: el oído no agrega nada
      if (hyp(x - u.x, z - u.z) < err + 1.5 && u.err <= err) { red.tSenal = Math.max(red.tSenal, t); return; }   // sonó donde ya creíamos que estaba: no se mueve
    }
    if (u && t < u.t) return;
    if (!u) red.uc = { x, y, z, vx, vz, t, tipo, err, alto };
    else { u.x = x; u.y = y; u.z = z; u.vx = vx; u.vz = vz; u.t = t; u.tipo = tipo; u.err = err; u.alto = alto; }
    red.tSenal = Math.max(red.tSenal, t); if (tipo === 'vista') red.tVisto = Math.max(red.tVisto, t);
    /* ancla: ¿hace cuánto que no sale de un radio? (para la granada) */
    const a = red.ancla;
    if (!a || hyp(x - a.x, z - a.z) > T.granada.quietoRadio) red.ancla = { x, z, t0: t };
    expoCentrar(x, z);
  }
  /* la mejor posición que conoce ESTE soldado: la propia si es más nueva que la del escuadrón */
  const _uc = { x: 0, y: 0, z: 0, vx: 0, vz: 0, t: -99, tipo: 'vista', err: 0, alto: 1.8, propia: false };
  function conocido(s) {
    const h = s.hist[(s.hI + 9) % 10], u = red.uc;
    if (h.t > -90 && (!u || h.t > u.t)) { _uc.x = h.x; _uc.y = h.y; _uc.z = h.z; _uc.vx = h.vx; _uc.vz = h.vz; _uc.t = h.t; _uc.tipo = 'vista'; _uc.err = 0; _uc.alto = h.alto; _uc.propia = true; return _uc; }
    return u;
  }
  /* Lo que uno ve, el escuadrón lo sabe T.aviso segundos después: cada cuadro se entrega la observación más
     nueva de cada soldado VIVO que ya tenga esa antigüedad. Uno que muere antes de avisar, no avisa. */
  function entregarAvisos() {
    const lim = ahora - T.aviso;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      let m = null; for (let q = 0; q < 10; q++) { const h = s.hist[q]; if (h.t <= lim && h.t > -90 && (!m || h.t > m.t)) m = h; }
      if (m && (!red.uc || m.t > red.uc.t)) {
        const nuevo = red.tVisto < -90 || red.muerto;
        ponerUC(m.x, m.y, m.z, m.vx, m.vz, m.t, 'vista', 0, m.alto);
        for (let q = 0; q < escuadrones.length; q++) if (escuadrones[q].activo) entrarCombate(escuadrones[q], nuevo ? s : null);
      }
    }
    for (let i = partes.length - 1; i >= 0; i--) {
      const p = partes[i]; if (ahora < p.t) continue; partes.splice(i, 1);
      if (!p.s.vivo) continue;
      ponerUC(p.x, p.y, p.z, 0, 0, p.t0, 'oido', p.err, 1.8);
      for (let q = 0; q < escuadrones.length; q++) { const e = escuadrones[q]; if (!e.activo) continue; if (p.fuerte) entrarCombate(e, null); else entrarSospecha(e, p.s, p.x, p.z); }
    }
  }

  /* ====================================================================================================
     PERCEPCIÓN — el ÚNICO lugar donde la IA mira dónde está el jugador de verdad.
     ==================================================================================================== */
  function tDetectar(d) {
    const D = T.detectar; if (d <= D[0]) return D[1];
    for (let i = 2; i < D.length; i += 2) if (d <= D[i]) return D[i - 1] + (D[i + 1] - D[i - 1]) * (d - D[i - 2]) / (D[i] - D[i - 2]);
    const n = D.length; return D[n - 1] + (d - D[n - 2]) * (D[n - 1] - D[n - 3]) / (D[n - 2] - D[n - 4]);
  }
  /* rayo real entre dos puntos: ¿llega sin chocar con el mundo? */
  function rayoLibre(ax, ay, az, bx, by, bz) {
    const dx = bx - ax, dy = by - ay, dz = bz - az, d = Math.sqrt(dx * dx + dy * dy + dz * dz); if (d < 0.5) return true;
    return ENV.rayo(ax, ay, az, dx / d, dy / d, dz / d, d) >= d - 0.45;
  }
  function percibir(s) {
    const dtP = Math.min(0.4, ahora - s.tPercAnt); s.tPercAnt = ahora;
    const j = ENV.jugador(), nivel = nivelDe(s);
    let ve = false, medio = false, d = 1e9;
    if (j.vivo) {
      const dx = j.x - s.x, dz = j.z - s.z; d = hyp(dx, dz);
      const rumboJ = Math.atan2(dx, dz), desv = Math.abs(angN(rumboJ - s.miraYaw));
      const v2 = j.vx * j.vx + j.vz * j.vz, quieto = v2 < 1;
      /* iluminado: por los reflectores, por su propia linterna, o por la linterna de este soldado si le apunta de cerca */
      const luz = j.linterna || ENV.luz(j.x, j.z) > 0.5 || (s.luz && d < 16 && desv < 0.35);
      let alc = T.vistaDist; if (luz) alc *= T.vistaLuz; else if (j.agach > 0.5 && quieto) alc *= T.vistaQuieto; if (alc > T.vistaTope) alc = T.vistaTope;
      const cono = (nivel >= 2 ? T.conoCombate : nivel === 1 ? T.conoSospecha : T.conoGuardia) * RAD * 0.5;
      if (d <= alc && (desv <= cono || d < 1.6)) {
        const oy = s.y + ojoDe(s), yp = j.y + j.alto * 0.62, yc = j.y + j.alto - 0.12;
        let r = lv(s.x, oy, s.z, j.x, yp, j.z, s.elev); if (r === 2) r = rayoLibre(s.x, oy, s.z, j.x, yp, j.z) ? 1 : 0;
        if (r) ve = true;
        else { r = lv(s.x, oy, s.z, j.x, yc, j.z, s.elev); if (r === 2) r = rayoLibre(s.x, oy, s.z, j.x, yc, j.z) ? 1 : 0; if (r) { ve = true; medio = true; } }
      }
      if (nivel < 2) {
        /* en guardia no lo detecta de inmediato: la sospecha sube según distancia, luz, postura y movimiento */
        if (ve) {
          let r = 1 / tDetectar(d);
          if (luz) r *= T.detLuz; if (j.agach > 0.5) r *= T.detAgach; if (quieto) r *= T.detQuieto; else if (j.corriendo) r *= T.detCorre;
          if (medio) r *= T.detMedio; if (desv > cono * 0.6) r *= T.detBorde; if (nivel === 1 || s.esc.alertado) r *= T.detAlerta;
          s.sosp = Math.min(1, s.sosp + r * dtP);
          s.estX = j.x; s.estZ = j.z; s.estT = ahora;                 // vio «algo» ahí: hacia allá va a mirar
        } else s.sosp = Math.max(0, s.sosp - T.sospechaBaja * dtP);
        if (ve && s.sosp >= 1) contacto(s); else ve = false;         // hasta no confirmarlo no «lo ve»: ni tira ni avisa
      }
      /* oído: pasos corriendo cerca */
      if (!ve && j.corriendo && d < T.oidoPasos && ahora - s.estT > 0.5) {
        const e = 1.5 + d * 0.1; s.estX = j.x + campana() * e; s.estZ = j.z + campana() * e; s.estT = ahora;
        if (nivel < 2) { s.sosp = Math.max(s.sosp, 0.5); }
        partes.push({ t: ahora + T.aviso, t0: ahora, s, x: s.estX, y: j.y, z: s.estZ, err: e + 1, fuerte: nivel >= 2 });
      }
    } else if (!red.muerto) jugadorMurio(s);
    if (j.vivo && red.muerto) red.muerto = false;
    if (ve) {
      if (!s.ve && ahora - s.tVisto > 0.3) {
        /* reaparece donde se escondió hace poco: ya lo estaba esperando, reacciona más rápido */
        const h = s.hist[(s.hI + 9) % 10], esperado = h.t > -90 && ahora - h.t < T.esperaT && hyp(j.x - h.x, j.z - h.z) < 3;
        s.veDesde = esperado ? ahora - (T.reaccion - T.reaccionEspera) : ahora;
      }
      s.ve = true; s.veMedio = medio; s.tVisto = ahora; if (s.tConoce < -90) s.tConoce = ahora;
      const h = s.hist[s.hI]; s.hI = (s.hI + 1) % 10;
      h.t = ahora; h.x = j.x; h.y = j.y; h.z = j.z; h.vx = j.vx; h.vz = j.vz; h.alto = j.alto; h.medio = medio;
      if (j.recargando) red.recJug = ahora;
    } else { s.ve = false; }
    percibirBichos(s);
  }
  /* la sospecha llegó a 1: contacto. El soldado ya está en combate; el escuadrón lo sabe en T.aviso segundos. */
  function contacto(s) {
    if (s.alerta < 2) { s.alerta = 2; s.tConoce = ahora; s.veDesde = ahora; decir(s, 'contacto'); ENV.evento('contacto', { s }); }
    s.sosp = 1;
  }
  function jugadorMurio(s) {
    red.muerto = true; red.fichas.length = 0;
    decir(s, 'muerto_jugador'); ENV.evento('jugador_muerto', { s });
    for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo) volverAGuardia(escuadrones[i], false);
  }
  /* mutantes: ve al más amenazante a menos de 30 m con línea de visión (o al que lo está mordiendo) */
  function percibirBichos(s) {
    if (!bichos.length) { if (s.bicho && ahora - s.bichoT > 0.6) s.bicho = null; return; }
    const oy = s.y + ojoDe(s); let mejor = null, mp = -1e9, md = 0;
    for (let i = 0; i < bichos.length; i++) {
      const b = bichos[i], d = hyp(b.x - s.x, b.z - s.z); if (d > T.vistaBicho) continue;
      let p = -d; if (s.bicho && s.bicho.ref === b.ref) p += 3;                    // no cambiar de blanco a cada rato
      if (p <= mp) continue;
      if (d > 2.5 && !lineaVista(s.x, oy, s.z, b.x, (b.y || 0) + 0.9, b.z, s.elev)) continue;
      mp = p; mejor = b; md = d;
    }
    if (mejor) {
      if (!s.bicho) s.bicho = { ref: null, x: 0, y: 0, z: 0, r: 0.5, d: 0 };
      const o = s.bicho; o.ref = mejor.ref; o.x = mejor.x; o.y = mejor.y; o.z = mejor.z; o.r = mejor.r || 0.5; o.d = md; s.bichoT = ahora;
      if (!red.bichosVistos) { red.bichosVistos = true; decir(s, 'bichos'); ENV.evento('bichos', { s }); }
      if (s.alerta < 1) s.alerta = 1;
    } else if (s.bicho && ahora - s.bichoT > 0.6) s.bicho = null;
  }

  /* ====================================================================================================
     ARMAS Y BALAS
     ==================================================================================================== */
  const _boca = { x: 0, y: 0, z: 0 };
  const _v3 = (typeof THREE !== 'undefined' && THREE.Vector3) ? new THREE.Vector3() : null;   // solo para pedirle la boca del arma al modelo
  /* boca del arma: la del modelo si hay; si no, una aproximación según la postura */
  function boca(s) {
    if (s.vista && _v3 && s.vista.boca) { s.vista.boca(_v3); _boca.x = _v3.x; _boca.y = _v3.y; _boca.z = _v3.z; return _boca; }
    const h = s.tierra > 0 ? 0.98 + (0.25 - 0.98) * s.tierra : 1.56 + (0.98 - 1.56) * s.agach;     // el arma apuntando va a la altura de la mira (un poco abajo del ojo)
    _boca.x = s.x + Math.sin(s.miraYaw) * 0.45; _boca.y = s.y + h; _boca.z = s.z + Math.cos(s.miraYaw) * 0.45;
    return _boca;
  }
  /* Punto de mira de s sobre el jugador: su observación de hace `atraso` segundos más una parte del adelanto.
     Con el jugador quieto es exacto; corriendo de costado queda atrás (0,09·v con los números iniciales).
     Devuelve false si s no tiene observaciones propias recientes. */
  function puntoMira(s, atraso, adelanto) {
    const tq = ahora - atraso; let h0 = null, h1 = null, viejo = null;
    for (let q = 0; q < 10; q++) {
      const h = s.hist[q]; if (h.t < ahora - 1.2) continue;
      if (h.t <= tq) { if (!h0 || h.t > h0.t) h0 = h; } else if (!h1 || h.t < h1.t) h1 = h;
      if (!viejo || h.t < viejo.t) viejo = h;
    }
    if (!h0) h0 = viejo; if (!h0) return false;
    let x = h0.x, y = h0.y, z = h0.z;
    if (h1 && h1.t - h0.t < 0.4 && h1.t > h0.t && tq > h0.t) { const u = (tq - h0.t) / (h1.t - h0.t); x += (h1.x - x) * u; y += (h1.y - y) * u; z += (h1.z - z) * u; }
    x += h0.vx * atraso * adelanto; z += h0.vz * atraso * adelanto;
    const ult = s.hist[(s.hI + 9) % 10];
    s.miraX = x; s.miraZ = z; s.miraY = y + (ult.medio ? ult.alto - 0.12 : ult.alto * 0.62); s.miraPie = y; s.miraAlto = ult.alto;
    return true;
  }
  /* rayo contra la cápsula del jugador (radio 0,35, de y a y+alto). Devuelve la distancia o Infinity. */
  function rayoCapsula(ox, oy, oz, dx, dy, dz, cx, cy, cz, r, alto) {
    const fx = ox - cx, fz = oz - cz, a = dx * dx + dz * dz; if (a < 1e-9) return Infinity;
    const b = fx * dx + fz * dz, c = fx * fx + fz * fz - r * r, disc = b * b - a * c; if (disc < 0) return Infinity;
    const sq = Math.sqrt(disc), t0 = (-b - sq) / a, t1 = (-b + sq) / a; if (t1 < 0) return Infinity;
    const y0 = oy + dy * Math.max(t0, 0), y1 = oy + dy * t1, lo = cy, hi = cy + alto;
    if ((y0 < lo && y1 < lo) || (y0 > hi && y1 > hi)) return Infinity;
    if (y0 >= lo && y0 <= hi) return Math.max(t0, 0);
    /* entra por arriba o por abajo del cilindro */
    const yb = y0 > hi ? hi : lo; if (Math.abs(dy) < 1e-9) return Infinity; const t = (yb - oy) / dy; return (t >= 0 && t <= t1) ? t : Infinity;
  }
  /* tope de daño: cuánto le sacaron las balas de fusil y escopeta en el último segundo */
  function danoReciente() {
    const v = red.dano; let i = 0; while (i < v.length && v[i] <= ahora - 1) i += 2; if (i) v.splice(0, i);
    let n = 0; for (let q = 1; q < v.length; q += 2) n += v[q]; return n;
  }
  const _ev = { s: null, ox: 0, oy: 0, oz: 0, hx: 0, hy: 0, hz: 0, tipo: 'fusil', pega: 'nada', modo: 'pegar', raf: 0, t: 0, px: 0, py: 0, pz: 0 };
  const _res = { t: 0, pega: 'nada', ref: null };
  /* FÍSICA de una bala: contra el mundo, los bichos y el jugador, con rayo real. Es la única lectura de la
     posición real del jugador fuera de percibir(), y nada de lo que devuelve se usa para decidir dónde está. */
  function resolverBala(ox, oy, oz, dx, dy, dz, alc) {
    let tM = ENV.rayo(ox, oy, oz, dx, dy, dz, alc), pega = 'mundo';
    if (!(tM < alc)) { tM = alc; pega = 'nada'; }
    if (dy < -1e-4) {                                                // el piso también frena
      let tp = (oy - ENV.piso(ox, oz)) / -dy; tp = (oy - ENV.piso(ox + dx * tp, oz + dz * tp)) / -dy;
      if (tp > 0 && tp < tM) { tM = tp; pega = 'mundo'; }
    }
    let ref = null;
    const hb = bichos.length ? ENV.rayoBichos(ox, oy, oz, dx, dy, dz, tM) : null;
    if (hb && hb.t < tM) { tM = hb.t; pega = 'bicho'; ref = hb.ref; }
    const j = ENV.jugador();
    if (j.vivo) { const tj = rayoCapsula(ox, oy, oz, dx, dy, dz, j.x, j.y, j.z, 0.35, j.alto); if (tj < tM) { tM = tj; pega = 'jugador'; ref = null; } }
    _res.t = tM; _res.pega = pega; _res.ref = ref; return _res;
  }
  /* Dispara UNA bala (o perdigón) de s hacia el punto (px,py,pz).
     modo: 'pegar' · 'suprimir' (erra a propósito; si igual le iba a pegar, se sortea de nuevo una vez) ·
           'aviso' (primera ráfaga: no pega nunca) · 'bicho' · 'laser' (tirador).
     Devuelve qué tocó. */
  function tirarBala(s, px, py, pz, modo, tipo, disp, dano, alc, enTope) {
    const b = boca(s), ox = b.x, oy = b.y, oz = b.z;
    let dx = px - ox, dy = py - oy, dz = pz - oz, d = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1; dx /= d; dy /= d; dz /= d;
    const hl = Math.sqrt(dx * dx + dz * dz) || 1, lx = -dz / hl, lz = dx / hl;       // lateral horizontal
    const da = campana() * disp * 1.6, dv = campana() * disp * 1.1;
    let ex = dx + lx * da, ey = dy + dv, ez = dz + lz * da, el = Math.sqrt(ex * ex + ey * ey + ez * ez); ex /= el; ey /= el; ez /= el;
    let r = resolverBala(ox, oy, oz, ex, ey, ez, alc);
    if (r.pega === 'jugador') {
      let errar = false;
      if (modo === 'aviso') errar = true;
      else if (modo === 'suprimir' || modo === 'bicho') {
        /* segundo sorteo: el mismo desvío para el otro lado. Si igual le pega, le pega (cruzó una línea de fuego). */
        ex = dx - lx * da; ey = dy - dv; ez = dz - lz * da; el = Math.sqrt(ex * ex + ey * ey + ez * ez); ex /= el; ey /= el; ez /= el;
        r = resolverBala(ox, oy, oz, ex, ey, ez, alc);
      }
      if (r.pega === 'jugador' && !errar && enTope && danoReciente() + dano > T.topeDano) errar = true;   // tope de daño por segundo
      if (errar) {
        /* la bala se corre lo justo para pasarle al lado (0,6 m fuera del cuerpo), del lado hacia el que ya iba */
        const j = ENV.jugador(), jx = j.x - ox, jz = j.z - oz, jd = Math.sqrt(jx * jx + jz * jz) || 1;
        const lado = (ex * (-jz) + ez * jx) >= 0 ? 1 : -1, qx = -jz / jd * lado, qz = jx / jd * lado;
        for (let q = 0; q < 3 && r.pega === 'jugador'; q++) {
          const tx = j.x + qx * (0.95 + q * 0.5) - ox, ty = oy + ey * jd - oy, tz = j.z + qz * (0.95 + q * 0.5) - oz;
          el = Math.sqrt(tx * tx + ty * ty + tz * tz) || 1; ex = tx / el; ey = ty / el; ez = tz / el;
          r = resolverBala(ox, oy, oz, ex, ey, ez, alc);
        }
        if (r.pega === 'jugador') return 'nada';                     // no hubo forma: la bala no sale
      }
    }
    if (r.pega === 'jugador') {
      if (enTope) { red.dano.push(ahora, dano); }
      ENV.herirJugador(dano, s.x, s.z, tipo);
    } else if (r.pega === 'bicho') ENV.herirBicho(r.ref, (dano / (T.dano || 1)) * T.bichoDano, ex, ez);
    const e = _ev; e.s = s; e.ox = ox; e.oy = oy; e.oz = oz; e.hx = ox + ex * r.t; e.hy = oy + ey * r.t; e.hz = oz + ez * r.t;
    e.tipo = tipo; e.pega = r.pega; e.modo = modo; e.raf = s.nRaf; e.t = ahora; e.px = px; e.py = py; e.pz = pz; e.ficha = !!s.ficha;
    ENV.bala(e);
    return r.pega;
  }
  /* daño del perdigón según la distancia: entero hasta `lleno`, ~2/3 a `util`, nada desde `nada` */
  function caidaEscopeta(d) { const E = T.escopeta; return d <= E.lleno ? 1 : d >= E.nada ? 0 : 1 - (d - E.lleno) / (E.nada - E.lleno); }

  /* ¿la boca del arma tiene línea limpia (rayo real) hasta el punto de mira? */
  function lineaLimpia(s) {
    const b = boca(s); if (rayoLibre(b.x, b.y, b.z, s.miraX, s.miraY, s.miraZ)) return true;
    const yc = s.miraPie + s.miraAlto - 0.12;                        // si el pecho está tapado, prueba la cabeza
    if (rayoLibre(b.x, b.y, b.z, s.miraX, yc, s.miraZ)) { s.miraY = yc; return true; }
    return false;
  }
  /* ¿tiene sentido tirarle al último lugar conocido sin verlo? Solo si se sabe bien dónde es y hace poco
     (después se barre, no se gasta munición), o si le pidieron cubrir a uno que se mueve. */
  function debeSuprimir(s) {
    const u = red.uc; if (!u || u.err > 3) return false;
    if (s.rol === 'tirador') return false;
    if (s.cubreHasta > ahora) return true;
    if (s.tarea !== 'fijar') return false;
    const sinVer = ahora - red.tVisto;
    return sinVer < T.perdidoAccion + 1;
  }
  /* Empieza una ráfaga si corresponde. Decide el MODO una vez por ráfaga. */
  function empezarRafaga(s) {
    const A = T[s.arma]; let modo = null;
    if (s.blanco === 'bicho' && s.bicho) modo = 'bicho';
    else if (s.blanco === 'jugador') {
      if (ahora - s.tConoce < T.reaccion) return false;              // tiempo humano de reacción
      if (s.ve) {
        if (ahora - s.veDesde < T.reaccion) return false;
        if (!puntoMira(s, T.miraAtraso, T.miraAdelanto)) return false;
        if (!s.avisoHecho) modo = 'aviso';                           // la primera ráfaga de cada uno es de aviso
        else if (s.ficha && lineaLimpia(s) && (s.arma !== 'escopeta' || hyp(s.miraX - s.x, s.miraZ - s.z) < T.escopeta.nada)) modo = 'pegar';
        else modo = 'suprimir';
      } else {
        if (!debeSuprimir(s)) return false;
        modo = s.avisoHecho ? 'suprimir' : 'aviso';
      }
    }
    if (!modo) return false;
    if (modo !== 'bicho' && !s.esc.fijarDicho && s.tarea === 'fijar') { s.esc.fijarDicho = true; decir(s, 'fijar'); }
    if (s.arma === 'escopeta' && modo !== 'pegar' && modo !== 'bicho') {
      const u = conocido(s); if (!u || hyp(u.x - s.x, u.z - s.z) > T.escopeta.alcance) return false;       // de lejos la escopeta ni suprime
    }
    s.rafModo = modo; s.rafLado = azar() < 0.5 ? -1 : 1; s.rafOff = entre(T.supOffMin, T.supOffMax);
    s.raf = s.arma === 'fusil' ? Math.min(s.balas, Math.round(entre(A.rafMin, A.rafMax))) : 1;
    s.rafT = 0; s.nRaf++;                                             // (la de aviso cuenta recién cuando sale la primera bala: ver soltarBala)
    return true;
  }
  /* una bala de la ráfaga en curso */
  function soltarBala(s) {
    const A = T[s.arma]; let modo = s.rafModo;
    if (modo === 'pegar' && (!s.ficha || !s.ve)) modo = 'suprimir';  // le sacaron la ficha o dejó de verlo en medio de la ráfaga
    let px, py, pz, disp, d;
    if (modo === 'bicho') {
      const b = s.bicho; if (!b) { s.raf = 0; return; }
      px = b.x; py = (b.y || 0) + 0.9; pz = b.z; disp = A.disp * 1.25 * (1 + s.supr);
    } else {
      if ((s.ve || ahora - s.tVisto < 0.6) && puntoMira(s, T.miraAtraso, T.miraAdelanto)) { px = s.miraX; py = s.miraY; pz = s.miraZ; }
      else { const u = red.uc; if (!u) { s.raf = 0; return; } px = u.x; py = u.y + 1.0; pz = u.z; if (modo === 'pegar') modo = 'suprimir'; }
      d = hyp(px - s.x, pz - s.z);
      if (modo === 'pegar') disp = A.disp * (1 + (A.suelto ? (A.suelto - 1) * (1 - s.asiento) : 0)) * T.punteria * (1 + s.supr);
      else {
        /* suprimir o avisar: apunta a propósito a un costado, con poca dispersión, para que se vean pasar y no peguen */
        disp = A.disp * 0.6;
        const off = s.rafOff + 1.7 * disp * 1.6 * d, ux = (px - s.x) / (d || 1), uz = (pz - s.z) / (d || 1);
        px += -uz * off * s.rafLado; pz += ux * off * s.rafLado; py += 0.15;
      }
    }
    s.balas--; s.tDisparo = ahora; s.esc.tFuego = ahora;
    if (s.rafModo === 'aviso') s.avisoHecho = true;
    if (s.vista && s.vista.disparo) s.vista.disparo();
    if (s.arma === 'escopeta') {
      d = hyp(px - s.x, pz - s.z); const dn = A.dano * caidaEscopeta(d) * (modo === 'bicho' ? 1 : T.dano);
      for (let q = 0; q < A.perdigones; q++) tirarBala(s, px, py, pz, modo, 'escopeta', modo === 'pegar' ? A.disp * T.punteria : A.disp, dn, A.alcance, true);
    } else tirarBala(s, px, py, pz, modo, s.arma === 'tirador' ? 'tirador' : 'fusil', disp, A.dano * (modo === 'bicho' ? 1 : T.dano), A.alcance, s.arma !== 'tirador');
  }
  /* cadencia de tiro: corre en cada cuadro mientras el soldado está en condiciones de tirar */
  function gatillo(s, dt) {
    const A = T[s.arma];
    if (s.raf > 0) {
      s.rafT -= dt;
      while (s.raf > 0 && s.rafT <= 0) {
        soltarBala(s); s.raf--; s.rafT += A.cadencia;
        if (s.raf <= 0 || s.balas <= 0) {
          s.raf = 0;
          s.pausaT = s.arma === 'fusil' ? entre(A.pausaMin, A.pausaMax) * (s.hp < T.vida * T.heridoBajo ? 1.7 : 1) * (s.rafModo === 'suprimir' && !s.ve ? 1.4 : 1) : A.cadencia;
        }
      }
      return;
    }
    s.pausaT -= dt;
    if (s.pausaT <= 0 && s.balas > 0) { if (!empezarRafaga(s)) s.pausaT = 0.12; }
  }
  /* ¿puede tirar ahora? (postura estable, arma arriba, mirando al blanco, sin correr) */
  function puedeTirar(s) {
    if (s.recT >= 0 || s.aturdido > 0 || s.salto >= 0 || s.lanzaT >= 0 || s.culT >= 0 || s.escondeT > 0) return false;
    if (s.apunta < 0.85) return false;
    if (s.tierra > 0.02 && s.tierra < 0.98) return false;            // a medio levantarse o tirarse
    if (s.vx * s.vx + s.vz * s.vz > 2.6) return false;               // corriendo no tira
    return true;
  }

  /* ---------------------------------------------------------------------------------------------------
     Fichas de ataque: como mucho TUNE.fichas soldados tiran a pegar a la vez (regla 4). Se la lleva el que
     mejor lo ve; rota. Una ficha que se suelta queda 0,4 s sin dueño (así nunca hay más de TUNE.fichas
     tirando a pegar ni siquiera durante el pase).
     --------------------------------------------------------------------------------------------------- */
  let fichaLibreEn = -99;
  function repartirFichas() {
    const F = red.fichas; let max = T.fichas;
    for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo && escuadrones[i].desorden > ahora) max = Math.min(max, 1);   // sin jefe: una sola
    if (red.muerto) max = 0;
    /* soltar las que ya no corresponden */
    for (let i = F.length - 1; i >= 0; i--) {
      const s = F[i];
      const vale = s.vivo && s.blanco === 'jugador' && (s.ve || ahora - s.tVisto < 0.7) && s.enTiro && s.recT < 0 && s.escondeT <= 0;
      if (!vale || F.length > max) { s.ficha = false; F.splice(i, 1); fichaLibreEn = ahora + 0.4; }
    }
    if (F.length >= max) {
      /* rotación: si uno la tiene hace mucho y otro que lo ve la espera, la suelta */
      if (F.length >= max && max > 0) for (let i = 0; i < F.length; i++) { const s = F[i]; if (ahora - s.fichaT > T.fichaMax && hayEsperando()) { s.ficha = false; s.fichaCd = ahora + 2.5; F.splice(i, 1); fichaLibreEn = ahora + 0.4; break; } }
      return;
    }
    let mejor = null, mp = -1e9;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!puedeFicha(s)) continue;
      const u = s.hist[(s.hI + 9) % 10], d = hyp(u.x - s.x, u.z - s.z);
      let p = s.asiento * 2 + (s.tarea === 'flanquear' || s.tarea === 'empujar' ? 3 : 0) - (s.veMedio ? 0.6 : 0);
      p += s.arma === 'escopeta' ? (d < 16 ? 2.5 : d < 28 ? 0.3 : -9) : 1 - d / 90;
      if (p > mp) { mp = p; mejor = s; }
    }
    if (mejor) { mejor.ficha = true; mejor.fichaT = ahora; F.push(mejor); }
  }
  function puedeFicha(s) {
    return s.vivo && s.activo && !s.ficha && s.rol !== 'tirador' && s.blanco === 'jugador' && s.ve && s.enTiro && s.recT < 0 && s.escondeT <= 0 && !(s.fichaCd > ahora) && ahora - s.veDesde >= T.reaccion * 0.5;
  }
  function hayEsperando() { for (let i = 0; i < soldados.length; i++) if (puedeFicha(soldados[i])) return true; return false; }

  /* ====================================================================================================
     MOVERSE: velocidad deseada y aceleración, seguimiento del camino, saltos de valla, anti-trabado
     ==================================================================================================== */
  let nTrab = 0;
  const prof = (TUNE && TUNE.perfil && typeof performance !== 'undefined') ? {} : null;   // perfil de los trabajos pesados (solo para medir)
  /* cola de trabajos pesados: cada pedido pisa al anterior del mismo soldado y la misma clave */
  function encolar(s, clave, fn) { const n = ++nTrab; s.pend[clave] = n; trabajos.push({ s, clave, n, fn }); }
  function procesarTrabajo() {
    while (trabajos.length) {
      const j = trabajos.shift();
      if (!j.s.vivo || j.s.pend[j.clave] !== j.n) continue;          // pedido viejo o de un muerto
      j.s.pend[j.clave] = 0; xPresu = T.presuLineas;
      if (prof) { const t0 = performance.now(), c0 = xCalc, a0 = aIt; j.fn(); const ms = performance.now() - t0, p = prof[j.clave] || (prof[j.clave] = { n: 0, ms: 0, max: 0, lentos: [] }); p.n++; p.ms += ms; if (ms > p.max) p.max = ms; if (ms > 2) p.lentos.push([+ahora.toFixed(1), +ms.toFixed(1), xCalc - c0, aIt - a0]); }
      else j.fn();
      xPresu = 1e9;
      return true;                                                    // uno solo por cuadro
    }
    return false;
  }
  /* manda a s a un punto. op = {expo, agach, evita}. El camino llega en uno de los próximos cuadros. */
  function irA(s, x, z, vel, op) {
    s.vel = vel; s.llego = false; s.dest = s.dest || { x: 0, z: 0 }; s.dest.x = x; s.dest.z = z;
    const d = hyp(x - s.x, z - s.z);
    if (d < 0.3) { s.camino = null; s.llego = true; s.esperaCamino = false; return; }
    if (d < 2.2 && !s.elev && libreEn(x, z) && lineaLibre(s.x, s.z, x, z, -1, false)) {      // paso corto y derecho: sin A*
      s.camino = [{ x, z, salto: false }]; s.ci = 0; s.esperaCamino = false; s.pend.camino = 0; return;
    }
    s.esperaCamino = true;
    encolar(s, 'camino', () => {
      let c = aEstrella(s.x, s.z, x, z, op);
      if (!c && op && op.expo) c = aEstrella(s.x, s.z, x, z, null);
      s.esperaCamino = false;
      if (!c) { s.camino = null; s.sinCamino = (s.sinCamino || 0) + 1; s.llego = true; s.fallo = true; return; }
      s.camino = c; s.ci = 0; s.fallo = false; s.sinCamino = 0;
    });
  }
  function parar(s) { s.camino = null; s.dvx = s.dvz = 0; s.esperaCamino = false; s.pend.camino = 0; s.llego = true; }
  function empezarSalto(s, p) {
    let q = s.ci; while (q < p.length && p[q].salto) q++;
    if (q >= p.length) { s.camino = null; s.llego = true; return; }  // camino roto: termina acá
    s.salto = 0; s.sx0 = s.x; s.sz0 = s.z; s.sx1 = p[q].x; s.sz1 = p[q].z;
    s.sDur = Math.max(T.saltoT, hyp(s.sx1 - s.sx0, s.sz1 - s.sz0) / 3.4); s.ci = q + 1;
  }
  /* sigue el camino: deja en dvx,dvz la velocidad que quiere. */
  function seguir(s) {
    const p = s.camino;
    if (!p || s.ci >= p.length) { s.dvx = s.dvz = 0; if (p && !s.esperaCamino) { s.camino = null; s.llego = true; } return; }
    let tg = p[s.ci];
    if (tg.salto) { empezarSalto(s, p); return; }
    let d = hyp(tg.x - s.x, tg.z - s.z);
    const sig = s.ci + 1 < p.length ? p[s.ci + 1] : null;
    if (sig && d < (sig.salto ? 0.3 : 0.6)) { s.ci++; if (sig.salto) { empezarSalto(s, p); return; } tg = sig; d = hyp(tg.x - s.x, tg.z - s.z); }
    const ultimo = s.ci >= p.length - 1;
    if (ultimo && d < (s.estado === 'asomado' || s.estado === 'volver' ? 0.07 : 0.22)) { s.ci = p.length; s.camino = null; s.llego = true; s.dvx = s.dvz = 0; return; }   // al puesto de tiro llega justo: la línea se calculó desde el centro del casillero
    let v = s.vel;
    if (s.tierra > 0.02) v = Math.min(v, 0.8); else if (s.agach > 0.6) v = Math.min(v, T.velAgach);
    if (ultimo) v *= clamp(d / 1.4, 0.25, 1);                         // frena al llegar
    else {
      const n2 = p[s.ci + 1];
      if (n2.salto) v *= clamp(d / 1.2, 0.45, 1);                     // llega despacio a la valla
      else if (d < 1.6) {                                             // y afloja en las curvas cerradas
        const ax = tg.x - s.x, az = tg.z - s.z, bx = n2.x - tg.x, bz = n2.z - tg.z, c = (ax * bx + az * bz) / ((d || 1) * (hyp(bx, bz) || 1));
        if (c < 0.5) v *= 0.6;
      }
    }
    s.dvx = (tg.x - s.x) / (d || 1) * v; s.dvz = (tg.z - s.z) / (d || 1) * v;
  }
  function mover(s, dt) {
    if (s.salto >= 0) {                                               // pasando una valla (o bajando del nido)
      s.salto += dt / s.sDur; const u = Math.min(1, s.salto);
      s.x = s.sx0 + (s.sx1 - s.sx0) * u; s.z = s.sz0 + (s.sz1 - s.sz0) * u;
      if (s.bajaDe > 0) s.y = s.bajaDe * (1 - u * u); else if (s.subeA > 0) s.y = s.subeA * Math.min(1, u * 1.4); else s.y = ENV.piso(s.x, s.z);
      if (s.salto >= 1 && s.subeA > 0) { const n = s.esc.nido; s.salto = -1; s.elev = { r: (n && n.r) || 1.5, y: s.subeA }; s.y = s.subeA; s.subeA = 0; s.vx = s.vz = 0; s.post = 2; s.trabT = 0; return; }
      if (s.salto >= 1) { s.salto = -1; s.bajaDe = 0; const l = hyp(s.sx1 - s.sx0, s.sz1 - s.sz0) || 1; s.vx = (s.sx1 - s.sx0) / l * 2; s.vz = (s.sz1 - s.sz0) / l * 2; }
      s.trabT = 0; s.trabX = s.x; s.trabZ = s.z;
      return;
    }
    if (s.elev) { s.vx = s.vz = 0; return; }                          // arriba del nido no camina
    /* separación: si se están por encimar, se corren un poco */
    let ex = 0, ez = 0;
    if (s.mov) for (let i = 0; i < soldados.length; i++) {
      const o = soldados[i]; if (o === s || !o.vivo || !o.activo || o.elev) continue;
      const dx = s.x - o.x, dz = s.z - o.z, d2 = dx * dx + dz * dz;
      if (d2 < 1.44 && d2 > 1e-4) { const d = Math.sqrt(d2), f = (1.2 - d) * 2.5; ex += dx / d * f; ez += dz / d * f; }
    }
    const ax = s.dvx + ex - s.vx, az = s.dvz + ez - s.vz, al = hyp(ax, az), m = T.acel * dt;
    if (al > m) { s.vx += ax / al * m; s.vz += az / al * m; } else { s.vx += ax; s.vz += az; }
    let nx = s.x + s.vx * dt, nz = s.z + s.vz * dt;
    if (!libreEn(nx, nz)) {                                           // se desliza contra lo que haya
      if (libreEn(nx, s.z)) { nz = s.z; s.vz = 0; } else if (libreEn(s.x, nz)) { nx = s.x; s.vx = 0; } else { nx = s.x; nz = s.z; s.vx = s.vz = 0; }
    }
    if (!libreEn(nx, nz)) {                                           // quedó adentro de algo (cambió la grilla): sale al libre más cercano
      const k = libreCerca(nx, nz, 4); if (k >= 0) { nx += (cX(k) - nx) * Math.min(1, dt * 10); nz += (cZ(k) - nz) * Math.min(1, dt * 10); if (!libreEn(nx, nz) && hyp(cX(k) - nx, cZ(k) - nz) < 0.75) { nx = cX(k); nz = cZ(k); } }
    }
    s.x = nx; s.z = nz; s.y = ENV.piso(nx, nz);
    /* anti-trabado: si quiere moverse y en 1 s no avanzó, replantea; a la tercera, se corre de costado */
    if (s.mov) {
      s.trabT += dt;
      if (s.trabT >= 1) {
        if (hyp(s.x - s.trabX, s.z - s.trabZ) < 0.45) {
          s.trabN++;
          if (s.dest && !s.esperaCamino) {
            if (s.trabN >= 3) { const k = libreCerca(s.x + campana() * 2, s.z + campana() * 2, 2); if (k >= 0) { s.camino = [{ x: cX(k), z: cZ(k), salto: false }]; s.ci = 0; } s.trabN = 0; s.replan = true; }
            else irA(s, s.dest.x, s.dest.z, s.vel, s.caminoOp);
          }
        } else s.trabN = 0;
        s.trabT = 0; s.trabX = s.x; s.trabZ = s.z;
      }
    } else { s.trabT = 0; s.trabX = s.x; s.trabZ = s.z; }
  }
  /* posturas: de pie ↔ agachado 0,25 s · agachado → tierra 0,6 s · tierra → agachado 0,9 s */
  function posturas(s, dt) {
    if (s.post === 2) { if (s.agach < 1) s.agach = Math.min(1, s.agach + dt / T.tAgach); else s.tierra = Math.min(1, s.tierra + dt / T.tATierra); }
    else if (s.tierra > 0) s.tierra = Math.max(0, s.tierra - dt / T.tDeTierra);
    else if (s.post === 1) s.agach = Math.min(1, s.agach + dt / T.tAgach);
    else s.agach = Math.max(0, s.agach - dt / T.tAgach);
  }
  function girarHacia(s, yaw, dt, vel) {
    const d = angN(yaw - s.miraYaw), m = (vel || T.giro) * dt;
    s.miraYaw = angN(s.miraYaw + clamp(d, -m, m));
  }
  const rumboA = (s, x, z) => Math.atan2(x - s.x, z - s.z);
  function ponerEstado(s, e) { if (s.estado !== e) { s.estado = e; s.tEst = ahora; } }

  /* ====================================================================================================
     ACTUAR: corre en cada cuadro. Relojes, postura, movimiento, giro, puntería, cadencia de tiro.
     ==================================================================================================== */
  function actuar(s, dt) {
    /* relojes */
    if (s.aturdido > 0) { s.aturdido -= dt; if (s.aturdido <= 0 && s.estado === 'aturdido') ponerEstado(s, s.cob ? 'volver' : 'alerta'); }
    if (s.radioT > 0) s.radioT -= dt;
    if (s.senalT >= 0) { s.senalT += dt / 1.4; if (s.senalT >= 1) s.senalT = -1; }
    if (s.culCd > 0) s.culCd -= dt;
    if (s.escondeT > 0) s.escondeT -= dt;
    if (s.supr > 0) s.supr = Math.max(0, s.supr - T.suprBaja * dt);
    /* puntería: se asienta mientras lo ve quieto; se pierde si deja de verlo, se mueve o lo suprimen */
    const v2 = s.vx * s.vx + s.vz * s.vz;
    if (s.ve && v2 < 2.6 && s.supr < T.suprEsconde && s.apunta > 0.8) s.asiento = Math.min(1, s.asiento + dt / T.asientoT);
    else {
      /* «lo están esperando»: si se escondió y el soldado sigue en su lugar apuntando adonde lo vio, la puntería se pierde
         despacio. Asomarse siempre por el mismo lado se paga; cambiar de lugar se la resetea. */
      const espera = !s.ve && ahora - s.tVisto < T.esperaT && s.supr < 0.3 && !enMovimiento(s);
      s.asiento = Math.max(0, s.asiento - dt * (espera ? T.asientoEspera : s.ve ? 1.5 : 3));
    }
    /* recarga */
    if (s.recT >= 0) {
      const A = T[s.arma];
      if (s.arma === 'escopeta') { s.recT += dt; if (s.recT >= A.recargaCartucho) { s.recT = 0; s.balas++; if (s.balas >= A.cargador) s.recT = -1; } }
      else { s.recT += dt; if (s.recT >= A.recarga) { s.recT = -1; s.balas = A.cargador; } }
    }
    posturas(s, dt);

    /* ---- movimiento según el estado ---- */
    s.mov = false;
    const est = s.estado;
    if (s.aturdido > 0 || est === 'lanzar' || est === 'radio' || est === 'culata') { s.dvx = s.dvz = 0; }
    else if (s.retro > 0) {                                           // retrocede de un bicho que se le vino encima
      s.retro -= dt;
    } else if (s.camino || s.esperaCamino) {
      if (s.tierra > 0.02 && s.post !== 2 && s.vel > 1) { s.dvx = s.dvz = 0; }   // se está levantando: todavía no corre
      else { seguir(s); s.mov = !!(s.camino) && s.salto < 0; }
    } else { s.dvx = s.dvz = 0; }
    mover(s, dt);

    /* ---- hacia dónde mira ---- */
    let yaw = s.miraObj;
    if (s.mov && v2 > 3 && !s.miraFija) yaw = Math.atan2(s.vx, s.vz);  // corriendo sin nada que mirar: mira adonde va
    if (yaw !== undefined && yaw !== null) girarHacia(s, yaw, dt, s.aturdido > 0 ? 1 : T.giro);
    /* el cuerpo sigue a la mirada; corriendo, al movimiento */
    const cuerpo = (v2 > 6) ? Math.atan2(s.vx, s.vz) : s.miraYaw;
    { const d = angN(cuerpo - s.rumbo), m = T.giro * 1.5 * dt; s.rumbo = angN(s.rumbo + clamp(d, -m, m)); }
    /* arma arriba o abajo */
    const ap = s.apObj ? 1 : 0; s.apunta += clamp(ap - s.apunta, -dt * 4, dt * 4);

    /* ---- cosas con reloj propio ---- */
    if (s.lanzaT >= 0) tickLanzar(s, dt);
    if (s.culT >= 0) tickCulata(s, dt);
    if (s.rol === 'tirador' && s.blanco !== 'bicho') tickTirador(s, dt);
    else if (s.enTiro && puedeTirar(s)) gatillo(s, dt);
    else if (s.raf > 0) { s.raf = 0; s.pausaT = 0.3; }                // se le cortó la ráfaga (se agachó, lo aturdieron…)
    if (s.vista) escribirVista(s, dt);
  }

  /* gesto de lanzar: grito al empezar; la granada sale en el 55 % del gesto y nunca antes de T.granada.aviso */
  function tickLanzar(s, dt) {
    const G = T.granada, antes = s.lanzaT; s.lanzaT += dt / G.gesto;
    const L = s.lanza;
    if (L && !L.salio && s.lanzaT >= 0.55 && ahora - s.gritoT >= G.aviso) {
      L.salio = true;
      const hx = s.x, hy = s.y + 1.75, hz = s.z;                                         // la mano (la misma que se usó para decidir)
      const a = ENV.arco(hx, hy, hz, L.x, L.y, L.z);
      if (a && s.granadas > 0) { s.granadas--; red.tGranada = ahora; ENV.granada(s, hx, hy, hz, a.vx, a.vy, a.vz, G.mecha, 'frag'); ENV.evento('granada', { s, x: L.x, z: L.z, motivo: L.motivo }); }
      else red.tGranada = ahora - G.cada + 3;                         // no había arco: se guarda la granada y se prueba más tarde
    }
    if (s.lanzaT >= 1) { s.lanzaT = -1; s.lanza = null; if (s.estado === 'lanzar') { ponerEstado(s, s.cob ? 'volver' : 'alerta'); s.tSal = ahora + 0.4; } }
  }
  /* culatazo: 0,35 s de aviso (el golpe cae en la mitad del gesto de 0,7 s) */
  function tickCulata(s, dt) {
    const C = T.culata; s.culT += dt / (C.aviso * 2);
    if (!s.culPego && s.culT >= 0.5) {
      s.culPego = true;
      if (s.culBicho) { const b = s.bicho; if (b && b.d < C.dist + 0.6) ENV.herirBicho(b.ref, 25 * T.bichoDano, Math.sin(s.miraYaw), Math.cos(s.miraYaw)); }
      else {
        /* física del golpe: llega si el jugador sigue al alcance y adelante (se puede esquivar retrocediendo) */
        const j = ENV.jugador(), dx = j.x - s.x, dz = j.z - s.z, d = hyp(dx, dz);
        if (j.vivo && d < C.dist + 0.25 && Math.abs(angN(Math.atan2(dx, dz) - s.miraYaw)) < 1.0 && Math.abs(j.y - s.y) < 1.5) ENV.herirJugador(C.dano * T.dano, s.x, s.z, 'culata');
      }
    }
    if (s.culT >= 1) { s.culT = -1; s.culCd = C.cada; if (s.estado === 'culata') ponerEstado(s, s.cob ? 'volver' : 'alerta'); }
  }

  /* ---------------------------------------------------------------------------------------------------
     EL TIRADOR. Ciclo: «lo tengo en la mira» → láser prendido siguiendo al jugador (con atraso) durante
     T.tirador.laser segundos CONTINUOS de línea de visión → destello → tiro al punto donde está el láser.
     Si la línea se corta un solo cuadro, se cancela. Mientras apunta mira en cada cuadro (no cada 0,12 s).
     --------------------------------------------------------------------------------------------------- */
  function soltarLaser(s, fallo) {
    s.laser = null; if (red.tirador === s) red.tirador = null;
    if (s.tir !== 'espera') { s.tir = 'espera'; s.tirSig = Math.max(s.tirSig, ahora + 0.9); if (fallo && ahora - s.tirDijo > 4) { if (decir(s, 'tirador_fallo')) s.tirDijo = ahora; } }
  }
  function tickTirador(s, dt) {
    const R = T.tirador;
    if (red.muerto || s.blanco !== 'jugador' || !s.enTiro || !puedeTirar(s) || s.supr > T.suprEsconde || s.mov) { if (s.tir !== 'espera') soltarLaser(s, false); else s.laser = null; return; }
    const u = s.hist[(s.hI + 9) % 10], d = s.ve ? hyp(u.x - s.x, u.z - s.z) : 1e9;
    if (s.tir === 'espera') {
      if (!s.ve || ahora - s.veDesde < T.reaccion || ahora - s.tConoce < T.reaccion || s.balas <= 0) return;
      if (d <= R.cerca) {
        /* de cerca: rápido y mal, sin láser */
        if (ahora >= s.tirSig && puntoMira(s, T.miraAtraso, T.miraAdelanto)) {
          const modo = s.avisoHecho ? 'pegar' : 'aviso'; s.avisoHecho = true; s.nRaf++; s.balas--; s.tDisparo = ahora; s.tirSig = ahora + R.cercaCadencia;
          if (s.vista && s.vista.disparo) s.vista.disparo();
          let px = s.miraX, pz = s.miraZ; if (modo === 'aviso') { const ux = (px - s.x) / (d || 1), uz = (pz - s.z) / (d || 1); px += -uz * 1.3; pz += ux * 1.3; }
          tirarBala(s, px, s.miraY, pz, modo, 'tirador', R.cercaDisp * T.punteria, R.cercaDano, R.alcance, true);
        }
        return;
      }
      if (ahora < s.tirSig || (red.tirador && red.tirador !== s)) return;
      red.tirador = s; s.tir = 'mira'; s.tirT = 0;
      if (ahora - s.tirDijo > 6) { if (decir(s, 'tirador_mira')) s.tirDijo = ahora; }
      ENV.evento('tirador_mira', { s });
    }
    /* apuntando: mira en cada cuadro; si se corta la línea, se cancela */
    percibir(s); s.tPerc = ahora + T.tPercibir;
    if (!s.ve || !puntoMira(s, R.atraso, R.adelanto)) { soltarLaser(s, true); return; }
    s.lx = s.miraX; s.ly = s.miraY; s.lz = s.miraZ; s.laser = s._laser; s._laser.x = s.lx; s._laser.y = s.ly; s._laser.z = s.lz;
    s.tirT += dt;
    if (s.tir === 'mira') { if (s.tirT >= R.laser) { s.tir = 'destello'; s.tirT = 0; } return; }
    if (s.tirT < R.destello) return;
    /* tiro: adonde está el punto rojo. El primero de cada tirador es de aviso (regla 4). */
    const modo = s.avisoHecho ? 'laser' : 'aviso'; s.avisoHecho = true; s.nRaf++; s.balas--; s.tDisparo = ahora; s.esc.tFuego = ahora;
    if (s.vista && s.vista.disparo) s.vista.disparo();
    let px = s.lx, pz = s.lz;
    if (modo === 'aviso') { const dd = hyp(px - s.x, pz - s.z) || 1, ux = (px - s.x) / dd, uz = (pz - s.z) / dd, l = azar() < 0.5 ? -1 : 1; px += -uz * 0.9 * l; pz += ux * 0.9 * l; }
    const pega = tirarBala(s, px, s.ly, pz, modo, 'tirador', R.disp * T.punteria, R.dano, R.alcance, false);
    s.laser = null; red.tirador = null; s.tir = 'espera'; s.tirSig = ahora + Math.max(0.6, R.ciclo - R.laser - R.destello);
    if (pega !== 'jugador' && modo === 'laser' && ahora - s.tirDijo > 4) { if (decir(s, 'tirador_fallo')) s.tirDijo = ahora; }
    if (s.balas <= 0) { s.recT = 0; }
  }

  /* ---------------------------------------------------------------------------------------------------
     Entradas del modelo 3D (SPEC 4.2). Convenciones que asume la IA (avisadas en el informe):
       mYaw > 0 = el arma apunta hacia la izquierda del cuerpo (mismo sentido que rotation.y)
       mPitch > 0 = hacia arriba · asoma −1 izquierda, +1 derecha · laser = objeto plano {x,y,z}
     --------------------------------------------------------------------------------------------------- */
  function escribirVista(s, dt) {
    const u = s.vista, e = u.e;
    u.root.position.set(s.x, s.y, s.z); u.root.rotation.y = s.rumbo;
    e.agach = s.agach; e.tierra = s.tierra; e.apunta = s.apunta;
    e.mYaw = clamp(angN(s.miraYaw - s.rumbo), -1.3, 1.3); e.mPitch = clamp(s.mPitch, -0.9, 0.9);
    e.asoma = (s.enTiro && s.cob && s.cob.tiro) ? s.cob.tiro.lado : 0;
    e.recarga = s.recT >= 0 ? (s.arma === 'escopeta' ? s.recT / T.escopeta.recargaCartucho : s.recT / T[s.arma].recarga) : -1;
    e.salto = (s.salto >= 0 && !(s.bajaDe > 0)) ? Math.min(1, s.salto) : -1;
    e.lanza = s.lanzaT; e.senal = s.senalT; e.senalTipo = s.senalTipo; e.culata = s.culT;
    e.radio = s.radioT > 0 ? Math.min(1, s.radioT * 4) : 0; e.aturdido = s.aturdido > 0 ? 1 : 0;
    e.luz = s.luz; e.laser = s.laser; e.muerte = s.muerte;
    u.update(dt);
  }

  /* ====================================================================================================
     PENSAR: unas 8 veces por segundo por soldado, escalonado. Decide; actuar() ejecuta.
     ==================================================================================================== */
  function pensar(s) {
    if (s.aturdido > 0 || s.salto >= 0) return;
    if (s.estado === 'esquivar') { pensarEsquivar(s); return; }
    if (empezarEsquivar(s)) return;
    elegirBlanco(s);
    if (s.estado === 'lanzar' || s.estado === 'culata') return;
    if (s.estado === 'llegando' && s.blanco !== 'bicho' && !red.muerto) { pensarLlegando(s, conocido(s)); return; }   // el refuerzo primero llega
    if (intentarCulata(s)) return;
    if (s.blanco === 'bicho') { pensarBicho(s); return; }
    if (s.estado === 'bicho') { ponerEstado(s, 'alerta'); s.enTiro = false; }
    const nivel = nivelDe(s);
    if (red.muerto || nivel === 0) pensarGuardia(s);
    else if (nivel === 2) pensarCombate(s);
    else if (s.esc.estado === 'busqueda') pensarBusqueda(s);
    else pensarSospecha(s);
  }

  /* ---------- blanco: el jugador o un bicho ---------- */
  function elegirBlanco(s) {
    const b = s.bicho, nivel = nivelDe(s);
    if (b && b.d < T.bichoManda) s.blanco = 'bicho';                                  // un bicho encima manda
    else if (nivel >= 2 && red.uc && !red.muerto && (!b || s.ve || (!s.esc.prioBichos && ahora - red.tSenal < 4))) s.blanco = 'jugador';
    else if (b) s.blanco = 'bicho';
    else s.blanco = (nivel >= 2 && !red.muerto) ? 'jugador' : null;
  }
  function mirarA(s, x, y, z) {
    s.miraObj = Math.atan2(x - s.x, z - s.z);
    const d = hyp(x - s.x, z - s.z); s.mPitch = Math.atan2(y - (s.y + 1.4 - 0.5 * s.agach), d || 1);
  }

  /* ---------- peligros: granadas y autos por explotar ---------- */
  function puntoDeEscape(s, p) {
    const base = Math.atan2(s.x - p.x, s.z - p.z); let mejor = null, mp = -1e9;
    for (let q = 0; q < 12; q++) {
      const a = base + q * PI / 6, x = p.x + Math.sin(a) * (p.r + 2.8), z = p.z + Math.cos(a) * (p.r + 2.8), k = libreCerca(x, z, 1);
      if (k < 0) continue; const fx = cX(k), fz = cZ(k);
      if (enPeligro(fx, fz, 0.5)) continue;
      let pt = -hyp(fx - s.x, fz - s.z);
      if (!lineaVista(p.x, 0.5, p.z, fx, 0.6, fz)) pt += 4;                           // mejor si queda algo entre la explosión y él
      if (pt > mp) { mp = pt; mejor = k; }
    }
    return mejor;
  }
  function empezarEsquivar(s) {
    const p = enPeligro(s.x, s.z, 0.8); if (!p || p.t > 6) return false;
    if (s.pelVisto !== p.x + p.z) { s.pelVisto = p.x + p.z; s.pelT = ahora; }           // tarda un instante en darse cuenta
    if (ahora - s.pelT < 0.2) return false;
    const propia = p.de && typeof p.de === 'object';                                    // una granada nuestra: se corren sin gritar
    if (!propia) decir(s, (p.tipo === 'auto' || p.r > 8) ? 'auto_fuego' : 'granada_enemiga');
    s.raf = 0; s.enTiro = false; if (s.rol === 'tirador') soltarLaser(s, false);
    if (s.lanzaT >= 0 && s.lanza && !s.lanza.salio) { s.lanzaT = -1; s.lanza = null; }
    if (s.elev) { bajarDelNido(s); ponerEstado(s, 'esquivar'); s.escK = -1; return true; }
    ponerEstado(s, 'esquivar'); s.post = 0; s.apObj = false; s.miraObj = null; s.miraFija = false;
    const k = puntoDeEscape(s, p); s.escK = k;
    if (k >= 0) irA(s, cX(k), cZ(k), T.velEscapar, { evita: [{ x: p.x, z: p.z, r: p.r, c: 5 }] }); else { parar(s); s.post = 2; }
    if (s.esc.mueve === s) s.esc.mueve = null;
    return true;
  }
  function pensarEsquivar(s) {
    const p = enPeligro(s.x, s.z, 3.5);
    if (!p) {                                                                           // pasó el peligro: a pelear de nuevo
      if (ahora - s.tEst < 0.4) return;
      s.post = 0; s.cob = null; parar(s); ponerEstado(s, 'alerta'); return;
    }
    if (s.escK === -1 && s.salto < 0 && !s.elev) { const k = puntoDeEscape(s, p); s.escK = k; if (k >= 0) irA(s, cX(k), cZ(k), T.velEscapar, null); }
    const dentro = hyp(p.x - s.x, p.z - s.z) < p.r + 0.5;
    if (p.t < 0.5 || (s.llego && !s.esperaCamino)) {
      if (dentro && p.t > 1.2 && s.llego) { const k = puntoDeEscape(s, p); if (k >= 0) { irA(s, cX(k), cZ(k), T.velEscapar, null); return; } }
      parar(s); s.post = 2;                                                             // al piso
    }
  }

  /* ---------- culatazo ---------- */
  function intentarCulata(s) {
    if (s.culCd > 0 || s.culT >= 0 || s.elev || s.tierra > 0.3 || s.recT >= 0 && false) return false;
    const C = T.culata;
    if (s.ve && s.blanco === 'jugador') {
      const h = s.hist[(s.hI + 9) % 10];
      if (ahora - h.t < 0.25 && hyp(h.x - s.x, h.z - s.z) < C.dist) {
        s.culT = 0; s.culPego = false; s.culBicho = false; s.raf = 0; s.dvx = s.dvz = 0; s.miraObj = rumboA(s, h.x, h.z); s.miraFija = true; ponerEstado(s, 'culata'); return true;
      }
    }
    const b = s.bicho;
    if (b && b.d < 1.7 && (s.balas <= 0 || s.recT >= 0)) { s.culT = 0; s.culPego = false; s.culBicho = true; s.raf = 0; s.miraObj = rumboA(s, b.x, b.z); s.miraFija = true; ponerEstado(s, 'culata'); return true; }
    return false;
  }

  /* ---------- contra los bichos: sin ficha, con buena puntería, retrocediendo si se le vienen encima ---------- */
  function pensarBicho(s) {
    const b = s.bicho; if (!b) return;
    if (s.elev) {                                                                       // el tirador en el nido solo se defiende de los que tiene cerca
      s.post = 2; s.apObj = true; s.miraFija = true;
      if (b.d > 15 || s.tir !== 'espera') { s.enTiro = false; return; }
      ponerEstado(s, 'bicho'); s.enTiro = true; mirarA(s, b.x, (b.y || 0) + 0.9, b.z);
      if (s.balas <= 0 && s.recT < 0) s.recT = 0;
      return;
    }
    if (s.estado !== 'bicho') { ponerEstado(s, 'bicho'); parar(s); if (s.esc.mueve === s) s.esc.mueve = null; }
    s.apObj = true; s.luz = true; s.miraFija = true; s.enTiro = true; s.post = s.tierra > 0 ? 0 : (b.d > 12 ? 1 : 0);
    mirarA(s, b.x, b.y, b.z);
    if (s.balas <= 0 && s.recT < 0) { s.recT = 0; decir(s, 'recarga'); }
    if (b.d < T.bichoRetro) {
      /* retrocede de frente al bicho, despacio (así puede seguir tirando), hacia un casillero libre */
      const ux = (s.x - b.x) / (b.d || 1), uz = (s.z - b.z) / (b.d || 1);
      let vx = ux, vz = uz;
      if (!libreEn(s.x + ux * 1.2, s.z + uz * 1.2)) { if (libreEn(s.x - uz * 1.2, s.z + ux * 1.2)) { vx = -uz; vz = ux; } else if (libreEn(s.x + uz * 1.2, s.z - ux * 1.2)) { vx = uz; vz = -ux; } else { vx = vz = 0; } }
      s.dvx = vx * 1.55; s.dvz = vz * 1.55; s.retro = 0.3;
    } else { s.dvx = s.dvz = 0; }
  }

  /* ====================================================================================================
     GUARDIA: puestos y ronda. No saben nada.
     ==================================================================================================== */
  function pensarGuardia(s) {
    const e = s.esc;
    s.apObj = false; s.enTiro = false; s.miraFija = false; s.cob = null;
    if (s.sosp >= T.sospechaMira && !red.muerto) { entrarSospecha(e, s, s.estX, s.estZ); return; }
    if (s.rol === 'tirador' && e.nido) {
      ponerEstado(s, 'puesto'); s.luz = false;
      if (!s.elev) { subirAlNido(s); return; }
      s.post = 2; s.miraObj = e.nido.rumbo + Math.sin(ahora * 0.33 + s.escaneo) * 0.45; return;
    }
    if (s.rol === 'asalto' && e.ronda && e.ronda.length) {
      ponerEstado(s, 'ronda'); s.post = 0; s.luz = true;
      if (s.espera > ahora) { s.miraObj = s.rondaYaw + Math.sin((ahora - s.tEsp0) * 1.3) * 1.1; s.miraFija = true; return; }   // parado, alumbrando los autos
      if (s.llego && !s.esperaCamino) {
        if (s.rondaYendo) { s.rondaYendo = false; s.espera = ahora + entre(1.5, 3); s.tEsp0 = ahora; s.rondaYaw = s.miraYaw; s.ri = (s.ri + 1) % e.ronda.length; return; }
        const p = e.ronda[s.ri % e.ronda.length]; irA(s, p.x, p.z, T.velRonda, null); s.rondaYendo = true;
      }
      s.miraObj = null; return;
    }
    ponerEstado(s, 'puesto'); s.post = s.rol === 'tirador' ? 1 : 0; s.luz = false;
    const p = s.puesto;
    if (hyp(p.x - s.x, p.z - s.z) > 0.8) { if (s.llego && !s.esperaCamino) irA(s, p.x, p.z, 2.4, null); s.miraObj = null; return; }
    s.miraObj = p.rumbo + Math.sin(ahora * 0.3 + s.escaneo) * 0.6;
    if (ahora > s.tOcio) { s.tOcio = ahora + entre(25, 50); if (e.estado === 'guardia') decir(s, 'ocioso'); }
  }
  /* el tirador vuelve a su nido: camina hasta el pie del furgón y sube */
  function subirAlNido(s) {
    const n = s.esc.nido, k = libreCerca(n.x, n.z, 5); if (k < 0) return;
    const d = hyp(cX(k) - s.x, cZ(k) - s.z); s.post = 0; s.miraObj = null;
    if (d > 0.7) { if (s.llego && !s.esperaCamino) irA(s, cX(k), cZ(k), 2.4, null); return; }
    parar(s); s.salto = 0; s.sx0 = s.x; s.sz0 = s.z; s.sx1 = n.x; s.sz1 = n.z; s.sDur = 1.6; s.subeA = n.y; s.bajaDe = 0;
  }
  function bajarDelNido(s) {
    if (!s.elev) return;
    const u = red.uc; let k = -1;
    if (u) { const l = hyp(s.x - u.x, s.z - u.z) || 1; k = libreCerca(s.x + (s.x - u.x) / l * 3, s.z + (s.z - u.z) / l * 3, 3); }   // baja del lado contrario al jugador
    if (k < 0) k = libreCerca(s.x, s.z, 5); if (k < 0) return;
    soltarLaser(s, false); s.enTiro = false;
    s.bajaDe = s.elev.y; s.elev = null; s.post = 0; s.tierra = 0; s.agach = 1;
    s.salto = 0; s.sx0 = s.x; s.sz0 = s.z; s.sx1 = cX(k); s.sz1 = cZ(k); s.sDur = T.tDeTierra + 0.5; s.cob = null;
  }

  /* ====================================================================================================
     SOSPECHA: vieron u oyeron algo. Miran, alumbran, uno va a revisar.
     ==================================================================================================== */
  function pensarSospecha(s) {
    const e = s.esc, q = e.sosp; if (!q) { pensarGuardia(s); return; }
    s.apObj = true; s.luz = s.rol !== 'tirador'; s.enTiro = false; s.cob = null; s.miraFija = true;
    if (s.sosp >= T.sospechaMira && ahora - s.estT < 0.3) { q.x = s.estX; q.z = s.estZ; q.t = ahora; }      // sigue viendo algo: actualiza adónde mirar
    if (q.quien === s && !s.elev) {
      ponerEstado(s, 'revisar'); s.post = 0;
      const d = hyp(q.x - s.x, q.z - s.z);
      if (d > 5) {
        if ((s.llego && !s.esperaCamino) || (s.dest && hyp(s.dest.x - q.x, s.dest.z - q.z) > 4 && !s.esperaCamino)) irA(s, q.x, q.z, 2.6, null);
        mirarA(s, q.x, 1.2, q.z); q.llegoT = 0;
      } else {
        parar(s); if (!q.llegoT) q.llegoT = ahora;
        s.miraObj = rumboA(s, q.x, q.z) + Math.sin((ahora - q.llegoT) * 1.6) * 1.2;
      }
    } else {
      ponerEstado(s, 'alerta'); if (s.camino) parar(s);
      s.post = s.rol === 'tirador' ? (s.elev ? 2 : 1) : 0; mirarA(s, q.x, 1.2, q.z);
    }
  }

  /* ====================================================================================================
     COMBATE
     ==================================================================================================== */
  const enMovimiento = s => s.estado === 'a_cubierto' || s.estado === 'avanzar' || s.estado === 'flanquear' || s.estado === 'replegar' || s.estado === 'llegando';
  function pensarCombate(s) {
    const e = s.esc, u = conocido(s);
    s.apObj = true;
    if (s.estado === 'llegando') { pensarLlegando(s, u); return; }                      // refuerzo en camino
    if (!u) {                                                                           // combate sin saber dónde: rodilla en tierra y a mirar hacia el estímulo
      ponerEstado(s, 'alerta'); s.enTiro = false; s.post = s.elev ? 2 : 1; s.miraFija = true;
      if (ahora - s.estT < 10) s.miraObj = rumboA(s, s.estX, s.estZ); return;
    }
    /* mirar: al jugador si lo ve; si no, al último lugar conocido */
    if (s.ve && puntoMira(s, T.miraAtraso, T.miraAdelanto)) mirarA(s, s.miraX, s.miraY, s.miraZ); else mirarA(s, u.x, u.y + 1.1, u.z);
    if (s.estado === 'radio') { pensarRadio(s); return; }
    if (s.orden) tomarOrden(s, u);
    if (s.estado === 'lanzar' || s.estado === 'radio') return;
    if (s.rol === 'tirador') { pensarTirador(s, u); return; }
    s.luz = s.tarea !== 'flanquear';
    /* clavado en descampado, lejos de su cobertura: cuerpo a tierra hasta que afloje */
    if (enMovimiento(s) && s.supr > T.suprEsconde && s.cob && hyp(s.cob.x - s.x, s.cob.z - s.z) > 6 && s.tarea !== 'replegar') {
      ponerEstado(s, 'tierra'); s.pinned = true; parar(s); if (ahora - s.tSuprDijo > 6) { decir(s, 'suprimido'); s.tSuprDijo = ahora; } return;
    }
    switch (s.estado) {
      case 'a_cubierto': case 'avanzar': case 'flanquear': case 'replegar': case 'llegando': enCamino(s, u); break;
      case 'cubierto': enCubierto(s, u); break;
      case 'asomado': enAsomado(s, u); break;
      case 'volver': enVolver(s); break;
      case 'tierra': enTierra(s, u); break;
      default: reaccionar(s); break;
    }
  }
  /* primer momento del combate (o quedó sin cobertura): arma arriba y a buscar dónde cubrirse */
  function reaccionar(s) {
    if (s.rol === 'tirador') s.tarea = 'tirador'; else if (s.tarea === 'guardia' || s.tarea === 'buscar') s.tarea = 'fijar';
    s.miraFija = true;
    if (s.estado !== 'alerta') ponerEstado(s, 'alerta');
    /* lo tiene encima y lo ve: primero devuelve el fuego agachado (un par de segundos), después busca dónde cubrirse */
    if (cercaYVisto(s, T.reaccionCerca) && ahora - s.tEst < 2.5) { s.enTiro = true; s.post = 1; if (s.camino) parar(s); return; }
    s.enTiro = false;
    if (s.camino && !s.cob) parar(s);
    if (!s.esperaCob) pedirCobertura(s);
  }
  /* qué cobertura busca según su tarea y su rol */
  function opcionesCob(s, u) {
    const e = s.esc, dA = hyp(s.x - u.x, s.z - u.z), herido = s.hp < T.vida * T.heridoBajo;
    let ideal = s.rol === 'jefe' ? T.distJefe : s.rol === 'asalto' ? T.distAsalto + 6 : T.distGranadero; if (herido) ideal += 10;
    if (s.tarea === 'replegar') { const r = e.reunion || s.puesto; return { cx: (s.x + r.x) / 2, cz: (s.z + r.z) / 2, radio: 26, dMin: 10, dMax: 120, dIdeal: dA + 14, atras: dA < 45, reunion: r }; }
    if (s.tarea === 'avanzar') { const f = Math.min(1, 12 / (dA || 1)); return { cx: s.x + (u.x - s.x) * f, cz: s.z + (u.z - s.z) * f, radio: 14, dMin: 6, dMax: Math.max(9, dA - 3), dIdeal: Math.max(9, dA - 14) }; }
    if (s.tarea === 'empujar') { const f = Math.min(1, 8 / (dA || 1)); return { cx: u.x + (s.x - u.x) * f, cz: u.z + (s.z - u.z) * f, radio: 11, dMin: 4, dMax: 14, dIdeal: 8, tiro: true, pesoCamino: 0.05 }; }
    return { radio: 22, dMin: s.rol === 'asalto' ? 6 : 9, dMax: 75, dIdeal: ideal };
  }
  function pedirCobertura(s) {
    if (s.esperaCob) return; s.esperaCob = true;
    encolar(s, 'cob', () => {
      s.esperaCob = false; const u = conocido(s); if (!u) return;
      let c = null;
      if (s.rol === 'tirador') c = buscarPuestoTirador(s, u.x, u.z);
      if (!c) {
        const o = opcionesCob(s, u);
        if (s.tarea === 'fijar' || s.tarea === 'tirador') {                              // la base de fuego quiere una cobertura DESDE DONDE TIRAR
          o.tiro = true; c = buscarCobertura(s, u.x, u.z, o);
          if (!c) c = buscarCobertura(s, u.x, u.z, Object.assign({}, o, { cx: (s.x + u.x) / 2, cz: (s.z + u.z) / 2, radio: 24, dIdeal: Math.min(o.dIdeal, 22) }));   // más adelante
          o.tiro = false;
        }
        if (!c) c = buscarCobertura(s, u.x, u.z, o);
      }
      if (!c && s.rol !== 'tirador' && hyp(u.x - s.x, u.z - s.z) > 45) { s.tarea = 'avanzar'; c = buscarCobertura(s, u.x, u.z, opcionesCob(s, u)); }   // muy lejos: se acerca de a saltos
      if (!c && s.tarea !== 'fijar' && s.rol !== 'tirador') { s.tarea = 'fijar'; c = buscarCobertura(s, u.x, u.z, opcionesCob(s, u)); }
      if (!c) {                                                                         // no hay dónde: pelea desde donde está, cuerpo a tierra
        if (s.cob && s.estado === 'cubierto') return;                                   // se queda con la que tenía
        s.cob = null; s.sinCob = ahora; parar(s); ponerEstado(s, 'tierra'); s.pinned = false; if (s.esc.mueve === s) s.esc.mueve = null; return;
      }
      tomarCobertura(s, c);
    });
  }
  function tomarCobertura(s, c) {
    s.cob = c; s.enTiro = false; s.tCob = ahora; s.tSinTiro = 0; s.fallo = false;
    if (hyp(c.x - s.x, c.z - s.z) < 0.5) { ponerEstado(s, 'cubierto'); s.tSal = ahora + entre(0.2, 0.6); if (s.esc.mueve === s) s.esc.mueve = null; return; }
    const sig = s.tarea === 'flanquear';
    ponerEstado(s, sig ? 'flanquear' : s.tarea === 'replegar' ? 'replegar' : (s.tarea === 'avanzar' || s.tarea === 'empujar') ? 'avanzar' : 'a_cubierto');
    s.caminoOp = { expo: s.tarea !== 'empujar', agach: sig, evita: peligros.length ? peligros.map(p => ({ x: p.x, z: p.z, r: p.r + 1, c: 8 })) : null };
    irA(s, c.x, c.z, sig ? T.velAgach : T.velCorrer, s.caminoOp);
    s.post = sig ? 1 : 0;
  }
  function cercaYVisto(s, dmax) {
    if (!s.ve || s.rol === 'tirador') return false;
    const h = s.hist[(s.hI + 9) % 10]; return h.t > -90 && hyp(h.x - s.x, h.z - s.z) < dmax;
  }
  /* corriendo hacia su cobertura */
  function enCamino(s, u) {
    const e = s.esc;
    s.enTiro = false; s.miraFija = false; s.post = s.estado === 'flanquear' ? 1 : 0;
    if (!s.cob) { reaccionar(s); return; }
    /* se le aparece cerca y la cobertura todavía está lejos: frena y le tira (no corre de espaldas a uno que tiene a 12 m) */
    if (s.estado !== 'flanquear' && cercaYVisto(s, T.reaccionCerca * 0.7) && hyp(s.cob.x - s.x, s.cob.z - s.z) > 3) { parar(s); s.cob = null; if (e.mueve === s) e.mueve = null; ponerEstado(s, 'alerta'); reaccionar(s); return; }
    if (s.llego && !s.esperaCamino) {
      const d = hyp(s.cob.x - s.x, s.cob.z - s.z);
      if (d < 0.9) {
        if (e.mueve === s) e.mueve = null;
        if (s.rol === 'tirador') { ponerEstado(s, 'tierra'); s.pinned = false; if (ahora - s.tirDijo > 5) { decir(s, 'tirador_listo'); s.tirDijo = ahora; } return; }
        ponerEstado(s, 'cubierto'); s.tSal = ahora + ((s.tarea === 'flanquear' || s.tarea === 'empujar') ? 0.25 : entre(0.3, 0.9));
        if (e.flanco && e.flanco.s === s && !e.flanco.tLlego) { e.flanco.tLlego = ahora; ENV.evento('flanco_llego', { s, t: ahora - e.flanco.t0 }); }
        return;
      }
      if (s.fallo || (s.sinCamino || 0) > 2) { s.cob = null; s.sinCamino = 0; reaccionar(s); return; }  // no se puede llegar: otra
      irA(s, s.cob.x, s.cob.z, s.vel || T.velCorrer, s.caminoOp);                       // camino parcial: sigue desde donde quedó
      return;
    }
    /* si el lugar conocido se movió y la cobertura a la que va ya no tapa, elige otra sin frenar */
    if (ahora - (s.tReval || 0) > 0.7) {
      s.tReval = ahora;
      if (hyp(u.x - s.cob.ax, u.z - s.cob.az) > 3 && !tapa(s.cob, u.x, u.z) && !s.esperaCob) pedirCobertura(s);
    }
  }
  /* a cubierto: escondido en su casillero. Recarga, decide si cambia de posición, y se asoma cada tanto */
  function enCubierto(s, u) {
    const e = s.esc, c = s.cob; if (!c) { reaccionar(s); return; }
    const A = T[s.arma];
    s.enTiro = false; s.miraFija = true; s.post = c.tipo === 'alta' ? 0 : 1;
    if (hyp(c.x - s.x, c.z - s.z) > 0.4 && s.llego && !s.esperaCamino) irA(s, c.x, c.z, 2.4, null);
    /* ¿me flanqueó? El lugar conocido ya ve mi cobertura: cambio urgente, sin pedir permiso */
    if ((c.tipo !== 'nada' || ahora - s.tCob > 7) && !s.esperaCob && !tapa(c, u.x, u.z)) {
      if (Math.abs(angN(rumboA(s, u.x, u.z) - rumboA(s, c.ax, c.az))) > 0.8) decir(s, 'flanqueado');
      c.tipo = 'nada'; s.tCob = ahora - 4; pedirCobertura(s); return;
    }
    if (s.tarea === 'avanzar' && c.tiro) s.tarea = 'fijar';                                // llegó a donde tiene tiro: base de fuego
    if (s.recT >= 0) { ponerEstado(s, 'recargar'); return; }
    if (s.estado === 'recargar') ponerEstado(s, 'cubierto');
    if (s.balas <= 0 || (s.balas <= A.cargador * 0.34 && !s.ve && ahora - s.tDisparo > 1)) { s.recT = 0; ponerEstado(s, 'recargar'); decir(s, 'recarga'); ENV.evento('recarga', { s }); return; }
    /* herido: se repliega una vez a una cobertura más atrás */
    if (s.hp < T.vida * T.heridoBajo && !s.replegado) {
      s.replegado = true; if (!s.heridoDijo) { s.heridoDijo = true; decir(s, 'herido'); } s.tarea = 'replegar'; if (!s.esperaCob) pedirCobertura(s); return;
    }
    /* cambio de posición no urgente: pide permiso (fuego y movimiento) */
    if (!s.esperaCob && quiereMoverse(s, u, c) && pedirPermiso(s)) { pedirCobertura(s); return; }
    /* «¡ahí está!»: si alguien lo acaba de ver (ya avisado por radio), los que tienen tiro se asoman enseguida */
    if (c.tiro && ahora - red.tVisto < 0.8 && s.tSal > ahora + 0.35 && s.escondeT <= 0 && s.supr < T.suprEsconde && ahora - (s.tVuelve || -99) > 0.6) s.tSal = ahora + entre(0.15, 0.35);
    /* asomarse: es también su manera de mirar */
    if (ahora >= s.tSal && s.escondeT <= 0 && c.tiro) {
      ponerEstado(s, 'asomado'); s.tVentana = entre(T.ventanaMin, T.ventanaMax); s.post = c.tiro.post;
      if (c.tiro.lado !== 0) irA(s, c.tiro.x, c.tiro.z, 2.6, null);
    }
  }
  function quiereMoverse(s, u, c) {
    const e = s.esc; if (e.desorden > ahora) return false;                              // sin jefe: cada uno aguanta donde está
    if (ahora - s.tCob < 4) return false;
    if (s.moverPor) return true;                                                        // se lo ordenaron (avanzar, empujar, fin del flanqueo)
    const dA = hyp(c.x - u.x, c.z - u.z);
    if (!c.tiro) return true;
    if (s.tarea === 'fijar') {
      const ideal = s.rol === 'jefe' ? T.distJefe : s.rol === 'asalto' ? T.distAsalto + 6 : T.distGranadero;
      if (dA > ideal + 20 || dA < (s.rol === 'asalto' ? 4 : 7)) return true;
      if (s.tSinTiro > 4.5) return true;                                                // desde acá no hay tiro al lugar conocido
    }
    return false;
  }
  /* Fuego y movimiento: uno se mueve si otro está tirando (o si hace rato que nadie ve al jugador).
     No se mueven todos a la vez. */
  function pedirPermiso(s) {
    const e = s.esc;
    if (e.mueve && e.mueve !== s) { if (e.mueve.vivo && enMovimiento(e.mueve) && ahora - e.tMueve < 9) return false; e.mueve = null; }
    let cubre = null;
    for (let i = 0; i < e.soldados.length; i++) { const m = e.soldados[i]; if (m !== s && m.vivo && m.activo && ahora - m.tDisparo < 1) { cubre = m; break; } }
    if (!cubre && ahora - red.tVisto < T.moverSinVer) {
      if (!s.pidioT || ahora - s.pidioT > 6) s.pidioT = ahora;
      if (ahora - s.pidioT < 3) {                                                       // pide fuego de cobertura y espera
        for (let i = 0; i < e.soldados.length; i++) { const m = e.soldados[i]; if (m !== s && m.vivo && m.activo && m.estado === 'cubierto' && m.cob && m.cob.tiro && m.balas > 3 && m.rol !== 'tirador') { m.tSal = 0; m.cubreHasta = ahora + 4; break; } }
        return false;
      }
    }
    e.mueve = s; e.tMueve = ahora; s.pidioT = 0; s.moverPor = null;
    if (cubre) { cubre.cubreHasta = ahora + 3.5; if (decir(s, 'muevo')) dialogos.push({ t: ahora + 1.25, e, quien: cubre, clave: 'tecubro', f: null }); }
    return true;
  }
  /* asomado en su puesto de tiro: gatillo() tira; acá se decide cuándo volver */
  function enAsomado(s, u) {
    const c = s.cob; if (!c || !c.tiro) { ponerEstado(s, 'cubierto'); return; }
    const t = c.tiro; s.post = t.post; s.miraFija = true;
    const enLugar = hyp(t.x - s.x, t.z - s.z) < 0.35;
    s.enTiro = enLugar && Math.abs(s.agach - (t.post === 1 ? 1 : 0)) < 0.25;
    if (!enLugar && s.llego && !s.esperaCamino) irA(s, t.x, t.z, 2.6, null);
    if (s.supr > T.suprEsconde) {                                                       // lo tienen clavado: se esconde y pierde la puntería
      s.escondeT = entre(T.suprTMin, T.suprTMax); s.raf = 0; if (ahora - s.tSuprDijo > 6) { decir(s, 'suprimido'); s.tSuprDijo = ahora; }
      volverACubierto(s); return;
    }
    /* ¿desde acá hay tiro al lugar conocido? (para decidir si conviene cambiar de posición) */
    if (s.enTiro && ahora - (s.tChkTiro || 0) > 0.5) {
      s.tChkTiro = ahora; const o = origenLibre(u.x, u.z);
      if (s.ve || lineaVista(s.x, s.y + ojoDe(s), s.z, o.x, 1.1, o.z)) s.tSinTiro = 0; else s.tSinTiro += 0.5;
    }
    if (s.raf > 0) return;                                                              // no corta una ráfaga
    const sigue = s.ve && s.asiento > 0.5 && ahora - s.tEst < s.tVentana * 2;            // lo tiene encarado y bien apuntado: no se esconde todavía
    if (s.balas <= 0 || (ahora - s.tEst > s.tVentana && !sigue)) { volverACubierto(s); return; }
    if (!s.ve && !debeSuprimir(s) && ahora - s.tEst > 0.9) { volverACubierto(s); s.tSal += 0.6; }
  }
  function volverACubierto(s) {
    const c = s.cob; s.enTiro = false; ponerEstado(s, 'volver'); s.tVuelve = ahora;
    if (c) irA(s, c.x, c.z, 2.8, null);
  }
  function enVolver(s) {
    const c = s.cob; if (!c) { reaccionar(s); return; }
    s.enTiro = false; s.miraFija = true; s.post = c.tipo === 'alta' ? 0 : 1;
    if ((s.llego && !s.esperaCamino) || hyp(c.x - s.x, c.z - s.z) < 0.3) { ponerEstado(s, 'cubierto'); s.tSal = ahora + entre(T.cubiertoMin, T.cubiertoMax) + Math.max(0, s.escondeT); }
  }
  /* cuerpo a tierra en descampado: o no hay cobertura, o lo clavaron corriendo */
  function enTierra(s, u) {
    s.post = 2; s.miraFija = true; s.enTiro = true;
    if (s.pinned) {
      if (s.supr < 0.3 && ahora - s.tEst > 0.8) { s.pinned = false; if (s.cob) { ponerEstado(s, 'a_cubierto'); s.post = 0; irA(s, s.cob.x, s.cob.z, T.velCorrer, s.caminoOp); } else reaccionar(s); }
      return;
    }
    if (ahora - (s.sinCob || 0) > 3 && !s.esperaCob) { s.sinCob = ahora; pedirCobertura(s); }
  }
  /* órdenes del cerebro: se toman cuando el soldado está en condiciones */
  function tomarOrden(s, u) {
    const o = s.orden, e = s.esc;
    if (ahora - o.t > 4) { s.orden = null; return; }
    const quieto = s.estado === 'cubierto' || s.estado === 'asomado' || s.estado === 'volver' || s.estado === 'tierra' || s.estado === 'alerta';
    if (o.tipo === 'lanzar') {
      if (!quieto || s.raf > 0 || s.granadas <= 0 || s.recT >= 0) return;
      s.orden = null; parar(s); ponerEstado(s, 'lanzar'); s.enTiro = false; s.post = 0;
      s.lanza = { x: o.x, y: o.y, z: o.z, motivo: o.motivo, salio: false }; s.lanzaT = 0; s.gritoT = ahora;
      mirarA(s, o.x, o.y + 1, o.z); s.miraFija = true;
      decir(s, 'granada'); ENV.evento('granada_aviso', { s, x: o.x, z: o.z, motivo: o.motivo });
    } else if (o.tipo === 'radio') {
      if (s.estado !== 'cubierto' && !(s.estado === 'tierra' && !s.pinned)) return;
      s.orden = null; ponerEstado(s, 'radio'); s.tRadio0 = ahora; s.enTiro = false; s.post = 1;
      e.tRadio = -99; decir(s, 'refuerzo_pide'); s.radioT = T.refuerzoPedir; ENV.evento('refuerzo', { fase: 'pide', s });
    } else if (o.tipo === 'flanquear') {
      if (!quieto || s.raf > 0) return;
      s.orden = null; s.tarea = 'flanquear'; s.cob = o.cob; s.tCob = ahora; s.enTiro = false; s.luz = false; s.post = 1;
      ponerEstado(s, 'flanquear'); s.camino = o.camino; s.ci = 0; s.llego = false; s.esperaCamino = false; s.vel = T.velAgach; s.dest = { x: o.cob.x, z: o.cob.z };
      s.caminoOp = { expo: true, agach: true }; e.mueve = null; s.tMov = ahora;
      decir(s, o.lado > 0 ? 'flanco_der' : 'flanco_izq'); ENV.evento('flanco_sale', { s, lado: o.lado > 0 ? 'der' : 'izq' });
    } else if (o.tipo === 'empujar' || o.tipo === 'avanzar' || o.tipo === 'replegar') {
      if (!quieto || s.raf > 0) return;
      s.orden = null; s.tarea = o.tipo; if (o.tipo === 'replegar') s.replegado = true;
      if (!s.esperaCob) pedirCobertura(s);
    } else s.orden = null;
  }
  /* pidiendo refuerzo: 3 s a cubierto con la mano en la radio. Si lo hieren, se interrumpe (ver herir) */
  function pensarRadio(s) {
    s.enTiro = false; s.post = 1; s.radioT = 1;
    if (ahora - s.tRadio0 >= T.refuerzoPedir) {
      red.refPedido = true; red.refEn = ahora + T.refuerzoLlega; ENV.evento('refuerzo', { fase: 'pedido', s, llega: red.refEn });
      const r = red.refuerzo; if (r) { vozCentral.esc = r; vozCentral.nombre = r.nombre + ' 1'; dialogos.push({ t: ahora + 1.3, e: s.esc, quien: vozCentral, clave: 'refuerzo_va', forzar: true }); }
      ponerEstado(s, s.cob ? 'cubierto' : 'alerta'); s.tSal = ahora + 0.5;
    }
  }
  /* el tirador: en su puesto, cuerpo a tierra. El ciclo del láser está en tickTirador() */
  function pensarTirador(s, u) {
    const e = s.esc; s.luz = false; s.miraFija = true; s.tarea = 'tirador';
    const d = hyp(u.x - s.x, u.z - s.z), fresco = ahora - red.tSenal < 3 && u.err < 4;
    if (s.elev) {
      s.post = 2; s.enTiro = true; ponerEstado(s, 'tierra'); s.pinned = false;
      if (!s.dijoListo) { s.dijoListo = true; if (decir(s, 'tirador_listo')) s.tirDijo = ahora; }
      /* lo flanquearon: el jugador está casi debajo o detrás de su sector. Se levanta (tarda) y se reubica */
      const fuera = Math.abs(angN(rumboA(s, u.x, u.z) - e.nido.rumbo)) > 1.9;
      if (fresco && (d < 9 || (fuera && d < 35))) { decir(s, 'flanqueado'); bajarDelNido(s); ponerEstado(s, 'alerta'); }
      return;
    }
    if (enMovimiento(s)) { enCamino(s, u); return; }
    if (s.estado !== 'tierra') { reaccionar(s); return; }
    const c = s.cob; s.post = c && c.tiro ? c.tiro.post : 2; s.enTiro = true;
    if (s.recT >= 0) return;
    if (s.pinned) { if (s.supr < 0.3) s.pinned = false; return; }
    /* reubicarse: sin puesto, con el jugador encima, o sin línea al lugar conocido hace rato */
    if (ahora - (s.tChkTiro || 0) > 0.5) { s.tChkTiro = ahora; const o = origenLibre(u.x, u.z); if (s.ve || lineaVista(s.x, s.y + ojoDe(s), s.z, o.x, 1.1, o.z)) s.tSinTiro = 0; else s.tSinTiro += 0.5; }
    const mal = !c ? ahora - (s.sinCob || 0) > 3 : ((fresco && d < 10) || s.tSinTiro > 6) && ahora - s.tCob > 5;
    if (mal && !s.esperaCob && s.tir === 'espera') { s.sinCob = ahora; s.tSinTiro = 0; pedirCobertura(s); }
  }

  /* ====================================================================================================
     BÚSQUEDA: perdieron al jugador. Barren el último lugar conocido y las coberturas de alrededor.
     ==================================================================================================== */
  function pensarBusqueda(s) {
    const e = s.esc, q = e.busq;
    s.apObj = true; s.enTiro = false; s.cob = null; s.miraFija = false;
    if (s.rol === 'tirador') {                                                          // el tirador cubre desde su puesto
      ponerEstado(s, 'alerta'); s.luz = false; s.post = (s.elev || s.tierra > 0.5) ? 2 : 1; s.miraFija = true;
      if (red.uc) s.miraObj = rumboA(s, red.uc.x, red.uc.z) + Math.sin(ahora * 0.5 + s.escaneo) * 0.5; return;
    }
    ponerEstado(s, 'buscar'); s.luz = true; s.post = 0;
    if (!q || !q.puntos) { if (s.camino) parar(s); return; }
    if (s.espera > ahora) { s.miraObj = s.rondaYaw + Math.sin((ahora - s.tEsp0) * 2.2) * 1.4; s.miraFija = true; return; }
    if (s.bi >= 0 && s.llego && !s.esperaCamino) { q.puntos[s.bi].visto = true; s.bi = -1; s.espera = ahora + 1.5; s.tEsp0 = ahora; s.rondaYaw = s.miraYaw; return; }
    if (s.bi < 0) {
      let b = -1, bd = 1e9;
      for (let i = 0; i < q.puntos.length; i++) { const p = q.puntos[i]; if (p.visto || p.n >= 2) continue; const d = hyp(p.x - s.x, p.z - s.z) + (p.n ? 6 : 0); if (d < bd) { bd = d; b = i; } }
      if (b < 0) { q.listo = true; if (s.camino) parar(s); s.miraObj = red.uc ? rumboA(s, red.uc.x, red.uc.z) + Math.sin(ahora + s.escaneo) : s.miraObj; return; }
      const p = q.puntos[b]; s.bi = b; p.n++;
      let x = p.x, z = p.z;
      if (p.n > 1) { const l = hyp(s.x - x, s.z - z) || 1, k = libreCerca(x + (s.x - x) / l * 3.5, z + (s.z - z) / l * 3.5, 2); if (k >= 0) { x = cX(k); z = cZ(k); } }   // el segundo se queda 3,5 m atrás, cubriendo
      irA(s, x, z, T.velAgach, null); s.miraObj = null;
    }
  }


  /* ====================================================================================================
     ESTADOS DEL ESCUADRÓN: guardia → sospecha → combate → búsqueda → guardia (más alertas)
     ==================================================================================================== */
  function jefeDe(e) {                                                                  // quién manda: el jefe; si cayó, granadero, asalto, tirador
    if (e.jefe && e.jefe.vivo) return e.jefe;
    const orden = ['jefe', 'granadero', 'asalto', 'tirador'];
    for (let r = 0; r < orden.length; r++) for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.rol === orden[r]) return s; }
    for (let i = 0; i < e.soldados.length; i++) if (e.soldados[i].vivo && e.soldados[i].activo) return e.soldados[i];
    return null;
  }
  function senal(s, tipo) { if (s && s.vivo) { s.senalT = 0; s.senalTipo = tipo; } }
  function elegirRevisor(e, x, z) {
    let mejor = null, md = 1e9;
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.activo || s.rol === 'tirador' || s.rol === 'jefe') continue;
      const d = hyp(s.x - x, s.z - z) - (s.rol === 'asalto' ? 15 : 0); if (d < md) { md = d; mejor = s; }
    }
    return mejor;
  }
  function entrarSospecha(e, s, x, z) {
    if (!e.activo || red.muerto || e.estado === 'combate') return;
    if (e.estado === 'busqueda') { if (e.busq && hyp(x - e.busq.x, z - e.busq.z) > 6) e.busq.mover = { x, z }; return; }   // corre el centro del barrido
    if (!e.sosp) {
      e.sosp = { x, z, t: ahora, t0: ahora, quien: elegirRevisor(e, x, z), llegoT: 0 };
      e.estado = 'sospecha'; e.tEst = ahora;
      if (s) decir(s, 'sospecha'); ENV.evento('sospecha', { s, x, z });
    } else { e.sosp.x = x; e.sosp.z = z; e.sosp.t = ahora; }
  }
  function entrarCombate(e, quien) {
    if (!e.activo || red.muerto || e.estado === 'combate') return;
    const antes = e.estado;
    let otro = false; for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i] !== e && escuadrones[i].activo && escuadrones[i].estado === 'combate') otro = true;
    if (!otro) red.tContacto = ahora;
    e.estado = 'combate'; e.tEst = ahora; e.fase = 0; e.sosp = null; e.busq = null; e.fijarDicho = false; e.replegados = false;
    if (e.tFlanco < ahora - T.flancoCada) e.tFlanco = ahora - T.flancoCada + 6;     // el primer flanqueo, no antes de 6 s de combate
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.activo) continue;
      if (s.alerta < 2) s.alerta = 2;
      if (!s.ve || s.tConoce < -90) s.tConoce = ahora;                                 // el reloj de reacción corre desde que se entera (por radio: ahora)
      s.tarea = s.rol === 'tirador' ? 'tirador' : 'fijar'; s.espera = 0; s.bi = -1; s.orden = null; s.rondaYendo = false;
      if (antes === 'guardia' || antes === 'sospecha') s.avisoHecho = false;           // contacto nuevo (no la vuelta de una búsqueda): la primera ráfaga avisa
      if (s.estado === 'ronda' || s.estado === 'puesto' || s.estado === 'revisar' || s.estado === 'buscar' || s.estado === 'alerta') { ponerEstado(s, 'alerta'); if (!s.elev && s.salto < 0) parar(s); }
    }
    e.orden = 'combate'; ENV.evento('combate', { esc: e, antes, s: quien });
  }
  function volverAGuardia(e, alertado, motivo) {
    e.estado = 'guardia'; e.tEst = ahora; e.sosp = null; e.busq = null; e.fase = 0; e.flanco = null; e.mueve = null; e.prioBichos = false;
    e.replegados = false; e.radioQuien = null; e.orden = '';
    if (alertado) e.alertado = true;
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.activo) continue;
      s.alerta = 0; s.sosp = 0; s.tarea = 'guardia'; s.orden = null; s.cob = null; s.enTiro = false; s.raf = 0; s.ficha = false;
      s.avisoHecho = false; s.tConoce = -99; s.veDesde = -99; s.bi = -1; s.espera = 0; s.pinned = false; s.cubreHasta = 0; s.ve = false;
      if (s.lanzaT >= 0 && s.lanza && !s.lanza.salio) { s.lanzaT = -1; s.lanza = null; }
      if (s.rol === 'tirador') soltarLaser(s, false);
      ponerEstado(s, 'puesto'); if (!s.elev && s.salto < 0) parar(s);
      for (let q = 0; q < 10; q++) s.hist[q].t = -99;                                   // olvida lo que vio
    }
    for (let i = red.fichas.length - 1; i >= 0; i--) if (red.fichas[i].esc === e) { red.fichas[i].ficha = false; red.fichas.splice(i, 1); }
    let alguno = false; for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo && escuadrones[i].estado !== 'guardia') alguno = true;
    if (!alguno) { red.uc = null; red.tVisto = -99; red.tSenal = -99; red.ancla = null; red.tContacto = -99; red.tirador = null; red.fichas.length = 0; xOk = false; partes.length = 0; }
    ENV.evento(motivo || (alertado ? 'limpio' : 'guardia'), { esc: e });
  }
  function empezarBusqueda(e) {
    const u = red.uc; if (!u) { volverAGuardia(e, true, 'nada'); return; }
    e.estado = 'busqueda'; e.tEst = ahora; e.fase = 3; e.flanco = null; e.mueve = null; e.orden = 'barrido';
    e.busq = { x: u.x, z: u.z, t0: ahora, puntos: null, listo: false, mover: null };
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.activo) continue;
      s.alerta = 1; s.tarea = 'buscar'; s.orden = null; s.bi = -1; s.espera = 0; s.cob = null; s.enTiro = false; s.raf = 0; s.pinned = false;
      if (s.ficha) { s.ficha = false; const k = red.fichas.indexOf(s); if (k >= 0) red.fichas.splice(k, 1); }
      if (s.rol === 'tirador') soltarLaser(s, false);
    }
    decir(jefeDe(e), 'busqueda'); ENV.evento('busqueda', { esc: e, x: u.x, z: u.z });
    planearBarrido(e);
  }
  /* puntos del barrido: el último lugar conocido y las coberturas de alrededor que no se ven desde donde están */
  function planearBarrido(e) {
    const b = e.busq, pts = [{ x: b.x, z: b.z, visto: false, n: 0 }];
    const i0 = Math.floor(b.x - EX0), j0 = Math.floor(b.z - EZ0), R = 12, cand = [];
    for (let dj = -R; dj <= R; dj += 2) for (let di = -R; di <= R; di += 2) {
      const i = i0 + di, j = j0 + dj; if (i < 1 || j < 1 || i >= EW - 1 || j >= EH - 1) continue;
      const k = j * EW + i; if (B[k] !== 0 || vecinoAlto(k) < 1) continue;
      const x = cX(k), z = cZ(k), d = hyp(x - b.x, z - b.z); if (d > R || d < 3) continue;
      let visto = false;
      for (let q = 0; q < e.soldados.length && !visto; q++) { const s = e.soldados[q]; if (s.vivo && s.activo && lineaVista(s.x, s.y + ojoDe(s), s.z, x, 0.9, z, s.elev)) visto = true; }
      if (!visto) cand.push({ x, z, d });
    }
    cand.sort((a, c) => a.d - c.d);
    for (let i = 0; i < cand.length && pts.length < 7; i++) { const c = cand[i]; let cerca = false; for (let q = 0; q < pts.length; q++) if (hyp(pts[q].x - c.x, pts[q].z - c.z) < 4) cerca = true; if (!cerca) pts.push({ x: c.x, z: c.z, visto: false, n: 0 }); }
    b.puntos = pts;
  }

  /* ====================================================================================================
     HERIDAS Y BAJAS
     ==================================================================================================== */
  function herir(s, dano, dir, parte, de, bicho) {
    if (!s || !s.vivo || !s.activo || !(dano > 0)) return;
    const m = parte === 'cabeza' ? T.multCabeza : parte === 'torso' ? T.multTorso : (parte === 'brazo' || parte === 'pierna' || parte === 'miembro') ? T.multMiembro : 1;
    const d = dano * m; s.hp -= d; s.herT = ahora;
    if (dir) { const dx = dir.x || 0, dz = dir.z || 0; if (dx || dz) s.herDir = Math.atan2(dx, dz); }
    ENV.evento('herido', { s, dano: d, parte, de });
    if (s.hp <= 0) { morir(s, de, parte); return; }
    s.asiento = 0; s.supr = Math.min(1, s.supr + 0.4);
    if (d >= T.aturdeDano && s.salto < 0 && !s.elev) { s.aturdido = T.aturdeT; s.raf = 0; if (s.estado !== 'lanzar' && s.estado !== 'radio') ponerEstado(s, 'aturdido'); }
    if (s.estado === 'radio') { ponerEstado(s, s.cob ? 'cubierto' : 'alerta'); s.radioT = 0; ENV.evento('refuerzo', { fase: 'interrumpido', s }); }
    if (s.lanzaT >= 0 && s.lanza && !s.lanza.salio && d >= 10) { s.lanzaT = -1; s.lanza = null; if (s.estado === 'lanzar') ponerEstado(s, s.cob ? 'volver' : 'alerta'); }
    if (s.rol === 'tirador' && s.tir !== 'espera') soltarLaser(s, true);
    if (de === 'jugador' || de === 'granada') {
      /* sabe que le tiran y de qué lado (no a qué distancia): mira hacia allá y el escuadrón entra en combate */
      if (s.herDir !== undefined && dir) { const a = s.herDir + PI; s.estX = s.x + Math.sin(a) * 15; s.estZ = s.z + Math.cos(a) * 15; s.estT = ahora; }
      if (s.alerta < 2) { s.alerta = 2; if (s.tConoce < -90) s.tConoce = ahora; }
      if (s.esc.estado !== 'combate') entrarCombate(s.esc, null);
    } else if (de === 'bicho' && bicho) {
      if (!s.bicho) s.bicho = { ref: null, x: 0, y: 0, z: 0, r: 0.5, d: 0 };
      const o = s.bicho; o.ref = bicho.ref || bicho; o.x = bicho.x; o.y = bicho.y || 0; o.z = bicho.z; o.r = bicho.r || 0.5; o.d = hyp(bicho.x - s.x, bicho.z - s.z); s.bichoT = ahora;
      if (s.alerta < 1) s.alerta = 1;
    }
  }
  function morir(s, de, parte) {
    const e = s.esc;
    s.vivo = false; s.hp = 0; ponerEstado(s, 'muerto'); s.tMuerte = ahora; s.raf = 0; s.enTiro = false; s.laser = null; s.camino = null; s.esperaCamino = false;
    s.vx = s.vz = s.dvx = s.dvz = 0; s.luz = false; s.orden = null; s.lanzaT = -1; s.lanza = null; s.culT = -1; s.radioT = 0; s.cob = null; s.ve = false;
    if (s.ficha) { s.ficha = false; const i = red.fichas.indexOf(s); if (i >= 0) red.fichas.splice(i, 1); }
    if (red.tirador === s) red.tirador = null;
    if (e.mueve === s) e.mueve = null;
    if (e.flanco && e.flanco.s === s) { e.flanco = null; e.tFlanco = ahora; }
    const tipo = (de === 'granada' || de === 'auto') ? 'derrumbe' : s.tierra > 0.5 ? 'tierra' : parte === 'cabeza' ? 'atras' : (azar() < 0.5 ? 'adelante' : 'derrumbe');
    s.muerte = { tipo, t: 0, dir: s.herDir || 0 };
    ENV.evento('baja', { s, de, parte });
    let otro = null, od = 1e9;
    for (let i = 0; i < e.soldados.length; i++) { const o = e.soldados[i]; if (!o.vivo || !o.activo) continue; const d = hyp(o.x - s.x, o.z - s.z); if (d < od) { od = d; otro = o; } }
    if (otro) dialogos.push({ t: ahora + 0.7, e, quien: otro, clave: 'baja', n: s.num });
    if (e.jefe === s) {
      e.jefe = jefeDe(e); e.desorden = ahora + T.jefeCaidoT; e.orden = 'desorden';
      ENV.evento('jefe_caido', { s, nuevo: e.jefe, hasta: e.desorden });
      if (e.jefe) dialogos.push({ t: ahora + 1.7, e, quien: e.jefe, clave: 'jefe_caido' });
      for (let i = 0; i < e.soldados.length; i++) { const o = e.soldados[i]; if (o.vivo && o.orden && o.orden.tipo !== 'lanzar') o.orden = null; }
      if (e.flanco) { e.flanco.s.tarea = 'fijar'; e.flanco = null; }
    }
    /* los compañeros que lo ven caer se dan cuenta aunque no sepan de dónde vino */
    if (e.estado !== 'combate' && !red.muerto && otro && od < 30 && lineaVista(otro.x, otro.y + ojoDe(otro), otro.z, s.x, 0.8, s.z)) entrarCombate(e, null);
  }

  /* ====================================================================================================
     EL CEREBRO DEL ESCUADRÓN (cada T.tCerebro s): pérdida de contacto, roles y órdenes, granada,
     flanqueo, empuje, repliegue, refuerzo, prioridad de bichos. Lo que «sabe» es red.uc, nunca el jugador.
     ==================================================================================================== */
  function cerebro(e) {
    let vivos = 0; for (let i = 0; i < e.soldados.length; i++) if (e.soldados[i].vivo && e.soldados[i].activo) vivos++;
    e.vivos = vivos; if (!vivos) { e.orden = 'sin gente'; return; }
    if (!e.jefe || !e.jefe.vivo) e.jefe = jefeDe(e);
    if (e.estado === 'sospecha') cerebroSospecha(e);
    else if (e.estado === 'combate') cerebroCombate(e, vivos);
    else if (e.estado === 'busqueda') cerebroBusqueda(e);
  }
  function cerebroSospecha(e) {
    const q = e.sosp; if (!q) { e.estado = 'guardia'; return; }
    if (!q.quien || !q.quien.vivo) q.quien = elegirRevisor(e, q.x, q.z);
    const sinNada = ahora - q.t, revisado = q.llegoT && ahora - q.llegoT > 4;
    if ((sinNada > 6 && (revisado || !q.quien)) || sinNada > 14 || ahora - q.t0 > 30) {
      decir(q.quien || jefeDe(e), 'nada'); volverAGuardia(e, true, 'nada');
    }
  }
  function cerebroBusqueda(e) {
    const b = e.busq; if (!b) { volverAGuardia(e, true); return; }
    if (b.mover) { b.x = b.mover.x; b.z = b.mover.z; b.mover = null; b.listo = false; planearBarrido(e); for (let i = 0; i < e.soldados.length; i++) e.soldados[i].bi = -1; }
    if (ahora - b.t0 > T.barridoT || (b.listo && ahora - b.t0 > 10)) { decir(jefeDe(e), 'limpio'); volverAGuardia(e, true, 'limpio'); }
  }
  function quienHabla(e) {
    let m = null, mt = -1e9;
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.tVisto > mt) { mt = s.tVisto; m = s; } }
    return m || jefeDe(e);
  }
  const quietoParaOrden = s => s.estado === 'cubierto' || s.estado === 'asomado' || s.estado === 'volver' || s.estado === 'alerta' || s.estado === 'recargar' || (s.estado === 'tierra' && !s.pinned);
  function cerebroCombate(e, vivos) {
    const u = red.uc, jefe = jefeDe(e);
    e.prioBichos = bichosCerca(e) >= 3;
    if (!u) { e.orden = 'sin lugar conocido'; return; }
    let sinSenal = ahora - red.tSenal;
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.ve) sinSenal = 0; }   // uno lo está viendo (y está por avisar): no está perdido
    /* 1. pérdida de contacto (SPEC 5): 2,5 s «lo perdí» y fuego al lugar viejo · 7 s granada o avance · 12 s barrido */
    if (sinSenal < T.perdidoT) e.fase = 0;
    else {
      if (e.fase < 1) { e.fase = 1; if (ahora - (e.tPerdido || -99) > 8) { decir(quienHabla(e), 'perdido'); e.tPerdido = ahora; } ENV.evento('perdido', { esc: e, x: u.x, z: u.z }); e.orden = 'perdido: fuego al lugar viejo'; }
      if (sinSenal >= T.perdidoAccion && e.fase < 2 && e.desorden <= ahora) { e.fase = 2; if (!ordenarGranada(e, u, 'perdido')) ordenarAvance(e, u); }
      if (sinSenal >= T.perdidoBarrido && e.fase < 3) { empezarBusqueda(e); return; }
    }
    if (e.desorden > ahora) { e.orden = 'desorden'; return; }                              // sin jefe: nadie da órdenes nuevas
    /* 2. refuerzo */
    pedirRefuerzo(e, vivos, jefe);
    /* 3. quedan pocos: se repliegan hacia la reunión y aguantan */
    if (vivos <= T.refuerzoVivos && !e.replegados) {
      e.replegados = true; e.orden = 'repliegue'; senal(jefe, 'alto');
      for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.rol !== 'tirador' && s.estado !== 'radio' && !(s.orden && s.orden.tipo === 'radio')) s.orden = { tipo: 'replegar', t: ahora }; }
    }
    /* 4. granada: lo tienen ubicado y no se mueve (quieto o escondido) */
    if (e.fase <= 1 && red.ancla && ahora - red.ancla.t0 >= T.granada.quieto) ordenarGranada(e, u, 'quieto');   // quieto o escondido 3,5 s en el mismo lugar (aunque ya no lo vean)
    ordenarGranadaBichos(e);
    /* 5. flanqueo */
    seguirFlanco(e);
    if (!e.flanco && !e.replegados && vivos >= T.flancoMinVivos && ahora - e.tFlanco >= T.flancoCada && sinSenal < 3 && u.err <= 4) planearFlanco(e, u);
    /* 6. el jugador recarga: el asalto empuja */
    if (red.recJug > ahora - 0.9 && ahora - e.tEmpuje > 10 && !e.replegados) ordenarEmpuje(e, u);
    if (!e.flanco && e.orden !== 'granada') e.orden = e.replegados ? 'repliegue' : 'base de fuego';
  }
  function bichosCerca(e) {
    if (!bichos.length) return 0;
    let n = 0;
    for (let i = 0; i < bichos.length; i++) {
      const b = bichos[i];
      for (let q = 0; q < e.soldados.length; q++) { const s = e.soldados[q]; if (s.vivo && s.activo && hyp(b.x - s.x, b.z - s.z) < 16) { n++; break; } }
    }
    return n;
  }
  /* granada al último lugar conocido. Devuelve true si la ordenó. */
  function ordenarGranada(e, u, motivo) {
    const G = T.granada;
    if (ahora - red.tGranada < G.cada || red.muerto || u.err > 3) return false;
    for (let i = 0; i < soldados.length; i++) { const o = soldados[i]; if (o.vivo && o.activo && hyp(o.x - u.x, o.z - u.z) < G.amigos) return false; }
    return ordenarLanzar(e, u.x, u.y, u.z, motivo);
  }
  function ordenarLanzar(e, x, y, z, motivo) {
    const G = T.granada; let mejor = null, mp = -1e9, obj = null;
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i];
      if (!s.vivo || !s.activo || s.granadas <= 0 || s.elev || s.orden || s.lanzaT >= 0 || !quietoParaOrden(s)) continue;
      if (e.flanco && e.flanco.s === s && !e.flanco.tLlego) continue;
      const d = hyp(s.x - x, s.z - z); if (d < G.distMin || d > G.distMax) continue;
      const p = (s.rol === 'granadero' ? 10 : s.rol === 'tirador' ? -5 : 0) - Math.abs(d - 18) * 0.1;
      if (p <= mp) continue;
      const o = puntoDeCaida(s, x, y, z); if (!o) continue;
      mp = p; mejor = s; obj = o;
    }
    if (!mejor) return false;
    x = obj.x; z = obj.z;
    mejor.orden = { tipo: 'lanzar', t: ahora, x, y, z, motivo };
    red.tGranada = ahora; e.orden = 'granada (' + motivo + ')';
    ENV.evento('granada_orden', { s: mejor, x, z, motivo });
    return true;
  }
  /* Dónde hacerla caer: en el lugar conocido si hay arco libre; si no (está pegado a un auto), hasta 1,8 m más allá,
     del lado de atrás de su cobertura vista desde el que la tira. Devuelve {x,z} o null. */
  const _desvio = [0, 0, 0.7, -0.7, 1.4, -1.4], _radio = [0, 1.2, 1.3, 1.3, 1.8, 1.8];
  function puntoDeCaida(s, x, y, z) {
    const base = Math.atan2(x - s.x, z - s.z);
    for (let q = 0; q < _desvio.length; q++) {
      const a = base + _desvio[q], tx = x + Math.sin(a) * _radio[q], tz = z + Math.cos(a) * _radio[q];
      if (q && !libreEn(tx, tz)) continue;
      if (ENV.arco(s.x, s.y + 1.75, s.z, tx, y, tz)) return { x: tx, z: tz };
    }
    return null;
  }
  function ordenarGranadaBichos(e) {
    const G = T.granada; if (bichos.length < G.bichos || ahora - red.tGranada < G.cada) return;
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.bicho || ahora - s.bichoT > 0.5) continue;
      const c = s.bicho; let n = 0, cx = 0, cz = 0;
      for (let q = 0; q < bichos.length; q++) { const b = bichos[q]; if (hyp(b.x - c.x, b.z - c.z) < G.bichosRadio) { n++; cx += b.x; cz += b.z; } }
      if (n < G.bichos) continue;
      cx /= n; cz /= n;
      let amigo = false; for (let q = 0; q < soldados.length; q++) { const o = soldados[q]; if (o.vivo && o.activo && hyp(o.x - cx, o.z - cz) < G.amigos) amigo = true; }
      if (amigo) continue;
      if (ordenarLanzar(e, cx, 0, cz, 'bichos')) return;
    }
  }
  /* sin señal hace rato y sin granada: uno o dos avanzan a una cobertura más cerca; los demás cubren */
  function ordenarAvance(e, u) {
    if (e.replegados || (e.vivos || 0) < 3) return;                                      // pocos: nadie va solo a buscarlo
    const c = [];
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.rol !== 'tirador' && !s.orden && quietoParaOrden(s)) c.push(s); }
    if (!c.length) return;
    c.sort((a, b) => hyp(a.x - u.x, a.z - u.z) - hyp(b.x - u.x, b.z - u.z));
    const n = c.length >= 3 ? 2 : 1;
    for (let i = 0; i < n; i++) c[i].orden = { tipo: 'avanzar', t: ahora };
    for (let i = n; i < c.length; i++) c[i].cubreHasta = ahora + 5;
    senal(jefeDe(e), 'avanzar'); e.orden = 'avance sobre el lugar viejo'; ENV.evento('avance', { esc: e, n });
  }
  function ordenarEmpuje(e, u) {
    let a = null;
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.rol === 'asalto' && !s.orden && s.hp >= T.vida * T.heridoBajo && quietoParaOrden(s)) { a = s; break; } }
    if (!a || (e.flanco && e.flanco.s === a && !e.flanco.tLlego)) return;
    const d = hyp(a.x - u.x, a.z - u.z); if (d > 28 || d < 6) return;
    e.tEmpuje = ahora; a.orden = { tipo: 'empujar', t: ahora };
    decir(a, 'recarga_jugador'); e.orden = 'empuje'; ENV.evento('empuje', { s: a });
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s !== a && s.vivo && s.activo && s.rol !== 'tirador') s.cubreHasta = ahora + 4; }
  }
  /* ---------- flanqueo: el asalto (o el granadero si no hay asalto) rodea por el lado con el camino más tapado ---------- */
  function planearFlanco(e, u) {
    let f = null;
    for (let r = 0; r < 2 && !f; r++) for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i];
      if (s.vivo && s.activo && s.rol === (r ? 'granadero' : 'asalto') && !s.orden && s.hp >= T.vida * T.heridoBajo && s.recT < 0 && (s.estado === 'cubierto' || s.estado === 'asomado' || s.estado === 'volver')) { f = s; break; }
    }
    if (!f) return;
    let bx = 0, bz = 0, n = 0;
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s !== f && s.vivo && s.activo && s.rol !== 'tirador') { bx += s.x; bz += s.z; n++; } }
    if (n) { bx /= n; bz /= n; } else { bx = f.x; bz = f.z; }
    e.tFlanco = ahora;
    const plan = { f, ux: u.x, uz: u.z, bx, bz, lados: [] };
    encolar(f, 'flanco1', () => ladoFlanco(plan, -1));
    encolar(f, 'flanco2', () => { ladoFlanco(plan, 1); decidirFlanco(e, plan); });
  }
  function ladoFlanco(plan, lado) {
    const f = plan.f; if (!f.vivo) return;
    const dA = hyp(plan.bx - plan.ux, plan.bz - plan.uz) || 1, bux = (plan.bx - plan.ux) / dA, buz = (plan.bz - plan.uz) / dA;
    const fi = -lado * 1.75, vx = bux * Math.cos(fi) - buz * Math.sin(fi), vz = bux * Math.sin(fi) + buz * Math.cos(fi);
    const cx = plan.ux + vx * T.flancoDist, cz = plan.uz + vz * T.flancoDist;
    const cob = buscarCobertura(f, plan.ux, plan.uz, { cx, cz, radio: 13, dMin: 6, dMax: 24, dIdeal: T.flancoDist, angMin: 1.05, bx: plan.bx, bz: plan.bz, lado, tiro: true, pesoCamino: 0.03 });
    if (!cob || hyp(cob.x - f.x, cob.z - f.z) < 5) return;                               // si ya está ahí, no es un flanqueo
    const cam = aEstrella(f.x, f.z, cob.x, cob.z, { expo: true, agach: true });
    if (!cam || cam.parcial) return;
    plan.lados.push({ lado, cob, camino: cam, costo: cam.costo + cam.expuestos * 2 });
  }
  function decidirFlanco(e, plan) {
    const f = plan.f; if (!f.vivo || f.orden || e.flanco || e.desorden > ahora) return;
    let m = null; for (let i = 0; i < plan.lados.length; i++) if (!m || plan.lados[i].costo < m.costo) m = plan.lados[i];
    if (!m || m.costo > 110) { e.tFlanco = ahora - T.flancoCada + 5; ENV.evento('flanco_no', { s: f }); return; }
    f.orden = { tipo: 'flanquear', t: ahora, cob: m.cob, camino: m.camino, lado: m.lado };
    e.flanco = { s: f, t0: ahora, lado: m.lado, tLlego: 0, cob: m.cob }; e.orden = 'flanqueo ' + (m.lado > 0 ? 'der' : 'izq');
    const j = jefeDe(e); if (j && j !== f) { decir(j, 'orden_flanco', f.num); senal(j, m.lado > 0 ? 'der' : 'izq'); }
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s !== f && s.vivo && s.activo && s.rol !== 'tirador') s.cubreHasta = ahora + 6; }
    ENV.evento('flanco', { s: f, lado: m.lado > 0 ? 'der' : 'izq', costo: m.costo, x: m.cob.x, z: m.cob.z });
  }
  function seguirFlanco(e) {
    const F = e.flanco; if (!F) return;
    const f = F.s;
    if (!f.vivo || (f.tarea !== 'flanquear' && !(f.orden && f.orden.tipo === 'flanquear'))) { e.flanco = null; return; }
    if (!F.tLlego && ahora - F.t0 > 30) { e.flanco = null; f.tarea = 'fijar'; ENV.evento('flanco_fin', { s: f, llego: false }); return; }
    if (F.tLlego && ahora - F.tLlego > 10) { e.flanco = null; f.tarea = 'fijar'; ENV.evento('flanco_fin', { s: f, llego: true }); }
  }
  /* refuerzo: lo pide el jefe (o el que quede) desde una cobertura, 3 s con la radio. Una sola vez. */
  function pedirRefuerzo(e, vivos, jefe) {
    if (!red.refuerzo || red.refPedido || e.esRefuerzo) return;
    if (!(vivos <= T.refuerzoVivos || ahora - red.tContacto >= T.refuerzoCombate)) return;
    const q = e.radioQuien;
    if (q && q.vivo && (q.estado === 'radio' || (q.orden && q.orden.tipo === 'radio'))) return;
    let s = jefe;
    if (!s || s.elev || s.orden) { s = null; for (let i = 0; i < e.soldados.length; i++) { const o = e.soldados[i]; if (o.vivo && o.activo && !o.elev && !o.orden && o.rol !== 'tirador') { s = o; break; } } }
    if (!s) return;
    s.orden = { tipo: 'radio', t: ahora }; e.radioQuien = s;
  }
  /* el escuadrón de refuerzo entra por `sale` y viene por `camino`, ya en combate y sabiendo lo que sabe la red */
  const vozCentral = { id: -1, num: 1, nombre: 'Tizón 1', rol: 'jefe', voz: 7, vivo: true, activo: true, x: 0, y: 0, z: 0, esc: null, virtual: true };
  function llegadaRefuerzo() {
    const r = red.refuerzo;
    if (!r || !red.refPedido || red.refLlego || ahora < red.refEn) return;
    red.refLlego = true; r.activo = true; poblar(r);
    if (red.muerto) { volverAGuardia(r, true); return; }
    entrarCombate(r, null);
    if (red.tSenal < -90) { red.tSenal = ahora; }
    for (let i = 0; i < r.soldados.length; i++) { const s = r.soldados[i]; s.wi = 0; ponerEstado(s, 'llegando'); s.tarea = 'fijar'; }
    r.orden = 'llegando'; ENV.evento('refuerzo', { fase: 'entra', esc: r });
  }
  function pensarLlegando(s, u) {
    const e = s.esc, cam = e.camino || [];
    s.enTiro = false; s.post = 0; s.luz = true; s.miraFija = false; s.apObj = true;
    const fin = cam.length ? cam[cam.length - 1] : (e.reunion || s.puesto);
    const llego = s.wi >= cam.length || (s.llego && !s.esperaCamino && s.wi >= cam.length - 1 && hyp(fin.x - s.x, fin.z - s.z) < 3);
    if (s.ve || (u && hyp(u.x - s.x, u.z - s.z) < 38) || llego) {
      if (!e.llegoDicho) { e.llegoDicho = true; decir(s, 'refuerzo_llega'); ENV.evento('refuerzo', { fase: 'llega', esc: e, s }); }
      s.puesto = { x: s.x, z: s.z, rumbo: s.miraYaw };
      ponerEstado(s, 'alerta'); reaccionar(s); return;
    }
    if (s.llego && !s.esperaCamino) {
      if (s.dest && hyp(s.dest.x - s.x, s.dest.z - s.z) < 2.5) s.wi++;
      if (s.wi < cam.length) { const p = cam[s.wi], o = (s.num - 2.5) * 1.3; irA(s, p.x + o * 0.3, p.z + o, T.velCorrer, { expo: true }); }
    }
  }

  /* ====================================================================================================
     OÍDO Y SUPRESIÓN (los llama el juego)
     ==================================================================================================== */
  function ruido(pos, tipo, fuerza) {
    if (!pos || red.muerto) return;
    fuerza = fuerza || 1;
    const alc = (tipo === 'disparo' ? T.oidoDisparo : tipo === 'pasos' ? T.oidoPasos : tipo === 'impacto' ? T.oidoImpacto : tipo === 'explosion' ? T.oidoExplosion : 20) * fuerza;
    const delJugador = tipo === 'disparo' || tipo === 'pasos' || tipo === 'jugador';
    const px = pos.x, pz = pos.z, py = pos.y || 0;
    let mejor = null, me = 1e9;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      const d = hyp(px - s.x, pz - s.z); if (d > alc) continue;
      const err = tipo === 'impacto' ? 1 : 1 + d * 0.06;                              // de lejos se lo ubica peor
      s.estX = px + campana() * err; s.estZ = pz + campana() * err; s.estT = ahora;
      if (nivelDe(s) < 2) s.sosp = Math.max(s.sosp, (tipo === 'disparo' || tipo === 'explosion') ? 0.9 : 0.55);
      if (err < me) { me = err; mejor = s; }
    }
    if (!mejor) return;
    if (!delJugador) {                                                                  // explosión, impacto: se alarman y miran, pero eso no dice dónde está el testigo
      for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo && escuadrones[i].estado === 'guardia') entrarSospecha(escuadrones[i], mejor, mejor.estX, mejor.estZ);
      return;
    }
    if (ahora - red.tRuido < 0.3 && hyp(px - red.ruX, pz - red.ruZ) < 2) return;       // la misma ráfaga: no hace falta avisar cada tiro
    red.tRuido = ahora; red.ruX = px; red.ruZ = pz;
    partes.push({ t: ahora + T.aviso, t0: ahora, s: mejor, x: mejor.estX, y: py, z: mejor.estZ, err: me, fuerte: tipo === 'disparo' });
  }
  function balaCerca(o, d, t) {
    if (!o || !d) return;
    const ox = o.x, oy = o.y, oz = o.z, dx = d.x, dy = d.y, dz = d.z, L = t > 0 && t < 400 ? t : 400;
    const ex = ox + dx * L, ez = oz + dz * L;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      const cx = s.x - ox, cy = s.y + ojoDe(s) - 0.35 - oy, cz = s.z - oz;
      let u = cx * dx + cy * dy + cz * dz; if (u < 0) continue; if (u > L) u = L;
      const qx = cx - dx * u, qy = cy - dy * u, qz = cz - dz * u, dist = Math.sqrt(qx * qx + qy * qy + qz * qz);
      const cerca = dist < T.suprCerca, impacto = hyp(ex - s.x, ez - s.z) < T.oidoImpacto;
      if (!cerca && !impacto) continue;
      if (cerca) { s.supr = Math.min(1, s.supr + T.suprSuma); s.asiento *= 0.6; }
      if (nivelDe(s) < 2) { s.sosp = Math.max(s.sosp, 0.7); s.estX = ox + campana() * 4; s.estZ = oz + campana() * 4; s.estT = ahora; }
      if (s.supr > T.suprEsconde && ahora - s.tSuprDijo > 6 && s.esc.estado === 'combate' && s.rol !== 'tirador') { if (decir(s, 'suprimido')) s.tSuprDijo = ahora; }
    }
  }
  function explosion(pos, radio, dano, de) {
    if (!pos) return;
    const px = pos.x, py = pos.y || 0, pz = pos.z;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      const d = hyp(s.x - px, s.z - pz); if (d > radio) continue;
      let dn = dano * (1 - d / radio);
      if (!rayoLibre(px, py + 0.4, pz, s.x, s.y + ojoDe(s) * 0.6, s.z)) dn *= T.granada.cobertura;
      if (s.tierra > 0.8) dn *= 0.7;
      const l = d || 1;
      herir(s, dn, { x: (s.x - px) / l, y: 0, z: (s.z - pz) / l }, 'explosion', de === 'jugador' ? 'granada' : (typeof de === 'string' ? de : 'granada'));
    }
    ruido(pos, 'explosion', 1);
  }

  /* ====================================================================================================
     BALA DEL JUGADOR CONTRA LOS SOLDADOS: el modelo si hay; si no, cápsulas según la postura
     ==================================================================================================== */
  function capsula(ox, oy, oz, dx, dy, dz, ax, ay, az, bx, by, bz, r) {               // rayo contra cápsula (segmento a-b, radio r): t o -1
    const bax = bx - ax, bay = by - ay, baz = bz - az, oax = ox - ax, oay = oy - ay, oaz = oz - az;
    const baba = bax * bax + bay * bay + baz * baz, bard = bax * dx + bay * dy + baz * dz, baoa = bax * oax + bay * oay + baz * oaz;
    const rdoa = dx * oax + dy * oay + dz * oaz, oaoa = oax * oax + oay * oay + oaz * oaz, a = baba - bard * bard;
    if (a < 1e-9) { const t1 = esfera(ox, oy, oz, dx, dy, dz, ax, ay, az, r), t2 = esfera(ox, oy, oz, dx, dy, dz, bx, by, bz, r); return t1 < 0 ? t2 : t2 < 0 ? t1 : Math.min(t1, t2); }
    const b = baba * rdoa - baoa * bard, c = baba * oaoa - baoa * baoa - r * r * baba, h = b * b - a * c;
    if (h < 0) return -1;
    const t = (-b - Math.sqrt(h)) / a, y = baoa + t * bard;
    if (y > 0 && y < baba) return t;
    return y <= 0 ? esfera(ox, oy, oz, dx, dy, dz, ax, ay, az, r) : esfera(ox, oy, oz, dx, dy, dz, bx, by, bz, r);
  }
  function esfera(ox, oy, oz, dx, dy, dz, cx, cy, cz, r) {
    const ex = ox - cx, ey = oy - cy, ez = oz - cz, b = dx * ex + dy * ey + dz * ez, c = ex * ex + ey * ey + ez * ez - r * r, h = b * b - c;
    return h > 0 ? -b - Math.sqrt(h) : -1;
  }
  function rayoCuerpo(s, ox, oy, oz, dx, dy, dz, maxT) {
    /* descarte rápido: el rayo pasa lejos del soldado */
    const cx = s.x - ox, cz = s.z - oz, hl = Math.sqrt(dx * dx + dz * dz) || 1e-6, u = (cx * dx + cz * dz) / hl;
    if (u < -1.5 || u / hl > maxT + 2) return null;
    if (Math.abs(cx * dz - cz * dx) / hl > 1.3) return null;
    let mt = maxT, parte = null, t;
    const y = s.y, k = s.agach;
    if (s.tierra > 0.5) {
      const fx = Math.sin(s.rumbo), fz = Math.cos(s.rumbo);
      t = esfera(ox, oy, oz, dx, dy, dz, s.x + fx * 0.8, y + 0.32, s.z + fz * 0.8, 0.14); if (t >= 0 && t < mt) { mt = t; parte = 'cabeza'; }
      t = capsula(ox, oy, oz, dx, dy, dz, s.x - fx * 0.05, y + 0.22, s.z - fz * 0.05, s.x + fx * 0.6, y + 0.25, s.z + fz * 0.6, 0.23); if (t >= 0 && t < mt) { mt = t; parte = 'torso'; }
      t = capsula(ox, oy, oz, dx, dy, dz, s.x - fx * 0.95, y + 0.15, s.z - fz * 0.95, s.x - fx * 0.1, y + 0.18, s.z - fz * 0.1, 0.17); if (t >= 0 && t < mt) { mt = t; parte = 'pierna'; }
    } else {
      const hc = 1.66 - 0.54 * k, t0 = 0.98 - 0.4 * k, t1 = 1.48 - 0.5 * k, p1 = 0.92 - 0.37 * k;
      t = esfera(ox, oy, oz, dx, dy, dz, s.x, y + hc, s.z, 0.14); if (t >= 0 && t < mt) { mt = t; parte = 'cabeza'; }
      t = capsula(ox, oy, oz, dx, dy, dz, s.x, y + t0, s.z, s.x, y + t1, s.z, 0.25); if (t >= 0 && t < mt) { mt = t; parte = 'torso'; }
      t = capsula(ox, oy, oz, dx, dy, dz, s.x, y + 0.12, s.z, s.x, y + p1, s.z, 0.17 + 0.05 * k); if (t >= 0 && t < mt) { mt = t; parte = 'pierna'; }
    }
    return parte ? { s, t: mt, parte } : null;
  }
  function rayoJugador(o, d, maxT) {
    const ox = o.x, oy = o.y, oz = o.z, dx = d.x, dy = d.y, dz = d.z; let mt = (maxT > 0) ? maxT : Infinity, mejor = null;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      if (s.vista && s.vista.rayo && _v3) {
        const r = s.vista.rayo(o, d);
        if (r) { const t = typeof r === 'number' ? r : r.t; if (t >= 0 && t < mt) { mt = t; mejor = { s, t, parte: r.parte || 'torso' }; } }
        continue;
      }
      const r = rayoCuerpo(s, ox, oy, oz, dx, dy, dz, mt); if (r) { mt = r.t; mejor = r; }
    }
    return mejor;
  }

  /* ====================================================================================================
     ESCUADRONES: crear, poblar, refuerzo
     ==================================================================================================== */
  function crearEscuadron(def, esRef) {
    const e = {
      nombre: def.nombre || (esRef ? 'Tizón' : 'Ceniza'), activo: !esRef, esRefuerzo: !!esRef, soldados: [],
      roles: (def.roles || ['jefe', 'asalto', 'granadero', 'tirador']).slice(),
      estado: 'guardia', tEst: ahora, puestos: def.puestos || null, ronda: def.ronda || null, nido: def.nido || null,
      reunion: def.reunion || null, sale: def.sale || null, camino: def.camino || null,
      sosp: null, busq: null, alertado: false, desorden: -99, jefe: null, tRadio: -99, ultFrase: {}, tFuego: -99,
      mueve: null, tMueve: 0, flanco: null, tFlanco: -99, tCerebro: ahora + azar() * T.tCerebro, orden: '', prioBichos: false,
      fase: 0, replegados: false, radioQuien: null, tEmpuje: -99, llegoDicho: false, fijarDicho: false, vivos: 0
    };
    escuadrones.push(e);
    if (!esRef) poblar(e);
    return e;
  }
  function puestoDe(e, rol, i) {
    const P = e.puestos; let p = null;
    if (Array.isArray(P)) p = P[i] || null; else if (P) p = P[rol] || null;
    return p;
  }
  function poblar(e) {
    const roles = e.roles, base = e.reunion || (e.sale) || { x: 0, z: 0 };
    let ang = 0;
    if (e.sale && e.camino && e.camino.length) ang = Math.atan2(e.camino[0].x - e.sale.x, e.camino[0].z - e.sale.z);
    for (let i = 0; i < roles.length; i++) {
      const rol = roles[i]; let p = null, nido = false;
      if (e.esRefuerzo && e.sale) {                                                     // el refuerzo aparece en fila, a la par del camino
        const o = (i - (roles.length - 1) / 2) * 1.6, x = e.sale.x + Math.cos(ang) * o - Math.sin(ang) * i * 0.8, z = e.sale.z - Math.sin(ang) * o - Math.cos(ang) * i * 0.8;
        const k = libreCerca(x, z, 4); p = { x: k >= 0 ? cX(k) : x, z: k >= 0 ? cZ(k) : z, rumbo: ang };
      } else {
        p = puestoDe(e, rol, i);
        if (!p && rol === 'tirador' && e.nido) { p = { x: e.nido.x, z: e.nido.z, rumbo: e.nido.rumbo || 0 }; nido = true; }
        if (!p && rol === 'asalto' && e.ronda && e.ronda.length) p = { x: e.ronda[0].x, z: e.ronda[0].z, rumbo: e.ronda[0].rumbo || 0 };
        if (!p) { const k = libreCerca(base.x + (i % 2 ? 1.5 : -1.5), base.z + i * 1.5 - 2, 4); p = { x: k >= 0 ? cX(k) : base.x, z: k >= 0 ? cZ(k) : base.z, rumbo: 0 }; }
        if (p.rumbo === undefined) p.rumbo = e.nido && e.nido.rumbo !== undefined ? e.nido.rumbo : 0;
        if (!nido && !libreEn(p.x, p.z)) { const k = libreCerca(p.x, p.z, 4); if (k >= 0) p = { x: cX(k), z: cZ(k), rumbo: p.rumbo }; }
      }
      const s = nuevoSoldado(e, rol, i + 1, p);
      if (nido) { s.elev = { r: e.nido.r || 1.5, y: e.nido.y || 2.4 }; s.y = s.elev.y; s.post = 2; s.agach = 1; s.tierra = 1; }
      else s.y = ENV.piso(s.x, s.z);
      if (e.esRefuerzo) { s.alerta = 2; s.tConoce = ahora; }
      e.soldados.push(s); soldados.push(s);
      if (rol === 'jefe' && !e.jefe) e.jefe = s;
      const v = ENV.vista ? ENV.vista(s) : null; if (v) { s.vista = v; escribirVista(s, 0); }
    }
    if (!e.jefe) e.jefe = jefeDe(e);
  }
  function escuadron(def) { defs.push({ tipo: 'escuadron', def }); return crearEscuadron(def || {}, false); }
  function refuerzo(def) { defs.push({ tipo: 'refuerzo', def }); const e = crearEscuadron(def || {}, true); red.refuerzo = e; return e; }

  /* ====================================================================================================
     UPDATE: un cuadro del juego
     ==================================================================================================== */
  let tLejosChk = -99, lejosTodos = false, tLentoPens = 0;
  const vivosObj = [];
  /* (percepción gruesa, solo para ahorrar: ¿está el jugador lejos de todos?) */
  function percibirLejos() {
    const j = ENV.jugador();
    for (let i = 0; i < soldados.length; i++) { const s = soldados[i]; if (s.vivo && s.activo && hyp(j.x - s.x, j.z - s.z) < T.lejos) return false; }
    return true;
  }
  function update(dt) {
    if (!(dt > 0)) return;
    if (dt > 0.1) dt = 0.1;
    ahora = ENV.ahora(); cuadro++; leerGrilla();
    let guardia = true; for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo && escuadrones[i].estado !== 'guardia') guardia = false;
    if (guardia && ahora - tLejosChk > 0.5) { tLejosChk = ahora; lejosTodos = percibirLejos(); }
    const lento = guardia && lejosTodos;
    peligros = ENV.peligros() || []; bichos = ENV.bichos() || [];
    tickDialogos(); entregarAvisos(); llegadaRefuerzo();
    for (let i = 0; i < escuadrones.length; i++) { const e = escuadrones[i]; if (e.activo && ahora >= e.tCerebro) { e.tCerebro = ahora + T.tCerebro; cerebro(e); } }
    repartirFichas();
    vivosObj.length = 0;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.activo) continue;
      if (!s.vivo) {
        if (s.muerte && s.muerte.t < 1) s.muerte.t = Math.min(1, (ahora - s.tMuerte) / 1.1);
        if (s.vista) escribirVista(s, dt);
        continue;
      }
      vivosObj.push(s);
      if (ahora >= s.tPerc) { s.tPerc = ahora + (lento ? 1 : T.tPercibir); percibir(s); }
      if (ahora >= s.tPens) { s.tPens = ahora + (lento ? 0.5 : T.tPensar); pensar(s); }
      actuar(s, dt);
    }
    for (let n = Math.max(1, Math.round(dt * 60)); n > 0; n--) if (!procesarTrabajo()) break;
  }
  function reset() {
    for (let i = 0; i < soldados.length; i++) { const s = soldados[i]; if (s.vista && s.vista.dispose) { try { s.vista.dispose(); } catch (err) { /* nada */ } } }
    soldados.length = 0; escuadrones.length = 0; trabajos.length = 0; dialogos.length = 0; partes.length = 0; idSig = 0; vivosObj.length = 0;
    red.uc = null; red.tVisto = -99; red.tSenal = -99; red.tContacto = -99; red.ancla = null; red.fichas.length = 0; red.tirador = null; red.dano.length = 0;
    red.tGranada = -99; red.muerto = false; red.refuerzo = null; red.refPedido = false; red.refEn = -1; red.refLlego = false; red.recJug = -99; red.bichosVistos = false;
    red.tRuido = -99; xOk = false; fichaLibreEn = -99; tLejosChk = -99; ahora = ENV.ahora();
    const d = defs.slice(); defs.length = 0;
    for (let i = 0; i < d.length; i++) { if (d[i].tipo === 'escuadron') escuadron(d[i].def); else refuerzo(d[i].def); }
  }

  /* ====================================================================================================
     CONSULTAS: objetivos (para los bichos), estado (HUD), debug (vista táctica)
     ==================================================================================================== */
  function objetivos() { return vivosObj; }
  function estado() {
    let m = null, ms = 0, combate = false, busqueda = false, quedan = 0;
    for (let i = 0; i < escuadrones.length; i++) { const e = escuadrones[i]; if (!e.activo) continue; if (e.estado === 'combate') combate = true; if (e.estado === 'busqueda') busqueda = true; }
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue; quedan++;
      const v = s.alerta >= 2 ? 1 : s.sosp; if (v > ms) { ms = v; m = s; }
    }
    return {
      sospecha: ms, x: m ? m.x : 0, z: m ? m.z : 0,
      angulo: m ? Math.atan2(m.x - m.estX, m.z - m.estZ) : 0,                          // rumbo desde donde lo percibió hacia el soldado (para el indicador del HUD)
      combate, busqueda, quedan, refuerzo: red.refLlego ? 'llego' : red.refPedido ? 'pedido' : 'no',
      refuerzoEn: red.refPedido && !red.refLlego ? Math.max(0, red.refEn - ahora) : null
    };
  }
  function debug() {
    const S = [], E = [];
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.activo) continue;
      const cam = []; if (s.camino) for (let q = s.ci; q < s.camino.length; q++) cam.push({ x: s.camino[q].x, z: s.camino[q].z });
      S.push({ id: s.id, nombre: s.nombre, rol: s.rol, esc: s.esc.nombre, x: s.x, z: s.z, y: s.y, rumbo: s.rumbo, estado: s.estado, tarea: s.tarea,
        postura: s.tierra > 0.5 ? 'tierra' : s.agach > 0.5 ? 'agachado' : 'pie', hp: Math.max(0, Math.round(s.hp)), vivo: s.vivo, ficha: !!s.ficha, ve: s.ve,
        sosp: s.sosp, suprimido: s.supr > T.suprEsconde || s.escondeT > 0, camino: cam, cob: s.cob ? { x: s.cob.x, z: s.cob.z } : null, blanco: s.blanco,
        laser: s.laser ? { x: s.laser.x, y: s.laser.y, z: s.laser.z } : null, luz: s.luz });
    }
    for (let i = 0; i < escuadrones.length; i++) {
      const e = escuadrones[i]; if (!e.activo) continue;
      E.push({ nombre: e.nombre, estado: e.estado, uc: red.uc ? { x: red.uc.x, z: red.uc.z, edad: ahora - red.uc.t, tipo: red.uc.tipo, err: red.uc.err } : null,
        fichas: red.fichas.filter(s => s.esc === e).length, orden: e.orden, sinJefe: e.desorden > ahora, refuerzoEn: red.refPedido && !red.refLlego ? red.refEn - ahora : null,
        fase: e.fase, flanco: e.flanco ? { nombre: e.flanco.s.nombre, lado: e.flanco.lado > 0 ? 'der' : 'izq' } : null });
    }
    const j = ENV.jugador();                                                            // solo para dibujar: ninguna decisión sale de acá
    const G = []; for (let i = 0; i < peligros.length; i++) G.push({ x: peligros[i].x, z: peligros[i].z, t: peligros[i].t });
    return { soldados: S, escuadrones: E, jugador: { x: j.x, z: j.z }, granadas: G };
  }

  return {
    interno: { prof, _estCob, buscarCobertura, puestoDeTiro, lv, aEstrella, conocido, opcionesCob },
    escuadron, refuerzo, update, reset, soldados, rayo: rayoJugador, herir, balaCerca, ruido, explosion, objetivos, estado, debug,
    get escuadrones() { return escuadrones; }, get red() { return red; }, T,
    get astar() { return aCuenta; }, get exposCalc() { return xCalc; }
  };
}

if (typeof module !== 'undefined') module.exports = { crearUE, UE_TUNE };
