const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs=require('fs');
const t0=Date.now();const log=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(1)+'s',...a);
(async()=>{
  const browser = await chromium.launch({headless:true,args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
  const page = await browser.newPage({viewport:{width:320,height:180}});
  page.on('pageerror',e=>log('PAGEERR '+e.message));
  await page.route('**/*',r=>{const u=r.request().url();if(u.startsWith('file:'))r.continue();else r.abort();});
  page.setDefaultTimeout(600000);
  await page.goto('file://'+process.cwd()+'/game-test.html',{waitUntil:'load',timeout:180000});
  log('loaded');
  await page.evaluate(()=>__ev("renderer.render=()=>{};1"));
  let r=await page.evaluate(()=>__ev("(()=>{const t=performance.now();buildSectionB();resetGame();return {ms:performance.now()-t,enReady,cars:VCARS.length,obst:obstacles.length};})()"));
  log('built',JSON.stringify(r));
  const X0=-640,X1=-160,Z0=500,Z1=720;
  const d=await page.evaluate(([X0,X1,Z0,Z1])=>__ev(`(()=>{
    const X0=${X0},X1=${X1},Z0=${Z0},Z1=${Z1},W=X1-X0,H=Z1-Z0;const B=[],Hh=[],G=[];
    for(let z=Z0;z<Z1;z++)for(let x=X0;x<X1;x++){const k=eCell(x+.5,z+.5);B.push(k<0?2:enB[k]);Hh.push(k<0?0:enH[k]);G.push(cellAt(x+.5,z+.5));}
    const inW=(x,z)=>x>X0&&x<X1&&z>Z0&&z<Z1;
    const cars=VCARS.filter(c=>inW(c.x,c.z)).map(c=>({id:c.S.id,mi:c.mi,x:+c.x.toFixed(2),z:+c.z.toFixed(2),a:+c.a.toFixed(3),L:+c.L.toFixed(2),W:+c.W.toFixed(2),H:+c.H.toFixed(2),lit:c.lit||null}));
    const obs=obstacles.filter(b=>b.x1>X0&&b.x0<X1&&b.z1>Z0&&b.z0<Z1).map(b=>({x0:+b.x0.toFixed(2),x1:+b.x1.toFixed(2),z0:+b.z0.toFixed(2),z1:+b.z1.toFixed(2),y0:+(b.y0||0).toFixed(2),y1:+b.y1.toFixed(2),glass:b.glass?1:0}));
    const sub=SUBTE.filter(s=>inW(s.x,s.z)).map(s=>({x:+s.x.toFixed(1),z:+s.z.toFixed(1)}));
    const mh=(typeof MH!=='undefined'?MH:[]).filter(s=>inW(s.x,s.z)).map(s=>({x:+s.x.toFixed(1),z:+s.z.toFixed(1)}));
    return {X0,Z0,W,H,B,Hh,G,cars,obs,sub,mh,carIds:CARS.map(c=>c.id)};})()`),[X0,X1,Z0,Z1]);
  log('dumped',d.cars.length,'cars',d.obs.length,'obst',d.sub.length,'subte',d.mh.length,'mh');
  fs.writeFileSync(process.argv[2]||'mapa-reten.json',JSON.stringify(d));
  await browser.close();
})().catch(e=>{log('FAIL',e.message);process.exit(1);});
