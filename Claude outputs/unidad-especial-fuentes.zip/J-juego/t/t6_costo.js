// Prueba 6: costo con 8 soldados en combate cerca del jugador (UE.update + modelos): media, percentiles y peor cuadro.
const H=require('../../harness.js'),fs=require('fs');
const INST=require('./inst.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
const OUT=process.argv[3]||__dirname+'/t6c.json';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto');const R={};const ev=c=>h.ev(c);
  try{
    await h.start();await ev("RETEN.ir({bichos:false});1");await ev(INST);await h.step(.5);
    await ev("window.__inmortal=true;P.pos.set(-410,floorAt(-410,607),607);P.vel.set(0,0,0);P.yaw=Math.PI/2;UE.T.refuerzoCombate=1;UE.T.refuerzoLlega=4;1");
    for(let k=0;k<40;k++){await h.step(1,1/60,"__fich()");if(await ev("UE.estado().refuerzo")==='llego')break;}
    await ev("P.pos.set(-420,floorAt(-420,607),607);P.vel.set(0,0,0);1");
    const Q=`(()=>{const r=UEG.MED.reg,ms=[];for(let i=0;i<r.length;i+=2)ms.push(r[i]);ms.sort((a,b)=>a-b);const q=p=>+ms[Math.min(ms.length-1,Math.floor(p*ms.length))].toFixed(2);
      return {n:ms.length,media:+(ms.reduce((a,b)=>a+b,0)/ms.length).toFixed(3),p50:q(.5),p90:q(.9),p99:q(.99),mod:+(UEG.MED.mod/UEG.MED.n).toFixed(3),bala:__L.bala.n};})()`;
    R.var={};
    for(const [n,pre] of [['normal',''],['sinEfectos','window.__b0=window.__b0||UEG.ENV.bala;UEG.ENV.bala=()=>{};'],['sinEfectosNiModelos','UEG.TUNE.visDist=0;'],['normal2','UEG.ENV.bala=window.__b0;UEG.TUNE.visDist=170;']]){
      await ev(pre+"UEG.medirReset();UEG.MED.reg=[];__L.bala.n=0;1");await h.step(15,1/60,"__fich()");R.var[n]=await ev(Q);lg(n,JSON.stringify(R.var[n]));}
    await ev("UEG.medirReset();UEG.MED.reg=[];1");
    const pasos=[];for(let k=0;k<2;k++)pasos.push(await h.step(5,1/60,"__fich()"));
    R.costo=await ev(`(()=>{const r=UEG.MED.reg,ms=[],mo=[];for(let i=0;i<r.length;i+=2){ms.push(r[i]);mo.push(r[i+1]);}ms.sort((a,b)=>a-b);mo.sort((a,b)=>a-b);
      const q=(a,p)=>+a[Math.min(a.length-1,Math.floor(p*a.length))].toFixed(3);
      return {cuadros:ms.length,total:{media:+(UEG.MED.ia/UEG.MED.n).toFixed(3),p50:q(ms,.5),p90:q(ms,.9),p99:q(ms,.99),max:q(ms,1),sobre4ms:ms.filter(v=>v>4).length},
        modelos:{media:+(UEG.MED.mod/UEG.MED.n).toFixed(3),p99:q(mo,.99),max:q(mo,1)},peores:UEG.MED.peores.sort((a,b)=>b[1]-a[1]).slice(0,6),
        vivos:UE.soldados.filter(s=>s.vivo).length,cerca40:UE.soldados.filter(s=>s.vivo&&Math.hypot(s.x-P.pos.x,s.z-P.pos.z)<40).length,
        enPantalla:UEG.modelos.filter(v=>v.vis&&v.enPantalla).length,combate:UE.estado().combate};})()`);
    R.costo.wallMsPorCuadro=+(pasos.reduce((a,p)=>a+p.wallMs,0)/(2*5*60)).toFixed(3);
    lg('costo',JSON.stringify(R.costo));
    R.L=await ev("({bala:__L.bala.n,fichMax:__L.fichMax,granadas:__L.ev.granada||0,T:+T.toFixed(1)})");lg('L',JSON.stringify(R.L));
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(OUT,JSON.stringify(R));
  await h.close();lg('cerrado');
})();
