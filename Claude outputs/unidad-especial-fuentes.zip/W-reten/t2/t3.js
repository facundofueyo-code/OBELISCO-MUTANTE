/* Capturas del retén (960×540) y costo de dibujo con y sin retén.
   Uso: node t3.js juego.html prefijo vistas   (vistas: lista separada por comas de nombres de VISTAS, o "todas")
   Al final opcional: prueba de balas hasta la explosión (si la lista incluye "balas"). */
const path = require('path'), fs = require('fs');
const UE = path.resolve(__dirname, '..', '..');
const H = require(path.join(UE, 'harness.js'));
const t0 = Date.now(); const log = (...a) => console.log(((Date.now() - t0) / 1000).toFixed(0) + 's', ...a);
const J = o => JSON.stringify(o);
/* [nombre, cámara, mira] */
const VISTAS = {
  arranque: [[-326, 1.55, 606], [-438, 1.6, 607]],
  m50: [[-388, 1.55, 607.5], [-438, 1.3, 607]],
  fila15: [[-423, 1.2, 608.4], [-438, 1.5, 606.5]],
  barricada: [[-429.5, 1.6, 610], [-438, 1.2, 606]],
  soldado: [[-442.6, 1.62, 607.2], [-400, 1.2, 607.5]],
  bolsas: [[-424.5, 1.5, 614.6], [-437, .4, 619.6]],
  pintada: [[-386, 1.6, 604], [-397.5, 1.9, 590.7]],
  barolo: [[-409.3, 1.6, 619.6], [-433, 1.4, 605]],
  arriba: [[-417, 44, 607.5], [-416.9, 0, 607.5]],
};
(async () => {
  const [file, pref, lista] = [process.argv[2] || path.join(__dirname, 'juego.html'), process.argv[3] || 'v', process.argv[4] || 'arranque'];
  const nombres = lista === 'todas' ? Object.keys(VISTAS) : lista.split(',').filter(n => VISTAS[n]);
  const out = path.join(__dirname, '..', 'capturas'); fs.mkdirSync(out, { recursive: true });
  const h = await H.open(file, { width: 960, height: 540 });
  try {
    await h.start(); await h.alReten(-326, 606); await h.step(1, 1 / 60, 'P.hp=100');
    /* vista fija: sin lógica de jugador, sin HUD ni arma */
    await h.ev("running=false;over=true;vm.visible=false;$('#hud').hidden=true;$('#cross').hidden=true;SECG.A.visible=false;SECG.B.visible=true;1");
    const cam = (c, m) => h.ev(`camera.position.set(${c});camera.lookAt(${m});camera.updateMatrixWorld();1`);
    /* espera a que destellen las balizas azules (para ver si se leen) */
    const flash = () => h.ev(`(()=>{let n=0;while(n++<120){const C=RETEN.piezas.GLOW.C;let on=false;for(const k of [0,1,2,3,7,8,9,10])if(C[k*3+2]>.5)on=true;if(on)return n;window.__simT+=1000/60;frame(window.__simT);}return -1;})()`);
    const info = () => h.ev("({calls:renderer.info.render.calls,tris:renderer.info.render.triangles,points:renderer.info.render.points})");
    for (const n of nombres) {
      const [c, m] = VISTAS[n]; await cam(c, m); await flash();
      if (n === 'arranque' || n === 'm50') {
        await h.ev("RETEN.grupo.visible=false;1"); await cam(c, m); await h.shot(path.join(out, `${pref}-${n}-sin.png`)); const a = await info();
        await h.ev("RETEN.grupo.visible=true;1"); await cam(c, m); await flash(); await h.shot(path.join(out, `${pref}-${n}.png`)); const b = await info();
        log(n, 'sin retén', J(a), 'con retén', J(b), 'diferencia', J({ calls: b.calls - a.calls, tris: b.tris - a.tris, points: b.points - a.points }));
      } else { await h.shot(path.join(out, `${pref}-${n}.png`)); log(n, J(await info())); }
    }
    if (lista.includes('costo')) {
      /* costo: cuadros alternados con y sin retén (cada cuadro actualiza algún mapa de sombra: un solo par es ruidoso) */
      await h.ev("window.__dc=0;RETEN.grupo.traverse(o=>{if(o.isMesh||o.isPoints||o.isSprite)o.onBeforeRender=()=>{window.__dc++;};});1");
      const draw = () => h.ev("(()=>{window.__dc=0;renderer.render=window.__render;window.__simT+=16;frame(window.__simT);renderer.render=()=>{};const i=renderer.info.render;return {calls:i.calls,tris:i.triangles,mios:window.__dc};})()");
      for (const n of ['arranque', 'm50', 'fila15']) {
        const [c, m] = VISTAS[n]; const sin = [], con = [];
        for (let k = 0; k < 6; k++) { const vis = k % 2 === 1; await h.ev(`RETEN.grupo.visible=${vis};1`); await cam(c, m); (vis ? con : sin).push(await draw()); }
        const med = a => a.slice().sort((x, y) => x - y)[a.length >> 1];
        log('costo', n, 'sin', J(sin.map(x => x.calls)), 'con', J(con.map(x => x.calls)), 'llamadas propias (pase principal)', J(con.map(x => x.mios)),
          'mediana dif llamadas', med(con.map(x => x.calls)) - med(sin.map(x => x.calls)), 'tris', med(con.map(x => x.tris)) - med(sin.map(x => x.tris)));
      }
      await h.ev("RETEN.grupo.visible=true;1");
    }
    if (lista.includes('balas')) {
      await h.ev("running=true;over=false;1");
      const tgt = await h.ev("(()=>{const c=RETEN.autos.find(c=>c.S.id==='furgon'&&c.x<-400);return {x:c.x,z:c.z,i:VCARS.indexOf(c)};})()");
      const aim = `{const dx=${tgt.x}-P.pos.x,dz=${tgt.z}-P.pos.z;P.yaw=Math.atan2(-dx,-dz);P.pitch=-.1;}`;
      await h.ev(`P.pos.set(-414,floorAt(-414,608.5),608.5);P.vel.set(0,0,0);MOV.reset();switchTo(2);1`);
      await h.step(1, 1 / 60, "P.hp=100;" + aim);
      const hist = [];
      for (let k = 0; k < 8; k++) { await h.step(2, 1 / 60, `P.hp=100;mouseDown=true;W[2].ammo=32;W[2].res=999;resetRecoil();W[2].bloom=0;${aim}`); hist.push(await h.ev(`VCARS[${tgt.i}].hits+'/'+VCARS[${tgt.i}].st`)); }
      log('balas: golpes/estado cada 2 s', hist.join(' '));
      await h.ev("mouseDown=false;P.pos.set(-370,floorAt(-370,607),607);1"); await h.step(9, 1 / 60, "P.hp=100;mouseDown=false");
      log('explosión', J(await h.ev(`(()=>{const c=VCARS[${tgt.i}],e=RETEN.piezas.HD,r=c.rg.find(r=>r[0]===e);return {st:c.st,muertos:c.cs.filter(q=>q.dead).length,restos:VWRECK.length,calcoY:r?+e.mesh.geometry.attributes.position.array[r[1]*3+1].toFixed(1):null};})()`)));
      await h.ev("resetGame();1");
      log('tras reset', J(await h.ev(`(()=>{const c=VCARS[${tgt.i}],e=RETEN.piezas.HD,r=c.rg.find(r=>r[0]===e);return {st:c.st,hits:c.hits,muertos:c.cs.filter(q=>q.dead).length,x:c.x,z:c.z,restos:VWRECK.length,calcoY:r?+e.mesh.geometry.attributes.position.array[r[1]*3+1].toFixed(2):null};})()`)));
    }
    log('errores', h.errors.length ? h.errors.join('\n').slice(0, 2000) : 'ninguno');
  } finally { await h.close(); log('cerrado'); }
})().catch(e => { log('FALLA', e.message.slice(0, 2000)); process.exit(1); });
