
/* ====================================================================================
   CUERPO Y EQUIPO
   Todo en la pose de enlace (brazos colgando). Las piezas de los dos lados se arman del lado
   izquierdo (+X) y se espejan con G.lado(-1). Pesos rígidos salvo el torso y el velo, que
   reparten entre dos huesos para que la cintura y el cuello doblen sin cortes.
   ==================================================================================== */

/* torso: cadera → columna → pecho según la altura */
const pesoTorso=(x,y,z)=>y<1.10?[H.cadera,H.columna,sst(1.00,1.10,y)]:[H.columna,H.pecho,sst(1.15,1.29,y)];

/* ---------- agarre de las manos ----------
   Coordenadas de la mano IZQUIERDA en la pose de enlace, relativas a la muñeca: la palma mira a -X,
   los dedos a -Y, el pulgar a +Z. La derecha es su espejo en X (palma a +X).
   El objeto agarrado es un cilindro que cruza la palma en diagonal (de la base del meñique hacia la
   del índice): pasa por C con dirección (0,-sin d, cos d). */
const AGARRE={
  I:{c:new V3(-.037,-.082,0),d:.42,r:.024},   /* guardamanos */
  D:{c:new V3(-.036,-.084,0),d:.36,r:.017}    /* empuñadura de pistola */
};
const DEDOS=[ /* z del nudillo, y del nudillo, largo, radio  (índice → meñique) */
  [.030,-.093,.086,.0088],[.0095,-.097,.094,.0092],[-.0105,-.095,.089,.0089],[-.029,-.089,.072,.0080]];

/* curva de un dedo envolviendo el cilindro del agarre (coordenadas de mano izquierda) */
function curvaDedo(ag,zk,yk,largo,cierre=1){
  const td=Math.tan(ag.d),cx=ag.c.x,cy=ag.c.y-zk*td,kx=.002,ky=yk;
  const R0=Math.hypot(kx-cx,ky-cy),R=ag.r+.0095,a0=Math.atan2(ky-cy,kx-cx);
  const vuelta=largo/((R0+R)/2)*cierre,pts=[],N=5;
  for(let i=0;i<=N;i++){const s=i/N,a=a0-s*vuelta,r=lerp(R0,R,ease(Math.min(1,s*1.6)));
    /* el dedo baja un poco por el cilindro diagonal a medida que lo rodea */
    pts.push([cx+Math.cos(a)*r,cy+Math.sin(a)*r-s*.004,zk]);}
  return pts;
}

/* mano con guante. lado 1: izquierda (dedos en dos huesos, se abren para las señas);
   lado -1: derecha (dedos fijos alrededor de la empuñadura, índice en su propio hueso) */
function mano(G,lado){
  const izq=lado>0,W=BIND[izq?H.manoI:H.manoD],wx=Math.abs(W.x),wy=W.y,wz=W.z,ag=izq?AGARRE.I:AGARRE.D;
  const P=(x,y,z)=>[wx+x,wy+y,wz+z];
  G.lado(lado).hueso(izq?'manoI':'manoD').mat('guante');
  /* palma y dorso */
  G.en(wx,wy-.05,wz).caja(.03,.094,.084,.013);
  G.mat('equipo2').en(wx+.017,wy-.07,wz).caja(.009,.034,.07,.004);           /* protector de nudillos */
  G.mat('guante').en(wx,wy-.012,wz).escala(1,1,1.12).cil(.037,.04,.05,10,0);  /* puño del guante */
  G.mat('equipo2').en(wx,wy+.03,wz).escala(1,1,1.12).cil(.041,.041,.012,10,0);
  /* pulgar (fijo): sobre el guardamanos apunta adelante; en la empuñadura, la rodea */
  const pu=izq?[[-.006,-.028,.034],[-.016,-.048,.052],[-.024,-.066,.068],[-.028,-.082,.08]]
              :[[-.006,-.028,.034],[-.022,-.045,.046],[-.042,-.058,.05],[-.056,-.07,.046]];
  G.mat('guante').en(0,0,0).manguera(pu.map(p=>P(...p)),[.011,.0105,.0095,.0085],5,3);
  if(izq){
    /* cuatro dedos rectos en la pose de enlace: proximal en dedosI, el resto en dedosI2 */
    const yk=BIND[H.dedosI].y-wy,yk2=BIND[H.dedosI2].y-wy;
    for(const [zk,ykk,lg,r] of DEDOS){const s0=yk2+.003,e=Math.min(ykk-lg+.002,yk2-.016);
      G.hueso('dedosI').manguera([P(.002,ykk+.004,zk),P(.002,yk2-.002,zk)],[r,r*.97],5,1);
      G.hueso('dedosI2').manguera([P(.002,s0,zk),P(.002,lerp(s0,e,.5),zk),P(.0015,lerp(s0,e,.85),zk),P(0,e,zk)],[r*.96,r*.92,r*.8,r*.45],5,2);
    }
  }else{
    /* medio, anular y meñique envolviendo la empuñadura; el índice va aparte */
    for(let i=1;i<4;i++){const [zk,yk,lg,r]=DEDOS[i];
      const c=curvaDedo(ag,zk,yk,lg).map(p=>P(...p));G.manguera(c,[r,r,r*.97,r*.93,r*.85,r*.5],5,2);}
    const [zk,yk,lg,r]=DEDOS[0],K=BIND[H.indiceD];
    G.hueso('indiceD').manguera([P(.002,yk+.004,zk),P(.002,yk-.04,zk),P(-.006,yk-.068,zk),P(-.013,yk-lg+.008,zk),P(-.015,yk-lg+.002,zk)],[r,r*.95,r*.9,r*.75,r*.4],5,2);
  }
  G.lado(1);
}

/* brazo: hombro, manga, codera, antebrazo */
function brazo(G,lado,rol){
  const izq=lado>0,b=izq?'I':'D',S=BIND[H['brazo'+b]],E=BIND[H['antebrazo'+b]],x=Math.abs(S.x);
  G.lado(lado).hueso('brazo'+b).mat('tela');
  G.en(x,S.y-.004,S.z).esfera(.067,.071,.069,10,5);
  G.en(0,0,0).loft([[S.y-.005,x,S.z,.063,.063,.065],[1.33,x,S.z,.06,.061,.061],[1.22,x,-.025,.053,.055,.054],[E.y-.01,x,E.z,.051,.052,.052]],10,0);
  G.mat('velcro').en(x+.058,1.36,S.z+.002,0,0,-.08).caja(.006,.062,.072,0);       /* velcro vacío */
  if(rol==='asalto'){G.mat('equipo2').en(x+.016,S.y+.018,S.z).esfera(.088,.07,.086,10,3,{f1:1.3,tapa:false});
    G.mat('equipo2').invertir(true).en(x+.016,S.y+.014,S.z).esfera(.084,.066,.082,8,2,{f1:1.3}).invertir(false);}
  G.hueso('antebrazo'+b).mat('tela');
  G.en(x,E.y,E.z).esfera(.051,.051,.051,8,4);
  G.en(0,0,0).loft([[E.y,x,E.z,.051,.052,.052],[1.06,x,-.022,.048,.049,.047],[.95,x,-.025,.04,.041,.039],[.90,x,-.025,.038,.038,.038]],10,0);
  G.mat('rodilla').en(x,E.y-.008,E.z-.04,-.12,0,0).esfera(.047,.058,.03,8,4);         /* codera */
  G.mat('equipo2').en(x,E.y-.07,E.z-.004).cil(.05,.049,.016,10,0);                    /* correa de la codera */
  G.lado(1);
}

/* pierna: pantalón amplio con bolsillo, rodillera, canilla y borceguí (puntera en su propio hueso) */
function pierna(G,lado){
  const izq=lado>0,b=izq?'I':'D',x=.095;
  G.lado(lado).hueso('muslo'+b).mat('tela');
  G.en(x+.006,.935,-.005).esfera(.106,.1,.106,8,4);
  G.en(0,0,0).loft([[.95,.104,0,.106,.102,.108],[.85,.106,.005,.103,.101,.103],[.72,.103,.008,.094,.092,.09],[.60,.099,.006,.082,.081,.079],[.52,x,.004,.074,.075,.072]],10,0);
  G.mat('tela2').en(x+.1,.735,.012,0,0,-.05).caja(.034,.16,.12,.012);                 /* bolsillo */
    G.hueso('pierna'+b).mat('tela');
  G.en(x,.50,0).esfera(.073,.073,.073,6,3);
  G.en(0,0,0).loft([[.50,x,.002,.073,.075,.073],[.40,x,-.004,.071,.07,.078],[.27,x,-.006,.066,.066,.07],[.205,x,0,.068,.072,.072],[.17,x,0,.062,.066,.066]],10,0);
  G.mat('rodilla').en(x,.50,.052).esfera(.07,.086,.034,8,4);                          /* rodillera */
  G.mat('equipo2').en(x,.43,0).cil(.073,.072,.018,10,0);
  /* borceguí: caña, empeine, puntera y suela con taco */
  const bota=(secs)=>G.loft(secs.map(([z,hw,yc,ab,ar])=>[z,0,-yc,hw,ab,ar,2.6]),10,3);
  G.mat('cuero');   /* la caña va con la canilla: así no se despega cuando el pie se estira */
  G.en(0,0,0).loft([[.07,x,-.008,.051,.062,.056,2.4],[.13,x,-.006,.055,.057,.059,2.2],[.215,x,-.004,.061,.061,.063,2]],10,0);
  G.mat('equipo2').en(x,.198,-.005).cil(.063,.064,.02,10,0);
  G.hueso('pie'+b).mat('cuero');
  G.mat('cuero').en(x,0,0,PI/2,0,0);bota([[-.085,.038,.06,.05,.03],[-.065,.047,.062,.055,.045],[-.01,.05,.066,.062,.055],[.07,.051,.056,.052,.04],[.125,.05,.047,.043,.031]]);
  G.mat('suela').en(x,.011,-.02).caja(.106,.022,.15,0);
  G.en(x,.008,.085).caja(.102,.016,.08,0);
  G.hueso('puntera'+b).mat('cuero').en(x,0,0,PI/2,0,0);bota([[.12,.05,.047,.043,.031],[.17,.048,.042,.039,.027],[.205,.039,.038,.034,.021],[.222,.02,.035,.024,.012]]);
  G.mat('suela').en(x,.009,.175).caja(.1,.018,.095,0);
  G.lado(1);
}

/* cabeza: pasamontañas, máscara antigás con lentes redondos y filtro lateral, casco de corte alto */
function cabeza(G,rol){
  G.lado(1).hueso('cuello').mat('tela2');
  G.en(0,0,0).loft([[1.495,0,-.012,.062,.058,.062],[1.56,0,-.008,.058,.056,.06],[1.625,0,0,.06,.058,.064]],10,0);
  G.hueso('cabeza').mat('tela2').en(0,1.672,0).esfera(.079,.104,.097,10,5);           /* pasamontañas */
  /* cuerpo de la máscara: frente ancho y plano, mentón y "hocico" */
  G.mat('goma').en(0,0,0).loft([
    [1.548,0,.040,.040,.045,.03,2.2],[1.562,0,.034,.064,.068,.045,2.3],[1.595,0,.026,.083,.088,.06,2.4],
    [1.635,0,.020,.090,.090,.07,2.5],[1.685,0,.016,.092,.090,.075,2.6],[1.722,0,.012,.086,.086,.075,2.5],[1.746,0,.008,.07,.074,.07,2.2]],14,3);
  /* lentes: copa de goma, aro de metal y vidrio con brillo frío. Miran un poco hacia afuera (de insecto) */
  for(const s of [1,-1]){G.lado(s);
    const dx=.30,dz=1,l=Math.hypot(dx,dz),ux=dx/l,uz=dz/l,cx=.037,cy=1.69,cz=.103;
    G.mat('goma2').dir(cx-ux*.012,cy,cz-uz*.012,ux,0,uz).cil(.032,.029,.034,12,2);
    G.mat('metal').dir(cx+ux*.0215,cy,cz+uz*.0215,ux,0,uz).toro(.0258,.0032,12,3);
    G.mat('lente').dir(cx+ux*.0205,cy,cz+uz*.0205,ux,0,uz).disco(.0262,12);
  }
  G.lado(1);
  /* hocico: fonador inclinado hacia abajo con rejilla oscura y válvula de exhalación debajo, como mandíbulas */
  {const d=[0,-.5,.87],o=[0,1.603,.092];
    G.mat('goma2').dir(o[0],o[1],o[2],...d).cil(.034,.029,.046,12,0);
    G.mat('equipo').tinte((x,y,z)=>(Math.floor((y*.5+z*.87)*260)%2?.55:1.05)).dir(o[0]+d[0]*.046,o[1]+d[1]*.046,o[2]+d[2]*.046,...d).torno([[.029,0],[.027,.008],[.02,.014],[0,.016]],12);G.tinte(null);
    G.mat('metal').dir(o[0]+d[0]*.03,o[1]+d[1]*.03,o[2]+d[2]*.03,...d).cil(.0335,.0335,.005,12,0);
    for(const sx of [1,-1])G.mat('goma2').dir(sx*.045,1.585,.083,sx*.55,-.45,.7).cil(.014,.011,.03,8,2);}
  G.mat('goma').en(0,1.651,.108,-.25,0,0).caja(.022,.05,.018,.008);                    /* puente entre los lentes */
  /* filtro en la mejilla izquierda, apuntando afuera, adelante y abajo */
  const fd=[.78,-.32,.54],fm=[.072,1.598,.07];
  G.mat('goma2').dir(fm[0],fm[1],fm[2],...fd).cil(.025,.025,.02,10,0);
  G.mat('metal').dir(fm[0]+fd[0]*.018,fm[1]+fd[1]*.018,fm[2]+fd[2]*.018,...fd)
    .torno([[.026,0],[.041,.003],[.042,.016],[.039,.019],[.042,.022],[.042,.05],[.036,.057],[0,.058]],10);
  /* correas del arnés debajo del casco */
  for(const s of [1,-1]){G.lado(s).mat('equipo');
    const pts=[35,5,-30,-62,-90].map(a=>[.066*Math.cos(a*RAD),1.604,.079*Math.sin(a*RAD)]);
    G.en(0,0,0).cinta(pts,.016,.004,(i,p)=>[p[0],0,p[2]]);}
  G.lado(1);
  const velo=rol==='tirador';
  /* casco de corte alto: alto sobre las orejas, bajo atrás */
  const cy=1.694,ry=.111,rx=.109,rz=.123;
  const borde=a=>{const s=Math.sin(a);return s>0?lerp(1.716,1.738,Math.pow(s,1.2)):lerp(1.716,1.648,Math.pow(-s,.8));};
  const corte=a=>Math.acos(clamp((borde(a)-cy)/ry,-1,1));
  G.mat('casco').en(0,cy,-.008).esfera(rx,ry,rz,16,7,{corte});
  G.mat('goma').invertir(true).en(0,cy-.004,-.008).esfera(rx*.94,ry*.94,rz*.94,10,4,{corte}).invertir(false);
  { const pts=[];for(let i=0;i<=14;i++){const a=i/14*TAU,f=corte(a);pts.push([rx*1.005*Math.sin(f)*Math.cos(a),cy+ry*Math.cos(f),-.008+rz*1.005*Math.sin(f)*Math.sin(a)]);}
    G.mat('goma2').en(0,0,0).cinta(pts,.014,.008,(i,p)=>[p[0],0,p[2]+.008]); }
  if(!velo){
    /* rieles laterales */
    for(const s of [1,-1]){G.lado(s);const pts=[];
      for(let i=0;i<=6;i++){const a=lerp(.55,-.85,i/6),f=corte(a)-.17;pts.push([rx*1.06*Math.sin(f)*Math.cos(a),cy+ry*1.04*Math.cos(f),-.008+rz*1.06*Math.sin(f)*Math.sin(a)]);}
      G.mat('equipo2').en(0,0,0).cinta(pts,.019,.011,(i,p)=>[p[0],(p[1]-cy)*.4,(p[2]+.008)*.6]);}
    G.lado(1);
    G.mat('metal').en(0,1.752,.117,-.42,0,0).caja(.038,.024,.014,.005);                   /* soporte frontal */
    if(rol==='jefe'){   /* visor nocturno levantado: dos tubos que se leen como antenas de insecto */
      G.mat('arma').en(0,1.786,.112,-.9,0,0).caja(.075,.026,.03,.008);
      for(const sx of [1,-1]){G.mat('arma').dir(sx*.031,1.79,.118,sx*.08,.62,-.78).cil(.0165,.015,.075,8,2);
        G.mat('vidrio').dir(sx*.031+sx*.08*.076,1.79+.62*.076,.118-.78*.076,sx*.08,.62,-.78).disco(.0135,8);}}
    G.mat('velcro').en(0,1.803,-.012,-.05,0,0).caja(.07,.006,.10,0);
    G.mat('velcro').en(0,1.716,-.121,.42,0,0).caja(.08,.05,.006,0);
    G.mat('equipo').en(0,1.667,-.126,.18,0,0).caja(.1,.052,.034,.012);                   /* contrapeso */
    G.mat('equipo2').en(0,1.722,-.13,.42,0,0).caja(.024,.016,.012,0);                 /* luz de la nuca */
    G.mat('led').en(0,1.722,-.137,.42,0,0).caja(.012,.008,.004,0);
    /* auriculares de radio sobre las orejas (el jefe, más grandes) */
    const ra=rol==='jefe'?.041:.035;
    for(const s of [1,-1]){G.lado(s).mat('equipo');
      G.en(.094,1.662,-.004,0,0,-PI/2).cil(ra,ra-.004,.034,12,2);
      G.mat('equipo2').en(0,0,0).cinta([[.125,1.672,-.004],[.122,1.70,-.006],[.118,1.715,-.008]],.012,.008,[1,0,0]);}
    G.lado(1);
  }else{
    /* velo del tirador: tela sobre el casco que cae sobre hombros y espalda, con el borde deshilachado.
       Arriba va con la cabeza, abajo con el pecho: así acompaña cuando gira la cabeza */
    const az=azarDe(777),seg=18,ani=[
      [1.838,0,-.01,.02,.02,.02],[1.81,0,-.01,.10,.10,.115],[1.75,0,-.01,.132,.122,.148],[1.69,0,-.01,.142,.062,.158],
      [1.62,0,-.01,.15,.034,.16],[1.55,0,-.012,.17,.05,.165],[1.49,0,-.012,.21,.075,.175],[1.44,0,-.015,.255,.12,.185]];
    const P=[],T=[],cols=[];
    for(const [y,cx,cz,rx_,rf,rb] of ani)for(let i=0;i<seg;i++){const a=i/seg*TAU,c=Math.cos(a),s=Math.sin(a),e=2/2.4;
      P.push(cx+rx_*Math.sign(c)*Math.pow(Math.abs(c),e),y,cz+(s>=0?rf:rb)*Math.sign(s)*Math.pow(Math.abs(s),e));}
    /* ruedo: más largo atrás, irregular */
    const base=P.length/3-seg;
    for(let i=0;i<seg;i++){const a=i/seg*TAU,s=Math.sin(a),c=Math.cos(a),j=base+i,x=P[j*3],z=P[j*3+2];
      const yb=lerp(1.39,1.20,sat(-s*.9+.25))-az()*.05,k=1.08+az()*.04;P.push(x*k,yb,z*k-(s<0?.01:0));}
    const nr=ani.length+1;
    for(let r=0;r<nr-1;r++)for(let i=0;i<seg;i++){const a=r*seg+i,b=r*seg+(i+1)%seg;T.push(a,a+seg,b+seg,a,b+seg,b);}
    G.hueso('cabeza').peso((x,y,z)=>[H.pecho,H.cabeza,sst(1.47,1.62,y)]).mat('velo');
    G.tinte((x,y,z)=>.8+.4*Math.abs(Math.sin(x*61+y*37)*Math.sin(z*53-y*29)));
    G.en(0,0,0).crudo(P,T);
    /* tiras sueltas atrás */
    for(let i=0;i<5;i++){const a=-PI/2+(i-2)*.32,x=Math.cos(a)*.2,z=Math.sin(a)*.18-.01,y0=1.40,l=.16+az()*.1;
      G.en(x,y0-l/2,z,0,a+PI/2,0).caja(.035,l,.006,.002);}
    G.tinte(null).hueso('cabeza');
    G.mat('led').en(0,1.722,-.162,.42,0,0).caja(.012,.008,.004,0);              /* la luz va sobre el velo */
  }
}

/* torso, chaleco y cinturón; lo que cambia por rol, al final */
function torso(G,rol){
  G.lado(1).hueso('cadera').peso(pesoTorso).mat('tela');
  G.en(0,0,0).loft([
    [.855,0,-.01,.13,.07,.09,2.2],[.90,0,-.01,.172,.094,.115,2.3],[.96,0,-.008,.18,.10,.12,2.4],[1.03,0,-.005,.166,.099,.106,2.4],
    [1.10,0,-.004,.152,.098,.096,2.4],[1.19,0,0,.16,.108,.10,2.4],[1.29,0,.004,.176,.118,.104,2.5],[1.38,0,0,.186,.112,.102,2.6],
    [1.44,0,-.008,.18,.092,.094,2.5],[1.485,0,-.012,.14,.074,.08,2.2],[1.515,0,-.014,.075,.06,.062,2]],14,3);
  /* cinturón con hebilla y cartucheras */
  G.hueso('cadera').mat('equipo').en(0,0,0).loft([[.985,0,-.006,.186,.114,.126,2.6],[1.037,0,-.005,.177,.112,.12,2.6]],16,0);
  G.mat('metal').en(0,1.011,.117).caja(.058,.04,.014,.004);
  G.mat('equipo').en(0,.99,-.145,-.06,0,0).caja(.14,.09,.06,.018);                       /* botiquín atrás */
  G.mat('equipo').en(.168,.99,-.07,0,-.5,0).caja(.05,.08,.045,.012);
  G.mat('equipo').en(-.17,.99,-.06,0,.5,0).caja(.05,.08,.045,.012);
  /* chaleco portaplacas */
  G.hueso('pecho').mat('equipo');
  G.en(0,1.305,.133,-.08,0,0).caja(.285,.31,.045,.012);
  G.en(0,1.30,-.121,.04,0,0).caja(.29,.33,.04,.012);
  G.en(0,0,0).loft([[1.15,0,0,.181,.126,.117,3],[1.30,0,.004,.192,.131,.121,3]],16,0);
  for(const s of [1,-1]){G.lado(s).mat('equipo').en(0,0,0)
    .cinta([[.095,1.455,.122],[.11,1.50,.062],[.116,1.517,-.01],[.106,1.49,-.08],[.095,1.452,-.112]],.056,.014,(i,p)=>[p[0]-.1,p[1]-1.43,p[2]]);}
  G.lado(1);
  G.mat('velcro').en(0,1.405,.157,-.08,0,0).caja(.12,.056,.004,0);                   /* parche vacío */
  G.mat('equipo').en(.198,1.235,.005).caja(.045,.11,.06,.014);                            /* portarradio */
  G.mat('equipo').en(-.197,1.225,-.01).caja(.04,.085,.055,.012);
  const tripleCargador=()=>{for(const x of [-.078,0,.078]){
    G.mat('equipo').en(x,1.222,.176,-.05,0,0).caja(.072,.12,.05,.014);
    G.mat('equipo2').en(x,1.288,.178,-.05,0,0).caja(.068,.014,.052,.005);}};
  if(rol==='jefe'){
    tripleCargador();
    G.mat('equipo').en(0,1.31,-.185,.04,0,0).caja(.165,.25,.078,.014);                   /* mochila de radio */
    G.mat('poli').en(.042,1.448,-.19).caja(.068,.05,.05,.01);
    G.mat('metal').en(.06,1.47,-.195).cil(.01,.008,.035,8,2);
    G.mat('goma').en(0,0,0).cinta([[.06,1.44,-.17],[.10,1.50,-.085],[.122,1.527,0],[.112,1.475,.1],[.09,1.405,.165]],.009,.007,[0,1,0]);
    G.mat('poli').en(.088,1.392,.172,-.08,0,0).caja(.036,.046,.022,.006);                 /* pulsador */
  }else if(rol==='asalto'){
    /* canana cruzada con cartuchos (del hombro izquierdo a la cadera derecha) */
    const cp=[[.125,1.505,.06],[.105,1.44,.167],[.035,1.335,.178],[-.045,1.225,.178],[-.115,1.125,.164],[-.168,1.035,.112]];
    G.mat('cuero').en(0,0,0).cinta(cp,.058,.012,[0,0,1]);
    const cb=[[-.12,1.03,.10],[-.19,1.05,-.02],[-.15,1.15,-.13],[-.02,1.32,-.155],[.09,1.45,-.12],[.125,1.505,-.03],[.125,1.505,.06]];
    G.en(0,0,0).cinta(cb,.058,.012,(i,p)=>[p[0]*.5,0,p[2]]);
    for(let i=0;i<8;i++){const u=.08+i*.105,k=Math.min(cp.length-2,Math.floor(u*(cp.length-1))),f=u*(cp.length-1)-k;
      const a=cp[k],b=cp[k+1],px=lerp(a[0],b[0],f),py=lerp(a[1],b[1],f),pz=lerp(a[2],b[2],f)+.014;
      const tx=b[0]-a[0],ty=b[1]-a[1],l=Math.hypot(tx,ty),wx=-ty/l,wy=tx/l;
      G.mat('cart').dir(px-wx*.024,py-wy*.024,pz,wx,wy,0).cil(.0098,.0098,.04,6,2);
      G.mat('laton').dir(px+wx*.016,py+wy*.016,pz,wx,wy,0).cil(.0102,.0102,.011,6,2);}
    for(const s of [1,-1])G.lado(s).mat('equipo').en(.125,1.205,.155,-.05,0,0).caja(.06,.075,.045,.014);
    G.lado(1);
  }else if(rol==='granadero'){
    /* cuatro portagranadas en el pecho, con la granada asomando */
    for(const x of [-.108,-.036,.036,.108]){
      G.mat('equipo').en(x,1.222,.18,-.05,0,0).caja(.064,.088,.058,.022);
      G.mat('granada').en(x,1.284,.18).esfera(.027,.026,.027,8,4);
      G.mat('metal').en(x+.012,1.302,.18,0,0,-.4).caja(.008,.03,.012,0);}
    for(const s of [1,-1])G.lado(s).mat('equipo').en(.196,1.21,.072,0,-.6,0).caja(.04,.12,.075,.014);
    G.lado(1);
    G.mat('equipo').en(0,1.30,-.162,.04,0,0).caja(.24,.25,.05,.014);
    /* correa del morral: del hombro derecho a la cadera izquierda, por delante y por la espalda */
    G.peso((x,y,z)=>[H.cadera,H.pecho,sst(1.04,1.18,y)]).mat('tela2').en(0,0,0)
      .cinta([[.205,1.04,.10],[.15,1.15,.172],[.05,1.30,.19],[-.06,1.42,.172],[-.112,1.5,.08],[-.115,1.515,-.02],[-.07,1.43,-.15],[.07,1.22,-.168],[.20,1.05,-.075]],.045,.01,(i,p)=>[p[0]*.6,0,p[2]]);
    G.hueso('cadera').mat('tela2').en(.232,.94,.02,0,0,-.08).caja(.092,.21,.25,.032);    /* morral */
    G.mat('equipo').en(.236,1.03,.02,0,0,-.08).caja(.098,.055,.255,.014);
  }else{
    tripleCargador();
    G.mat('equipo').en(0,1.30,-.162,.04,0,0).caja(.24,.25,.05,.014);
  }
  /* cartuchera de pierna con la pistola (derecha) */
  G.lado(1).hueso('musloD').mat('equipo');
  G.en(-.183,.79,.004,0,0,.06).caja(.014,.17,.10,.004);
  G.en(-.203,.77,.006,0,0,.06).caja(.045,.15,.088,.016);
  G.mat('poli').en(-.205,.866,-.012,.28,0,.06).caja(.03,.07,.04,.01);
  G.mat('equipo2').en(-.095,.835,.0).cil(.087,.086,.02,10,0);
  G.en(-.095,.70,.004).cil(.078,.077,.02,10,0);
  G.hueso('cadera').mat('equipo2').en(0,0,0).cinta([[-.165,1.0,.02],[-.18,.93,.012],[-.185,.88,.008]],.03,.006,[-1,0,0]);
}
