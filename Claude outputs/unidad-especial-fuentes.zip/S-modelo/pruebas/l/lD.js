/* acciones: recarga, granada, señas, culatazo, disparo */
const v=(rol,pose,t,az,el,txt,o={})=>Object.assign({rol,pose,t,az,el,dist:3.1,obj:[0,1.0,0],txt},o);
module.exports={cols:4,vistas:[
  v('jefe','Recarga',.85,.95,.12,'recarga: saca el cargador',{dist:2.4,obj:[0,1.1,0]}),
  v('granadero','Recarga',1.45,.95,.12,'recarga: mete el nuevo',{dist:2.4,obj:[0,1.1,0]}),
  v('granadero','Granada',.5,1.25,.1,'granada: brazo atrás (sale en 0,55)'),
  v('asalto','Culatazo',.5,1.1,.08,'culatazo: golpe'),
  v('jefe','Seña',.95,.5,.08,'seña: avanzar'),v('jefe','Seña',3.15,.35,.08,'seña: izquierda'),
  v('jefe','Seña',5.35,.3,.08,'seña: derecha'),v('jefe','Seña',7.55,.5,.08,'seña: alto')]};
