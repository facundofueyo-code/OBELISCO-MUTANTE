function crearUE(ENV, TUNE) {
  /* ---------- números: los de UE_TUNE, pisados por lo que venga en TUNE (las armas se mezclan campo por campo) ---------- */
  const T = {};
  for (const k in UE_TUNE) { const v = UE_TUNE[k]; T[k] = (v && typeof v === 'object' && !Array.isArray(v)) ? Object.assign({}, v) : v; }
  if (TUNE) for (const k in TUNE) {
    const v = TUNE[k];
    if (k === 'daño') { T.dano = v; continue; }
    if (v && typeof v === 'object' && !Array.isArray(v) && T[k] && typeof T[k] === 'object') Object.assign(T[k], v); else T[k] = v;
  }

  /* ====================================================================================================
     UTILIDADES
     ==================================================================================================== */
  const PI = Math.PI, PI2 = PI * 2, RAD = PI / 180;
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const hyp = Math.hypot;
  const angN = a => { a = a % PI2; if (a > PI) a -= PI2; else if (a < -PI) a += PI2; return a; };   // deja el ángulo en (−π, π]
  const azar = () => ENV.azar();
  const entre = (a, b) => a + (b - a) * ENV.azar();
  /* desvío acotado con forma de campana (triángulo): entre −1 y 1, casi siempre cerca de 0 */
  const campana = () => ENV.azar() + ENV.azar() - 1;
  let ahora = 0;        // reloj del juego (s), se lee una vez por cuadro
  let cuadro = 0;       // contador de cuadros

  /* ====================================================================================================
     GRILLA (SPEC 2.3): B 0 libre · 1 trepable (H en dm) · 2 bloqueado. Casillero de 1 m.
     Se relee de ENV en cada cuadro por si el juego reemplazó los arreglos.
     ==================================================================================================== */
  let B = ENV.B, H = ENV.H, EW = ENV.EW, EH = ENV.EH, EX0 = ENV.EX0, EZ0 = ENV.EZ0;
  function leerGrilla() { B = ENV.B; H = ENV.H; EW = ENV.EW; EH = ENV.EH; EX0 = ENV.EX0; EZ0 = ENV.EZ0; }
  const celda = (x, z) => { const i = Math.floor(x - EX0), j = Math.floor(z - EZ0); return (i < 0 || j < 0 || i >= EW || j >= EH) ? -1 : j * EW + i; };
  const cX = k => EX0 + (k % EW) + 0.5, cZ = k => EZ0 + ((k / EW) | 0) + 0.5;
  const esLibre = k => k >= 0 && B[k] === 0;
  const libreEn = (x, z) => { const k = celda(x, z); return k >= 0 && B[k] === 0; };
  /* altura de lo que hay en un casillero, en metros (lo bloqueado cuenta como pared) */
  const altoDe = k => k < 0 ? 99 : B[k] === 2 ? 99 : B[k] === 1 ? H[k] * 0.1 : 0;
  const D8I = [1, -1, 0, 0, 1, -1, 1, -1], D8J = [0, 0, 1, -1, 1, 1, -1, -1];

  /* casillero libre más cercano a un punto (para arrancar un camino o sacar a alguien de adentro de algo) */
  function libreCerca(x, z, radio) {
    const k0 = celda(x, z); if (esLibre(k0)) return k0;
    const i0 = Math.floor(x - EX0), j0 = Math.floor(z - EZ0); let mejor = -1, md = 1e9;
    for (let dj = -radio; dj <= radio; dj++) for (let di = -radio; di <= radio; di++) {
      const i = i0 + di, j = j0 + dj; if (i < 0 || j < 0 || i >= EW || j >= EH) continue;
      const k = j * EW + i; if (B[k] !== 0) continue;
      const ddx = EX0 + i + 0.5 - x, ddz = EZ0 + j + 0.5 - z, d = ddx * ddx + ddz * ddz; if (d < md) { md = d; mejor = k; }
    }
    return mejor;
  }

  /* ----------------------------------------------------------------------------------------------------
     Línea de visión rápida: la grilla como campo de alturas. Avanza de a 0,5 m entre a y b; si lo que hay en
     el casillero es más alto que el rayo en ese punto, tapa. Saltea los primeros y los últimos 0,6 m (el que
     mira y el mirado pueden estar pegados a su cobertura).
     Devuelve 1 (se ve), 0 (tapado) o 2 (tapado solo en el último tramo: «dudoso»).
       · «dudoso» existe porque la grilla entra inflada 0,3 m: un jugador pegado a una pared queda ADENTRO
         de un casillero bloqueado y la grilla lo daría por invisible. La percepción resuelve ese caso con un
         rayo real (ENV.rayo); todo lo demás lo toma como tapado.
       · plat = {r, y}: el que mira está subido a algo (el nido del tirador): hasta r metros, lo que hay
         debajo es su propia plataforma y solo tapa si el rayo baja de y.
     ---------------------------------------------------------------------------------------------------- */
  function lv(ax, ay, az, bx, by, bz, plat) {
    const dx = bx - ax, dz = bz - az, d = Math.sqrt(dx * dx + dz * dz);
    if (d < 1.3) return 1;
    const n = Math.ceil(d / 0.5), ix = dx / n, iz = dz / n, iy = (by - ay) / n, paso = d / n;
    let x = ax, y = ay, z = az;
    for (let q = 1; q < n; q++) {
      x += ix; y += iy; z += iz;
      const rec = q * paso;
      if (rec < 0.6) continue;
      if (d - rec < 0.6) break;
      const i = Math.floor(x - EX0), j = Math.floor(z - EZ0);
      if (i < 0 || j < 0 || i >= EW || j >= EH) return 0;
      const k = j * EW + i, b = B[k];
      if (b === 0) continue;
      if (plat && rec < plat.r) { if (y < plat.y - 0.02) return 0; continue; }
      if (b === 2 || y < H[k] * 0.1) return (d - rec <= 1.7) ? 2 : 0;
    }
    return 1;
  }
  const lineaVista = (ax, ay, az, bx, by, bz, plat) => lv(ax, ay, az, bx, by, bz, plat) === 1;

  /* Camino recto por casilleros libres (para suavizar caminos y para pasos cortos). Muestrea cada 0,4 m.
     Con esc ≥ 0 además limita cuántos metros del tramo pueden quedar a la vista del último lugar conocido. */
  function lineaLibre(ax, az, bx, bz, exMax, agach) {
    const dx = bx - ax, dz = bz - az, d = Math.sqrt(dx * dx + dz * dz), n = Math.max(1, Math.ceil(d / 0.4));
    let ex = 0;
    for (let q = 1; q <= n; q++) {
      const u = q / n, k = celda(ax + dx * u, az + dz * u);
      if (k < 0 || B[k] !== 0) return false;
      if (exMax >= 0 && expuesta(k, agach)) { ex += d / n; if (ex > exMax + 0.6) return false; }
    }
    return true;
  }

  /* El punto desde donde «mira» una amenaza: si el lugar conocido cae adentro de un casillero no libre
     (el jugador pegado a un auto o a una pared, por la grilla inflada), se usa el casillero libre más cercano. */
  const _ol = { x: 0, z: 0 };
  function origenLibre(x, z) {
    const k = libreCerca(x, z, 2);
    if (k < 0 || k === celda(x, z)) { _ol.x = x; _ol.z = z; } else { _ol.x = cX(k); _ol.z = cZ(k); }
    return _ol;
  }

  /* ====================================================================================================
     EXPOSICIÓN: qué casilleros ve el jugador desde su último lugar conocido.
     Se calcula una sola vez para todos (a pedido, casillero por casillero) y se comparte mientras el lugar
     conocido no cambie. La usan el A* (flanqueos tapados) y el suavizado de caminos.
     ==================================================================================================== */
  const XW = 128, XN = XW * XW;
  const xDat = new Uint8Array(XN), xSel = new Uint32Array(XN);
  let xSello = 1, xI0 = 0, xJ0 = 0, xOx = 1e9, xOz = 1e9, xVx = 0, xVz = 0, xOk = false, xCalc = 0;
  function expoCentrar(x, z) {
    if (xOk && Math.abs(x - xOx) < 1 && Math.abs(z - xOz) < 1) return;
    const o = origenLibre(x, z); xOx = x; xOz = z; xVx = o.x; xVz = o.z; xSello++; xOk = true;
    xI0 = Math.floor(o.x - EX0) - (XW >> 1); xJ0 = Math.floor(o.z - EZ0) - (XW >> 1);
  }
  /* ¿se ve el casillero k desde el último lugar conocido? agach: el que pasa va agachado (se lo ve menos) */
  function expuesta(k, agach) {
    if (!xOk) return 0;
    const i = (k % EW) - xI0, j = ((k / EW) | 0) - xJ0;
    if (i < 0 || j < 0 || i >= XW || j >= XW) return 0;            // lejos: no cuenta
    const l = j * XW + i; let v = xSel[l] === xSello ? xDat[l] : 0;
    const bitC = agach ? 1 : 4, bitV = agach ? 2 : 8;
    if (!(v & bitC)) {
      xCalc++;
      const ve = lv(xVx, 1.6, xVz, cX(k), agach ? 1.0 : 1.6, cZ(k)) === 1;
      v |= bitC | (ve ? bitV : 0); xDat[l] = v; xSel[l] = xSello;
    }
    return (v & bitV) ? 1 : 0;
  }

  /* ====================================================================================================
     A* sobre la grilla de 1 m, en una ventana de 144 × 144 m que contiene al que camina.
     · pasa por casilleros libres; las vallas y cosas de hasta 1,2 m se saltan con costo; los autos se rodean
     · con op.expo, pasar por donde el último lugar conocido tiene línea de visión cuesta (1+costoExpo) veces:
       de ahí salen solos los caminos tapados y los flanqueos por donde no se los ve
     · op.evita = [{x,z,r,c}]: zonas con costo extra (granadas, autos por explotar)
     Devuelve una lista de puntos {x,z,salto} ya suavizada, o null. Si no llega, devuelve el tramo que más
     se acerca (camino.parcial = true): nunca deja a nadie sin camino por un destino difícil.
     ==================================================================================================== */
  const AMAX = 144, AN = AMAX * AMAX;
  const aG = new Float32Array(AN), aDe = new Int32Array(AN), aAb = new Uint32Array(AN), aCe = new Uint32Array(AN);
  const HCAP = AN * 4, hF = new Float32Array(HCAP), hK = new Int32Array(HCAP);
  let aSello = 0, hN = 0, aCuenta = 0;
  function hPush(f, k) {
    if (hN >= HCAP) return;
    let a = hN++; hF[a] = f; hK[a] = k;
    while (a > 0) { const p = (a - 1) >> 1; if (hF[p] <= hF[a]) break; const f0 = hF[p], k0 = hK[p]; hF[p] = hF[a]; hK[p] = hK[a]; hF[a] = f0; hK[a] = k0; a = p; }
  }
  function hPop() {
    const k = hK[0]; hN--;
    if (hN > 0) {
      hF[0] = hF[hN]; hK[0] = hK[hN]; let a = 0;
      for (;;) { const L = 2 * a + 1, R = L + 1; let m = a; if (L < hN && hF[L] < hF[m]) m = L; if (R < hN && hF[R] < hF[m]) m = R; if (m === a) break;
        const f0 = hF[m], k0 = hK[m]; hF[m] = hF[a]; hK[m] = hK[a]; hF[a] = f0; hK[a] = k0; a = m; }
    }
    return k;
  }
  function aEstrella(sx, sz, tx, tz, op) {
    aCuenta++;
    const expo = !!(op && op.expo) && xOk, agach = !!(op && op.agach), evita = (op && op.evita) || null;
    let s0 = celda(sx, sz); if (s0 < 0) return null;
    if (B[s0] !== 0) { s0 = libreCerca(sx, sz, 3); if (s0 < 0) return null; }
    const si = s0 % EW, sj = (s0 / EW) | 0, ti = Math.floor(tx - EX0), tj = Math.floor(tz - EZ0);
    /* ventana centrada entre el origen y el destino; el origen queda siempre adentro, con margen */
    let i0 = ((si + ti) >> 1) - (AMAX >> 1), j0 = ((sj + tj) >> 1) - (AMAX >> 1);
    if (si - i0 < 8) i0 = si - 8; if (i0 + AMAX - 1 - si < 8) i0 = si + 9 - AMAX;
    if (sj - j0 < 8) j0 = sj - 8; if (j0 + AMAX - 1 - sj < 8) j0 = sj + 9 - AMAX;
    const gk = l => (j0 + ((l / AMAX) | 0)) * EW + i0 + (l % AMAX);
    const enGrilla = (i, j) => { const gi = i0 + i, gj = j0 + j; return gi >= 0 && gj >= 0 && gi < EW && gj < EH; };
    /* destino: adentro de la ventana y en un casillero libre (si no, el libre más cercano) */
    let li = clamp(ti - i0, 1, AMAX - 2), lj = clamp(tj - j0, 1, AMAX - 2), corrido = (li !== ti - i0 || lj !== tj - j0);
    if (!enGrilla(li, lj) || B[gk(lj * AMAX + li)] !== 0) {
      let bl = -1, bd = 1e9;
      for (let dj = -4; dj <= 4; dj++) for (let di = -4; di <= 4; di++) {
        const ni = li + di, nj = lj + dj; if (ni < 1 || nj < 1 || ni >= AMAX - 1 || nj >= AMAX - 1 || !enGrilla(ni, nj)) continue;
        if (B[gk(nj * AMAX + ni)] !== 0) continue; const dd = di * di + dj * dj; if (dd < bd) { bd = dd; bl = nj * AMAX + ni; }
      }
      if (bl < 0) return null; li = bl % AMAX; lj = (bl / AMAX) | 0; corrido = true;
    }
    const s = (sj - j0) * AMAX + (si - i0), t = lj * AMAX + li;
    const heur = l => { const dx = Math.abs((l % AMAX) - li), dz = Math.abs(((l / AMAX) | 0) - lj); return dx + dz - 0.586 * (dx < dz ? dx : dz); };
    aSello++; hN = 0; aG[s] = 0; aAb[s] = aSello; aDe[s] = -1; hPush(heur(s), s);
    const maxIt = (op && op.maxIt) || 7000, salMax = T.saltoMax;
    let it = 0, ok = false, mejor = s, mejorH = heur(s);
    while (hN > 0 && it++ < maxIt) {
      const k = hPop(); if (aCe[k] === aSello) continue; aCe[k] = aSello;
      if (k === t) { ok = true; break; }
      const hk = heur(k); if (hk < mejorH) { mejorH = hk; mejor = k; }
      const i = k % AMAX, j = (k / AMAX) | 0, gK = gk(k), bK = B[gK];
      for (let q = 0; q < 8; q++) {
        const di = D8I[q], dj = D8J[q], ni = i + di, nj = j + dj;
        if (ni < 0 || nj < 0 || ni >= AMAX || nj >= AMAX) continue;
        const gi = i0 + ni, gj = j0 + nj; if (gi < 0 || gj < 0 || gi >= EW || gj >= EH) continue;
        const n = nj * AMAX + ni; if (aCe[n] === aSello) continue;
        const gN = gj * EW + gi, bN = B[gN];
        if (bN === 2 || (bN === 1 && H[gN] > salMax)) continue;
        if (di !== 0 && dj !== 0) {                                   // en diagonal no se cortan esquinas ni se salta
          if (bN !== 0 || bK !== 0 || B[gK + di] !== 0 || B[gK + dj * EW] !== 0) continue;
        }
        let c = (di !== 0 && dj !== 0) ? 1.4142 : 1;
        if (bN === 1) c += (bK === 1) ? 0.6 : T.costoSalto;
        if (expo && expuesta(gN, agach)) c *= 1 + T.costoExpo;
        if (evita) for (let m = 0; m < evita.length; m++) { const e = evita[m], ex = EX0 + gi + 0.5 - e.x, ez = EZ0 + gj + 0.5 - e.z; if (ex * ex + ez * ez < e.r * e.r) c += e.c; }
        const ng = aG[k] + c;
        if (aAb[n] !== aSello || ng < aG[n]) { aAb[n] = aSello; aG[n] = ng; aDe[n] = k; hPush(ng + heur(n), n); }
      }
    }
    const fin = ok ? t : mejor;
    if (!ok && mejorH >= heur(s) - 1.5) return null;                // no se acercó nada: sin camino
    const pts = []; let nEx = 0;
    for (let k = fin; k !== -1; k = aDe[k]) { const g = gk(k), e = expo ? expuesta(g, agach) : 0; nEx += e; pts.push({ x: cX(g), z: cZ(g), salto: B[g] === 1, ex: e }); }
    pts.reverse();
    const ult = pts[pts.length - 1];
    if (ok && !corrido && !ult.salto && (Math.abs(tx - ult.x) > 0.05 || Math.abs(tz - ult.z) > 0.05) && libreEn(tx, tz)) pts.push({ x: tx, z: tz, salto: false, ex: ult.ex });
    /* suavizado: atajos rectos por casilleros libres. No se ataja a través de un salto, y con exposición
       no se ataja por un tramo más a la vista que el original (si no, el A* tapado no serviría de nada). */
    const out = []; let a = 0;
    while (a < pts.length - 1) {
      let elegido = a + 1;
      if (!pts[a].salto) {
        for (let b = Math.min(pts.length - 1, a + 20); b > a + 1; b--) {
          if (pts[b].salto) continue;
          let hay = false, exN = 0; for (let m = a + 1; m < b; m++) { if (pts[m].salto) { hay = true; break; } exN += pts[m].ex; }
          if (hay) continue;
          if (lineaLibre(pts[a].x, pts[a].z, pts[b].x, pts[b].z, expo ? exN : -1, agach)) { elegido = b; break; }
        }
      }
      out.push(pts[elegido]); a = elegido;
    }
    if (!out.length) out.push(pts[pts.length - 1]);
    out.costo = aG[fin]; out.expuestos = nEx; out.largo = pts.length; out.parcial = !ok;
    return out;
  }

  /* ====================================================================================================
     COBERTURAS
     Candidatas: casilleros libres pegados a algo de 1 m o más.
       baja (1 a 1,5 m: un auto): se cubre agachado.     alta (pared, furgón, columna): se cubre de pie.
     Para tirar se asoma a un «puesto de tiro»: un casillero vecino (0,7 a 1,4 m) con línea de visión al
     último lugar conocido, o el mismo casillero parándose si la cobertura es baja de verdad (hasta 1,25 m).
     ==================================================================================================== */
  const _cand = [];      // se reutiliza
  function vecinoAlto(k) {
    let h = 0, a;
    a = altoDe(k - 1); if (a > h) h = a; a = altoDe(k + 1); if (a > h) h = a;
    a = altoDe(k - EW); if (a > h) h = a; a = altoDe(k + EW); if (a > h) h = a;
    return h;
  }
  /* ¿hay otro soldado (o su cobertura reservada) a menos de r de este punto? */
  function ocupado(s, x, z, r) {
    const r2 = r * r;
    for (let i = 0; i < soldados.length; i++) {
      const o = soldados[i]; if (o === s || !o.vivo || !o.activo) continue;
      let ox = o.x, oz = o.z; if (o.cob) { ox = o.cob.x; oz = o.cob.z; }
      const dx = ox - x, dz = oz - z; if (dx * dx + dz * dz < r2) return true;
      if (o.cob) { const ex = o.x - x, ez = o.z - z; if (ex * ex + ez * ez < 1.5) return true; }
    }
    return false;
  }
  function enPeligro(x, z, margen) {
    for (let i = 0; i < peligros.length; i++) { const p = peligros[i], dx = p.x - x, dz = p.z - z, r = p.r + margen; if (dx * dx + dz * dz < r * r) return p; }
    return null;
  }
  /* puesto de tiro de una cobertura contra una amenaza en (ax,az). Devuelve {x,z,post,lado} o null.
     post: 0 de pie · 1 agachado.  lado: −1 se asoma por su izquierda · +1 por su derecha · 0 por arriba */
  function puestoDeTiro(s, x, z, k, ax, az, hmax) {
    const fx = ax - x, fz = az - z, fl = hyp(fx, fz) || 1, ux = fx / fl, uz = fz / fl;
    if (hmax <= 1.25 && lineaVista(x, 1.45, z, ax, 1.1, az)) return { x, z, post: 0, lado: 0 };
    let mejor = null, mp = 1e9;
    for (let q = 0; q < 8; q++) {
      const n = k + D8J[q] * EW + D8I[q]; if (!esLibre(n)) continue;
      if (q >= 4 && (B[k + D8I[q]] === 2 || B[k + D8J[q] * EW] === 2)) continue;       // no se asoma cortando una esquina de pared
      const nx = cX(n), nz = cZ(n);
      const lat = Math.abs(D8I[q] * ux + D8J[q] * uz);                                   // 0 = bien de costado
      let post = -1;
      if (lineaVista(nx, 0.95, nz, ax, 1.1, az)) post = 1; else if (lineaVista(nx, 1.45, nz, ax, 1.1, az)) post = 0;
      if (post < 0) continue;
      if (ocupado(s, nx, nz, 1.2)) continue;
      const p = lat * 2 + (q >= 4 ? 0.4 : 0) + (post === 0 ? 0.3 : 0);
      if (p < mp) { mp = p; mejor = { x: nx, z: nz, post, lado: ((nx - x) * (-uz) + (nz - z) * ux) >= 0 ? 1 : -1 }; }
    }
    return mejor;
  }
  /* ¿la cobertura c sigue tapando contra una amenaza en (ax,az)? */
  function tapa(c, ax, az) {
    const o = origenLibre(ax, az);
    return !lineaVista(o.x, 1.6, o.z, c.x, c.tipo === 'alta' ? 1.7 : 1.1, c.z);
  }
  /* Busca la mejor cobertura para s contra una amenaza en (ax,az).
     op = { cx,cz,radio: dónde buscar · dMin,dMax,dIdeal: distancia a la amenaza · tiro: exigir puesto de tiro ·
            atras: tiene que quedar más lejos de la amenaza que ahora · bx,bz,angMin,lado: flanqueo (ángulo mínimo
            respecto de la base de fuego vista desde la amenaza, y de qué lado) · reunion:{x,z} }  */
  function buscarCobertura(s, ax, az, op) {
    const o = origenLibre(ax, az), ox = o.x, oz = o.z;
    const ccx = op.cx !== undefined ? op.cx : s.x, ccz = op.cz !== undefined ? op.cz : s.z, R = op.radio || 22;
    const i0 = Math.floor(ccx - EX0), j0 = Math.floor(ccz - EZ0);
    const dAhora = hyp(s.x - ax, s.z - az);
    let bux = 0, buz = 0; if (op.angMin) { const l = hyp(op.bx - ax, op.bz - az) || 1; bux = (op.bx - ax) / l; buz = (op.bz - az) / l; }
    let n = 0;
    for (let dj = -R; dj <= R; dj++) for (let di = -R; di <= R; di++) {
      const i = i0 + di, j = j0 + dj; if (i < 1 || j < 1 || i >= EW - 1 || j >= EH - 1) continue;
      const k = j * EW + i; if (B[k] !== 0) continue;
      const hmax = vecinoAlto(k); if (hmax < 1) continue;
      const x = EX0 + i + 0.5, z = EZ0 + j + 0.5, dA = hyp(x - ax, z - az);
      if (dA < op.dMin || dA > op.dMax) continue;
      if (op.atras && dA < dAhora + 5) continue;
      let ang = 0;
      if (op.angMin) {
        const vx = (x - ax) / dA, vz = (z - az) / dA; ang = Math.acos(clamp(vx * bux + vz * buz, -1, 1));
        if (ang < op.angMin) continue;
        if (op.lado && ((vx * buz - vz * bux) > 0 ? 1 : -1) !== op.lado) continue;
      }
      if (ocupado(s, x, z, T.separacion)) continue;
      if (enPeligro(x, z, 1.5)) continue;
      const dS = hyp(x - s.x, z - s.z);
      let p = -Math.abs(dA - op.dIdeal) * 0.25 - dS * (op.pesoCamino || 0.16);
      if (hmax >= 1.6) p += 0.6;
      if (s.cob && Math.abs(s.cob.x - x) < 0.1 && Math.abs(s.cob.z - z) < 0.1) p += 2.5;       // histéresis: no cambiar por cambiar
      if (op.angMin) p -= Math.abs(ang - 1.75) * 2.2;                                            // lo mejor: de costado y un poco de atrás
      if (op.reunion) p -= hyp(x - op.reunion.x, z - op.reunion.z) * 0.12;
      let c = _cand[n]; if (!c) c = _cand[n] = { k: 0, x: 0, z: 0, p: 0, h: 0, dA: 0 };
      c.k = k; c.x = x; c.z = z; c.p = p; c.h = hmax; c.dA = dA; n++;
    }
    if (!n) return null;
    /* los mejores por puntaje barato primero; a esos se les mira lo caro: que tape, que tenga tiro, que no esté flanqueada */
    let mejor = null, mp = -1e9, vistos = 0;
    const usados = new Uint8Array(n);
    while (vistos < 14) {
      let b = -1, bp = -1e9; for (let q = 0; q < n; q++) if (!usados[q] && _cand[q].p > bp) { bp = _cand[q].p; b = q; }
      if (b < 0) break; usados[b] = 1;
      if (mejor && bp + 9.5 < mp) break;                               // ya no puede ganarle nadie
      const c = _cand[b], tipo = c.h >= 1.6 ? 'alta' : 'baja', yT = tipo === 'alta' ? 1.7 : 1.1;
      if (lineaVista(ox, 1.6, oz, c.x, yT, c.z)) continue;             // no tapa: no sirve (y no cuenta como vista)
      vistos++;
      let p = c.p;
      const tiro = puestoDeTiro(s, c.x, c.z, c.k, ox, oz, c.h);
      if (tiro) p += 6; else if (op.tiro) continue;
      /* robusta: que siga tapando si el jugador se corre 3 m para cada lado */
      const px = -(c.z - oz) / c.dA, pz = (c.x - ox) / c.dA;
      if (!lineaVista(ox + px * 3, 1.6, oz + pz * 3, c.x, yT, c.z)) p += 1.2;
      if (!lineaVista(ox - px * 3, 1.6, oz - pz * 3, c.x, yT, c.z)) p += 1.2;
      /* separación cómoda de los compañeros */
      for (let q = 0; q < soldados.length; q++) { const m = soldados[q]; if (m === s || !m.vivo || !m.activo) continue; const mx = m.cob ? m.cob.x : m.x, mz = m.cob ? m.cob.z : m.z, dm = hyp(mx - c.x, mz - c.z); if (dm < 6) p -= (6 - dm) * 0.7; }
      if (p > mp) { mp = p; mejor = { x: c.x, z: c.z, k: c.k, tipo, h: c.h, tiro, ax, az, p }; }
    }
    return mejor;
  }
  /* Puesto para el tirador cuando no tiene nido (o lo sacaron de ahí): lejos, cuerpo a tierra si desde el
     piso hay línea; si no, agachado. Devuelve una «cobertura» con tiro en el mismo lugar. */
  function buscarPuestoTirador(s, ax, az) {
    const o = origenLibre(ax, az), ox = o.x, oz = o.z, i0 = Math.floor(s.x - EX0), j0 = Math.floor(s.z - EZ0), R = 30;
    let mejor = null, mp = -1e9;
    for (let dj = -R; dj <= R; dj += 2) for (let di = -R; di <= R; di += 2) {
      const i = i0 + di, j = j0 + dj; if (i < 1 || j < 1 || i >= EW - 1 || j >= EH - 1) continue;
      const k = j * EW + i; if (B[k] !== 0) continue;
      const x = EX0 + i + 0.5, z = EZ0 + j + 0.5, dA = hyp(x - ox, z - oz);
      if (dA < T.tirador.distMin || dA > T.tirador.distMax) continue;
      if (ocupado(s, x, z, T.separacion) || enPeligro(x, z, 1.5)) continue;
      let p = -Math.abs(dA - 45) * 0.08 - hyp(x - s.x, z - s.z) * 0.2 + (vecinoAlto(k) >= 1 ? 1.5 : 0);
      if (p + 4 < mp) continue;
      let post = -1;
      if (lineaVista(x, 0.35, z, ox, 1.1, oz)) { post = 2; p += 4; } else if (lineaVista(x, 1.0, z, ox, 1.1, oz)) post = 1;
      if (post < 0) continue;
      if (p > mp) { mp = p; mejor = { x, z, k, tipo: 'tirador', h: 0, tiro: { x, z, post, lado: 0 }, ax, az, p }; }
    }
    return mejor;
  }

