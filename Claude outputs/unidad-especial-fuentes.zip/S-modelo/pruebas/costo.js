/* costo de update con 8 soldados (Node, mismo motor V8 que Chromium) + prueba de u.rayo en las tres posturas */
const THREE=require('../../three.r128.min.js');global.THREE=THREE;const fs=require('fs');
const UEM=new Function('THREE',fs.readFileSync(__dirname+'/../ue_modelo.js','utf8')+'\nreturn UEM;')(THREE);
const V3=THREE.Vector3;const escena=new THREE.Scene();
const roles=['jefe','asalto','granadero','tirador'];
const us=[];for(let i=0;i<8;i++){const u=UEM.crear(roles[i%4],{semilla:i});u.root.position.set(i*3,0,0);escena.add(u.root);us.push(u);}
const prog=[(u,t)=>{u.e.apunta=1;u.e.mYaw=.4*Math.sin(t);},(u,t)=>{u.root.position.z=1.4*t;u.e.apunta=.4;},(u,t)=>{u.e.recarga=(t%2.6)/2.6;},(u,t)=>{u.e.tierra=1;u.e.apunta=1;u.e.laser=u._lp||(u._lp=new V3(0,0,20));},
  (u,t)=>{u.root.position.z=5*t;},(u,t)=>{u.e.agach=1;u.e.apunta=1;if((t*10|0)%7===0)u.disparo();},(u,t)=>{u.e.lanza=(t%1.5)/1.5;},(u,t)=>{u.e.senal=(t%1.6)/1.6;u.e.luz=true;}];
let t=0;const dt=1/60;
for(let i=0;i<120;i++){t+=dt;us.forEach((u,k)=>{prog[k](u,t);u.update(dt);});escena.updateMatrixWorld();}   /* calentar el JIT */
const N=1200;const t0=process.hrtime.bigint();
for(let i=0;i<N;i++){t+=dt;us.forEach((u,k)=>{prog[k](u,t);u.update(dt);});}
const ms=Number(process.hrtime.bigint()-t0)/1e6/N;
let t1=process.hrtime.bigint();for(let i=0;i<N;i++)escena.updateMatrixWorld();const msM=Number(process.hrtime.bigint()-t1)/1e6/N;
console.log('update de 8 soldados:',ms.toFixed(3),'ms por cuadro ·',(ms/8).toFixed(3),'ms cada uno · updateMatrixWorld de la escena',msM.toFixed(3),'ms');
/* rayo: tiros desde 10 m al frente, a distintas alturas, en las tres posturas */
const u=UEM.crear('jefe',{semilla:1});escena.add(u.root);
for(const [nombre,e] of [['de pie',{apunta:1}],['agachado',{agach:1,apunta:1}],['a tierra',{tierra:1,apunta:1}]]){
  Object.assign(u.e,{agach:0,tierra:0},e);for(let i=0;i<90;i++)u.update(dt);
  const res=[];for(let y=0.05;y<=1.9;y+=0.15){const r=u.rayo(new V3(0.0,y,10),new V3(0,0,-1));res.push(y.toFixed(2)+':'+(r?r.parte[0]+r.t.toFixed(2):'-'));}
  const lat=u.rayo(new V3(5,.9,0),new V3(-1,0,0)),ojo=u.ojos(new V3()),boca=u.boca(new V3());
  console.log(nombre.padEnd(9),res.join(' '),'| lateral',lat&&lat.parte,'| ojos',ojo.toArray().map(x=>x.toFixed(2)).join(','),'| boca',boca.toArray().map(x=>x.toFixed(2)).join(','));}
/* el rayo sigue al root: mover y girar */
u.root.position.set(5,0,5);u.root.rotation.y=Math.PI/2;Object.assign(u.e,{agach:0,tierra:0});for(let i=0;i<60;i++)u.update(dt);
const r=u.rayo(new V3(15,1.5,5),new V3(-1,0,0));console.log('girado 90° y movido: impacto',r&&r.parte,r&&r.t.toFixed(2),'(esperado ~9.9 m al torso o cabeza)');
let a0=process.hrtime.bigint();for(let i=0;i<10000;i++)u.rayo(new V3(15,1.2,5),new V3(-1,0,0));console.log('rayo:',(Number(process.hrtime.bigint()-a0)/1e6/10000*1000).toFixed(1),'µs por consulta');
