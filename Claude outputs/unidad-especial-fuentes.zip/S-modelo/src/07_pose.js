
/* ====================================================================================
   POSES: matemática, IK de dos huesos y resolución del esqueleto
   Una POSE es una descripción chica del cuerpo en el espacio del modelo: cadera (posición y
   giro), giros locales de columna, pecho, cuello y cabeza, y para cada mano y cada pie un
   objetivo (posición de la muñeca o el tobillo, orientación, y hacia dónde va el codo o la
   rodilla). Dos poses se mezclan componente a componente y siempre se resuelven con la misma
   cadena, así que cualquier mezcla queda armada (no se despegan los miembros).
   ==================================================================================== */
const EJX=new V3(1,0,0),EJY=new V3(0,1,0),EJZ=new V3(0,0,1),QI=new Q4();
const _eu=new THREE.Euler(),_mb=new M4(),_bx=new V3(),_by=new V3(),_bz=new V3();
function qE(q,x,y,z){return q.setFromEuler(_eu.set(x,y,z,'YXZ'));}
/* +Z local → fwd, +Y local → up (ortogonalizado) */
function qBase(q,fwd,up){
  _bz.copy(fwd).normalize();_bx.crossVectors(up,_bz);
  if(_bx.lengthSq()<1e-8)_bx.crossVectors(Math.abs(_bz.y)<.9?EJY:EJX,_bz);
  _bx.normalize();_by.crossVectors(_bz,_bx);_mb.makeBasis(_bx,_by,_bz);return q.setFromRotationMatrix(_mb);}
/* segmento de miembro: -Y local → dir; +Z local, hacia 'frente' */
function qSeg(q,dir,frente){
  _by.copy(dir).negate().normalize();_bz.copy(frente).addScaledVector(_by,-frente.dot(_by));
  if(_bz.lengthSq()<1e-10)_bz.crossVectors(EJX,_by);_bz.normalize();_bx.crossVectors(_by,_bz);
  _mb.makeBasis(_bx,_by,_bz);return q.setFromRotationMatrix(_mb);}
/* mano: los dedos (−Y local) hacia 'dedos'; la palma (−X la izquierda, +X la derecha) hacia 'palma' */
function qMano(q,izq,dedos,palma){
  _by.copy(dedos).negate().normalize();_bx.copy(palma);if(izq)_bx.negate();
  _bx.addScaledVector(_by,-_bx.dot(_by));if(_bx.lengthSq()<1e-10)_bx.crossVectors(_by,EJZ);_bx.normalize();
  _bz.crossVectors(_bx,_by);_mb.makeBasis(_bx,_by,_bz);return q.setFromRotationMatrix(_mb);}
const _ia=new V3(),_ib=new V3();
/* IK analítica de dos huesos. A: articulación de arriba, T: objetivo. Escribe el codo/rodilla en B,
   el extremo real en E (si no llega, queda corto sobre la recta) y la normal del plano de doblez en N */
function ik2(A,T,L1,L2,polo,B,E,N,ymin){
  _ia.subVectors(T,A);let d=_ia.length();if(d<1e-6){_ia.set(0,-1,0);d=1e-6;}else _ia.divideScalar(d);
  const dd=clamp(d,Math.abs(L1-L2)+1e-4,(L1+L2)*.9995);
  N.copy(polo).addScaledVector(_ia,-polo.dot(_ia));
  if(N.lengthSq()<1e-10){N.set(0,0,1).addScaledVector(_ia,-_ia.z);if(N.lengthSq()<1e-10)N.set(1,0,0);}
  N.normalize();
  const ca=(L1*L1+dd*dd-L2*L2)/(2*L1*dd),sa=Math.sqrt(Math.max(0,1-ca*ca));
  /* piso: si el codo o la rodilla quedarían por debajo de ymin, el plano de doblez gira sobre el eje
     (lo mínimo necesario) para que la articulación quede arriba */
  if(ymin!==undefined){const cy=A.y+_ia.y*L1*ca,r=L1*sa;
    if(cy+r*N.y<ymin&&r>1e-4){_ib.crossVectors(_ia,N);const R=Math.hypot(N.y,_ib.y);
      if(R>1e-6){const k=(ymin-cy)/(r*R),f0=Math.atan2(_ib.y,N.y);let f;
        if(k>=1)f=f0;else{const ac=Math.acos(Math.max(-1,k)),f1=envol(f0-ac),f2=envol(f0+ac);f=Math.abs(f1)<Math.abs(f2)?f1:f2;}
        const c=Math.cos(f),s=Math.sin(f);N.multiplyScalar(c).addScaledVector(_ib,s).normalize();}}}
  B.copy(A).addScaledVector(_ia,L1*ca).addScaledVector(N,L1*sa);E.copy(A).addScaledVector(_ia,dd);
}

function nuevaPose(){
  const m=()=>({p:new V3(),q:new Q4(),polo:new V3(0,-1,0)});
  return {pel:new V3(),pelQ:new Q4(),col:new Q4(),pec:new Q4(),cue:new Q4(),cab:new Q4(),mano:[m(),m()],pie:[m(),m()],ded:[0,0,0],punta:[0,0]};
}
function copiarPose(o,a){
  o.pel.copy(a.pel);o.pelQ.copy(a.pelQ);o.col.copy(a.col);o.pec.copy(a.pec);o.cue.copy(a.cue);o.cab.copy(a.cab);
  for(let i=0;i<2;i++){o.mano[i].p.copy(a.mano[i].p);o.mano[i].q.copy(a.mano[i].q);o.mano[i].polo.copy(a.mano[i].polo);
    o.pie[i].p.copy(a.pie[i].p);o.pie[i].q.copy(a.pie[i].q);o.pie[i].polo.copy(a.pie[i].polo);o.punta[i]=a.punta[i];}
  o.ded[0]=a.ded[0];o.ded[1]=a.ded[1];o.ded[2]=a.ded[2];return o;
}
/* o = a mezclado con b (w=0 → a, w=1 → b). o puede ser a. manos/pies: qué partes mezclar */
function mezclarPose(o,a,b,w,manos=true,pies=true){
  if(w<=0){if(o!==a)copiarPose(o,a);return o;}
  o.pel.lerpVectors(a.pel,b.pel,w);o.pelQ.copy(a.pelQ).slerp(b.pelQ,w);
  o.col.copy(a.col).slerp(b.col,w);o.pec.copy(a.pec).slerp(b.pec,w);o.cue.copy(a.cue).slerp(b.cue,w);o.cab.copy(a.cab).slerp(b.cab,w);
  for(let i=0;i<2;i++){
    if(manos){const x=o.mano[i],y=a.mano[i],z=b.mano[i];x.p.lerpVectors(y.p,z.p,w);x.q.copy(y.q).slerp(z.q,w);x.polo.lerpVectors(y.polo,z.polo,w);}
    else if(o!==a){o.mano[i].p.copy(a.mano[i].p);o.mano[i].q.copy(a.mano[i].q);o.mano[i].polo.copy(a.mano[i].polo);}
    if(pies){const x=o.pie[i],y=a.pie[i],z=b.pie[i];x.p.lerpVectors(y.p,z.p,w);x.q.copy(y.q).slerp(z.q,w);x.polo.lerpVectors(y.polo,z.polo,w);o.punta[i]=lerp(a.punta[i],b.punta[i],w);}
    else if(o!==a){o.pie[i].p.copy(a.pie[i].p);o.pie[i].q.copy(a.pie[i].q);o.pie[i].polo.copy(a.pie[i].polo);o.punta[i]=a.punta[i];}
  }
  for(let i=0;i<3;i++)o.ded[i]=lerp(a.ded[i],b.ded[i],w);
  return o;
}
const _gq=new Q4();
/* gira una pose entera alrededor del eje Y que pasa por el origen del modelo */
function girarPose(o,ang){
  if(Math.abs(ang)<1e-5)return o;const q=qE(_gq,0,ang,0);
  o.pel.applyQuaternion(q);o.pelQ.premultiply(q);
  for(let i=0;i<4;i++){const m=i<2?o.mano[i]:o.pie[i-2];m.p.applyQuaternion(q);m.q.premultiply(q);m.polo.applyQuaternion(q);}
  return o;
}

/* ---------- resolución: de la pose a las transformaciones de los huesos ---------- */
function cadena(P,Q,i,local){const p=PADRE[i];Q[i].copy(Q[p]).multiply(local);P[i].copy(OFF[i]).applyQuaternion(Q[p]).add(P[p]);}
function resolverColumna(st,sp,conCabeza=true){
  const P=st.P,Q=st.Q;P[H.cadera].copy(sp.pel);Q[H.cadera].copy(sp.pelQ);
  cadena(P,Q,H.columna,sp.col);cadena(P,Q,H.pecho,sp.pec);
  if(conCabeza){cadena(P,Q,H.cuello,sp.cue);cadena(P,Q,H.cabeza,sp.cab);}
}
/* puntos del borceguí para no hundirlo: del pie (marco del tobillo) y de la puntera (marco de la base de los dedos, que se dobla aparte) */
const PUNTOS_PIE=[[0,-.085,-.08],[0,-.085,.12],[0,.05,0],[0,.06,.1],[.053,-.085,-.09],[-.053,-.085,-.09],[.053,-.085,.12],[-.053,-.085,.12],[0,-.07,-.1],[.06,.0,-.04],[-.06,.0,-.04]].map(a=>new V3(...a));
const PUNTOS_PUNTA=[[0,-.025,.08],[0,.035,.085],[.05,-.025,.04],[-.05,-.025,.04]].map(a=>new V3(...a));
const _rqp=new Q4(),_ra=new V3(),_rb=new V3(),_rc=new V3(),_rd=new V3(),_rn=new V3(),_rg=new V3(),_rq=new Q4();
function resolverMiembros(st,sp){
  const P=st.P,Q=st.Q;
  for(let l=0;l<2;l++){                                    /* brazos: 0 izquierdo, 1 derecho */
    const b=l?H.brazoD:H.brazoI,a=b+1,m=b+2,h=sp.mano[l];
    _ra.copy(OFF[b]);_ra.x*=st.kx;_ra.applyQuaternion(Q[H.pecho]).add(P[H.pecho]);
    /* el hombro se adelanta (hasta 4,5 cm) cuando la mano queda lejos: la clavícula */
    _rg.subVectors(h.p,_ra);const d=_rg.length(),alc=(L_BRAZO+L_ANTEBRAZO)*.96;
    if(d>alc)_ra.addScaledVector(_rg,Math.min(.045,d-alc)/d);
    ik2(_ra,h.p,L_BRAZO,L_ANTEBRAZO,h.polo,_rb,_rc,_rn,.062);
    _rn.negate();                                          /* el pliegue del codo mira al lado contrario del codo */
    P[b].copy(_ra);_rg.subVectors(_rb,_ra);qSeg(Q[b],_rg,_rn);
    P[a].copy(_rb);_rg.subVectors(_rc,_rb);qSeg(Q[a],_rg,_rn);
    P[m].copy(_rc);Q[m].copy(h.q);
  }
  cadena(P,Q,H.dedosI,qE(_rq,0,0,-sp.ded[0]));cadena(P,Q,H.dedosI2,qE(_rq,0,0,-sp.ded[1]));cadena(P,Q,H.indiceD,qE(_rq,0,0,sp.ded[2]));
  for(let l=0;l<2;l++){                                    /* piernas */
    const t=l?H.musloD:H.musloI,s=t+1,p=t+2,f=sp.pie[l];
    /* el borceguí nunca entra en el piso: si algún punto del pie quedaría abajo, sube el tobillo */
    let my=1;for(const q of PUNTOS_PIE){_rg.copy(q).applyQuaternion(f.q);my=Math.min(my,_rg.y);}
    _rq.copy(f.q).multiply(qE(_rqp,sp.punta[l],0,0));_rd.copy(OFF[t+3]).applyQuaternion(f.q);
    for(const q of PUNTOS_PUNTA){_rg.copy(q).applyQuaternion(_rq).add(_rd);my=Math.min(my,_rg.y);}
    if(f.p.y+my<.002)f.p.y=.002-my;
    _ra.copy(OFF[t]).applyQuaternion(Q[H.cadera]).add(P[H.cadera]);
    ik2(_ra,f.p,L_MUSLO,L_PIERNA,f.polo,_rb,_rc,_rn,.08);
    P[t].copy(_ra);_rg.subVectors(_rb,_ra);qSeg(Q[t],_rg,_rn);
    P[s].copy(_rb);_rg.subVectors(_rc,_rb);qSeg(Q[s],_rg,_rn);
    P[p].copy(_rc);Q[p].copy(f.q);
    cadena(P,Q,t+3,qE(_rq,sp.punta[l],0,0));
  }
}

/* pie apoyado: dado el punto de apoyo (proyección del tobillo con el pie plano), el rumbo y el
   cabeceo (positivo: talón arriba, pivota en la base de los dedos; negativo: punta arriba, pivota en el talón),
   escribe el tobillo y la orientación del pie */
const _pa=new V3(),_pq=new Q4(),BOLA=new V3(0,-.06,.135),TALON=new V3(0,-.078,-.07);
function piePlantado(f,x,y,z,rumbo,cabeceo,giroExtra=0){
  qE(f.q,0,rumbo,0);
  const piv=cabeceo>=0?BOLA:TALON;
  _pa.copy(piv).applyQuaternion(f.q);                       /* pivote con el pie plano */
  qE(_pq,cabeceo,rumbo,giroExtra);
  f.p.set(x,y+ALTO_TOBILLO,z).add(_pa);                      /* punto del pivote en el mundo del modelo */
  _pa.copy(piv).applyQuaternion(_pq);f.p.sub(_pa);f.q.copy(_pq);
}
