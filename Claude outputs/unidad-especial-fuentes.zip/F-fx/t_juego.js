/* Pruebas de F adentro del juego 1.16.0 (juego_fx.html = v116/base.html + patch_fx.py).
   Una sola corrida: partida normal 30 s · funciones a mano en el retén · sonido · costo · capturas.
   Resultados en pruebas_juego.json (se va escribiendo a medida que avanza). Uso: node t_juego.js [sin-capturas] */
const H=require('../harness.js');
const fs=require('fs');
const OUT=__dirname+'/pruebas_juego.json',CAP=__dirname+'/capturas/';
const SIN_CAPTURAS=process.argv.includes('sin-capturas');
const R={};
const log=(k,v)=>{R[k]=v;fs.writeFileSync(OUT,JSON.stringify(R,null,1));console.log('['+k+']',JSON.stringify(v).slice(0,600));};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

/* ayudantes que viven ADENTRO del juego (ven sus variables) */
const AYUDA=`(()=>{
  const V=(x,y,z)=>new THREE.Vector3(x,y,z);
  const U=window.__U={V,
    snd:()=>({made:AUD.made,reaped:AUD.reaped,voices:AUD.voices,loose:AUD.loose,dropped:AUD.dropped,peak:AUD.peak}),
    /* punto del soldado (arma a 1,4 m sobre el piso) */
    sol:(x,z)=>V(x,floorAt(x,z)+1.4,z),
    /* bala que pasa a 'off' metros a la derecha (+) o izquierda (−) de la cámara y sigue 20 m */
    pasa:(a,off)=>{const c=camera.position,r=V(Math.cos(P.yaw),0,-Math.sin(P.yaw)),p=c.clone().addScaledVector(r,off),d=p.clone().sub(a).normalize();return p.addScaledVector(d,20);},
    hud:()=>{const q=s=>document.querySelector(s),det=q('#ueDet'),vis=q('#ueVisto');
      return {lineas:[...document.querySelectorAll('#ueRadio .ue-rl')].map(e=>(e.classList.contains('pel')?'[PEL] ':'')+e.textContent+(e.classList.contains('in')?'':' (entrando)')),
        det:det.style.display==='none'?'oculto':{color:det.style.color,op:det.style.opacity,rot:det.getAttribute('transform')||'-',d:q('#ueDet .rell').getAttribute('d')},
        visto:vis.style.display==='none'?'':'TE VIERON op '+vis.style.opacity,
        golpes:[...document.querySelectorAll('#ueGolpes path')].filter(e=>e.style.display!=='none').map(e=>e.getAttribute('transform')+' op'+e.style.opacity),
        granadas:[...document.querySelectorAll('#ueGranadas .gr')].filter(e=>e.style.display!=='none').map(e=>e.getAttribute('class')+' | '+e.textContent+' | '+e.lastChild.getAttribute('transform')+' | op'+e.style.opacity)};}};
  /* soldados de mentira en el retén: posiciones reales (autos 779, 781, 786 de la fila; veredas N y S) */
  const rumboA=(x,z)=>Math.atan2(P.pos.x-x,P.pos.z-z);
  U.D={soldados:[
    {id:1,nombre:'Ceniza 1',rol:'jefe',esc:'Ceniza',x:-439.5,z:600.5,rumbo:0,estado:'cubierto',postura:'agachado',hp:100,ficha:false,ve:true,suprimido:false,camino:[],cob:{x:-439.5,z:600.5},blanco:'jugador'},
    {id:2,nombre:'Ceniza 2',rol:'asalto',esc:'Ceniza',x:-421,z:618.6,rumbo:Math.PI/2,estado:'flanquear',postura:'pie',hp:80,ficha:false,ve:false,suprimido:false,camino:[{x:-412,z:619},{x:-402,z:619.5},{x:-396,z:618.5}],cob:{x:-396,z:618.5},blanco:'jugador'},
    {id:3,nombre:'Ceniza 3',rol:'granadero',esc:'Ceniza',x:-419.5,z:614.5,rumbo:0,estado:'lanzar',postura:'pie',hp:100,ficha:true,ve:true,suprimido:false,camino:[],cob:{x:-419.5,z:614.5},blanco:'jugador'},
    {id:4,nombre:'Ceniza 4',rol:'tirador',esc:'Ceniza',x:-452,z:596.5,rumbo:0,estado:'asomado',postura:'agachado',hp:100,ficha:true,ve:true,suprimido:false,camino:[],cob:{x:-452,z:596.5},blanco:'jugador',laser:{x:0,y:1.3,z:0}},
    {id:5,nombre:'Tizón 1',rol:'jefe',esc:'Tizón',x:-458,z:601,rumbo:0,estado:'muerto',postura:'tierra',hp:0,ficha:false,ve:false,suprimido:false,camino:[],cob:null,blanco:null},
    {id:6,nombre:'Tizón 2',rol:'asalto',esc:'Tizón',x:-466,z:606,rumbo:Math.PI/2,estado:'buscar',postura:'pie',hp:100,ficha:false,ve:false,suprimido:false,camino:[{x:-455,z:607},{x:-445,z:609}],cob:null,blanco:null},
    {id:7,nombre:'Tizón 3',rol:'granadero',esc:'Tizón',x:-462,z:612.5,rumbo:1.2,estado:'recargar',postura:'agachado',hp:55,ficha:false,ve:false,suprimido:true,camino:[],cob:{x:-462,z:612.5},blanco:null},
    {id:8,nombre:'Tizón 4',rol:'tirador',esc:'Tizón',x:-470,z:609,rumbo:Math.PI/2,estado:'llegando',postura:'pie',hp:100,ficha:false,ve:false,suprimido:false,camino:[{x:-460,z:608}],cob:null,blanco:null}],
   escuadrones:[{nombre:'Ceniza',estado:'combate',uc:{x:0,z:0,edad:4.2},fichas:2,orden:'base de fuego',sinJefe:false,refuerzoEn:22},
                {nombre:'Tizón',estado:'busqueda',uc:{x:0,z:0,edad:4.2},fichas:0,orden:'barrido',sinJefe:true,refuerzoEn:null}],
   jugador:{x:0,z:0},granadas:[{x:-396.5,z:605,t:1.8}]};
  /* la debug de mentira sigue al jugador como la de verdad: rumbos hacia él, último lugar conocido a ~3,4 m */
  U.debug=()=>{const D=U.D;D.jugador.x=P.pos.x;D.jugador.z=P.pos.z;
    for(const s of D.soldados)if(s.estado!=='muerto'&&s.estado!=='flanquear'&&s.estado!=='buscar'&&s.estado!=='llegando')s.rumbo=rumboA(s.x,s.z);
    for(const e of D.escuadrones){e.uc.x=P.pos.x-1.5;e.uc.z=P.pos.z+3.1;}
    const t=D.soldados[3];t.laser.x=P.pos.x;t.laser.z=P.pos.z;return D;};
  return 'ok';})()`;

(async()=>{
  const t0=Date.now();
  const h=await H.open(__dirname+'/juego_fx.html',{width:1280,height:720});
  const ev=h.ev,err=()=>h.errors.slice();
  try{
    log('carga',{s:(Date.now()-t0)/1000,errores:err(),
      tipos:await ev("[typeof UEFX,typeof UESND,typeof UEHUD,typeof UEDBG,'modo '+UEDBG.modo,typeof GRAN,UEB.debug()===null?'debug null':'debug ?'].join(' · ')"),
      ayuda:await ev("[...document.querySelectorAll('#scr-start dd')].map(e=>e.textContent).filter(t=>/táctica/.test(t)).join('|')"),
      contrato:await ev("JSON.stringify({UEFX:Object.keys(UEFX),UESND:Object.keys(UESND),UEHUD:Object.keys(UEHUD),UEDBG:Object.keys(UEDBG),largos:{trazadora:UEFX.trazadora.length,impacto:UEFX.impacto.length,sangre:UEFX.sangre.length,radio:UEHUD.radio.length,alerta:UEHUD.alerta.length,golpe:UEHUD.golpe.length}})")});
    await h.start();
    await ev(AYUDA);

    /* ===== 1 · partida normal de 30 s con oleadas (sin tocar nada) ===== */
    {const a=await h.step(30);
      log('normal30',{...a,errores:err(),juego:await ev("({oleada:wave,bichos:enemies.length,hp:Math.round(P.hp),over,running,STAGE,fx:UEFX.vivos,ac:!!AC})")});}

    /* ===== 2 · al retén, limpio ===== */
    await h.start();await h.alReten(-392,609);await h.step(1);
    log('reten',await ev("({pos:[+P.pos.x.toFixed(2),+P.pos.y.toFixed(3),+P.pos.z.toFixed(2)],cam:[+camera.position.x.toFixed(2),+camera.position.y.toFixed(2),+camera.position.z.toFixed(2)],piso:+floorAt(P.pos.x,P.pos.z).toFixed(3),bichos:enemies.length})"));

    /* --- 2a · sonido con AC nulo: no tiene que fallar ni crear nada --- */
    log('ac_nulo',await ev(`(()=>{const U=__U,a=AUD.made;let e='';try{const p=U.sol(-420,612);
      UESND.disparo('fusil',p);UESND.disparo('escopeta',p);UESND.disparo('tirador',p);UESND.silbido(.5);UESND.radio(2,1.5,p);UESND.radio(3,1);UESND.pasos(p,1);UESND.equipo(p);UESND.cuerpo(p);UESND.impacto(p,'metal');
      UEFX.trazadora(p,U.pasa(p,.7),'fusil');UEFX.impacto(U.V(-398,.6,604.6),null,'metal');UESND.pausa(true);UESND.reset();}catch(x){e=String(x);}return {AC:AC,nodos:AUD.made-a,error:e};})()`));

    /* --- 2b · trazadoras con valores reales: impactos al jugador, roces, lejos y de cerca --- */
    log('trazadoras',await ev(`(()=>{const U=__U,c=camera.position,out={};const orig=UESND.silbido;let silb=[];UESND.silbido=function(pan){silb.push(+pan.toFixed(2));return orig.apply(this,arguments);};
      const S1=U.sol(-439.5,600.5),S4=U.sol(-452,596.5),S3=U.sol(-419.5,614.5),cerca=U.sol(P.pos.x-3.5,P.pos.z+1.5);
      const caso=(k,a,b,tipo)=>{silb=[];UEFX.trazadora(a,b,tipo);UEFX.update(1/60);out[k]={silbido:silb.slice(),cuadraditos:UEFX.vivos};};
      caso('pega_al_pecho',S1,U.V(c.x,c.y-.35,c.z),'fusil');
      caso('roza_derecha_0,7m',S1,U.pasa(S1,.7),'fusil');
      caso('roza_izquierda_0,9m',S4,U.pasa(S4,-.9),'tirador');
      caso('pasa_a_3m',S3,U.pasa(S3,3),'fusil');
      caso('tirador_a_3,8m',cerca,U.pasa(cerca,.6),'fusil');
      silb=[];for(let i=0;i<8;i++)UEFX.trazadora(S3,U.pasa(S3,-1.2+i*.3),'escopeta');out.escopeta_8_perdigones={silbido:silb.slice()};
      UEFX.update(1/60);out.cuadraditos_con_todo=UEFX.vivos;UEFX.update(.2);out.a_los_200ms=UEFX.vivos;
      UESND.silbido=orig;out.recientes=UEFX.recientes.filter(r=>r.t===T).length;return out;})()`));

    /* --- 2c · impactos y sangre; chispas sobre la calzada (piso −0,15) --- */
    log('impactos',await ev(`(()=>{const U=__U,vivas=()=>parts.filter(q=>q.alive).length,out={};UEFX.reset();
      const p0=vivas();UEFX.impacto(U.V(-398.5,.7,604.6),U.V(1,0,0),'metal');UEFX.update(1/60);out.metal={cuadraditos:UEFX.vivos,particulas:vivas()-p0};
      let p1=vivas();UEFX.impacto(U.V(-410,1.6,591.6),U.V(0,0,1),'pared');out.pared={particulas:vivas()-p1};
      p1=vivas();UEFX.impacto(U.V(-395,floorAt(-395,611),611),null,'piso');out.piso={particulas:vivas()-p1};
      p1=vivas();UEFX.impacto(U.V(-405,.8,612),null,'carne');out.carne={particulas:vivas()-p1};
      p1=vivas();const d0=decals.filter(d=>d.m.visible).length;for(let i=0;i<4;i++)UEFX.sangre(U.V(-404,1.2,610),U.V(-.7,0,.7));out.sangre_x4={particulas:vivas()-p1,manchas_piso:decals.filter(d=>d.m.visible).length-d0};
      UEFX.update(1/60);out.cuadraditos=UEFX.vivos;
      /* chispas: impacto de metal a 0,35 m sobre la calzada con la normal hacia abajo: a los 0,1 s ya rebotaron.
         Con el piso real rebotan en −0,13 (la cola de cada rayita baja un poco más); con el piso viejo rebotarían en +0,02 */
      UEFX.reset();UEFX.impacto(U.V(-394,.35,612),U.V(0,-1,0),'metal');for(let i=0;i<6;i++)UEFX.update(1/60);
      const pos=UEFX.malla.geometry.attributes.position.array,n=UEFX.vivos*4;let mn=1e9;for(let i=0;i<n;i++)mn=Math.min(mn,pos[i*3+1]);
      out.chispas_y_min=+mn.toFixed(3);out.piso_ahi=+floorAt(-394,612).toFixed(3);UEFX.reset();return out;})()`));

    /* --- 2d · subtítulos de radio --- */
    await ev("UEHUD.radio('Ceniza 1','Contacto. Testigo al frente.');UEHUD.radio('Ceniza 4','Lo tengo en la mira.','tirador_mira');UEHUD.radio('Ceniza 3','¡Granada va!');UEHUD.radio({nombre:'Tizón 1'},'Tizón en camino. Treinta segundos.');UEHUD.radio('Ceniza 2','Está recargando. ¡Voy!','recarga_jugador');1");
    await h.step(.1);const r1=await ev("__U.hud().lineas");
    await h.step(2.6);const r2=await ev("__U.hud().lineas");await h.step(4);const r3=await ev("__U.hud().lineas");
    log('radio_hud',{a_0_1s:r1,a_2_7s:r2,a_6_7s:r3});

    /* --- 2e · detección: sube de 0 a 1 en 2 s desde la derecha, pasa a combate, gira el jugador, se calma --- */
    {const m=[];m.push(['inicio',await ev("__U.hud().det")]);
      await ev("window.__T0=T;1");   // rampa continua: nivel = (T−T0)/2, de 0 a 1 en 2 s, desde 0,6 rad a la derecha
      for(let i=1;i<=4;i++){await h.step(.5,1/60,"UEHUD.alerta(Math.min(1,(T-window.__T0)/2),0.6,false)");m.push(['t '+(i*.5)+' s',await ev("({det:__U.hud().det,visto:__U.hud().visto})")]);}
      await h.step(.3,1/60,"UEHUD.alerta(1,0.6,true)");m.push(['combate 0,3 s',await ev("({det:__U.hud().det,visto:__U.hud().visto})")]);
      await h.ev("P.yaw+=0.3;1");await h.step(.4);m.push(['giró 0,3 rad a la izq (espera rot ≈ 51,6°)',await ev("__U.hud().det.rot")]);
      await h.step(3.2,1/60,"UEHUD.alerta(1,null,true)");m.push(['combate 3,9 s, sin dirección',await ev("({det:__U.hud().det,visto:__U.hud().visto})")]);
      await h.ev("P.yaw-=0.3;UEHUD.alerta(0,null,false);1");await h.step(1.2);m.push(['calma 1,2 s',await ev("__U.hud().det")]);
      /* lo que lee solo si el integrador llena UEB.estado */
      await ev("window.__est0=UEB.estado;UEB.estado=()=>({alerta:.8,ang:-.5,combate:false,vivos:4});1");await h.step(.6);m.push(['UEB.estado 0,8 a −0,5 rad',await ev("__U.hud().det")]);
      /* la forma que devuelve UE.estado() de la IA: {sospecha,x,z,combate}; tiene que apuntar al soldado (Ceniza 4: 0,205 rad = 11,8°) */
      await ev("UEB.estado=()=>({sospecha:.6,x:-452,z:596.5,angulo:0,combate:false,busqueda:false,quedan:4});1");await h.step(.6);m.push(['UEB.estado con la forma de UE.estado() (sospecha 0,6, Ceniza 4)',await ev("__U.hud().det")]);
      await ev("UEB.estado=window.__est0;UEHUD.alerta(0,null,false);1");await h.step(1.5);
      log('deteccion',m);}

    /* --- 2f · golpes desde cuatro lados y desde un soldado --- */
    await ev("UEHUD.golpe(0);UEHUD.golpe(Math.PI/2);UEHUD.golpe(Math.PI);UEHUD.golpe(-Math.PI/2);1");await h.step(.1);const g1=await ev("__U.hud().golpes");
    await ev("UEHUD.golpe(0.1);1");const g2=await ev("__U.hud().golpes.length");
    await h.step(.8);const g3=await ev("__U.hud().golpes");
    await ev("UEHUD.golpeDesde(-452,596.5);1");await h.step(.05);const g4=await ev("({golpes:__U.hud().golpes,angulo:+UEHUD.angulo(-452,596.5).toFixed(3)})");await h.step(1);
    log('golpes',{cuatro_lados:g1,otro_desde_0_1rad_reusa:g2,a_los_0_9s:g3,desde_Ceniza4:g4});

    /* --- 2g · aviso de granada con un GRAN de mentira (granada a 6 m adelante a la derecha) --- */
    {const m=[];
      await ev("window.GRAN={lista:[{p:new THREE.Vector3(P.pos.x-4.5,floorAt(P.pos.x-4.5,P.pos.z-4)+.05,P.pos.z-4),v:new THREE.Vector3(),t:2.6,de:{},tipo:'frag'}]};1");
      for(let i=0;i<6;i++){await h.step(.1,1/60,"GRAN.lista[0].t=Math.max(0,GRAN.lista[0].t-1/60)");m.push(await ev("__U.hud().granadas"));}
      const blinks=await ev(`(()=>{let c=0,prev='';for(let i=0;i<60;i++){GRAN.lista[0].t=Math.max(0,GRAN.lista[0].t-1/60);UEHUD.update(1/60);const o=document.querySelector('#ueGranadas .gr').style.opacity;if(o!==prev){c++;prev=o;}}return c;})()`);
      await ev("GRAN.lista[0].p.set(P.pos.x+.5,P.pos.y,P.pos.z+.6);GRAN.lista[0].t=.5;1");await h.step(.05);m.push(await ev("__U.hud().granadas"));
      await ev("GRAN.lista[0].p.set(P.pos.x+20,0,P.pos.z);1");await h.step(.05);m.push(await ev("__U.hud().granadas"));
      await ev("GRAN.lista.push({p:new THREE.Vector3(P.pos.x,0,P.pos.z+5),v:new THREE.Vector3(),t:3,de:'jugador',tipo:'frag'},{p:new THREE.Vector3(P.pos.x-3,0,P.pos.z),v:new THREE.Vector3(),t:3,de:{},tipo:'humo'});1");await h.step(.05);m.push(await ev("__U.hud().granadas"));
      await ev("delete window.GRAN;1");await h.step(.05);m.push(await ev("__U.hud().granadas"));
      log('granada',{muestras:m,cambios_de_parpadeo_en_1s_con_poca_mecha:blinks});}

    /* --- 2h · vista táctica sin escuadrón, con error y con la debug de mentira (sin captura) --- */
    {const m={};await h.page.keyboard.press('F2');await h.step(.3);
      m.f2=await ev("({modo:UEDBG.modo,hidden:$('#ueTac').hidden,texto:$('#ueTac .ue-tx').textContent.slice(0,80),cab:$('#ueTac .ue-cab span').textContent})");
      await ev("UEB.debug=()=>{throw new Error('prueba')};1");await h.step(.3);m.error=await ev("$('#ueTac .ue-tx').textContent.slice(0,60)");
      await ev("UEB.debug=__U.debug;1");await h.step(.3);m.con_debug=await ev("$('#ueTac .ue-tx').textContent.slice(0,700)");
      const sp0=await ev("P.sprintOn");await h.page.keyboard.press('Shift+F2');await h.step(.3);
      m.shift_f2=await ev(`({modo:UEDBG.modo,clase:$('#ueTac').className,sprint_antes:${sp0},sprint_despues:P.sprintOn,cab:$('#ueTac .ue-cab span').textContent,filas:document.querySelectorAll('#ueTac tr').length})`);
      await h.page.keyboard.press('Shift+F2');await h.step(.1);m.vuelve=await ev("UEDBG.modo");
      await h.page.keyboard.press('F2');await h.step(.1);m.apaga=await ev("({modo:UEDBG.modo,hidden:$('#ueTac').hidden})");
      log('tactica',m);}

    /* --- 2i · pausa y reset dejan todo limpio --- */
    log('reset',await ev(`(()=>{UEHUD.radio('Ceniza 1','Me muevo.');UEHUD.alerta(.7,.3,false);UEHUD.golpe(1);window.GRAN={lista:[{p:new THREE.Vector3(P.pos.x+3,0,P.pos.z),v:new THREE.Vector3(),t:2,de:{},tipo:'frag'}]};
      UEFX.trazadora(__U.sol(-439,600),__U.pasa(__U.sol(-439,600),.8),'tirador');UEFX.impacto(__U.V(-398.5,.7,604.6),null,'metal');for(let i=0;i<10;i++){UEFX.update(1/60);UEHUD.update(1/60);}
      const antes={fx:UEFX.vivos,hud:__U.hud()};delete window.GRAN;resetGame();UEFX.update(1/60);UEHUD.update(1/60);
      return {antes,despues:{fx:UEFX.vivos,hud:__U.hud(),recientes:UEFX.recientes.filter(r=>r.t>-9).length}};})()`));
    await h.start();await h.alReten(-392,609);await h.step(.5);await ev(AYUDA);

    /* ===== 3 · sonido con AC activo ===== */
    log('audio_ini',await ev("(()=>{initAudio();return {AC:!!AC,estado:AC&&AC.state,sr:AC&&AC.sampleRate,t:AC&&AC.currentTime};})()"));
    await sleep(800);
    log('audio_reloj',await ev("({estado:AC.state,t:+AC.currentTime.toFixed(3),voces:AUD.voices,nodos:AUD.made,sueltos:AUD.loose})"));
    {const fns=[
        ['disparo fusil 10 m',"UESND.disparo('fusil',__U.sol(P.pos.x-10,P.pos.z))"],
        ['disparo fusil 40 m',"UESND.disparo('fusil',__U.sol(P.pos.x-40,P.pos.z-3))"],
        ['disparo fusil 80 m',"UESND.disparo('fusil',__U.sol(P.pos.x-80,P.pos.z))"],
        ['disparo fusil 200 m',"UESND.disparo('fusil',__U.sol(P.pos.x-200,P.pos.z))"],
        ['disparo fusil 300 m (fuera de alcance)',"UESND.disparo('fusil',__U.sol(P.pos.x-300,P.pos.z))"],
        ['disparo escopeta 15 m (8 perdigones)',"for(let i=0;i<8;i++)UESND.disparo('escopeta',__U.sol(P.pos.x-15,P.pos.z+2))"],
        ['disparo tirador 60 m',"UESND.disparo('tirador',__U.sol(P.pos.x-60,P.pos.z-12))"],
        ['silbido',"UESND.silbido(-.7)"],
        ['impacto metal 8 m',"UESND.impacto(__U.V(P.pos.x-8,.7,P.pos.z-4),'metal')"],
        ['impacto pared 8 m',"UESND.impacto(__U.V(P.pos.x-8,1.5,P.pos.z-4),'pared')"],
        ['impacto piso 8 m',"UESND.impacto(__U.V(P.pos.x-8,0,P.pos.z+2),'piso')"],
        ['impacto carne 8 m',"UESND.impacto(__U.V(P.pos.x-8,1,P.pos.z+2),'carne')"],
        ['radio 2 s sin lugar',"UESND.radio(3,2)"],
        ['radio 2,4 s desde 20 m',"UESND.radio(5,2.4,__U.sol(P.pos.x-20,P.pos.z+5))"],
        ['pasos 5 m caminando',"UESND.pasos(__U.V(P.pos.x-5,0,P.pos.z),1)"],
        ['pasos 5 m corriendo',"UESND.pasos(__U.V(P.pos.x-5,0,P.pos.z+1),1.4)"],
        ['pasos 20 m (no se oye)',"UESND.pasos(__U.V(P.pos.x-20,0,P.pos.z),1)"],
        ['equipo 4 m',"UESND.equipo(__U.V(P.pos.x-4,1,P.pos.z))"],
        ['cuerpo 12 m',"UESND.cuerpo(__U.V(P.pos.x-12,0,P.pos.z))"]];
      const s0=await ev("__U.snd()"),fil=[];
      for(const [k,c] of fns){const r=await ev(`(()=>{const a=__U.snd();let e='';const t0=performance.now();try{${c};}catch(x){e=String(x.stack||x).slice(0,200);}const ms=performance.now()-t0,b=__U.snd();return {nodos:b.made-a.made,fuentes_sonando:b.voices-a.voices,sueltos:b.loose-a.loose,descartados:b.dropped-a.dropped,ms:+ms.toFixed(2),error:e};})()`);fil.push([k,r]);await sleep(160);}
      await sleep(4200);const s1=await ev("__U.snd()");
      log('audio_funciones',{tabla:fil,errores:err(),balance:{creados:s1.made-s0.made,liberados:s1.reaped-s0.reaped,sueltos:s1.loose-s0.loose,voces_antes:s0.voices,voces_despues:s1.voices}});}

    /* 40 disparos en 2 s (8 tiradores de 10 a 90 m, mezcla de armas, la escopeta avisa por perdigón) */
    {await ev(`(()=>{const T8=[[-10,-3,'fusil'],[-18,6,'escopeta'],[-25,-8,'fusil'],[-33,9,'fusil'],[-47,-4,'tirador'],[-58,7,'fusil'],[-72,-9,'escopeta'],[-90,2,'fusil']];
        AUD.peak=AUD.voices;const r=window.__r40={tiros:0,max:0,a:__U.snd(),fin:false};let i=0;
        const mon=setInterval(()=>{if(AUD.voices>r.max)r.max=AUD.voices;},5);
        const id=setInterval(()=>{const q=T8[i%8],p=__U.sol(P.pos.x+q[0],P.pos.z+q[1]);if(q[2]==='escopeta')for(let k=0;k<8;k++)UESND.disparo('escopeta',p);else UESND.disparo(q[2],p);
          if(i%3===0)UEFX.trazadora(p,__U.pasa(p,(i%2?1:-1)*(.5+(i%4)*.3)),q[2]);r.tiros++;if(++i>=40){clearInterval(id);setTimeout(()=>{clearInterval(mon);r.b=__U.snd();r.fin=true;},300);}},50);return 1;})()`);
      await sleep(2700);const r40=await ev("window.__r40");await sleep(3500);const fin=await ev("__U.snd()");
      log('audio_40_tiros',{tiros:r40.tiros,voces_pico:r40.max,AUD_peak:await ev("AUD.peak"),topes_de_voces:'AU_TH=[70,110,170,∞] (prioridad 0,1,2,3)',
        descartados_por_compuerta:r40.b.dropped-r40.a.dropped,nodos:r40.b.made-r40.a.made,liberados_despues:fin.reaped-r40.a.reaped,voces_antes:r40.a.voices,voces_al_final:fin.voices,errores:err()});}

    /* pausa: corta la radio que esté sonando */
    log('audio_pausa',await ev(`(()=>{UESND.radio(1,4);const a=AUD.voices;setPaused(true);const ok=AUD.voices;setPaused(false);return {voces_con_radio:a,nota:'cortarRadios baja la ganancia a 0 en 30 ms; las fuentes terminan cuando estaba previsto (4 s)'};})()`));

    /* ===== 4 · costo ===== */
    log('costo_fx_hud',await ev(`(()=>{const U=__U,dt=1/60,N=900,S=[U.sol(-439.5,600.5),U.sol(-452,596.5),U.sol(-419.5,614.5),U.sol(-421,618.6),U.sol(-466,606)];
      const corre=(forzar)=>{const tt=[];let tz=0,ti=0;UEFX.reset();UEHUD.reset();
        for(let i=0;i<N;i++){
          if(i%2===0){const s=S[(i/2|0)%S.length],t0=performance.now();UEFX.trazadora(s,i%6===0?U.pasa(s,(i%4?1:-1)*.9):U.pasa(s,(i%3)-1+2.5),i%10===0?'tirador':i%7===0?'escopeta':'fusil');tz+=performance.now()-t0;}
          if(i%4===1){const t0=performance.now();UEFX.impacto(U.V(-398.5+(i%5),.5+(i%3)*.4,604.6),null,['metal','pared','piso'][i%3]);ti+=performance.now()-t0;}
          if(i%60===5)UEHUD.radio('Ceniza '+(1+i%4),'Fuego de cobertura.');
          if(i%20===7)UEHUD.golpe((i%7)-3);
          UEHUD.alerta(.5+.5*Math.sin(i/50),.6+.3*Math.sin(i/90),i%400>300);
          if(i%180===0)window.GRAN={lista:[{p:new THREE.Vector3(P.pos.x-4,0,P.pos.z+3),v:new THREE.Vector3(),t:3,de:{},tipo:'frag'}]};if(i%180===120)delete window.GRAN;
          const t0=performance.now();UEFX.update(dt);UEHUD.update(dt);if(forzar)document.body.offsetHeight;tt.push(performance.now()-t0);}
        delete window.GRAN;tt.sort((a,b)=>a-b);const m=tt.reduce((a,b)=>a+b,0)/N;
        return {ms_medio:+m.toFixed(4),mediana:+tt[N>>1].toFixed(3),p95:+tt[Math.floor(N*.95)].toFixed(3),p99:+tt[Math.floor(N*.99)].toFixed(3),max:+tt[N-1].toFixed(3),cuadros_mas_de_1ms:tt.filter(x=>x>1).length,trazadora_us:+(tz/(N/2)*1000).toFixed(1),impacto_us:+(ti/(N/4)*1000).toFixed(1),cuadraditos_al_final:UEFX.vivos};};
      corre(false);const a=corre(false),b=corre(true);
      const base=[];for(let i=0;i<N;i++){const t0=performance.now();document.body.offsetHeight;base.push(performance.now()-t0);}
      UEFX.reset();UEHUD.reset();
      return {res:'30 trazadoras/s (1 de cada 3 roza), 15 impactos/s, alerta moviéndose, golpes, radio, granada a ratos; 900 cuadros',
        solo_js:a,js_mas_estilos_y_diseno:b,diseno_sin_cambios_ms:+(base.reduce((x,y)=>x+y,0)/N).toFixed(4),apagado_ms_mediana_de_9_tandas:(()=>{const b=[];for(let k=0;k<9;k++){const t0=performance.now();for(let i=0;i<1000;i++){UEFX.update(dt);UEHUD.update(dt);}b.push((performance.now()-t0)/1000);}b.sort((x,y)=>x-y);return +b[4].toFixed(5);})()};})()`));

    log('costo_tactica',await ev(`(()=>{UEB.debug=__U.debug;const dt=1/60,N=600,cv=document.querySelector('#ueTac canvas'),g2=cv.getContext('2d');
      const mide=(modo)=>{UEDBG.poner(0);const tp=performance.now();UEDBG.poner(modo);const prender=performance.now()-tp;const tt=[];
        for(let i=0;i<N;i++){const t0=performance.now();UEDBG.update(dt);const t1=performance.now();tt.push(t1-t0);}
        /* con volcado: obliga a rasterizar lo dibujado (en la placa de Facu eso lo hace la GPU) */
        const tv=[];for(let i=0;i<N;i++){const t0=performance.now();UEDBG.update(dt);g2.getImageData(0,0,1,1);tv.push(performance.now()-t0);}
        const dib=tt.filter(x=>x>.02),s=tt.reduce((a,b)=>a+b,0),sv=tv.reduce((a,b)=>a+b,0);
        /* fondo: mover al jugador 11 m obliga a rehacerlo */
        const px=P.pos.x;let t0=performance.now();UEDBG.dibujar();const sinFondo=performance.now()-t0;P.pos.x+=11;t0=performance.now();UEDBG.dibujar();const conFondo=performance.now()-t0;P.pos.x=px;UEDBG.dibujar();
        dib.sort((a,b)=>a-b);
        return {prender_ms:+prender.toFixed(2),dibujo_mediana_ms:+(dib[dib.length>>1]||0).toFixed(3),cuadros_mas_de_2ms:tt.filter(x=>x>2).length,por_cuadro_ms:+(s/N).toFixed(4),por_cuadro_con_volcado_ms:+(sv/N).toFixed(4),dibujos:dib.length,por_dibujo_ms:+(dib.reduce((a,b)=>a+b,0)/Math.max(1,dib.length)).toFixed(3),max_ms:+Math.max(...tt).toFixed(3),
          dibujo_sin_fondo_ms:+sinFondo.toFixed(3),dibujo_rehaciendo_fondo_ms:+conFondo.toFixed(3),lienzo:cv.width+'x'+cv.height};};
      const chica=mide(1),grande=mide(2);UEDBG.poner(0);const t0=performance.now();for(let i=0;i<N;i++)UEDBG.update(dt);
      return {chica,grande,apagada_ms:+((performance.now()-t0)/N).toFixed(5)};})()`));
    log('errores_tras_costo',err());

    /* ===== 5 · capturas ===== */
    if(!SIN_CAPTURAS){
      await ev("SECG.A.visible=false;UEB.debug=__U.debug;1");
      /* j01: HUD en acción: radio (3, una de peligro) + detección a 0,65 desde el tirador + dos golpes + aviso de granada + trazadoras e impactos */
      await ev("UEHUD.reset();UEHUD.radio('Ceniza 1','Contacto. Testigo al frente.');UEHUD.radio('Ceniza 4','Lo tengo en la mira.','tirador_mira');UEHUD.radio('Ceniza 3','¡Granada va!','granada');1");
      await h.step(1.2,1/60,"UEHUD.alerta(.65,UEHUD.angulo(-452,596.5),false)");
      await ev(`(()=>{const U=__U;window.GRAN={lista:[{p:U.V(P.pos.x-4.5,floorAt(P.pos.x-4.5,P.pos.z-4)+.05,P.pos.z-4),v:U.V(0,0,0),t:2.2,de:{},tipo:'frag'}]};
        UEHUD.golpeDesde(-452,596.5);UEHUD.golpeDesde(-421,618.6);
        const S1=U.sol(-439.5,600.5),S3=U.sol(-419.5,614.5),S4=U.sol(-452,596.5);
        UEFX.trazadora(S1,U.pasa(S1,1.1),'fusil');UEFX.trazadora(S3,U.pasa(S3,-1.6),'fusil');UEFX.trazadora(S4,U.pasa(S4,2.2),'tirador');
        UEFX.impacto(U.V(-398.6,.75,604.9),U.V(1,0,0),'metal');UEFX.impacto(U.V(-397,floorAt(-397,612),612),null,'piso');UEFX.update(.03);return 1;})()`);
      await sleep(600);const ta=Date.now();await h.shot(CAP+'j01_hud.png');log('captura_j01',{s:(Date.now()-ta)/1000,hud:await ev("__U.hud()")});
      /* j02: vista táctica chica (F2) con combate (arco rojo, TE VIERON) */
      await h.page.keyboard.press('F2');
      await ev("GRAN.lista[0].t=2.2;UEHUD.radio('Ceniza 2','Voy por derecha.');UEHUD.radio('Tizón 1','Tizón en posición.');1");
      await h.step(.6,1/60,"UEHUD.alerta(1,UEHUD.angulo(-439.5,600.5),true)");
      await sleep(600);const tb=Date.now();await h.shot(CAP+'j02_tactica_chica.png');log('captura_j02',{s:(Date.now()-tb)/1000,modo:await ev("UEDBG.modo"),hud:await ev("__U.hud()"),medidas:await ev(`(()=>{const caja=(sel)=>{const e=document.querySelector(sel);if(!e)return null;const r=e.getBoundingClientRect();return [Math.round(r.left),Math.round(r.top),Math.round(r.right),Math.round(r.bottom)];};
        const cab=document.querySelector('#ueTac .ue-cab span'),filas=[...document.querySelectorAll('#ueTac tr')].map(t=>Math.round(t.getBoundingClientRect().height));
        return {tac:caja('#ueTac'),lienzo:caja('#ueTac canvas'),armas:caja('#wslots'),radio:caja('#ueRadio'),salud:caja('.health'),cab_cortada:cab.scrollWidth>cab.clientWidth+1,cab:cab.textContent,altos_filas_tabla:filas,
          texto:document.querySelector('#ueTac .ue-tx').scrollHeight+' de alto'};})()`)});
      /* j03: vista táctica grande (Shift+F2) */
      await h.page.keyboard.press('Shift+F2');await h.step(.3);
      await sleep(600);const tc=Date.now();await h.shot(CAP+'j03_tactica_grande.png');log('captura_j03',{s:(Date.now()-tc)/1000,modo:await ev("UEDBG.modo"),medidas:await ev(`(()=>{const caja=(sel)=>{const e=document.querySelector(sel);if(!e)return null;const r=e.getBoundingClientRect();return [Math.round(r.left),Math.round(r.top),Math.round(r.right),Math.round(r.bottom)];};
        const cab=document.querySelector('#ueTac .ue-cab span'),filas=[...document.querySelectorAll('#ueTac tr')].map(t=>Math.round(t.getBoundingClientRect().height));
        return {tac:caja('#ueTac'),lienzo:caja('#ueTac canvas'),armas:caja('#wslots'),radio:caja('#ueRadio'),salud:caja('.health'),cab_cortada:cab.scrollWidth>cab.clientWidth+1,cab:cab.textContent,altos_filas_tabla:filas,
          texto:document.querySelector('#ueTac .ue-tx').scrollHeight+' de alto'};})()`)});
      await h.page.keyboard.press('F2');
    }
    log('fin',{s:(Date.now()-t0)/1000,errores:err()});
  }catch(e){log('FALLA',String(e&&e.stack||e).slice(0,1500));log('errores',err());}
  finally{await h.close();}
})();
