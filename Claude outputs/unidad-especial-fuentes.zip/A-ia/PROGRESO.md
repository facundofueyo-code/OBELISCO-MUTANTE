# PROGRESO — A-ia (IA de escuadrón)

## Hecho
- `ue_ia.js` completo (borrador p1–p6 corregido + p7: cerebro de escuadrón y API 4.7).
- `sim/mundo.js` (sirve en navegador), `sim/verificar.js`, `sim/jugadores.js`, `sim/correr.js`, `sim/dibujar.py`, `sim/prueba_modelo.js`.
- 10/10 verificaciones OK en 12 semillas × 11 escenarios y en 30 semillas.
- Trazas en `trazas/` (a, c, e, f0, g12). Afinado hecho (ver INFORME.md §6). INFORME.md escrito.

## Falta / dudoso
- Ver INFORME.md §7 (disposición provisoria ciega desde los puestos, dispersión de f0, fusil del jugador, sin probar en navegador real).
