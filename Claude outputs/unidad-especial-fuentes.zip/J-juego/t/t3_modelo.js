// Prueba 3 (el modelo obedece a la IA) y 6 (costo con 8 soldados en combate cerca del jugador).
const H=require('../../harness.js'),fs=require('fs');
const INST=require('./inst.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
const OUT=process.argv[3]||__dirname+'/t3.json';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto');const R={};const ev=c=>h.ev(c);
  try{
    await h.start();await ev("RETEN.ir({bichos:false});1");await ev(INST);await h.step(.5);
    /* A. convención: un modelo suelto, girado 0,7 rad, con las entradas como las escribe la IA (escribirVista) */
    R.conv=await ev(`(()=>{const angN=a=>Math.atan2(Math.sin(a),Math.cos(a)),deg=a=>+(a*180/Math.PI).toFixed(1);
      const u=UEM.crear('jefe',{semilla:5});_sceneAdd(u.root);const th=.7,x=-300,z=640;u.root.position.set(x,floorAt(x,z),z);u.root.rotation.y=th;
      const e=u.e;e.apunta=1;const o=new V3(),b=new V3(),o0=new V3(),R={dir:[],cano:[]};const qg=new THREE.Quaternion(),c=new V3();const run=n=>{for(let i=0;i<n;i++)u.update(1/60);};
      for(const [n,my,mp] of [['frente',0,0],['izquierda',.8,0],['derecha',-.8,0],['arriba',0,.5],['abajo',0,-.5],['izq+arriba',1.1,.6],['der+abajo',-1.1,-.6]]){
        e.mYaw=my;e.mPitch=mp;run(90);u.ojos(o);u.boca(b);const dx=b.x-o.x,dy=b.y-o.y,dz=b.z-o.z;
        R.dir.push([n,deg(angN(Math.atan2(dx,dz)-(th+my))),deg(Math.atan2(dy,Math.hypot(dx,dz))-mp)]);
        u.root.children[0].getWorldQuaternion(qg);c.set(0,0,1).applyQuaternion(u._st.arma.q).applyQuaternion(qg);R.cano.push([n,deg(angN(Math.atan2(c.x,c.z)-(th+my))),deg(Math.atan2(c.y,Math.hypot(c.x,c.z))-mp)]);}
      e.mYaw=0;e.mPitch=0;e.asoma=0;run(60);u.ojos(o0);const der=[-Math.cos(th),Math.sin(th)];
      e.asoma=1;run(60);u.ojos(o);R.asomaDer=+((o.x-o0.x)*der[0]+(o.z-o0.z)*der[1]).toFixed(3);
      e.asoma=-1;run(60);u.ojos(o);R.asomaIzq=+((o.x-o0.x)*der[0]+(o.z-o0.z)*der[1]).toFixed(3);
      e.asoma=0;run(60);u.ojos(o);R.ojoPie=+(o.y-u.root.position.y).toFixed(3);
      e.agach=1;run(60);u.ojos(o);R.ojoAgach=+(o.y-u.root.position.y).toFixed(3);
      e.agach=0;e.tierra=1;run(120);u.ojos(o);R.ojoTierra=+(o.y-u.root.position.y).toFixed(3);
      u.dispose();return R;})()`);
    lg('conv',JSON.stringify(R.conv));
    /* B. en combate de verdad: el jugador parado en la luz, a 30 m, inmortal. Se compara cada soldado que apunta */
    await ev("window.__inmortal=true;P.pos.set(-410,floorAt(-410,607),607);P.vel.set(0,0,0);P.yaw=Math.PI/2;switchTo(2);1");
    R.vivo=await ev(`window.__S={n:0,yaw:[],pit:[],ojo:[],fuera:0,cy:[],cp:[],por:{},raros:[]};1`);
    for(let k=0;k<30;k++){
      await h.step(1,1/60,`__fich();if((Math.round(T*60)%12)===0){const angN=a=>Math.atan2(Math.sin(a),Math.cos(a)),o=new V3(),b=new V3();
        for(const s of UE.soldados){if(!s.vivo||!s.vista||!s.vista.vis||s.apunta<.95||s.recT>=0||s.lanzaT>=0||s.culT>=0)continue;
          if(Math.abs(angN(s.miraYaw-s.rumbo))>1.25){__S.fuera++;continue;}
          const u=s.vista.u;u.ojos(o);u.boca(b);const dx=b.x-o.x,dy=b.y-o.y,dz=b.z-o.z;__S.n++;
          __S.yaw.push(Math.abs(angN(Math.atan2(dx,dz)-s.miraYaw))*57.3);__S.pit.push(Math.abs(Math.atan2(dy,Math.hypot(dx,dz))-s.mPitch)*57.3);
          const ia=s.tierra>0?.3*s.tierra+1.05*(1-s.tierra):1.62+(1.05-1.62)*s.agach;__S.ojo.push(Math.abs((o.y-s.y)-ia));
          const qg=new THREE.Quaternion(),c=new V3();u.root.children[0].getWorldQuaternion(qg);c.set(0,0,1).applyQuaternion(u._st.arma.q).applyQuaternion(qg);
          const ey=Math.abs(angN(Math.atan2(c.x,c.z)-s.miraYaw))*57.3,ep=Math.abs(Math.atan2(c.y,Math.hypot(c.x,c.z))-s.mPitch)*57.3;__S.cy.push(ey);__S.cp.push(ep);
          const po=s.elev?'nido':s.tierra>.5?'tierra':s.agach>.5?'agach':'pie';const P_=__S.por[po]||(__S.por[po]={n:0,y:0,p:0,ojo:0});P_.n++;P_.y+=ey;P_.p+=ep;P_.ojo+=Math.abs((o.y-s.y)-ia);
          if((ey>15||ep>15)&&__S.raros.length<8)__S.raros.push([s.nombre,po,+ey.toFixed(0),+ep.toFixed(0),+s.mPitch.toFixed(2),+(s.miraYaw-s.rumbo).toFixed(2),+s.apunta.toFixed(2)]);}}`);
    }
    R.vivo=await ev(`(()=>{const q=(a,p)=>{if(!a.length)return null;const b=a.slice().sort((x,y)=>x-y);return +b[Math.min(b.length-1,Math.floor(p*b.length))].toFixed(1);};
      const S=__S;return {n:S.n,fueraDeAlcance:S.fuera,yaw:{med:q(S.yaw,.5),p90:q(S.yaw,.9),max:q(S.yaw,1),bajo10:+(S.yaw.filter(v=>v<10).length/S.yaw.length).toFixed(3)},
        pitch:{med:q(S.pit,.5),p90:q(S.pit,.9),max:q(S.pit,1),bajo10:+(S.pit.filter(v=>v<10).length/S.pit.length).toFixed(3)},ojoCm:{med:q(S.ojo.map(v=>v*100),.5),p90:q(S.ojo.map(v=>v*100),.9)},
        cano:{yaw:{med:q(S.cy,.5),p90:q(S.cy,.9),max:q(S.cy,1),bajo10:+(S.cy.filter(v=>v<10).length/S.cy.length).toFixed(3)},pitch:{med:q(S.cp,.5),p90:q(S.cp,.9),max:q(S.cp,1),bajo10:+(S.cp.filter(v=>v<10).length/S.cp.length).toFixed(3)}},
        por:Object.fromEntries(Object.entries(S.por).map(([k,v])=>[k,{n:v.n,yaw:+(v.y/v.n).toFixed(1),pitch:+(v.p/v.n).toFixed(1),ojoCm:+(v.ojo/v.n*100).toFixed(0)}])),raros:S.raros};})()`);
    lg('vivo',JSON.stringify(R.vivo));
    /* C. costo con 8: refuerzo enseguida y el jugador cerca */
    await ev("UE.T.refuerzoCombate=1;UE.T.refuerzoLlega=4;1");
    for(let k=0;k<40;k++){await h.step(1,1/60,"__fich()");const e=await ev("UE.estado().refuerzo");if(e==='llego')break;}
    await ev("P.pos.set(-420,floorAt(-420,607),607);P.vel.set(0,0,0);UEG.medirReset();1");
    const pasos=[];for(let k=0;k<4;k++){pasos.push(await h.step(5,1/60,"__fich()"));}
    R.costo=await ev(`({frames:UEG.MED.n,iaMasModelosMs:+(UEG.MED.ia/UEG.MED.n).toFixed(3),modelosMs:+(UEG.MED.mod/UEG.MED.n).toFixed(3),peorMs:+UEG.MED.max.toFixed(2),peorModelosMs:+UEG.MED.maxMod.toFixed(2),
      vivos:UE.soldados.filter(s=>s.vivo).length,total:UE.soldados.length,visibles:UEG.modelos.filter(v=>v.vis).length,cerca:UE.soldados.filter(s=>s.vivo&&Math.hypot(s.x-P.pos.x,s.z-P.pos.z)<40).length,
      est:UE.estado(),astar:UE.astar,peores:UEG.MED.peores.sort((a,b)=>b[1]-a[1]).slice(0,6)})`);
    R.costo.pasos=pasos;lg('costo',JSON.stringify(R.costo));
    R.L=await ev("({bala:__L.bala,fichMax:__L.fichMax,ev:__L.ev,expl:__L.expl.length,radio:__L.radio.length,T:+T.toFixed(1)})");
    lg('L',JSON.stringify(R.L));
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(OUT,JSON.stringify(R));
  await h.close();lg('cerrado');
})();
