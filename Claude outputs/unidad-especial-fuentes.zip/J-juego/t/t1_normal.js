// Prueba 1: partida normal de 60 s con oleadas en la zona del Obelisco (sección A). Errores, y costo por cuadro.
// Uso: node t1_normal.js juego.html salida.json   (correrlo con la 1.17.0 y con v116/base.html para comparar)
const H=require('../../harness.js'),fs=require('fs');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
const OUT=process.argv[3]||__dirname+'/t1.json';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto',F);const R={archivo:F};const ev=c=>h.ev(c);
  try{
    await h.start();
    /* el jugador no muere (la partida tiene que durar 60 s) y tira a lo que tenga más cerca, para que las oleadas avancen */
    await ev(`(()=>{const hp0=hurtPlayer;hurtPlayer=function(n,g){if(P.hp-n<=5)P.hp=100;return hp0(n,g);};
      window.__F=new Float64Array(4000);window.__fn=0;const f0=frame;
      window.__apuntaBicho=()=>{let b=null,bd=1e9;for(const e of enemies){const p=e.obj.position,d=Math.hypot(p.x-P.pos.x,p.z-P.pos.z);if(d<bd&&e.hp>0){bd=d;b=e;}}
        if(b&&bd<40){const p=b.obj.position,dx=p.x-P.pos.x,dz=p.z-P.pos.z;P.yaw=Math.atan2(-dx,-dz);P.pitch=Math.atan2(p.y+.6-(P.pos.y+1.7),Math.hypot(dx,dz));mouseDown=true;}else mouseDown=false;W[2].res=200;W[1].res=40;};
      switchTo(2);return 1;})()`);
    if(await ev("typeof UEG!=='undefined'"))await ev("UEG.medirReset();UEG.MED.reg=[];1");
    const pasos=[];
    for(let k=0;k<12;k++){pasos.push(await h.step(5,1/60,"__apuntaBicho()"));}
    R.pasos=pasos;R.wallMsPorCuadro=+(pasos.reduce((a,p)=>a+p.wallMs,0)/(12*5*60)).toFixed(3);
    R.estado=await ev("({T:+T.toFixed(1),oleada:wave,bichos:enemies.length,kills,hp:Math.round(P.hp),pos:[+P.pos.x.toFixed(0),+P.pos.z.toFixed(0)],stage:STAGE})");
    if(await ev("typeof UEG!=='undefined'")){
      R.ue=await ev(`(()=>{const r=UEG.MED.reg,ms=[];for(let i=0;i<r.length;i+=2)ms.push(r[i]);ms.sort((a,b)=>a-b);const q=p=>+ms[Math.min(ms.length-1,Math.floor(p*ms.length))].toFixed(3);
        return {cuadros:ms.length,mediaMs:+(UEG.MED.ia/UEG.MED.n).toFixed(4),p50:q(.5),p99:q(.99),max:q(1),modelosMs:+(UEG.MED.mod/UEG.MED.n).toFixed(4),
          visibles:UEG.modelos.filter(v=>v.vis).length,estado:UE.estado(),dist:Math.round(Math.hypot(P.pos.x+438,P.pos.z-607))};})()`);
    }
    lg('R',JSON.stringify(R));
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(OUT,JSON.stringify(R));
  await h.close();lg('cerrado');
})();
