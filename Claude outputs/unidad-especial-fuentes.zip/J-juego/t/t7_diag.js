const H=require('../../harness.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F,{width:640,height:360});lg('abierto');
  try{await h.start();lg('start');await h.ev("RETEN.ir({bichos:false});1");lg('ir');await h.step(1);lg('step');
    await h.ev("P.pos.set(-398,floorAt(-398,607.5),607.5);P.vel.set(0,0,0);P.yaw=Math.PI/2;1");
    await h.shot(__dirname+'/../capturas/diag.png');lg('shot1',JSON.stringify(await h.ev("({c:renderer.info.render.calls,t:renderer.info.render.triangles,p:renderer.info.programs.length})")));
    await h.shot(__dirname+'/../capturas/diag2.png');lg('shot2');
  }catch(e){lg('EXC',e.message.slice(0,300));}
  lg('err',JSON.stringify(h.errors.slice(0,4)));await h.close();lg('cerrado');})();
