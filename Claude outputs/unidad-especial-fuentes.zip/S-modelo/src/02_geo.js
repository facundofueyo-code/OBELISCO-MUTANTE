
/* ====================================================================================
   CONSTRUCTOR DE MALLAS
   Junta primitivas redondeadas en una sola geometría con color, material (aspereza, metal,
   emisión) y hueso por vértice. Las normales salen de promediar las caras por área: con los
   chaflanes, las caras grandes quedan planas y los bordes, redondeados.
   ==================================================================================== */
function Constructor(H){               /* H: {nombreDeHueso: índice} */
  const pos=[],nor=[],col=[],uem=[],ski=[],skw=[],idx=[];
  const M=new M4(),N3=new THREE.Matrix3(),pila=[];
  let esp=1,inv=false,cr=1,cg=1,cb=1,ur=1,um=0,ue=0,hueso=0,pesoFn=null,tinteFn=null,tris=0,varia=.06;
  const jit=azarDe(20261003),t=new V3(),n=new V3(),eu=new THREE.Euler(),m2=new M4(),qa=new Q4();
  const G={H};
  /* material actual (clave de PAL) con un factor de brillo opcional */
  G.mat=(clave,k=1)=>{const p=PAL[clave],c=p[0];cr=((c>>16)&255)/255*k;cg=((c>>8)&255)/255*k;cb=(c&255)/255*k;ur=p[1];um=p[2];ue=p[3];return G;};
  G.hueso=nombre=>{if(H[nombre]===undefined)throw new Error('UEM: hueso desconocido '+nombre);hueso=H[nombre];pesoFn=null;return G;};
  G.peso=fn=>{pesoFn=fn;return G;};    /* fn(x,y,z del modelo) → [hueso0,hueso1,peso1] */
  G.tinte=fn=>{tinteFn=fn;return G;};  /* fn(x,y,z del modelo) → factor de brillo, o clave de PAL */
  G.lado=s=>{esp=s;return G;};         /* -1: espeja en X (lado derecho) */
  G.varia=v=>{varia=v;return G;};
  /* transformación local de lo que se emite a continuación */
  G.en=(x=0,y=0,z=0,rx=0,ry=0,rz=0,orden='YXZ')=>{eu.set(rx,ry,rz,orden);M.makeRotationFromEuler(eu);M.setPosition(x,y,z);return G;};
  G.guardar=()=>{pila.push(M.clone());return G;};
  G.volver=()=>{M.copy(pila.pop());return G;};
  G.mover=(x,y,z,rx=0,ry=0,rz=0,orden='YXZ')=>{eu.set(rx,ry,rz,orden);m2.makeRotationFromEuler(eu);m2.setPosition(x,y,z);M.multiply(m2);return G;};
  G.escala=(x,y,z)=>{m2.makeScale(x,y,z);M.multiply(m2);return G;};
  G.tris=()=>tris;

  function emit(P,T){
    const nv=P.length/3,NN=new Float32Array(P.length);
    for(let i=0;i<T.length;i+=3){const a=T[i]*3,b=T[i+1]*3,c=T[i+2]*3;
      const ux=P[b]-P[a],uy=P[b+1]-P[a+1],uz=P[b+2]-P[a+2],vx=P[c]-P[a],vy=P[c+1]-P[a+1],vz=P[c+2]-P[a+2];
      const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
      NN[a]+=nx;NN[a+1]+=ny;NN[a+2]+=nz;NN[b]+=nx;NN[b+1]+=ny;NN[b+2]+=nz;NN[c]+=nx;NN[c+1]+=ny;NN[c+2]+=nz;}
    N3.getNormalMatrix(M);const giro=(M.determinant()<0)!==(esp<0)!==inv,base=pos.length/3,k=1+(jit()-.5)*2*varia;
    for(let i=0;i<nv;i++){
      t.set(P[i*3],P[i*3+1],P[i*3+2]).applyMatrix4(M);n.set(NN[i*3],NN[i*3+1],NN[i*3+2]).applyMatrix3(N3);
      if(inv)n.negate();
      if(n.lengthSq()<1e-20)n.set(0,1,0);else n.normalize();
      if(esp<0){t.x=-t.x;n.x=-n.x;}
      pos.push(t.x,t.y,t.z);nor.push(n.x,n.y,n.z);
      let r=cr*k,g=cg*k,b=cb*k,a=ur,m=um,e=ue;
      if(tinteFn){const f=tinteFn(t.x,t.y,t.z);
        if(typeof f==='string'){const p=PAL[f],c=p[0];r=((c>>16)&255)/255*k;g=((c>>8)&255)/255*k;b=(c&255)/255*k;a=p[1];m=p[2];e=p[3];}
        else{r*=f;g*=f;b*=f;}}
      col.push(r,g,b);uem.push(a,m,e);
      if(pesoFn){const w=pesoFn(t.x,t.y,t.z);ski.push(w[0],w[1],0,0);skw.push(1-w[2],w[2],0,0);}
      else{ski.push(hueso,0,0,0);skw.push(1,0,0,0);}
    }
    for(let i=0;i<T.length;i+=3){if(giro)idx.push(base+T[i],base+T[i+2],base+T[i+1]);else idx.push(base+T[i],base+T[i+1],base+T[i+2]);}
    tris+=T.length/3;
  }
  /* da vuelta los triángulos que miran hacia el punto de referencia (para primitivas convexas) */
  function afuera(P,T,ref){
    for(let i=0;i<T.length;i+=3){const a=T[i]*3,b=T[i+1]*3,c=T[i+2]*3;
      const ux=P[b]-P[a],uy=P[b+1]-P[a+1],uz=P[b+2]-P[a+2],vx=P[c]-P[a],vy=P[c+1]-P[a+1],vz=P[c+2]-P[a+2];
      const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
      const gx=(P[a]+P[b]+P[c])/3,gy=(P[a+1]+P[b+1]+P[c+1])/3,gz=(P[a+2]+P[b+2]+P[c+2])/3;
      const R=typeof ref==='function'?ref(gx,gy,gz):ref;
      if(nx*(gx-R[0])+ny*(gy-R[1])+nz*(gz-R[2])<0){const s=T[i+1];T[i+1]=T[i+2];T[i+2]=s;}}
  }
  G.emit=emit;G.afuera=afuera;
  G.invertir=v=>{inv=v;return G;};     /* caras hacia adentro (interior de un casco, de una capucha) */

  /* caja con chaflán, centrada. c=0: aristas vivas */
  G.caja=(sx,sy,sz,c)=>{const hx=sx/2,hy=sy/2,hz=sz/2;
    if(c===undefined)c=Math.min(sx,sy,sz)*.2;c=Math.min(c,hx*.9,hy*.9,hz*.9);
    const P=[],T=[],v=(i,j,k,f)=>(i*4+j*2+k)*3+f,q=(a,b,c_,d)=>T.push(a,b,c_,a,c_,d);
    for(let i=0;i<2;i++)for(let j=0;j<2;j++)for(let k=0;k<2;k++){const x=i?1:-1,y=j?1:-1,z=k?1:-1;
      P.push(x*hx,y*(hy-c),z*(hz-c), x*(hx-c),y*hy,z*(hz-c), x*(hx-c),y*(hy-c),z*hz);}
    for(let i=0;i<2;i++){q(v(i,0,0,0),v(i,1,0,0),v(i,1,1,0),v(i,0,1,0));q(v(0,i,0,1),v(1,i,0,1),v(1,i,1,1),v(0,i,1,1));q(v(0,0,i,2),v(1,0,i,2),v(1,1,i,2),v(0,1,i,2));}
    if(c>0){for(let i=0;i<2;i++)for(let j=0;j<2;j++){q(v(i,j,0,0),v(i,j,1,0),v(i,j,1,1),v(i,j,0,1));q(v(i,0,j,0),v(i,1,j,0),v(i,1,j,2),v(i,0,j,2));q(v(0,i,j,1),v(1,i,j,1),v(1,i,j,2),v(0,i,j,2));}
      for(let i=0;i<2;i++)for(let j=0;j<2;j++)for(let k=0;k<2;k++)T.push(v(i,j,k,0),v(i,j,k,1),v(i,j,k,2));}
    afuera(P,T,[0,0,0]);
    if(c<=0){/* sin chaflán: una cara por lado, sin compartir vértices */
      for(let f=0;f<12;f+=2){emit([0,1,2,3,4,5].map(o=>T[f*3+o]).reduce((a,ix)=>(a.push(P[ix*3],P[ix*3+1],P[ix*3+2]),a),[]),[0,1,2,3,4,5]);}return G;}
    emit(P,T);return G;};

  /* cilindro o cono a lo largo de +Y, de 0 a h. tapas: 1 abajo, 2 arriba, 3 las dos */
  G.cil=(r0,r1,h,seg=8,tapas=3)=>{const P=[],T=[];
    for(let i=0;i<seg;i++){const a=i/seg*TAU,c=Math.cos(a),s=Math.sin(a);P.push(c*r0,0,s*r0,c*r1,h,s*r1);}
    for(let i=0;i<seg;i++){const a=i*2,b=((i+1)%seg)*2;if(r1>1e-6)T.push(a,a+1,b+1);if(r0>1e-6)T.push(a,b+1,b);}
    emit(P,T);
    for(const top of [0,1]){if(!(tapas&(top?2:1)))continue;const r=top?r1:r0;if(r<1e-6)continue;const Pc=[0,top?h:0,0],Tc=[];
      for(let i=0;i<seg;i++){const a=i/seg*TAU;Pc.push(Math.cos(a)*r,top?h:0,Math.sin(a)*r);}
      for(let i=0;i<seg;i++){const a=1+i,b=1+(i+1)%seg;if(top)Tc.push(0,b,a);else Tc.push(0,a,b);}
      emit(Pc,Tc);}
    return G;};
  /* cilindro entre dos puntos */
  G.tubo=(ax,ay,az,bx,by,bz,r0,r1,seg=8,tapas=3)=>{t.set(bx-ax,by-ay,bz-az);const L=t.length();if(L<1e-6)return G;
    qa.setFromUnitVectors(n.set(0,1,0),t.multiplyScalar(1/L));G.guardar();m2.makeRotationFromQuaternion(qa);m2.setPosition(ax,ay,az);M.multiply(m2);G.cil(r0,r1===undefined?r0:r1,L,seg,tapas);return G.volver();};

  /* torno alrededor de Y. perfil: [[r,y],…] recorrido de abajo hacia arriba por afuera. Un punto repetido corta el suavizado (arista viva) */
  G.torno=(perfil,seg=10)=>{let ini=0;
    for(let k=1;k<=perfil.length;k++){
      const corte=k===perfil.length||(Math.abs(perfil[k][0]-perfil[k-1][0])<1e-9&&Math.abs(perfil[k][1]-perfil[k-1][1])<1e-9);
      if(!corte)continue;const tr=perfil.slice(ini,k);ini=k;if(tr.length<2)continue;
      const P=[],T=[];for(const [r,y] of tr)for(let i=0;i<seg;i++){const a=i/seg*TAU;P.push(Math.cos(a)*r,y,Math.sin(a)*r);}
      for(let j=0;j<tr.length-1;j++)for(let i=0;i<seg;i++){const a=j*seg+i,b=j*seg+(i+1)%seg,a1=a+seg,b1=b+seg;
        if(tr[j+1][0]>1e-6)T.push(a,a1,b1);if(tr[j][0]>1e-6)T.push(a,b1,b);}
      emit(P,T);}
    return G;};

  /* piel entre secciones apiladas en Y. sección: [y, cx, cz, rx, rzAdelante, rzAtrás, exponente]
     (exponente 2 = elipse; más alto = más cuadrado). tapa: 1 primera, 2 última */
  G.loft=(secs,seg=10,tapa=3,nDef=2)=>{const P=[],T=[],S=secs.length;
    for(const s of secs){const y=s[0],cx=s[1]||0,cz=s[2]||0,rx=s[3],rf=s[4]===undefined?rx:s[4],rb=s[5]===undefined?rf:s[5],ex=2/(s[6]||nDef);
      for(let i=0;i<seg;i++){const a=i/seg*TAU,c=Math.cos(a),sn=Math.sin(a);
        P.push(cx+rx*Math.sign(c)*Math.pow(Math.abs(c),ex),y,cz+(sn>=0?rf:rb)*Math.sign(sn)*Math.pow(Math.abs(sn),ex));}}
    const sube=secs[S-1][0]>=secs[0][0];
    for(let j=0;j<S-1;j++)for(let i=0;i<seg;i++){const a=j*seg+i,b=j*seg+(i+1)%seg,a1=a+seg,b1=b+seg;
      if(sube)T.push(a,a1,b1,a,b1,b);else T.push(a,b1,a1,a,b,b1);}
    for(const fin of [0,1]){if(!(tapa&(fin?2:1)))continue;const j=fin?S-1:0,s=secs[j],c=P.length/3;P.push(s[1]||0,s[0],s[2]||0);
      for(let i=0;i<seg;i++){const a=j*seg+i,b=j*seg+(i+1)%seg;if((fin===1)===sube)T.push(c,b,a);else T.push(c,a,b);}}
    emit(P,T);return G;};

  /* elipsoide. opt.f0, opt.f1: ángulo polar inicial y final (0 = polo de arriba); opt.corte(az) → ángulo final por azimut (casco) */
  G.esfera=(rx,ry,rz,seg=10,anillos=6,opt={})=>{const P=[],T=[],f0=opt.f0||0,polo=f0<1e-6;
    const fin=a=>opt.corte?opt.corte(a):(opt.f1===undefined?PI:opt.f1);
    if(polo)P.push(0,ry,0);
    for(let j=polo?1:0;j<=anillos;j++)for(let i=0;i<seg;i++){const a=i/seg*TAU,f=f0+(fin(a)-f0)*j/anillos,sf=Math.sin(f);
      P.push(rx*sf*Math.cos(a),ry*Math.cos(f),rz*sf*Math.sin(a));}
    const fila=j=>polo?1+(j-1)*seg:j*seg;
    for(let j=polo?1:0;j<anillos;j++)for(let i=0;i<seg;i++){const a=fila(j)+i,b=fila(j)+(i+1)%seg,a1=a+seg,b1=b+seg;T.push(a,b,b1,a,b1,a1);}
    if(polo)for(let i=0;i<seg;i++)T.push(0,1+(i+1)%seg,1+i);
    const cierra=!opt.corte&&(opt.f1===undefined||opt.f1>PI-1e-6);
    if(!cierra&&opt.tapa){const c=P.length/3,j=anillos;let cy=0;for(let i=0;i<seg;i++)cy+=P[(fila(j)+i)*3+1];P.push(0,cy/seg,0);for(let i=0;i<seg;i++)T.push(c,fila(j)+i,fila(j)+(i+1)%seg);}
    afuera(P,T,[0,opt.refY||0,0]);emit(P,T);return G;};

  /* prisma: polígono en XY (cualquier forma, sin agujeros) extruido en Z con espesor e y chaflán c.
     suave: las esquinas del contorno se redondean (equipo blando); si no, quedan facetadas (piezas del arma) */
  G.prisma=(poly,e,c=0,suave=false)=>{let ar=0;const np=poly.length;
    for(let i=0;i<np;i++){const p=poly[i],q=poly[(i+1)%np];ar+=p[0]*q[1]-q[0]*p[1];}
    if(ar<0)poly=poly.slice().reverse();
    c=Math.min(c,e*.45);const h=e/2;
    /* contorno achicado para las caras de adelante y atrás */
    let ins=poly;if(c>0){const E=[];for(let i=0;i<np;i++){const a=poly[i],b=poly[(i+1)%np];let dx=b[0]-a[0],dy=b[1]-a[1];const l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;E.push([a[0]-dy*c,a[1]+dx*c,dx,dy]);}
      ins=[];for(let i=0;i<np;i++){const A=E[(i+np-1)%np],B=E[i],den=A[2]*B[3]-A[3]*B[2];
        if(Math.abs(den)<1e-5){ins.push([B[0],B[1]]);continue;}const tt=((B[0]-A[0])*B[3]-(B[1]-A[1])*B[2])/den;ins.push([A[0]+A[2]*tt,A[1]+A[3]*tt]);}}
    const caras=THREE.ShapeUtils.triangulateShape(ins.map(p=>new THREE.Vector2(p[0],p[1])),[]);
    if(suave){const P=[],T=[];
      for(const p of ins)P.push(p[0],p[1],h);for(const p of poly)P.push(p[0],p[1],h-c);for(const p of poly)P.push(p[0],p[1],-h+c);for(const p of ins)P.push(p[0],p[1],-h);
      for(const f of caras){T.push(f[0],f[1],f[2]);T.push(3*np+f[0],3*np+f[2],3*np+f[1]);}
      for(let i=0;i<np;i++){const j=(i+1)%np;for(let k=0;k<3;k++){if(c<=0&&k!==1)continue;const a=k*np+i,b=k*np+j,a1=a+np,b1=b+np;T.push(a,a1,b1,a,b1,b);}}
      emit(P,T);return G;}
    {const P=[],T=[];for(const p of ins)P.push(p[0],p[1],h);for(const f of caras)T.push(f[0],f[1],f[2]);emit(P,T);}
    {const P=[],T=[];for(const p of ins)P.push(p[0],p[1],-h);for(const f of caras)T.push(f[0],f[2],f[1]);emit(P,T);}
    for(let i=0;i<np;i++){const j=(i+1)%np,a=poly[i],b=poly[j],ia=ins[i],ib=ins[j];
      emit([a[0],a[1],h-c,a[0],a[1],-h+c,b[0],b[1],-h+c,b[0],b[1],h-c],[0,1,2,0,2,3]);
      if(c>0){emit([ia[0],ia[1],h,a[0],a[1],h-c,b[0],b[1],h-c,ib[0],ib[1],h],[0,1,2,0,2,3]);
        emit([a[0],a[1],-h+c,ia[0],ia[1],-h,ib[0],ib[1],-h,b[0],b[1],-h+c],[0,1,2,0,2,3]);}}
    return G;};

  /* cinta (correa) a lo largo de puntos: ancho w de costado, espesor e hacia la normal nh (vector o función del índice) */
  G.cinta=(pts,w,e,nh)=>{const P=[],T=[],C=[],tg=new V3(),sd=new V3(),up=new V3(),N=pts.length;
    for(let i=0;i<N;i++){const p=pts[i],a=pts[Math.max(0,i-1)],b=pts[Math.min(N-1,i+1)];tg.set(b[0]-a[0],b[1]-a[1],b[2]-a[2]).normalize();
      const h=typeof nh==='function'?nh(i,p):nh;up.set(h[0],h[1],h[2]);sd.crossVectors(tg,up).normalize();up.crossVectors(sd,tg).normalize();
      C.push(p);for(const [s,u] of [[1,1],[-1,1],[-1,-1],[1,-1]])P.push(p[0]+sd.x*s*w/2+up.x*u*e/2,p[1]+sd.y*s*w/2+up.y*u*e/2,p[2]+sd.z*s*w/2+up.z*u*e/2);}
    for(let i=0;i<N-1;i++)for(let k=0;k<4;k++){const a=i*4+k,b=i*4+(k+1)%4,a1=a+4,b1=b+4;T.push(a,a1,b1,a,b1,b);}
    T.push(0,1,2,0,2,3);const z=(N-1)*4;T.push(z,z+2,z+1,z,z+3,z+2);
    const nt=T.length/3;let it=0;
    afuera(P,T,(gx,gy,gz)=>{const k=it++;if(k>=nt-4){const q=C[k<nt-2?Math.min(1,N-1):Math.max(0,N-2)];return q;}
      let best=0,bd=1e9;for(let i=0;i<N;i++){const d=(C[i][0]-gx)**2+(C[i][1]-gy)**2+(C[i][2]-gz)**2;if(d<bd){bd=d;best=i;}}
      const i0=Math.max(0,Math.min(N-2,best)),q0=C[i0],q1=C[i0+1];return [(q0[0]+q1[0])/2,(q0[1]+q1[1])/2,(q0[2]+q1[2])/2];});
    emit(P,T);return G;};

  /* disco plano mirando a +Y (o anillo si r0>0) */
  G.disco=(r,seg=10,r0=0)=>{const P=[],T=[];
    if(r0<=0){P.push(0,0,0);for(let i=0;i<seg;i++){const a=i/seg*TAU;P.push(Math.cos(a)*r,0,Math.sin(a)*r);}for(let i=0;i<seg;i++)T.push(0,1+(i+1)%seg,1+i);}
    else{for(let i=0;i<seg;i++){const a=i/seg*TAU,c=Math.cos(a),s=Math.sin(a);P.push(c*r0,0,s*r0,c*r,0,s*r);}for(let i=0;i<seg;i++){const a=i*2,b=((i+1)%seg)*2;T.push(a,b,b+1,a,b+1,a+1);}}
    emit(P,T);return G;};

  /* toro alrededor de Y */
  G.toro=(R,r,segR=12,segr=5)=>{const P=[],T=[];
    for(let i=0;i<segR;i++){const a=i/segR*TAU;for(let j=0;j<segr;j++){const b=j/segr*TAU,q=R+Math.cos(b)*r;P.push(Math.cos(a)*q,Math.sin(b)*r,Math.sin(a)*q);}}
    for(let i=0;i<segR;i++)for(let j=0;j<segr;j++){const a=i*segr+j,b=i*segr+(j+1)%segr,a1=((i+1)%segR)*segr+j,b1=((i+1)%segR)*segr+(j+1)%segr;T.push(a,b,b1,a,b1,a1);}
    afuera(P,T,(gx,gy,gz)=>{const l=Math.hypot(gx,gz)||1;return [gx/l*R,0,gz/l*R];});emit(P,T);return G;};

  /* orienta lo que sigue para que su +Y apunte a (dx,dy,dz), parado en (x,y,z); giro: vuelta extra sobre ese eje */
  G.dir=(x,y,z,dx,dy,dz,giro=0)=>{t.set(dx,dy,dz).normalize();qa.setFromUnitVectors(n.set(0,1,0),t);
    if(giro){const q2=new Q4().setFromAxisAngle(n.set(0,1,0),giro);qa.multiply(q2);}
    M.makeRotationFromQuaternion(qa);M.setPosition(x,y,z);return G;};
  /* manguera: tubo redondo a lo largo de una polilínea (dedos, cables). rads: número o lista por punto */
  G.manguera=(pts,rads,seg=5,tapas=3)=>{const P=[],T=[],N=pts.length,tg=new V3(),rf=new V3(),nn=new V3(),bb=new V3();
    for(let i=0;i<N;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(N-1,i+1)];tg.set(b[0]-a[0],b[1]-a[1],b[2]-a[2]).normalize();
      if(i===0){rf.set(0,0,1);if(Math.abs(tg.z)>.85)rf.set(1,0,0);nn.crossVectors(rf,tg).normalize();}
      else{nn.addScaledVector(tg,-nn.dot(tg));if(nn.lengthSq()<1e-12){rf.set(0,1,0);nn.crossVectors(rf,tg);}nn.normalize();}
      bb.crossVectors(tg,nn);const r=Array.isArray(rads)?rads[i]:rads;
      for(let k=0;k<seg;k++){const th=k/seg*TAU,c=Math.cos(th),s=Math.sin(th);
        P.push(pts[i][0]+r*(c*nn.x+s*bb.x),pts[i][1]+r*(c*nn.y+s*bb.y),pts[i][2]+r*(c*nn.z+s*bb.z));}}
    for(let i=0;i<N-1;i++)for(let k=0;k<seg;k++){const a=i*seg+k,b=i*seg+(k+1)%seg;T.push(a,b,b+seg,a,b+seg,a+seg);}
    const nl=T.length/3;let c0=-1,c1=-1;
    if(tapas&1){c0=P.length/3;P.push(pts[0][0],pts[0][1],pts[0][2]);for(let k=0;k<seg;k++)T.push(c0,(k+1)%seg,k);}
    if(tapas&2){c1=P.length/3;const e=pts[N-1],o=(N-1)*seg;P.push(e[0],e[1],e[2]);for(let k=0;k<seg;k++)T.push(c1,o+k,o+(k+1)%seg);}
    /* sentido de las caras: hacia afuera del eje (las tapas, hacia afuera del extremo) */
    let it=0;const p0=pts[0],p1=pts[Math.min(1,N-1)],q0=pts[N-1],q1=pts[Math.max(0,N-2)];
    afuera(P,T,(gx,gy,gz)=>{const k=it++;
      if(k>=nl){const fin=(tapas&1)&&k<nl+seg?0:1;const a=fin?q0:p0,b=fin?q1:p1;return [(a[0]*2+b[0])/3,(a[1]*2+b[1])/3,(a[2]*2+b[2])/3];}
      let best=0,bd=1e9;for(let i=0;i<N-1;i++){const a=pts[i],b=pts[i+1];const vx=b[0]-a[0],vy=b[1]-a[1],vz=b[2]-a[2];
        let u=((gx-a[0])*vx+(gy-a[1])*vy+(gz-a[2])*vz)/(vx*vx+vy*vy+vz*vz||1);u=u<0?0:u>1?1:u;
        const d=(a[0]+vx*u-gx)**2+(a[1]+vy*u-gy)**2+(a[2]+vz*u-gz)**2;if(d<bd){bd=d;best=[a[0]+vx*u,a[1]+vy*u,a[2]+vz*u];}}
      return best;});
    emit(P,T);return G;};
  /* triángulos sueltos ya armados (para mallas a medida: velo, haces) */
  G.crudo=(P,T)=>{emit(P,T);return G;};

  /* geometría final */
  G.fin=()=>{const g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(nor,3));
    g.setAttribute('color',new THREE.Float32BufferAttribute(col,3));g.setAttribute('uem',new THREE.Float32BufferAttribute(uem,3));
    g.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(ski,4));g.setAttribute('skinWeight',new THREE.Float32BufferAttribute(skw,4));
    g.setIndex(pos.length/3>65535?new THREE.Uint32BufferAttribute(idx,1):new THREE.Uint16BufferAttribute(idx,1));
    g.userData.tris=tris;return g;};
  return G;
}
