/* =====================================================================================================
   SONIDO DE LA PÁGINA — mínimo y sintetizado con Web Audio, sin archivos. Arranca recién con un clic
   (PAG_SONIDO.iniciar() se llama solo desde botones). Disparo propio y ajeno (más bajo con la distancia),
   explosión y radio (pitido de apertura, ráfaga de voz distorsionada y clic de cierre).
   ===================================================================================================== */
const PAG_SONIDO = (() => {
  let ctx = null, sal = null, ruidoB = null, activo = true, ocupadoHasta = 0;
  const ultimo = {};
  function iniciar() {
    try {
      if (!ctx) {
        const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
        ctx = new AC();
        const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 6;
        sal = ctx.createGain(); sal.gain.value = activo ? 0.55 : 0; sal.connect(comp); comp.connect(ctx.destination);
        ruidoB = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
        const d = ruidoB.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      }
      if (ctx.state === 'suspended') ctx.resume();
    } catch (e) { ctx = null; }
  }
  const listo = () => ctx && activo && ctx.state === 'running';
  function env(g, t, a, pico, caida) { g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(pico, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + caida); }
  function ruido(t, dur, tipo, frec, q, pico, ataque, destino) {
    const s = ctx.createBufferSource(); s.buffer = ruidoB; s.loop = true;
    const f = ctx.createBiquadFilter(); f.type = tipo; f.frequency.value = frec; f.Q.value = q;
    const g = ctx.createGain(); env(g, t, ataque, pico, dur);
    s.connect(f); f.connect(g); g.connect(destino || sal); s.start(t, Math.random() * 0.5); s.stop(t + ataque + dur + 0.05);
    return f;
  }
  function tono(t, tipo, f0, f1, dur, pico, destino) {
    const o = ctx.createOscillator(); o.type = tipo; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = ctx.createGain(); env(g, t, 0.004, pico, dur); o.connect(g); g.connect(destino || sal); o.start(t); o.stop(t + dur + 0.05);
  }
  /* arma: pistola|escopeta|uzi|fusil|tirador · dist en m · propio: el del jugador */
  function disparo(arma, dist, propio, clave) {
    if (!listo()) return;
    const t = ctx.currentTime, k = clave || arma;
    if (ultimo[k] && t - ultimo[k] < 0.035) return; ultimo[k] = t;
    const v = propio ? 1 : Math.min(0.8, 9 / (9 + dist)) * (dist > 60 ? 0.6 : 1);
    if (v < 0.03) return;
    const grave = arma === 'escopeta' ? 0.75 : arma === 'tirador' ? 1.2 : 1;
    const corte = propio ? 5200 : Math.max(900, 5200 - dist * 55);
    ruido(t, (arma === 'escopeta' ? 0.22 : 0.13) * (propio ? 1 : 1.25), 'lowpass', corte * grave, 0.7, 0.75 * v, 0.002);
    tono(t, 'triangle', 150 * grave, 45, arma === 'escopeta' ? 0.2 : 0.12, 0.5 * v);
    if (arma === 'tirador') ruido(t + 0.004, 0.5, 'bandpass', 1800, 0.9, 0.18 * v, 0.01);
  }
  function explosion(dist) {
    if (!listo()) return;
    const t = ctx.currentTime, v = Math.min(1, 25 / (25 + dist));
    const f = ruido(t, 1.6, 'lowpass', 900, 0.8, 1.1 * v, 0.006); f.frequency.setValueAtTime(1600, t); f.frequency.exponentialRampToValueAtTime(120, t + 1.4);
    tono(t, 'sine', 70, 28, 0.9, 0.9 * v);
  }
  /* radio interceptada: pitido, voz distorsionada (ruido modulado a ritmo de sílabas) y clic final */
  let dist = null;
  function curva() { const n = 1024, c = new Float32Array(n); for (let i = 0; i < n; i++) { const x = i / (n - 1) * 2 - 1; c[i] = Math.tanh(x * 3.2); } return c; }
  function radio(voz, largo, peligro) {
    if (!listo()) return;
    let t = ctx.currentTime; if (t < ocupadoHasta) t = ocupadoHasta;
    const dur = Math.min(1.7, 0.35 + largo * 0.045);
    ocupadoHasta = t + dur + 0.15;
    const f0 = 1050 + (voz % 4) * 90;
    tono(t, 'square', f0, f0, 0.07, 0.07);
    if (!dist) dist = curva();
    const ws = ctx.createWaveShaper(); ws.curve = dist;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1400 + (voz % 3) * 220; bp.Q.value = 1.4;
    const g = ctx.createGain(); g.gain.value = 0;
    const s = ctx.createBufferSource(); s.buffer = ruidoB; s.loop = true;
    s.connect(ws); ws.connect(bp); bp.connect(g); g.connect(sal);
    const t0 = t + 0.09, pico = peligro ? 0.16 : 0.11;
    for (let q = t0; q < t0 + dur; q += 0.075 + Math.random() * 0.06) {          // «sílabas»
      g.gain.setValueAtTime(pico * (0.5 + Math.random() * 0.5), q); g.gain.setValueAtTime(0.012, q + 0.05);
    }
    g.gain.setValueAtTime(0, t0 + dur);
    s.start(t0, Math.random() * 0.5); s.stop(t0 + dur + 0.05);
    ruido(t0 + dur + 0.01, 0.05, 'highpass', 2500, 0.7, 0.08, 0.002);
  }
  function activar(b) { activo = !!b; if (sal) sal.gain.value = activo ? 0.55 : 0; if (activo) iniciar(); }
  return { iniciar, disparo, explosion, radio, activar, get activo() { return activo; }, get listo() { return !!listo(); } };
})();
