#!/bin/sh
# junta las partes de src/ en ue_modelo.js (el orden importa)
cd "$(dirname "$0")"
cat src/01_base.js src/02_geo.js src/03_rig.js src/04_cuerpo.js src/05_armas.js src/06_mat.js src/07_pose.js src/08_anim.js src/09_muerte.js src/10_api.js > ue_modelo.js
node -e "new Function(require('fs').readFileSync('ue_modelo.js','utf8'))" && echo "ue_modelo.js: $(wc -c < ue_modelo.js) bytes"
