/* capas: recarga, granada, señas, culatazo, muertes (pose final) */
const v=(rol,pose,t,az,el,txt,o={})=>Object.assign({rol,pose,t,az,el,dist:3.2,obj:[0,1.0,0],txt},o);
module.exports={cols:4,vistas:[
  v('jefe','Recarga',1.2,.9,.12,'recarga (mitad)',{dist:2.6,obj:[0,1.1,0]}),
  v('granadero','Granada',.52,1.2,.1,'granada: brazo atrás',{dist:3.3}),
  v('jefe','Seña',.95,.5,.08,'seña avanzar'),v('jefe','Seña',5.35,.3,.08,'seña der'),
  v('jefe','Seña',7.55,.5,.08,'seña alto'),v('asalto','Culatazo',.5,1.1,.08,'culatazo (golpe)'),
  v('jefe','Cae',2.4,1.3,.45,'muerte atrás',{obj:[0,.3,-.6],dist:3.6}),v('jefe','Cae',6.0,1.1,.45,'muerte adelante',{obj:[0,.3,.2],dist:3.6})]};
