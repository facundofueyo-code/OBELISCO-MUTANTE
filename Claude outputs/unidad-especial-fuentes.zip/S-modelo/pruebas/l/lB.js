/* luz plena: los cuatro de frente, primer plano de la cabeza, aturdido, radio y lo hieren */
const v=(rol,pose,t,az,el,txt,o={})=>Object.assign({rol,pose,t,az,el,dist:3.2,obj:[0,.92,0],txt,plena:true},o);
module.exports={cols:4,vistas:[
  v('jefe','De pie',1.5,.12,.04,'jefe (luz plena)'),v('asalto','De pie',1.5,.12,.04,'asalto (luz plena)'),
  v('granadero','De pie',1.5,.12,.04,'granadero (luz plena)'),v('tirador','De pie',1.5,.12,.04,'tirador (luz plena)'),
  v('jefe','De pie',1.5,.45,.04,'cabeza: casco y máscara',{dist:.78,obj:[0,1.63,0]}),
  v('granadero','Aturdido',1.6,.6,.06,'aturdido',{plena:false}),v('jefe','Radio',1.0,.6,.06,'mano a la radio',{plena:false}),
  v('asalto','Lo hieren',1.17,.7,.06,'lo hieren (sacudón)',{plena:false})]};
