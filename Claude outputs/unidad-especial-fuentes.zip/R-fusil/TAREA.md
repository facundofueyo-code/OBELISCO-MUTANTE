# Tarea R — fusil, granadas y botín del jugador

Leé primero `../SPEC.md` entero (sobre todo 0, 2, 3, 4.1, 4.3, 7 y 8). Tu carpeta es `R-fusil/`.

## Qué tenés que lograr

Facu eligió que el jugador pueda levantar **el fusil y las granadas** de los soldados que mata. Hoy el jugador tiene pistola (balas infinitas), escopeta de doble caño y Uzi. Vos sumás:

1. **El fusil** como cuarta arma, en primera persona, al mismo nivel de detalle que las otras tres: modelo, manos articuladas agarrándolo, recarga animada, retroceso, sonido, HUD.
2. **Granadas de mano** para el jugador (tecla G) y el **sistema de granadas** (`GRAN`) que también van a usar los soldados.
3. **Las cajas de botín** que sueltan los soldados al morir.

Todo sobre el juego real: entregás un parche sobre `../base.html` (protocolo en 3.3 de la SPEC).

## Antes de escribir

Leé en `../base-view.txt` cómo están hechas las armas actuales, porque el fusil tiene que ser una más:

- Líneas ~9193–9480: materiales `WM`, ayudantes de modelado en milímetros (`kExt`, `kBox`, `kCyl`, `kIn`…), manos, `buildPistol`, `buildShotgun`, `buildUzi`, sus `anim*` y `reload*`, la tabla `W=[…]` y la linterna montada en el arma.
- ~9495–9560: fogonazo, humo, vainas. ~9582–9610: retroceso `REC`.
- ~9612: `hudAmmo`. ~9660–9722: `reload`, `switchTo`, modos secundarios (`ALT_NAME`, `wAuto`, `wCd`), `curSpread`, `fire()`.
- ~10035–10055: cajas (`addPickup`, `addAmmo`, `updatePickups`).
- ~10867–11200: `MOV`, que tiene las manos, brazos y cuerpo nuevos en primera persona con poses por arma (`RUN`, agarres). Buscá dónde aparecen `'uzi'` y `'escopeta'` en todo el archivo: en cada uno de esos lugares hay que decidir qué hace el fusil.
- ~11292: `updateWeapon`. ~11654: teclado y rueda. `resetWeapons` (~9481). El HUD en el HTML (`#wslots`, `#shells`) y su CSS.
- `carBoom` (~3317) como referencia de cómo el juego hace una explosión: partículas con `vSpawn`, sonido con `vSfx('boom',…)`, daño al jugador y a los bichos.

## 1. El fusil

- `W[3]`, `id:'fusil'`, nombre `FUSIL`, tecla **4**. El jugador **no lo tiene** hasta que levanta uno (`w.owned`): mientras no lo tenga, su casilla del HUD no se muestra, y ni la tecla, ni la rueda, ni Q, ni el botón táctil lo seleccionan. `resetGame` lo quita.
- Modelo genérico (no copies un fusil real de fábrica), coherente con el de los soldados: fusil de asalto corto, negro, guardamanos con rieles, mira de punto rojo, cargador curvo de 30, culata extensible. La linterna del juego ya va montada en el arma: que quede bien ubicada.
- Números de partida: automático, 0,09 s entre balas, daño 22, cargador 30, reserva máxima 120, dispersión 0,028 sin apuntar y 0,0035 apuntando, alcance 160 m con caída de daño a partir de los 50 m (hasta 60 %). Al apuntar se mira por el punto rojo (campo de visión 50). Retroceso firme pero controlable. Tiro secundario (rueda apretada o B): **ráfaga de 3**, más precisa.
- Manos: la derecha en la empuñadura con el dedo en el gatillo; la izquierda en el guardamanos. En la recarga la izquierda saca el cargador, pone otro y golpea el pestillo. Correr y tirar: a dos manos desde la cadera, como la escopeta.
- Sonido propio (`sfx.fusil`, asignado desde tu módulo: ver 2.1 de la SPEC): seco y fuerte, distinto de la Uzi. Sonidos de recarga propios o los existentes.
- Vainas, fogonazo, humo: como las otras armas.
- Que nada de lo viejo cambie: pistola, escopeta y Uzi tienen que comportarse igual que antes (cambio de arma, recarga, modos secundarios, HUD, táctil).

## 2. Granadas

**`GRAN`** (contrato en 4.3):

- Física: tiro parabólico, rebote contra el piso (`floorAt`), paredes (`rayWalls`), obstáculos y autos (`rayCars`), con pérdida de energía; rueda un poco y se frena. No atraviesa nada.
- `GRAN.arco(desde,hasta,opt)`: la solución de lanzamiento que usan el jugador automático y los soldados. Tiene que ser consistente con tu física: lo que `arco` dice que cae en un lugar, cae ahí (probalo). Devuelve `ok:false` si el arco choca antes.
- Mecha: la que le pasen. Mientras vive: un pitido que se acelera y una luz roja chica que parpadea (sprite, no luz real), para que se la pueda ver y oír.
- Explosión: radio 7 m, daño 80 en el centro y 0 en el borde, ×0,3 si hay cobertura entre la granada y el blanco (rayo desde 0,3 m sobre la granada hasta el pecho). Daña al jugador (`hurtPlayer`, con empujón y sacudida), a los bichos (`damageEnemy`) y a los autos cercanos (`carDamage`: puede prenderlos y encadenar). Efecto visual y sonido propios, más chicos que la explosión de un auto. Marca en el piso. Y avisa `UEB.explosion(pos,7,80,de)`.
- `GRAN.lista` siempre al día (la lee la IA para esquivar y el HUD para avisar).
- La malla de la granada: si existe `UEM.granada` usala; si no, una propia simple.
- Opcional, solo si te sobra tiempo: `tipo:'humo'` (nube de 5 m que dura 14 s) y `GRAN.humos=[{p,r,t}]`. Si no entra, que `lanzar` con `'humo'` no rompa nada.

**El jugador:**

- Tecla **G**: lanza hacia donde mira, con un gesto de la mano izquierda (suelta el arma con esa mano, lanza, vuelve). No se puede en medio de una recarga, un cambio de arma, una trepada o una deslizada.
- Mecha de 3 s desde que sale de la mano. Avisá el lanzamiento con `UEB.ruido(pos,'granada',1)`.
- Lleva hasta 4. Arranca con 0. Contador en el HUD junto a la munición (solo se ve si tuvo alguna).
- La explosión propia le hace daño al jugador igual que cualquier otra.

## 3. Botín

Tipos nuevos de caja, con el mismo estilo que las actuales (giran, flotan, brillo propio, mensaje en el `feed`, sonido):

- **Fusil**: si el jugador no lo tiene, se lo da con el cargador lleno y lo selecciona; si ya lo tiene, +30 balas.
- **Balas de fusil** (5,56): +30.
- **Granada**: +1.
- **Botiquín**: +35 de salud (los soldados no sueltan empanadas).

`UEB.botin=(x,z,rol)=>{…}` decide qué cae. Punto de partida: el primer soldado que muere suelta siempre un fusil (si el jugador no tiene). Después: `jefe` y `granadero` sueltan balas de fusil (75 %); `granadero` suelta 1 o 2 granadas siempre y los demás 1 con 35 %; `asalto` suelta cartuchos de escopeta (los que ya existen); `tirador` suelta balas de fusil; cualquiera, botiquín con 40 %. Dejá las probabilidades en constantes con comentario.

Agregá las teclas nuevas a la ayuda de la pantalla de inicio (`<!--UE:ayuda-->`).

## Pruebas (con `../harness.js`)

En una misma corrida, sobre tu copia parcheada:

1. Partida normal de 30 s con oleada: sin errores. Pistola, escopeta y Uzi: disparar, recargar y cambiar de arma dan lo mismo que en `base.html` (compará balas y estados).
2. Sin fusil: tecla 4, rueda y Q no lo seleccionan. Soltar botín con `UEB.botin(x,z,'jefe')` cerca del jugador: lo levanta, queda seleccionado, HUD correcto. Disparar un cargador, recargar, ráfaga de 3, apuntar. Un bicho recibe el daño esperado.
3. Granada: `GRAN.arco` hacia 5 puntos a distintas distancias y alturas de obstáculo: mide dónde cae y cuánto erra. Rebote contra una pared y contra un auto. Explosión: daño al jugador a 2, 4 y 6 m, con y sin cobertura; a un bicho; a un auto; y que `UEB.explosion` se llame.
4. Reinicio (`resetGame`): sin fusil, sin granadas, sin cajas colgadas.
5. Capturas (ocultá el mapa para que sean rápidas, o no, como prefieras; miralas): fusil en mano quieto, apuntando por el punto rojo, a mitad de recarga, corriendo; el gesto de lanzar; una granada en el piso con su luz; la explosión; las cuatro cajas nuevas; el HUD con el fusil y el contador de granadas.

## Qué no hacer

- No toques la línea de `fire()` que tiene `SHJ.ray` ni el marcador `/*UE:rayo-jugador*/` que la sigue: ahí engancha el integrador las balas contra soldados. Dejá también el `UEB.ruido(ray.o,'disparo',…)` que ya está en `fire()`.
- No edites el objeto `sfx` ni `PRI`; no agregues luces reales.
- No toques nada fuera de `R-fusil/`.
