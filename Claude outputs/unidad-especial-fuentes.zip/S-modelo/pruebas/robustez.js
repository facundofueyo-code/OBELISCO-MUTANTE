/* visor en ronda un buen rato + casos borde del contrato, en Chromium */
const H=require('../../harness.js'),path=require('path');
(async()=>{const h=await H.openPage(path.join(__dirname,'..','prueba.html'),{width:640,height:360});
  await h.page.waitForFunction(()=>window.V);
  await h.page.waitForTimeout(2500);                    /* deja correr el bucle real un rato */
  const r=await h.page.evaluate(()=>{
    const out={};V.pausa(true);
    V.rol('todos');V.linterna(true);V.laser(true);V.ronda(true);V.avanzar(95);out.rondaTodos=V.info();
    V.rol('tirador');V.ronda(true);V.avanzar(95);out.rondaUno=V.info();V.ronda(false);
    for(const p of V.poses){V.pose(p);V.avanzar(2.2);}
    out.poses=V.poses.length;
    /* casos borde */
    const s=new THREE.Scene(),u=UEM.crear('nadie');s.add(u.root);out.rolDesconocido=u.rol;
    u.update(0);u.update(5);u.update(NaN);u.root.position.set(500,0,500);u.update(1/60);
    u.e.muerte={tipo:'inventada',t:.5,dir:2};u.update(1/60);u.e.muerte.t=1;u.update(1/60);u.e.muerte=null;u.update(1/60);
    u.e.recarga=.5;u.e.lanza=.5;u.e.senal=.5;u.e.culata=.5;u.e.salto=.5;u.e.radio=1;u.e.aturdido=1;u.e.asoma=1;u.e.tierra=.5;u.update(1/60);
    const v=new THREE.Vector3();out.boca=u.boca(v).toArray().map(x=>+x.toFixed(2));out.ojos=u.ojos(v).toArray().map(x=>+x.toFixed(2));
    out.rayoErra=u.rayo(new THREE.Vector3(0,50,0),new THREE.Vector3(0,1,0));
    let nan=false;u.root.updateMatrixWorld(true);for(const b of u.malla.skeleton.bones)for(const x of b.matrixWorld.elements)if(!isFinite(x))nan=true;out.nan=nan;
    u.soltarArma();u.soltarArma();u.dispose();out.disposeOk=!u.root.parent;
    out.calentar=window.__calentar===undefined?UEM.calentar(s,true):window.__calentar;UEM.calentar(s,false);out.restos=s.children.length;
    out.granada=!!UEM.granada().geometry;
    return out;});
  console.log(JSON.stringify(r));console.log('errores',JSON.stringify(h.errors));await h.close();})().catch(e=>{console.error(e);process.exit(1);});
