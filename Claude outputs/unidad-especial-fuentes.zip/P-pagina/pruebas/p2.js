/* Prueba 2: capturas de reposo, combate (mirando una pelea) y «Ver lo que saben». */
const path = require('path');
const H = require(path.join(__dirname, '../../harness.js'));
const PAG = path.join(__dirname, '../prueba.html');
const CAP = path.join(__dirname, '../cap/');
const quiero = process.argv.slice(2);
(async () => {
  const h = await H.openPage(PAG, { width: 1280, height: 800 });
  const p = h.page;
  try {
    await p.waitForTimeout(800);
    await p.evaluate(() => { UEPAG.congelar(true); UEPAG.avanzar(4); });
    if (quiero.includes('reposo')) await p.screenshot({ path: CAP + '2-reposo.png', clip: { x: 0, y: 200, width: 1280, height: 600 } });
    await p.click('#bMirarV');
    await p.evaluate(() => UEPAG.congelar(true));
    let info;
    for (let i = 0; i < 60; i++) { info = await p.evaluate(() => UEPAG.avanzar(1)); if (info.combate && info.t > 22) break; }
    // buscar un cuadro con trazadoras o láser
    const r = await p.evaluate(() => { for (let i = 0; i < 400; i++) { UEPAG.avanzar(1 / 60); const P = UEPAG.P; if (P.trazas.length >= 2 && P.radio.length >= 2) return { i, t: UEPAG.M.t, trazas: P.trazas.length }; } return null; });
    console.log('combate:', JSON.stringify(r), JSON.stringify({ t: info.t, quedan: info.quedan, hp: info.hp }));
    await p.evaluate(() => { document.getElementById('stage').scrollIntoView({ block: 'center' }); });
    if (quiero.includes('combate')) await p.screenshot({ path: CAP + '3-combate.png' });
    await p.evaluate(() => { UEPAG.alternarSaben(); UEPAG.dibujar(); });
    if (quiero.includes('saben')) await p.screenshot({ path: CAP + '4-saben.png' });
    console.log('errores:', h.errors.length ? h.errors.slice(0, 5).join('\n') : 0);
  } finally { await h.close(); }
})();
