/* Prueba 1: carga, reposo con el velo, «Mirar una pelea» 90 s de juego adelantando el tiempo. */
const path = require('path');
const H = require(path.join(__dirname, '../../harness.js'));
const PAG = path.join(__dirname, '../prueba.html');
const CAP = path.join(__dirname, '../cap/');
const fotos = process.argv.includes('--fotos');
(async () => {
  const h = await H.openPage(PAG, { width: 1280, height: 800 });
  const p = h.page;
  try {
    await p.waitForTimeout(1200);
    const r0 = await p.evaluate(() => ({ info: UEPAG.info(), velo: !document.getElementById('velo').hidden, sw: document.documentElement.scrollWidth, iw: innerWidth }));
    console.log('reposo:', JSON.stringify({ t: r0.info.t, quedan: r0.info.quedan, velo: r0.velo, sw: r0.sw, iw: r0.iw }));
    if (fotos) await h.shotPage(CAP + '1-reposo.png');
    await p.click('#bMirarV');
    await p.evaluate(() => UEPAG.congelar(true));
    let info = null, enCombate = null;
    for (let i = 0; i < 18; i++) {
      info = await p.evaluate(() => UEPAG.avanzar(5));
      if (info.combate && enCombate === null) enCombate = info.t;
      if (info.fin) break;
    }
    console.log('mirar:', JSON.stringify({ t: info.t, fin: info.fin, vivo: info.vivo, hp: info.hp, quedan: info.quedan, bajas: info.bajas, combateDesde: enCombate }));
    console.log('cuentas:', JSON.stringify(info.cuentas));
    console.log('radio:', info.radio.join(' | '));
    console.log('errores:', h.errors.length ? h.errors.slice(0, 5).join('\n') : 0);
  } finally { await h.close(); }
})();
