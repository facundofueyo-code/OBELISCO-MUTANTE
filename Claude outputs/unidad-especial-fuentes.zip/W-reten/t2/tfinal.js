/* Prueba final del retén (lógica, sin dibujar). Uso: node tfinal.js [juego.html] */
const path = require('path'), fs = require('fs');
const UE = path.resolve(__dirname, '..', '..');
const H = require(path.join(UE, 'harness.js'));
const t0 = Date.now(); const log = (...a) => console.log(((Date.now() - t0) / 1000).toFixed(0) + 's', ...a);
const J = o => JSON.stringify(o);
const S = "JSON.stringify({x:+P.pos.x.toFixed(2),y:+P.pos.y.toFixed(2),z:+P.pos.z.toFixed(2)})";
(async () => {
  const h = await H.open(process.argv[2] || path.join(__dirname, 'juego.html'));
  try {
    await h.ev("(()=>{const a=RETEN.armar;RETEN.armar=function(){window.__orig=VCARS.map(c=>[c.x,c.z,c.a]);const t=performance.now();const r=a.apply(this,arguments);window.__ms=performance.now()-t;return r;};return 1;})()");
    await h.start();
    log('1) armar', Math.round(await h.ev('window.__ms')), 'ms · avisos', J(await h.ev('RETEN.avisos')), '· errores', h.errors.length);
    log('   autos movidos (índices VCARS)', J(await h.ev("VCARS.map((c,i)=>{const o=window.__orig[i];return (Math.abs(o[0]-c.x)+Math.abs(o[1]-c.z)+Math.abs(o[2]-c.a))>1e-6?i:-1;}).filter(i=>i>=0)")), '· total VCARS', await h.ev('VCARS.length'));
    /* partida normal 30 s con oleada en la zona A */
    await h.ev("intermission=.1;1");
    for (let i = 0; i < 6; i++) await h.step(5, 1 / 60, 'P.hp=100');
    log('2) 30 s en la zona A', await h.ev("JSON.stringify({wave,bichos:enemies.length,STAGE,autosA_movidos:VCARS.slice(0,469).filter((c,i)=>{const o=window.__orig[i];return Math.abs(o[0]-c.x)+Math.abs(o[1]-c.z)>1e-6;}).length})"), '· errores', h.errors.length);
    await h.ev("resetGame();running=true;over=false;1");
    log('3) datos', J(await h.ev('RETEN.datos')));
    const v = await h.ev('RETEN.verificar()');
    log('   verificar: ok', v.ok, '· nido sobre furgón', v.nidoSobreFurgon, '· puntos', v.puntos.length, '· libres', v.puntos.filter(p => p.libre).length, '· conectados', v.puntos.filter(p => p.conectado).length);
    log('   fila', J(await h.ev("RETEN.autos.map(c=>[VCARS.indexOf(c),c.S.id,+c.x.toFixed(1),+c.z.toFixed(1)])")));
    log('   chequeo fila (círculos ajenos a <0,15 m, ruedas fuera de la calzada, distancia mínima entre autos de la fila)', J(await h.ev(`(()=>{const F=RETEN.autos;let pegados=0,fuera=0,dmin=1e9;
      for(const c of F){for(const q of c.cs)for(const o of circles){if(o.dead||c.cs.includes(o)||(o.brk&&o.brk.k==='car'&&F.includes(o.brk.c)))continue;if(Math.hypot(o.x-q.x,o.z-q.z)-o.r-q.r<.15)pegados++;}
        const sa=Math.sin(c.a),ca=Math.cos(c.a);for(const [f,l] of [[.96,.96],[.96,-.96],[-.96,.96],[-.96,-.96]])if(!PISO.calzada(c.x+sa*f*c.L/2+ca*l*c.W/2,c.z+ca*f*c.L/2-sa*l*c.W/2))fuera++;
        for(const o of F)if(o!==c)for(const q of c.cs)for(const p of o.cs)dmin=Math.min(dmin,Math.hypot(p.x-q.x,p.z-q.z)-p.r-q.r);}
      const xs=F.filter(c=>c.x>-432&&c.x<-366).map(c=>c.x).sort((a,b)=>b-a);return {pegados,fuera,separacionMin:+dmin.toFixed(2),pasos:xs.slice(1).map((x,i)=>+(xs[i]-x).toFixed(1))};})()`)));
    log('   luz', J(await h.ev("[[-428,606],[-418,607],[-410,606],[-400,608],[-392,608],[-385,607],[-370,606],[-410.8,600.2],[-446,609]].map(([x,z])=>[x,z,+RETEN.luz(x,z).toFixed(2)])")));
    log('   costo cpu: luz() µs/llamada', await h.ev("(()=>{const t=performance.now();let s=0;for(let i=0;i<20000;i++)s+=RETEN.luz(-440+Math.random()*70,596+Math.random()*22);return +((performance.now()-t)/20000*1000).toFixed(2);})()"),
      '· fx() µs/cuadro', await h.ev("(()=>{SECG.B.visible=true;const t=performance.now();for(let i=0;i<2000;i++)RETEN.fx(1/60);return +((performance.now()-t)/2000*1000).toFixed(1);})()"),
      '· hornear() ms', await h.ev("(()=>{const t=performance.now();RETEN.hornear();return Math.round(performance.now()-t);})()"));
    /* 4) caminar, saltar vallas, chocar */
    await h.alReten(-326, 606.8); await h.ev("P.pos.y=floorAt(P.pos.x,P.pos.z);1");
    await h.step(20, 1 / 60, "keys.KeyW=true;P.yaw=Math.PI/2;P.hp=100");
    log('4) 20 s al oeste por z=606,8 → frena en la valla del medio (cara este x=-437,7, radio 0,45)', await h.ev(S));
    await h.step(.05, 1 / 60, "keys.KeyW=true;keys.Space=true;P.yaw=Math.PI/2"); await h.step(1.2, 1 / 60, "keys.KeyW=true;keys.Space=false;P.yaw=Math.PI/2");
    log('   Espacio contra la valla del medio → del otro lado', await h.ev(S));
    for (const [x, z, yaw, nom] of [[-431, 603, Math.PI / 2, 'furgón norte (cara este -436,94)'], [-431, 612, Math.PI / 2, 'furgón sur (cara este -436,94)'], [-445, 598.3, -Math.PI / 2, 'valla norte desde el oeste (cara -438,3)'], [-431, 616.2, Math.PI / 2, 'valla sur desde el este (cara -437,7)'], [-452, 609.6, -Math.PI / 2, 'camioneta desde el oeste (cola... trompa en -449,3)']]) {
      await h.ev(`P.pos.set(${x},floorAt(${x},${z}),${z});P.vel.set(0,0,0);P.yaw=${yaw};MOV.reset();1`);
      await h.step(3, 1 / 60, `keys.KeyW=true;P.yaw=${yaw};P.hp=100`);
      log('   choca:', nom, await h.ev(S));
    }
    await h.ev("P.pos.set(-433,floorAt(-433,598.7),598.7);P.vel.set(0,0,0);MOV.reset();1");
    await h.step(1.2, 1 / 60, "keys.KeyW=true;P.yaw=Math.PI/2;P.hp=100"); await h.step(.05, 1 / 60, "keys.KeyW=true;keys.Space=true;P.yaw=Math.PI/2"); await h.step(1.2, 1 / 60, "keys.KeyW=true;keys.Space=false;P.yaw=Math.PI/2");
    log('   salto valla norte desde el este', await h.ev(S));
    await h.ev("keys.KeyW=false;keys.Space=false;1");
    /* 5) balas: Uzi contra el furgón 782 de la fila hasta prenderlo y que explote; rayo contra el furgón del retén */
    const tgt = await h.ev("(()=>{const c=RETEN.autos.find(c=>c.S.id==='furgon'&&c.x<-400);return {x:c.x,z:c.z,i:VCARS.indexOf(c)};})()");
    const aim = `{const dx=${tgt.x}-P.pos.x,dz=${tgt.z}-P.pos.z;P.yaw=Math.atan2(-dx,-dz);P.pitch=-.1;}`;
    await h.ev(`P.pos.set(-414,floorAt(-414,608.5),608.5);P.vel.set(0,0,0);MOV.reset();switchTo(2);1`); await h.step(1, 1 / 60, "P.hp=100;" + aim);
    const hist = []; for (let k = 0; k < 5; k++) { await h.step(1, 1 / 60, `P.hp=100;mouseDown=true;W[2].ammo=32;W[2].res=999;resetRecoil();W[2].bloom=0;${aim}`); hist.push(await h.ev(`VCARS[${tgt.i}].hits+'/'+VCARS[${tgt.i}].st`)); }
    await h.ev("mouseDown=false;P.pos.set(-370,floorAt(-370,607),607);1"); await h.step(9, 1 / 60, "P.hp=100;mouseDown=false");
    log('5) Uzi contra el auto', tgt.i, 'golpes/estado por segundo', hist.join(' '), '→', J(await h.ev(`(()=>{const c=VCARS[${tgt.i}],e=RETEN.piezas.HD,r=c.rg.find(r=>r[0]===e);return {st:c.st,circulosMuertos:c.cs.filter(q=>q.dead).length,restos:VWRECK.length,calcoY:r?+e.mesh.geometry.attributes.position.array[r[1]*3+1].toFixed(1):null};})()`)));
    log('   bala contra el furgón norte del retén desde x=-425', J(await h.ev(`(()=>{const o=new THREE.Vector3(-425,1.5,603.3),d=new THREE.Vector3(-1,0,0);let best=1e9,k=null;for(const b of obstacles){const t=rayBox(o,d,b);if(t<best){best=t;k=b.k||'?';}}return {t:+best.toFixed(2),k,detras:rayCars(o,d,60)?VCARS.indexOf(rayCars(o,d,60).car):null};})()`)));
    await h.ev("resetGame();1");
    log('6) tras resetGame', J(await h.ev(`(()=>{const c=VCARS[${tgt.i}],e=RETEN.piezas.HD,r=c.rg.find(r=>r[0]===e),F=RETEN.autos;return {st:c.st,hits:c.hits,x:c.x,z:c.z,restos:VWRECK.length,calcoY:r?+e.mesh.geometry.attributes.position.array[r[1]*3+1].toFixed(2):null,
      filaEntera:F.every(c=>c.st===0&&c.cs.every(q=>!q.dead)),obsEnJuego:RETEN.obs.every(b=>obstacles.includes(b)),verificar:RETEN.verificar().ok};})()`)));
    /* 7) RETEN.ir sin y con bichos */
    let t1 = Date.now(); await h.ev("RETEN.ir({bichos:false});1");
    log('7) RETEN.ir({bichos:false})', Date.now() - t1, 'ms', J(await h.ev("({running,STAGE,gate:GATE.open,wave,intermission,esc:W[1].res,uzi:W[2].res,x:+P.pos.x.toFixed(1),y:+P.pos.y.toFixed(2),z:+P.pos.z.toFixed(1),yaw:+P.yaw.toFixed(3),cartel:$('#left').textContent})")));
    await h.step(15, 1 / 60, "P.hp=100"); log('   15 s después', J(await h.ev("({wave,bichos:enemies.length,toSpawn})")));
    t1 = Date.now(); await h.ev("RETEN.ir({bichos:true});1");
    log('   RETEN.ir({bichos:true})', Date.now() - t1, 'ms', J(await h.ev("({wave,intermission,bossCount})")));
    await h.step(20, 1 / 60, "P.hp=100"); log('   20 s desde el arranque', J(await h.ev("({wave,bichos:enemies.length,porSalir:toSpawn,aMenosDe4m:enemies.filter(e=>Math.hypot(e.obj.position.x-P.pos.x,e.obj.position.z-P.pos.z)<4).length})")));
    await h.ev("P.pos.set(-416,floorAt(-416,607.5),607.5);P.vel.set(0,0,0);1");
    const pos = []; for (let k = 0; k < 4; k++) { await h.step(5, 1 / 60, "P.hp=100"); pos.push(await h.ev("enemies.map(e=>[e.type,+e.obj.position.x.toFixed(1),+e.obj.position.z.toFixed(1)])")); }
    const ult = pos[3], ant = pos[1];
    log('   20 s más con el jugador al este de la barricada (x=-416)', J({ bichos: ult.length, alEste: ult.filter(e => e[1] > -436).length, aMenosDe4m: await h.ev("enemies.filter(e=>Math.hypot(e.obj.position.x-P.pos.x,e.obj.position.z-P.pos.z)<4).length"),
      quietosEnLaBarricada: ult.filter(([t, x, z], i) => x > -452 && x < -430 && ant[i] && Math.hypot(ant[i][1] - x, ant[i][2] - z) < 1) }));
    await h.ev("gameOver();1"); await h.ev("document.getElementById('btnAgain').click();1");
    log('8) «Otra vuelta» tras morir en el retén', J(await h.ev("({running,STAGE,wave,x:+P.pos.x.toFixed(1),z:+P.pos.z.toFixed(1)})")));
    await h.ev("gameOver();document.getElementById('btnStart').click();1");
    log('   botón normal después', J(await h.ev("({running,STAGE,wave,x:+P.pos.x.toFixed(1),z:+P.pos.z.toFixed(1)})")));
    log('errores', h.errors.length ? h.errors.join('\n').slice(0, 3000) : 'ninguno');
  } finally { await h.close(); log('cerrado'); }
})().catch(e => { log('FALLA', e.message.slice(0, 2000)); process.exit(1); });
