
/* ====================================================================================
   ANIMACIÓN DEL SOLDADO VIVO
   Orden de cada cuadro: movimiento del root → pies (clavados en el mundo, con el paso atado a la
   distancia) → cadera y columna (postura, puntería, capas) → cabeza → arma → manos → miembros.
   ==================================================================================== */

/* posturas fijas: rodillas en el piso → plancha con una mano al piso → panza abajo.
   pies: {anc:[x,z,rumbo,cabeceo]} (apoyado, con piePlantado) o {p,fwd,up}; y el polo de la rodilla */
function poseFija(pel,pelE,colE,pecE,pies){
  const p=nuevaPose();p.pel.set(...pel);qE(p.pelQ,...pelE);qE(p.col,...colE);qE(p.pec,...pecE);
  for(let i=0;i<2;i++){const f=pies[i],o=p.pie[i];
    if(f.anc){piePlantado(o,f.anc[0],0,f.anc[1],f.anc[2],f.anc[3]);p.punta[i]=-f.anc[3];}
    else{o.p.set(...f.p);qBase(o.q,new V3(...f.fwd),new V3(...f.up));p.punta[i]=0;}
    o.polo.set(...f.polo).normalize();}
  return p;
}
const K_RODILLAS=poseFija([0,.53,-.06],[.22,0,0],[.12,0,0],[.1,0,0],
  [{anc:[.12,-.585,0,1.15],polo:[0,-.35,1]},{anc:[-.12,-.585,0,1.15],polo:[0,-.35,1]}]);
const K_MANOS=poseFija([0,.37,-.40],[1.28,0,0],[.12,0,0],[.06,0,0],
  [{anc:[.14,-1.38,0,1.3],polo:[0,-.3,1]},{anc:[-.14,-1.38,0,1.3],polo:[0,-.3,1]}]);
const K_TIERRA=poseFija([0,.19,-.12],[PI/2,0,0],[-.26,0,0],[-.36,0,0],
  [{p:[.27,.105,-1.0],fwd:[.3,-.28,-.91],up:[.1,-.95,.28],polo:[.6,-1,0]},{p:[-.27,.105,-1.0],fwd:[-.3,-.28,-.91],up:[-.1,-.95,.28],polo:[-.6,-1,0]}]);
/* pie al arrastrarse: la pierna activa se recoge hacia el costado */
const PIE_ARRASTRE=[new V3(.40,.08,-.60),new V3(-.40,.08,-.60)],POLO_ARRASTRE=[new V3(1,-.25,.3).normalize(),new V3(-1,-.25,.3).normalize()];

/* descanso de los pies (modelo): [x, z, rumbo] de pie quieto / de pie andando / rodilla en tierra / agachado andando */
const DESCANSO=[
  [[.14,.11,.12],[.10,0,.06],[.13,.31,.10],[.14,0,.15]],
  [[-.13,-.12,-.38],[-.10,0,-.06],[-.15,-.42,-.15],[-.14,0,-.15]]];

/* claves de las capas (constantes: nada se arma en cada cuadro) */
const KC1=[[0,0],[.25,0],[.45,-.6],[.56,.45],[.75,.3],[1,0]],
  KC2=[[0,0],[.3,0],[.45,-.15],[.56,.25],[.72,.15],[1,0]],
  KC3=[[0,0],[.3,-.45],[.42,-.1],[.5,.45],[.65,.35],[1,0]],
  KC4=[[0,0],[.3,-.05],[.5,.22],[.65,.15],[1,0]],
  KC5=[[0,0],[.3,-.04],[.5,.11],[.7,.08],[1,0]],
  KC6=[[0,0],[.15,-.1],[.3,.1],[.45,.36],[.62,.24],[.78,-.12],[.9,-.05],[1,0]],
  KC7=[[0,0],[.3,.08],[.6,.05],[1,0]],
  KC8=[[0,0],[.3,.4],[.5,.62],[.75,.2],[1,0]],
  KC9=[[0,0],[.35,.25],[.55,.35],[.75,0]],
  KC10=[[0,-.12,.12,.12],[.3,-.24,.10,-.02],[.42,-.12,.20,.25],[.5,-.03,.30,.52],[.62,-.04,.28,.47],[.85,-.1,.15,.2],[1,-.12,.12,.12]],
  KC11=[[0,.25,-.3,1],[.3,.55,.35,.75],[.42,1,.25,-.05],[.5,.38,-.3,-.88],[.62,.4,-.25,-.88],[.85,.3,-.2,.9],[1,.25,-.3,1]],
  KC12=[[.17,0],[.25,.14],[.33,.25]],
  KC13=[[.48,.12],[.58,.06],[.64,0]],
  KC14=[[0,0],[.15,0],[.55,1],[.8,1],[1,0]],
  KC15=[[0,-.1,-.05,.25],[.14,.02,-.06,.22],[.24,-.05,.12,.3],[.40,-.30,.36,-.22],[.47,-.32,.38,-.18],[.55,-.12,.48,.38],[.68,.14,-.18,.38],[.8,.05,-.1,.3],[1,-.1,-.05,.25]],
  KC16=[[0,-.7,-.6,-.2],[.24,-.8,-.4,-.2],[.40,-.7,.55,-.45],[.55,-.6,.3,.2],[.68,-.4,-.7,.3],[1,-.7,-.6,-.2]],
  KC17=[[0,-.5],[.4,.6],[.55,.2],[.7,-.6]],
  KC18=[[0,0],[.35,1],[.55,1],[1,0]];
const fr=x=>x-Math.floor(x);
/* curva por tramos: claves [[t,v],…] con escalón suave entre claves */
function curva(t,k){if(t<=k[0][0])return k[0][1];for(let i=1;i<k.length;i++)if(t<=k[i][0]){const a=k[i-1],b=k[i];return lerp(a[1],b[1],ease((t-a[0])/(b[0]-a[0])));}return k[k.length-1][1];}
/* lo mismo con vectores: claves [[t,x,y,z],…] */
function curvaV(t,k,o){if(t<=k[0][0])return o.set(k[0][1],k[0][2],k[0][3]);
  for(let i=1;i<k.length;i++)if(t<=k[i][0]){const a=k[i-1],b=k[i],w=ease((t-a[0])/(b[0]-a[0]));return o.set(lerp(a[1],b[1],w),lerp(a[2],b[2],w),lerp(a[3],b[3],w));}
  const z=k[k.length-1];return o.set(z[1],z[2],z[3]);}
/* resorte amortiguado: x'' = -w²x - 2zw x' */
function resorte(s,x,v,w,z,dt){const a=-w*w*s[x]-2*z*w*s[v];s[v]+=a*dt;s[x]+=s[v]*dt;}

/* pasa un punto del marco del pecho (o de cualquier hueso) al modelo */
const aModelo=(st,hueso,x,y,z,o)=>o.set(x,y,z).applyQuaternion(st.Q[hueso]).add(st.P[hueso]);

/* ---------- movimiento del root ---------- */
function movimiento(st,root,dt){
  const yaw=root.rotation.y,px=root.position.x,pz=root.position.z;
  if(st.nuevo){st.prevX=px;st.prevZ=pz;st.prevYaw=yaw;st.nuevo=false;st.reubicar=true;}
  let dx=px-st.prevX,dz=pz-st.prevZ;st.prevX=px;st.prevZ=pz;
  if(dx*dx+dz*dz>2.25){dx=dz=0;st.reubicar=true;st.vel.set(0,0,0);}     /* teletransporte: se reacomoda */
  st.dyaw=envol(yaw-st.prevYaw);st.prevYaw=yaw;st.yaw=yaw;st.px=px;st.pz=pz;
  st.cy=Math.cos(yaw);st.sy=Math.sin(yaw);
  st.dist=Math.hypot(dx,dz)/st.k;
  if(dt>0){const a=Math.min(1,dt*9);st.vel.x+=(dx/st.k/dt-st.vel.x)*a;st.vel.z+=(dz/st.k/dt-st.vel.z)*a;}
  st.rap=Math.hypot(st.vel.x,st.vel.z);
  st.vlx=st.cy*st.vel.x-st.sy*st.vel.z;st.vlz=st.sy*st.vel.x+st.cy*st.vel.z;   /* velocidad en el marco del cuerpo */
}
const aMundo=(st,lx,lz,o)=>{o.x=st.px+(st.cy*lx+st.sy*lz)*st.k;o.z=st.pz+(-st.sy*lx+st.cy*lz)*st.k;return o;};
const aLocal=(st,wx,wz,o)=>{const dx=(wx-st.px)/st.k,dz=(wz-st.pz)/st.k;o.x=st.cy*dx-st.sy*dz;o.z=st.sy*dx+st.cy*dz;return o;};

/* ---------- pies clavados en el mundo ----------
   Andando, la fase avanza con la distancia: cada pie levanta cuando su fase entra en vuelo y cae
   adelante, en el lugar donde va a quedar el cuerpo (predicción con la velocidad). Apoyado no se mueve
   en el mundo: no patina. Quieto, si un pie quedó lejos de su lugar (frenó a mitad de paso, giró,
   cambió de postura), da un paso corto para acomodarse. */
const _fa=new V3(),_fb=new V3();
function pies(st,dt,L,beta,alza,mv,ag,cr){
  const kn=ag*(1-mv);
  for(let i=0;i<2;i++){const D=DESCANSO[i];
    st.rest[i].set(descanso(D,0,mv,ag),0,descanso(D,1,mv,ag));st.restYaw[i]=descanso(D,2,mv,ag);}
  if(st.reubicar){for(let i=0;i<2;i++){const f=st.pie[i];aMundo(st,st.rest[i].x,st.rest[i].z,f.w);f.yaw=st.yaw+st.restYaw[i];f.vuelo=false;f.pos.copy(f.w);f.yawAct=f.yaw;f.alto=0;f.cab=0;f.ciclo=-9;}st.reubicar=false;}
  const mov=st.rap>.06&&st.ti<.5,vn=st.rap||1,dwx=st.vel.x/vn,dwz=st.vel.z/vn;
  const err=st.errPie;
  for(let i=0;i<2;i++){const f=st.pie[i];aMundo(st,st.rest[i].x,st.rest[i].z,_fa);
    err[i]=Math.hypot(f.w.x-_fa.x,f.w.z-_fa.z)/st.k+.16*Math.abs(envol(f.yaw-st.yaw-st.restYaw[i]));}
  for(let i=0;i<2;i++){
    const f=st.pie[i],o=st.pie[1-i],yawR=st.yaw+st.restYaw[i],q=fr(st.fase+i*.5),ciclo=Math.floor(st.fase+i*.5);
    aMundo(st,st.rest[i].x,st.rest[i].z,_fa);
    if(f.vuelo){
      if(f.modo===0){
        const sF=ciclo>f.ciclo?1:(q-f.q0)/(1-f.q0);
        f.s=mov?Math.max(f.s,Math.min(1,sF)):Math.min(1,f.s+dt/.2);
        const resto=mov?((1-f.s)*(1-beta)*L+beta*L*.4)*st.k:0;   /* cae un poco adelante: el apoyo queda más atrás que adelante */
        _fb.set(_fa.x+dwx*resto,0,_fa.z+dwz*resto);
      }else{f.s=Math.min(1,f.s+dt/f.dur);_fb.copy(_fa);}
      const w=ease(f.s);
      f.pos.x=lerp(f.desde.x,_fb.x,w);f.pos.z=lerp(f.desde.z,_fb.z,w);
      f.alto=f.alza*Math.pow(Math.sin(PI*f.s),.8);
      f.yawAct=f.desdeYaw+envol(yawR-f.desdeYaw)*w;
      f.cab=f.modo===0?(-(.5+.4*cr)*Math.sin(PI*Math.min(1,f.s*1.7))*(f.s<.59?1:0)+.28*sst(.55,.85,f.s)*(1-sst(.9,1,f.s))):0;
      if(f.s>=1){f.vuelo=false;f.w.copy(_fb);f.yaw=yawR;f.pos.copy(f.w);f.yawAct=yawR;f.alto=0;f.cab=0;}
    }else{
      f.pos.copy(f.w);f.yawAct=f.yaw;f.alto=0;f.cab=0;
      if(mov){
        if(q>=beta&&ciclo>f.ciclo&&(cr>.3||!o.vuelo)){f.vuelo=true;f.modo=0;f.s=0;f.q0=Math.min(q,.97);f.ciclo=ciclo;f.desde.copy(f.w);f.desdeYaw=f.yaw;f.alza=alza;}
      }else if(!o.vuelo&&st.t>st.pausaPaso&&st.ti<.3){
        const umbral=kn>.5?.07:.11;
        if(err[i]>umbral&&err[i]>=err[1-i]){f.vuelo=true;f.modo=1;f.s=0;f.dur=lerp(.24,.32,ag);f.desde.copy(f.w);f.desdeYaw=f.yaw;f.alza=lerp(.07,.05,ag);st.pausaPaso=st.t+f.dur+.04;}
      }
    }
  }
}

/* ---------- el soldado vivo ---------- */
const _v=[0,1,2,3,4,5,6,7].map(()=>new V3()),_w=[0,1,2,3].map(()=>new Q4());
/* lleva una mano hacia el objetivo de una capa (_v[5] posición, _w[3] giro, _v[6] codo) con peso w */
function fijar(m,w){if(w<=0)return;m.p.lerp(_v[5],w);m.q.slerp(_w[3],w);m.polo.lerp(_v[6],w).normalize();}
function descanso(D,j,mv,ag){return lerp(lerp(D[0][j],D[1][j],mv),lerp(D[2][j],D[3][j],mv),ag);}
function vivo(st,e,dt){
  const sp=st.sp,fi=st.ficha,P=st.P,Q=st.Q,a1=_v[0],a2=_v[1],a3=_v[2],a4=_v[3],a5=_v[4],a6=_v[5],a7=_v[6],a8=_v[7],q1=_w[0],q2=_w[1],q3=_w[2],q4=_w[3];
  /* entradas, apenas suavizadas (la IA puede saltar de golpe) */
  st.ap+=(sat(e.apunta)-st.ap)*Math.min(1,dt*14);st.ag+=(sat(e.agach)-st.ag)*Math.min(1,dt*12);st.ti+=(sat(e.tierra)-st.ti)*Math.min(1,dt*12);
  st.as+=(clamp(e.asoma||0,-1,1)-st.as)*Math.min(1,dt*10);st.mYaw+=(clamp(e.mYaw||0,-1.3,1.3)-st.mYaw)*Math.min(1,dt*18);st.mPitch+=(clamp(e.mPitch||0,-.9,.9)-st.mPitch)*Math.min(1,dt*18);
  st.radio+=(sat(e.radio||0)-st.radio)*Math.min(1,dt*8);st.aturd+=(sat(e.aturdido||0)-st.aturd)*Math.min(1,dt*5);
  const ti=st.ti,ag=st.ag*(1-sst(0,.35,ti)),rap=st.rap,mv=sst(.1,.55,rap),cr=sst(2.6,4.8,rap)*(1-ag),at=st.aturd;
  const rec=e.recarga>=0?sat(e.recarga):-1,lan=e.lanza>=0?sat(e.lanza):-1,sen=e.senal>=0?sat(e.senal):-1,cul=e.culata>=0?sat(e.culata):-1,sal=e.salto>=0?sat(e.salto):-1;
  /* ---- paso ---- */
  const L=lerp(.8+.4*rap,.66+.3*rap,ag)*st.ritmo,beta=lerp(lerp(.54,.26,cr),.6,ag),alza=lerp(lerp(.11,.2,cr),.075,ag);
  if(rap>.05&&ti<.5)st.fase+=st.dist/L;
  if(ti>.5&&rap>.03)st.faseR+=st.dist/.9;
  pies(st,dt,L,beta,alza,mv,ag,cr);
  /* ---- pose base de pie / agachado ---- */
  const fw=st.fase*TAU;
  let py=lerp(lerp(lerp(.948-.012*st.ap,.945,mv),.915,cr),lerp(.535,.67,mv),ag);
  py+=mv*(1-ag*.5)*(-.016*(1-cr)*Math.cos(2*fw)-.03*cr*Math.cos(2*fw-beta*TAU))+st.respira*.004*Math.sin(st.t*1.6+st.fase0);
  const osc=.07*mv*(1-cr*.5)*Math.sin(fw);
  sp.pel.set(.022*mv*(1-cr)*Math.sin(fw)+.1*st.as*(1-ti),py-.05*Math.abs(st.as),lerp(0,.05,cr)+lerp(0,-.04,ag*(1-mv)));
  const lean=lerp(lerp(.09+.07*st.ap,.1,mv),.24,cr)+lerp(0,lerp(.12,.38,mv),ag);
  qE(sp.pelQ,lean*.6,.2*st.mYaw-.06*st.ap+osc,0);
  qE(sp.col,lean*.2+.06*at,.3*st.mYaw-osc*.6,.4*st.as);
  qE(sp.pec,lean*.2-.1*st.mPitch*(1-ti)+.1*at,.33*st.mYaw-(.16+.14*st.ap)*(1-ti)-osc*.4,.32*st.as);
  /* piernas desde los pies clavados */
  for(let i=0;i<2;i++){const f=st.pie[i],o=sp.pie[i];aLocal(st,f.pos.x,f.pos.z,a1);
    const ry=envol(f.yawAct-st.yaw),arrod=i===1?ag*(1-mv)*(1-ti):0;
    piePlantado(o,a1.x,f.alto,a1.z,ry,f.vuelo?f.cab:1.15*arrod);
    sp.punta[i]=f.vuelo?0:-1.15*arrod;
    o.polo.set(Math.sin(ry)+(i?-.15:.15),-.45*arrod,Math.cos(ry)).normalize();}
  /* cuerpo a tierra: rodillas → manos al piso → panza abajo (pasando por poses intermedias) */
  if(ti>.001){
    if(ti<.4)mezclarPose(sp,sp,K_RODILLAS,ease(ti/.4),false);
    else if(ti<.7)mezclarPose(sp,K_RODILLAS,K_MANOS,ease((ti-.4)/.3),false);
    else{const pr=st.poseT;copiarPose(pr,K_TIERRA);
      /* arrastrarse: piernas alternadas y un poco de rolido */
      if(rap>.03){const s=Math.sin(st.faseR*TAU),w=sst(.03,.25,rap);
        for(let i=0;i<2;i++){const c=sat((i?-s:s))*w,o=pr.pie[i];o.p.lerp(PIE_ARRASTRE[i],c);o.polo.lerp(POLO_ARRASTRE[i],c).normalize();}
        pr.pelQ.multiply(qE(q1,0,0,.12*s*w));}
      mezclarPose(sp,K_MANOS,pr,ease((ti-.7)/.3),false);}
    if(ti>.85){sp.pec.multiply(qE(q1,-.25*st.mPitch,.25*st.mYaw,.18*st.as));sp.pelQ.multiply(qE(q1,0,.15*st.mYaw,0));}
  }
  /* capas que mueven el tronco */
  if(lan>=0){const tw=curva(lan,KC1),lb=curva(lan,KC2);
    sp.pec.multiply(qE(q1,lb*.6,tw*.6,0));sp.col.multiply(qE(q1,lb*.4,tw*.4,0));}
  if(cul>=0){const tw=curva(cul,KC3),lb=curva(cul,KC4);
    sp.pec.multiply(qE(q1,lb*.5,tw*.55,0));sp.col.multiply(qE(q1,lb*.5,tw*.45,0));sp.pel.z+=curva(cul,KC5)*(1-ti);}
  if(sal>=0){const sy=curva(sal,KC6);
    sp.pel.y+=sy;sp.pel.z+=curva(sal,KC7);sp.pelQ.multiply(qE(q1,curva(sal,KC8),0,curva(sal,KC9)));}
  if(at>.001){sp.col.multiply(qE(q1,.06*at*Math.sin(st.t*1.3),0,.1*at*Math.sin(st.t*.9)));sp.pel.y-=.06*at;}
  /* golpes y patada del arma: resortes sobre el pecho */
  sp.pec.multiply(qE(q1,st.gp-st.rp*.12,0,st.gr));sp.col.multiply(qE(q1,st.gp*.5,0,st.gr*.5));
  /* el pie de atrás levanta el talón (pivota en la base de los dedos) y, si igual no llega, la cadera baja un poco */
  resolverColumna(st,sp,false);
  if(ti<.5){let baja=0;
    for(let i=0;i<2;i++){const f=st.pie[i],o=sp.pie[i];
      a1.copy(OFF[i?H.musloD:H.musloI]).applyQuaternion(Q[H.cadera]).add(P[H.cadera]);
      if(!f.vuelo&&!(i===1&&ag*(1-mv)>.3)){
        const atras=-((o.p.x-a1.x)*st.vlx+(o.p.z-a1.z)*st.vlz)/(rap||1);
        const c=mv*clamp((atras-.17)*2.4,0,.85);
        if(c>0){aLocal(st,f.pos.x,f.pos.z,a2);piePlantado(o,a2.x,0,a2.z,envol(f.yawAct-st.yaw),c);sp.punta[i]=-c;}}
      if(f.vuelo&&f.s>.15&&f.s<.85)continue;
      const dh=Math.hypot(a1.x-o.p.x,a1.z-o.p.z),lm=(L_MUSLO+L_PIERNA)*.995;
      if(dh<lm){const ym=o.p.y+Math.sqrt(lm*lm-dh*dh);baja=Math.max(baja,a1.y-ym);}}
    baja=Math.min(baja,.11)*(1-sst(.3,.5,ti));if(sal>.15&&sal<.85)baja=0;
    if(baja>0){sp.pel.y-=baja;resolverColumna(st,sp,false);}}
  /* ---- cabeza: mira hacia donde apunta; con el arma al hombro, mejilla a la culata ---- */
  const apE=st.ap*(1-sat(st.golpeT*3))*(1-.85*at)*(1-.5*cr);
  qE(q1,-st.mPitch*.85+.2*apE*(1-ti*.5)+.35*at+.3*at*Math.sin(st.t*.7),st.mYaw*.97,.14*apE*(1-ti*.6)+.12*st.radio-.25*at*Math.sin(st.t*.5)+.3*st.as*(1-ti));
  q2.copy(Q[H.pecho]).invert().multiply(q1);
  sp.cue.copy(QI).slerp(q2,.45);sp.cab.copy(sp.cue).invert().multiply(q2);
  sp.cab.multiply(qE(q3,st.gp*1.6,0,st.gr*1.6));
  cadena(P,Q,H.cuello,sp.cue);cadena(P,Q,H.cabeza,sp.cab);
  a1.set(0,ti,1-ti).applyQuaternion(Q[H.pecho]);st.yawPecho=Math.atan2(a1.x,a1.z);
  /* ---- arma ---- */
  armaViva(st,e,dt,apE,ti,rec,lan,sen,cul,sal,cr);
  /* ---- manos ---- */
  manosVivas(st,e,ti,rec,lan,sen,cul,sal,at);
  resolverMiembros(st,sp);
}

/* ---------- el arma en las manos ---------- */
function armaViva(st,e,dt,apE,ti,rec,lan,sen,cul,sal,cr){
  const P=st.P,Q=st.Q,W=st.arma,fi=st.ficha,a1=_v[0],a2=_v[1],a3=_v[2],a4=_v[3],a5=_v[4],a6=_v[5],q1=_w[0],q2=_w[1],q3=_w[2];
  const ya=st.mYaw,pa=st.mPitch;
  a1.set(Math.sin(ya)*Math.cos(pa),Math.sin(pa),Math.cos(ya)*Math.cos(pa));          /* hacia dónde apunta */
  /* al hombro: cantonera en el bolsillo del hombro derecho, la mira frente al ojo */
  aModelo(st,H.pecho,-.125*st.kx,.205,.10,st.pAim);qBase(st.qAim,a1,EJY);
  aModelo(st,H.cabeza,-.034,.105,.075,a2);                                             /* ojo derecho (detrás del lente) */
  a3.copy(fi.ojo).applyQuaternion(st.qAim).add(st.pAim);                               /* dónde queda la mira */
  a2.sub(a3);a4.set(1,0,0).applyQuaternion(st.qAim);a5.set(0,1,0).applyQuaternion(st.qAim);
  st.pAim.addScaledVector(a4,clamp(a2.dot(a4),-.04,.04)).addScaledVector(a5,clamp(a2.dot(a5)-.012,-.06,.05));
  /* arma baja: la boca abajo y hacia adentro (en el piso, apenas baja) */
  const yl=ya+.28*(1-ti),pl=lerp(-.58+pa*.3,pa-.1,ti);
  a6.set(Math.sin(yl)*Math.cos(pl),Math.sin(pl),Math.cos(yl)*Math.cos(pl));
  qBase(st.qLow,a6,EJY);aModelo(st,H.pecho,-.115*st.kx,lerp(.165,.19,ti),.105,st.pLow);
  const w=ease(apE);W.p.lerpVectors(st.pLow,st.pAim,w);W.q.copy(st.qLow).slerp(st.qAim,w);
  /* corriendo, el arma rebota un poco */
  if(cr>0){W.p.y+=.012*cr*Math.sin(st.fase*TAU*2);W.q.multiply(qE(q1,.03*cr*Math.sin(st.fase*TAU*2+1),0,0));}
  /* recarga: el arma se acerca al pecho y se ladea para que la mano llegue al brocal */
  if(rec>=0){const wr=sst(0,.12,rec)*(1-sst(.86,1,rec));if(wr>0){
    const esc=fi.tipo==='escopeta';
    aModelo(st,H.pecho,-.13,lerp(.03,.2,ti),lerp(0,-.1,ti),a2);qE(q1,-.4+.25*ti,.35*(1-.6*ti),(esc?.8:.5)*(1-.5*ti));q1.premultiply(qE(q2,0,st.yawPecho,0));
    W.p.lerp(a2,wr);W.q.slerp(q1,wr);}}
  /* granada: el arma queda colgando en la mano izquierda, boca abajo */
  if(lan>=0){const wl=sst(0,.13,lan)*(1-sst(.8,.98,lan));if(wl>0){
    a3.set(.1,-.45,.89).normalize().applyQuaternion(qE(q2,0,st.yawPecho,0));qBase(q1,a3,EJY);
    aModelo(st,H.pecho,.26,-.28,.17,a2);a4.copy(fi.guarda).applyQuaternion(q1);a2.sub(a4);
    W.p.lerp(a2,wl);W.q.slerp(q1,wl);}}
  /* seña: una sola mano en el arma, boca al piso */
  if(sen>=0){const ws=sst(0,.15,sen)*(1-sst(.85,1,sen));if(ws>0){
    aModelo(st,H.pecho,-.11,.09,.11,a2);a3.set(Math.sin(ya+.2),-1.05,Math.cos(ya+.2)).normalize();qBase(q1,a3,EJY);
    W.p.lerp(a2,ws);W.q.slerp(q1,ws);}}
  /* culatazo: carga atrás, la culata sale adelante a la altura de la cara */
  if(cul>=0){const wc=sst(0,.12,cul)*(1-sst(.82,1,cul));if(wc>0){
    curvaV(cul,KC10,a4);
    aModelo(st,H.pecho,a4.x,a4.y,a4.z,a2);
    curvaV(cul,KC11,a3).normalize();
    a3.applyQuaternion(qE(q2,0,st.yawPecho,0));qBase(q1,a3,EJY);
    W.p.lerp(a2,wc);W.q.slerp(q1,wc);}}
  /* salto: el arma va en la mano derecha, al costado */
  if(sal>=0){const wv=sst(.05,.2,sal)*(1-sst(.8,.95,sal));if(wv>0){
    aModelo(st,H.pecho,-.2,-.05,.12,a2);a3.set(-.2,-.75,.6).normalize();qBase(q1,a3,EJY);W.p.lerp(a2,wv);W.q.slerp(q1,wv);}}
  /* patada del arma: gira sobre la cantonera y retrocede */
  W.q.multiply(qE(q1,-st.rp,0,0));a1.set(0,0,-st.rb).applyQuaternion(W.q);W.p.add(a1);
  /* cuerpo a tierra con bípode: el arma apoya un poco más alto */
  if(fi.bipode&&ti>.85&&apE>.5)W.p.y+=.0;
}

/* ---------- manos: agarradas al arma, salvo que una capa las lleve a otro lado ---------- */
function manosVivas(st,e,ti,rec,lan,sen,cul,sal,at){
  const sp=st.sp,P=st.P,Q=st.Q,W=st.arma,fi=st.ficha,a1=_v[0],a2=_v[1],a3=_v[2],a4=_v[3],a5=_v[4],a6=_v[5],a7=_v[6],q1=_w[0],q2=_w[1],q3=_w[2],q4=_w[3],mI=sp.mano[0],mD=sp.mano[1];
  /* derecha en la empuñadura, izquierda en el guardamanos (o en la corredera de la escopeta) */
  mD.q.copy(W.q).multiply(fi.agD.q);mD.p.copy(fi.agD.p).applyQuaternion(W.q).add(W.p);
  a1.copy(fi.agI.p);if(fi.agIcorredera)a1.z-=st.bombaZ;
  mI.q.copy(W.q).multiply(fi.agI.q);mI.p.copy(a1).applyQuaternion(W.q).add(W.p);
  /* si el guardamanos queda lejos, la mano se corre hacia atrás sobre él (la corredera no deja mucho) */
  {a2.copy(OFF[H.brazoI]);a2.x*=st.kx;a2.applyQuaternion(Q[H.pecho]).add(P[H.pecho]);a3.set(0,0,-1).applyQuaternion(W.q);
    const tope=fi.agIcorredera&&cul<0&&ti<.5?.05:.14,alc=(L_BRAZO+L_ANTEBRAZO)+.035;let corre=0;
    for(let it=0;it<3;it++){const d=a4.subVectors(mI.p,a2).length();if(d<=alc)break;
      const c=Math.min(tope-corre,(d-alc)*1.4);if(c<=1e-4)break;mI.p.addScaledVector(a3,c);corre+=c;}}
  /* codos: abajo y un poco afuera (de pie, en el marco del pecho sin su cabeceo); en el piso, apoyados */
  qE(q1,0,st.yawPecho,0);
  mD.polo.set(-.72,-.66,-.18).applyQuaternion(q1);mI.polo.set(.42,-.9,0).applyQuaternion(q1);
  if(ti>0){mD.polo.lerp(a1.set(-.5,-.86,.12),ti).normalize();mI.polo.lerp(a1.set(.5,-.86,.15),ti).normalize();}
  sp.ded[0]=1.05;sp.ded[1]=1.2;sp.ded[2]=st.ap>.85?.72:.12;
  if(st.armaSuelta){   /* sin arma: manos sueltas al costado */
    aModelo(st,H.cadera,.24,-.18,.03,mI.p);qMano(mI.q,true,a1.set(0,-1,.1),a2.set(-1,0,0));
    aModelo(st,H.cadera,-.24,-.18,.03,mD.p);qMano(mD.q,false,a1.set(0,-1,.1),a2.set(1,0,0));
    mI.polo.set(.3,0,-1);mD.polo.set(-.3,0,-1);sp.ded[0]=.4;sp.ded[1]=.5;sp.ded[2]=.4;return;}
  /* recarga */
  if(rec>=0&&fi.tipo!=='escopeta'){
    /* cargador: en el arma, en la mano, guardado o nuevo en la mano */
    const enMano=rec>.17&&rec<.64,visible=rec<.33||rec>.43;st.cargVis=visible?1:0;st.cargMano=enMano;
    /* agarre del cargador: palma de costado, dedos hacia adelante */
    a2.copy(fi.cargador).applyQuaternion(W.q).add(W.p);
    a3.set(0,-1,0).applyQuaternion(W.q);                        /* eje del cargador (hacia abajo) */
    const wMano=sst(.04,.16,rec)*(1-sst(.8,.93,rec));
    let objetivo;
    if(rec<.17){a6.copy(a2).addScaledVector(a3,.1);}                                             /* va al cargador */
    else if(rec<.33){a6.copy(a2).addScaledVector(a3,.1+curva(rec,KC12));}/* lo saca */
    else if(rec<.48){aModelo(st,H.cadera,.20,lerp(.0,.1,ti),.02,a4);aModelo(st,H.pecho,lerp(.078,.2,ti),-.06,lerp(.24,.05,ti),a5);a4.y=Math.max(a4.y,.08);a5.y=Math.max(a5.y,.09);
      a6.lerpVectors(a4,a5,sst(.38,.46,rec));}                                                    /* lo guarda y saca otro del chaleco */
    else if(rec<.64){aModelo(st,H.pecho,lerp(.078,.2,ti),-.06,lerp(.24,.05,ti),a5);a5.y=Math.max(a5.y,.09);a4.copy(a2).addScaledVector(a3,.1+curva(rec,KC13));
      a6.lerpVectors(a5,a4,sst(.48,.58,rec));}                                                    /* lo mete */
    else if(rec<.8){a4.set(.045,.02,.37).applyQuaternion(W.q).add(W.p);a5.copy(a2).addScaledVector(a3,.1);
      a6.lerpVectors(a5,a4,sst(.64,.72,rec));}                                                    /* golpe al retén */
    else a6.copy(mI.p);
    a4.set(0,0,1).applyQuaternion(W.q);qMano(q4,true,a4,a5.set(-1,.2,0).applyQuaternion(W.q));
    a7.set(.6,-.7,.2);fijar(mI,wMano);
    sp.ded[0]=lerp(sp.ded[0],1.3,wMano);sp.ded[1]=lerp(sp.ded[1],1.35,wMano);
    /* el cargador sigue a la mano mientras está en ella */
    st.cargEnMano=enMano?1:0;
  }else if(rec>=0){
    /* escopeta: tres cartuchos desde la canana a la ventana de carga */
    const c=fr(rec*3.2),wMano=sst(.03,.12,rec)*(1-sst(.88,.97,rec));
    aModelo(st,H.pecho,-.03,.09,.20,a4);a5.set(0,-.045,.42).applyQuaternion(W.q).add(W.p);
    a6.lerpVectors(a4,a5,curva(c,KC14));
    a4.set(0,.3,1).applyQuaternion(W.q);qMano(q4,true,a4,a5.set(0,1,0).applyQuaternion(W.q));
    a7.set(.6,-.7,0);fijar(mI,wMano);
    st.cargVis=wMano>.5&&c>.12&&c<.62?1:0;st.cargEnMano=1;
  }else{st.cargVis=1;st.cargEnMano=0;}
  /* granada: la derecha va al chaleco, la saca, carga atrás y lanza (sale en 0,55) */
  if(lan>=0){
    const wl=sst(.02,.12,lan)*(1-sst(.78,.95,lan));
    curvaV(lan,KC15,a1);
    a6.copy(a1).applyQuaternion(qE(q1,0,st.yawPecho,0)).add(P[H.pecho]);
    curvaV(lan,KC16,a7).applyQuaternion(q1).normalize();
    a2.set(0,0,1).applyQuaternion(q1);a3.copy(a7).negate();qMano(q4,false,a2.set(-.2,curva(lan,KC17),.8).applyQuaternion(q1),a3.set(.5,0,.3).applyQuaternion(q1));
    fijar(mD,wl);sp.ded[2]=lerp(sp.ded[2],.9,wl);
    st.granVis=lan>.15&&lan<.55?1:0;
  }else st.granVis=0;
  /* seña del jefe con la mano izquierda */
  if(sen>=0){
    const ws=sst(0,.17,sen)*(1-sst(.83,1,sen)),tipo=e.senalTipo||'avanzar',h=(sen-.17)/.66,osc=Math.sin(sat(h)*TAU*2);
    qE(q1,0,st.yawPecho,0);let abierto=1;
    if(tipo==='alto'){a1.set(.30,.40,.06);a2.set(.05,1,.05);a3.set(0,0,1);a7.set(1,-.3,-.1);abierto=0;}
    else if(tipo==='izq'){a1.set(.64,.15+.04*osc,.10);a2.set(1,.05,.1);a3.set(0,0,1);a7.set(0,-1,-.4);}
    else if(tipo==='der'){a1.set(-.30,.16+.03*osc,.42);a2.set(-1,0,.15);a3.set(0,0,-1);a7.set(.3,-1,.2);}
    else{const c=.5+.5*osc;a1.set(.24,lerp(.42,.16,c),lerp(.16,.56,c));a2.set(0,lerp(.7,0,c),lerp(.7,1,c));a3.set(-1,0,0);a7.set(.5,-1,-.2);}
    a6.copy(a1).applyQuaternion(q1).add(P[H.pecho]);a2.applyQuaternion(q1);a3.applyQuaternion(q1);a7.applyQuaternion(q1);
    qMano(q4,true,a2,a3);fijar(mI,ws);
    sp.ded[0]=lerp(sp.ded[0],abierto?.08:1.55,ws);sp.ded[1]=lerp(sp.ded[1],abierto?.05:1.7,ws);
  }
  /* camino a cuerpo a tierra: la izquierda se apoya en el piso */
  if(ti>.55&&ti<.97){const wt=sst(.56,.68,ti)*(1-sst(.86,.97,ti));a6.set(.25,.05,lerp(.42,.36,sst(.6,.9,ti)));
    qMano(q4,true,a2.set(.15,0,1),a3.set(0,-1,0));a7.set(1,.2,-.6);fijar(mI,wt);sp.ded[0]=lerp(sp.ded[0],.15,wt);sp.ded[1]=lerp(sp.ded[1],.1,wt);}
  /* radio: la izquierda al pulsador del pecho */
  if(st.radio>.01&&rec<0&&sen<0){aModelo(st,H.pecho,.09,.12,.20,a6);qE(q1,0,st.yawPecho,0);
    a2.set(-.5,.6,.3).applyQuaternion(q1);a3.set(-.2,0,-1).applyQuaternion(q1);qMano(q4,true,a2,a3);a7.set(.8,-.5,-.2).applyQuaternion(q1);
    fijar(mI,st.radio);sp.ded[0]=lerp(sp.ded[0],1.3,st.radio);sp.ded[1]=lerp(sp.ded[1],1.0,st.radio);}
  /* aturdido: se agarra la máscara */
  if(at>.4){const wa=sst(.4,.8,at);aModelo(st,H.cabeza,.11,.06,.06,a6);a2.set(-.3,.8,.3);a3.set(-1,0,-.2);
    a2.applyQuaternion(Q[H.cabeza]);a3.applyQuaternion(Q[H.cabeza]);qMano(q4,true,a2,a3);a7.set(1,-.6,0);fijar(mI,wa);}
  /* salto: la izquierda se apoya arriba de la valla (clavada en el mundo) */
  if(sal>=0){const wv=sst(.2,.3,sal)*(1-sst(.56,.66,sal)),wl=sst(.04,.16,sal)*(1-sst(.82,.95,sal));
    if(wl>0){aModelo(st,H.pecho,.2,-.02,.32,a6);qMano(q4,true,a2.set(.1,-.3,1),a3.set(-.3,-.6,.2));a7.set(1,-.4,-.3);fijar(mI,wl);}
    if(sal<.26||!st.saltoFijo){aModelo(st,H.cadera,.16,.0,.38,a1);aMundo(st,a1.x,a1.z,st.saltoW);st.saltoFijo=sal>=.26;}
    if(wv>0){aLocal(st,st.saltoW.x,st.saltoW.z,a6);a6.y=1.16;qMano(q4,true,a2.set(-.2,0,1),a3.set(0,-1,0));a7.set(1,.2,-.4);fijar(mI,wv);}
    /* piernas recogidas por encima de la valla */
    const wp=sst(.25,.38,sal)*(1-sst(.6,.78,sal));
    if(wp>0)for(let i=0;i<2;i++){const o=sp.pie[i];a1.set(i?-.05:.18,lerp(.75,1.12,sst(.25,.45,sal)),i?.05:-.06);
      o.p.lerp(a1,wp);o.polo.lerp(a2.set(i?-.4:.6,.2,1),wp).normalize();o.q.slerp(qE(q1,-.5,i?-.3:.4,0),wp);}
  }else st.saltoFijo=false;
}
