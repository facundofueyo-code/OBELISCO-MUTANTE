# Tarea S — modelo, animación y página de concepto

Leé primero `../SPEC.md` entero (sobre todo 0, 1, 2.1, 4.2, 7, 8 y 9). Tu carpeta es `S-modelo/`.

## Qué tenés que lograr

Los soldados de la unidad especial, en 3D, hechos por código (sin archivos externos), listos para meter en el juego, y una página de concepto donde Facu los pueda mirar y corregir. Facu es exigente con los modelos: del enemigo anterior dijo que era «poco amenazante y poco articulado». Estos tienen que **dar miedo** y **moverse como gente entrenada**.

Lo que da miedo acá no es el monstruo: es que son personas sin cara, iguales entre sí, tranquilas, que vinieron a matar al que vio algo. Lentes redondos como de insecto, nada de piel a la vista (guantes, pasamontañas bajo la máscara), movimientos económicos, el arma siempre lista.

## Entregables

1. **`ue_modelo.js`**: define `const UEM=(()=>{ … })();` con el contrato de la sección 4.2 de la SPEC. Solo depende de `THREE` global (r128). Va a ir pegado adentro del script del juego: nada de `import`, `export`, `window.algo` ni nombres globales fuera de `UEM`.
2. **`concepto.html`**: la página de concepto con el visor (detalle abajo). La arma un script tuyo, `armar.py`, a partir de `pagina.src.html` + `ue_modelo.js`. Que `armar.py` saque también **`prueba.html`**, igual pero cargando `../three.r128.min.js` local, para probar sin red.
3. **`capturas/`**: las imágenes de la lista de abajo.
4. **`INFORME.md`** (sección 8 de la SPEC).

## El modelo

**Cuerpo.** Humano de 1,80 m, atlético, hombros normales (no un ropero). Esqueleto: raíz → cadera → columna → pecho → cuello → cabeza; hombro, brazo, antebrazo y mano a cada lado; muslo, pierna y pie a cada lado. Manos con dedos suficientes para que se lea el agarre del arma y el dedo en el gatillo (no hace falta animar cada falange).

**Equipo común.** Uniforme negro mate. Chaleco portaplacas con portacargadores, correaje y hebillas en gris carbón, apenas más claro que la tela para que el volumen se lea de noche. Rodilleras y coderas. Borcegos. Guantes. Cinturón con pistolera. Casco balístico de corte alto con rieles laterales y soporte frontal. Máscara antigás de cara completa: dos lentes redondos grandes, pieza bucal, filtro cilíndrico a un costado, arnés de correas. Velcro vacío en hombros y pecho. Luz roja chica en la nuca del casco, que parpadea.

**Diferencias por rol** (tienen que distinguirse por la silueta, de lejos y de noche):

- `jefe`: fusil. Mochila de radio chica con **antena de látigo larga** (1 m) que se mueve un poco. Auricular con micrófono.
- `asalto`: escopeta de corredera. Más liviano: sin mochila, canana de cartuchos cruzada, hombreras.
- `granadero`: fusil. Tres o cuatro portagranadas en el pecho y un morral al costado.
- `tirador`: fusil de tirador largo con mira telescópica, bípode plegable y supresor. **Capucha o velo de tela** sobre el casco y los hombros, que le cambia la silueta. Láser rojo.

**Armas** (genéricas, sin copiar un modelo real de fábrica): fusil de asalto corto, negro, con mira de punto rojo, linterna al costado del guardamanos, cargador curvo de 30 y culata extensible. Escopeta de corredera con culata fija y linterna. Fusil de tirador como arriba. Granada de mano oscura con espoleta y anilla (`UEM.granada()`).

**Lo que se ve de noche.** Lentes de la máscara con un brillo frío tenue (emisivo, que no ilumine nada). Linterna del arma: un cono aditivo de unos 14 m con borde suave, más un disco brillante en la boca de la linterna cuando mira hacia la cámara. Láser: haz fino aditivo rojo desde el arma hasta `u.e.laser` (punto mundial), con un punto brillante al final. Fogonazo: sprite o malla aditiva en la boca, unos 50 ms por tiro. **Ninguna luz real de Three.js** (ver 2.1 de la SPEC).

## La técnica

- **Costo por soldado: 6 llamadas de dibujo o menos con todo prendido, y 9.000 triángulos o menos contando el arma.** Va a haber 8 a la vez en un juego que ya es pesado. Lo razonable es una sola `SkinnedMesh` con pesos rígidos (cada pieza atada a un hueso, con mezcla de dos huesos en las articulaciones si querés), color por vértice y uno o dos materiales, con el arma como parte de esa malla o colgada del hueso de la mano. Medilo con `renderer.info` y poné los números en el informe.
- Geometría armada con primitivas redondeadas (cápsulas, cajas con chaflán, tornos, extrusiones), unida por código. Nada de cajas crudas con aristas vivas en el cuerpo: se tiene que ver una persona con equipo, no un muñeco de bloques.
- Materiales y geometrías compartidas se crean una sola vez. `UEM.calentar(scene,on)` pone y saca una muestra de cada rol con linterna, láser y fogonazo prendidos, para que el juego compile los shaders antes de jugar.
- Nada de crear objetos en `update` (vectores temporales reutilizados). Medí el costo de `update` con 8 soldados animándose: objetivo, menos de 0,5 ms en total en una PC normal (acá el reloj es más lento: informá lo que mida y la proporción).
- `castShadow=true` en el cuerpo.
- **Brazos con cinemática inversa de dos huesos** (solución analítica): las dos manos tienen que quedar agarradas al arma en todas las posturas, apuntando arriba, abajo y a los costados, y durante la patada. El arma se ubica según `mYaw`, `mPitch` y `apunta`; los brazos la siguen.
- **Piernas**: ciclo de paso atado a la distancia que recorrió `u.root` (leé la posición anterior en `update`): que no patinen. Tiene que salir bien caminar, trotar con el arma lista, correr, moverse de costado y hacia atrás (según hacia dónde va respecto de adonde mira), avanzar agachado y arrastrarse cuerpo a tierra.
- **Posturas**: de pie, agachado (rodilla en tierra o cuclillas bajas, estable para tirar) y cuerpo a tierra (panza abajo, codos apoyados, piernas abiertas; el tirador con el bípode apoyado). La mezcla entre posturas tiene que verse como un movimiento, no como un fundido: pasar por poses intermedias creíbles.
- **Capas** que se suman encima: asomarse (`asoma`), patada de cada tiro (`disparo()`), recarga (saca el cargador, pone otro, golpea), lanzamiento de granada (toma, brazo atrás, lanza, vuelve al arma; la granada deja la mano en 0,55), seña del jefe con la mano izquierda (cuatro señas distintas y claras), culatazo, salto de valla, mano al pulsador de la radio, sacudida por impacto (`golpe`), aturdido.
- **Muertes** (`u.e.muerte`): cuatro caídas distintas que terminan con el cuerpo en el piso en una pose creíble, sin atravesarlo. `tierra` es para el que ya estaba cuerpo a tierra.
- **Impactos** (`u.rayo`): esferas pegadas a los huesos, un 10 % más grandes que el cuerpo, actualizadas solo cuando se consulta. Cabeza, torso, brazos, piernas. Probalo en las tres posturas.
- Entre un soldado y otro, variá apenas la altura (±3 %), la complexión y el ritmo, con `semilla`, para que no sean clones exactos.

## La página de concepto

Mismo sistema visual que `../conceptos/movimiento-concepto.html` (leelo: variables de color, tipografías, tarjetas, botones de herramienta, el `stage` con relación 16:9). Es un **fragmento**: sin `<!doctype>`, `<html>`, `<head>` ni `<body>`; empieza con `<title>Unidad especial</title>`. Carga Three.js desde `https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js` y lleva `ue_modelo.js` pegado adentro. Ningún otro recurso externo salvo Google Fonts. Sin `localStorage`.

- Encabezado: `OBELISCO MUTANTE · CONCEPTO DE ENEMIGO · V1`, título **Unidad especial**, y una bajada de dos o tres oraciones que diga qué es y qué hay que mirar.
- **Visor**: escena de noche con niebla y piso mojado parecida al juego (fondo y niebla `0x1b1822`, luz de sodio lateral, algo de luz fría de relleno para que el negro no se empaste). Una referencia de escala: un auto esquemático de 1,45 m o una regla de 1,80 m. Arrastrar gira, la rueda acerca, en celular funciona con el dedo.
- Controles sobre el visor: los cuatro roles, «Los cuatro» (formación), y las poses y acciones: De pie · Apunta · Agachado · Cuerpo a tierra · Camina · Corre · De costado · Asoma · Dispara · Recarga · Granada · Seña · Culatazo · Lo hieren · Cae. Interruptores: Linterna · Láser · Girar solo · Luz plena (iluminación neutra para ver el modelado). Y «Ronda»: una demo que encadena todo sola.
- Tarjetas debajo (texto corto, en rioplatense, sin relleno; sacá el contenido de la SPEC): **QUIÉNES SON** · **LOS CUATRO ROLES** (cómo reconocer a cada uno y qué hace) · **REGLAS DE JUEGO LIMPIO** (sección 1.3, en palabras de jugador) · **LA RADIO** (las frases de la sección 9, agrupadas, con una nota: «Hoy suenan como radio distorsionada con subtítulos. Si las grabás, entran con tu voz») · **NÚMEROS** (tabla de la sección 5, resumida, aclarando que son iniciales) · **CÓMO SE PRUEBA** (dejá un párrafo marcado `<!--PRUEBA-->` que el integrador completa).
- Sin errores en consola. Que el visor frene cuando no está a la vista o la pestaña está oculta.

## Capturas (mirá cada una antes de darla por buena)

Con `H.openPage('prueba.html',{width:1280,height:720})`. Guardalas en `capturas/` con nombres claros:

1. Cada rol de pie apuntando: tres cuartos de frente, perfil y espalda (12).
2. Cada rol con «Luz plena», de frente (4).
3. Primer plano de la cabeza: casco y máscara.
4. Agachado apuntando; cuerpo a tierra apuntando (el tirador, con láser); corriendo; asomándose a los dos lados.
5. Mitad de la recarga; granada con el brazo atrás; las cuatro señas del jefe; culatazo.
6. Las cuatro muertes en su pose final.
7. Los cuatro en formación, de noche, con linternas prendidas.
8. Las armas solas, con luz plena.

Corregí lo que veas mal (manos que atraviesan el arma, codos al revés, pies hundidos, cabeza desproporcionada, siluetas que no se distinguen) antes de entregar. Cuando creas que terminaste, mirá las capturas otra vez como si fueras Facu.

## Qué no hacer

- No uses luces de Three.js en el modelo. No cargues texturas ni modelos de afuera.
- No toques nada fuera de `S-modelo/`.
- No simplifiques el contrato: la IA va a escribir en `u.e` exactamente esos campos. Si agregás campos, que sean opcionales y contalo en el informe.
