# S-modelo · progreso

Estado: **terminado** (ver INFORME.md). `ue_modelo.js` se arma con `./armar.sh` a partir de `src/*.js`.

## Hecho (probado)
- Contrato UEM completo (+ extras opcionales). Rayo, boca, ojos, soltarArma, dispose, calentar: probados en Node y Chromium.
- 4 roles con armas: 7.430–7.570 triángulos con efectos; 2 llamadas por soldado (+1 por mapa de sombras).
- Paso sin patinar (0 mm), de pie / agachado / a tierra con manos en el arma, transición a tierra por poses intermedias.
- Capas: asoma, disparo, recarga, granada, 4 señas, culatazo, salto, radio, golpe, aturdido. 4 muertes.
- update de 8 soldados: 0,15–0,20 ms (Chromium). Sin objetos creados en update.
- Visor `ue_visor.js` + `prueba.html` + 6 láminas en `capturas/`.

## Flojo (detalle en INFORME.md)
- Articulaciones rígidas de cerca; mano derecha con agarre fijo; arrastre a tierra local; velo rígido.
- No probado dentro del juego.
