# Tarea M — que los mutantes y los soldados se peleen

Leé primero `../SPEC.md` entero (sobre todo 0, 1, 2, 3, 4.1, 4.6, 7 y 8). Tu carpeta es `M-bichos/`.

## Qué tenés que lograr

Facu eligió que la unidad especial **pelee contra todos**: matan bichos y testigos por igual, y los bichos los atacan a ellos. Hoy toda la lógica de los mutantes da por sentado que el único blanco es el jugador. Tu trabajo es abrir eso con cirugía chica: que cada bicho pueda elegir entre el jugador y un soldado, que lo dañe, y que las balas y explosiones de los soldados dañen a los bichos. Sin romper nada de cómo se comportan hoy contra el jugador.

De la IA de los soldados no te ocupás: la hace otro. Vos trabajás contra el contrato `UEB.objetivos()` (4.1 y 4.6 de la SPEC) y lo probás con soldados de mentira.

Entregás un parche sobre `../base.html` (protocolo en 3.3) y, si hace falta código nuevo, `mod_bichos.js`.

## Antes de escribir

Leé con cuidado en `../base-view.txt`:

- `TYPES` (~7663): rata, bagayo, baboso, escupidor, mole, boss (el Engendro).
- `spawnEnemy` y oleadas (~9632–9660).
- `fire()` (~9683): cómo una bala del jugador encuentra un bicho (esfera del cuerpo, esferas de las partes, ojos que valen ×2,5, `updatePartSpheres`).
- `damageEnemy`, `killEnemy`, `hurtPlayer` (~9724–9752).
- Escupitajos: `spit`, `updateProjs` (~10056–10072).
- Navegación (~10762–10865): el campo de costo hacia **el jugador** (`enBuild`, `ENF`, `enTick`), `enLine`, `enSteer`, `enVert`, `enUnstick`.
- **`updateEnemies(dt)`** (~11338–11558): todo. Acá `dx,dz,dist` son siempre hacia `P.pos`; los ataques (mordida, salto del bagayo, embestida del mole, autos que tira el Engendro, pisotones) terminan en `hurtPlayer`.
- `carBoom` (~3317) y el daño de la explosión de un auto (buscá dónde le hace daño al jugador y a los bichos).
- El Shajar (`SHJ`, ~10074) no entra: no lo toques. Aparece solo en la oleada 3, lejos del retén.

## Qué hacer

**1. Elegir blanco.** Cada bicho tiene `e.tg`: `null` (el jugador) o uno de `UEB.objetivos()`. Lo revisa cada medio segundo más o menos, escalonado entre bichos:

- Candidatos: el jugador y los objetivos vivos a menos de 24 m del bicho.
- Elige el más cercano, con una leve preferencia por el jugador (multiplicá por 1,15 la distancia a los soldados) y sin cambiar de blanco a cada rato (histéresis: solo cambia si el otro está bastante más cerca, o si el suyo murió o se alejó más de 30 m).
- A un soldado solo lo persigue si puede llegar: el campo de navegación del juego apunta al jugador, así que hacia un soldado el bicho va **en línea recta** cuando `enLine` da libre, y si no hay línea libre usa un camino corto propio o directamente vuelve al jugador. No construyas un campo de costo por soldado: es caro. Lo simple que funcione bien.
- Si `UEB.objetivos()` devuelve vacío (el caso de hoy), el comportamiento tiene que ser **idéntico** al actual, cuadro por cuadro.

**2. Atacar al blanco.** Todo lo que hoy se calcula «hacia el jugador» en `updateEnemies` pasa a ser «hacia el blanco»: rumbo, distancia, cuándo frena, cuándo muerde, el salto del bagayo, la carrera de la rata, el escupidor que mantiene distancia y escupe (el escupitajo tiene que apuntar al blanco y pegarle: `updateProjs`), el mole. Cuando el golpe le llega a un soldado: `tg.herir(daño,e)` en vez de `hurtPlayer`. Usá `tg.x, tg.z, tg.y` (pies) y `tg.r` (radio, ~0,4); no supongas que tienen velocidad.

El Engendro: sigue yendo por el jugador, pero sus golpes de área (pisotón, barrido, el auto que arroja y explota) dañan también a los soldados que agarren. No hace falta que los elija como blanco.

**3. Balas de soldados contra bichos.** Sacá de `fire()` la cuenta de «rayo contra bichos» a una función que puedan usar los dos:

```js
rayoBichos(o,d,maxT) → null | {e,t,p,ojo}   // e: el bicho · t: distancia · p: la parte (o null si es el cuerpo) · ojo: si es un ojo
```

Que `fire()` siga dando exactamente lo mismo que hoy (podés dejar `fire()` como está y escribir la función aparte, repitiendo la cuenta, si es más seguro: lo que importa es que el jugador no note nada). El integrador aplica el daño con `damageEnemy(e,dm,dir)`: fijate que funcione bien cuando el que mata no es el jugador (puntaje, combo, frases del `feed`, cajas que suelta: **un bicho que matan los soldados no le da puntos ni combo al jugador ni dice frases, pero sí puede dejar su caja**). Para eso sumá un cuarto parámetro opcional a `damageEnemy(e,dm,dir,de)` y llevalo hasta `killEnemy`: `de==='soldado'`.

**4. Explosiones.** Donde un auto explota y daña al jugador y a los bichos, agregá `UEB.explosion(pos,radio,daño,'auto')` con el mismo radio y daño que usa el juego.

**5. Lo que ve la IA de los soldados.** Dejá una función barata `bichosVivos()` que devuelva los mutantes como los necesita la IA: `[{ref:e, x,y,z, r, tipo, hp}]` (posición del centro del cuerpo), reutilizando un mismo arreglo para no generar basura.

## Cuidados

- `updateEnemies` es código denso y delicado, con animación y navegación mezcladas. **Ediciones mínimas**: no lo reescribas ni lo reordenes. Preferí definir al principio del cuerpo del bucle unas variables de blanco (`tx,tz,ty`) y reemplazar los usos de `P.pos` que correspondan, dejando como están los que son realmente del jugador (por ejemplo, lo que depende de si el jugador lo está mirando, los sonidos según la distancia al jugador, el anti-trabado que solo reacomoda si el jugador no ve).
- Rendimiento: con 20 bichos y 8 soldados, el costo extra tiene que ser despreciable (medilo). Nada de crear arreglos por cuadro.
- No toques el marcador `/*UE:rayo-jugador*/` ni la línea de `SHJ.ray` en `fire()`.

## Pruebas (con `../harness.js`)

Todo con soldados de mentira: en la prueba asignás `UEB.objetivos=()=>lista`, con objetos `{x,z,y:0,r:.4,vivo:true,hp:100,herir(d,e){this.hp-=d;if(this.hp<=0)this.vivo=false;}}`.

1. **Sin soldados, nada cambia.** Corré la misma partida de 40 s con oleadas en `base.html` y en tu copia, con el mismo azar (reemplazá `Math.random` por un generador con semilla antes de `start()` en las dos) y un jugador que camina y dispara igual en las dos. Las posiciones y la vida de los bichos y la vida del jugador tienen que coincidir cuadro por cuadro, o explicá con precisión qué difiere y por qué.
2. **Con soldados.** En Av. de Mayo (`h.alReten()`), poné 4 soldados de mentira cerca de `x=-440, z=608` y al jugador lejos (`x=-380`). Hacé aparecer bichos de cada tipo con `spawnEnemy(tipo,[x,z])` entre los dos grupos y cerca de los soldados. Comprobá: que eligen blanco como se espera, que llegan, que los dañan (`hp` baja con el daño de `TYPES`), que cuando muere su soldado pasan a otro blanco, que el escupidor le acierta a un soldado quieto, que el bagayo salta sobre el soldado, que el mole lo embiste. Y que con el jugador más cerca, van al jugador.
3. **`rayoBichos`**: mismos resultados que `fire()` para una tanda de rayos al azar contra bichos reales (cuerpo, parte, ojo, nada).
4. **Muerte por soldado**: `damageEnemy(e,999,dir,'soldado')` no suma puntos ni combo.
5. **Explosión de auto**: se llama `UEB.explosion` con valores razonables.
6. **Engendro**: en la oleada 5 (podés forzarla), con soldados de mentira cerca: sus golpes de área los dañan.
7. Costo: `updateEnemies` con 20 bichos, con y sin 8 objetivos.

## Qué no hacer

- No cambies cómo se comportan los bichos contra el jugador.
- No toques al Shajar.
- No toques nada fuera de `M-bichos/`.
