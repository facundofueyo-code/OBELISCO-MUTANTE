# S-modelo · Informe

Modelo 3D, armas y animación de la Unidad Especial (módulo `UEM`), más un visor reutilizable para mirarlos.
Todo por código (Three.js r128, sin archivos externos). Lo corrí en Node (lógica) y en Chromium con el arnés (dibujo).

## Archivos

| Archivo | Qué es |
|---|---|
| `ue_modelo.js` | `const UEM=(()=>{…})();` listo para pegar dentro del script del juego. Solo usa `THREE`. **No se edita a mano:** sale de `src/*.js` con `./armar.sh`. |
| `src/01…10_*.js` | Fuentes: base y paleta, constructor de mallas, esqueleto, cuerpo, armas, materiales y efectos, poses e IK, animación viva, muertes, API. |
| `ue_visor.js` | `function crearVisorUE(canvas, opciones)`: escena de noche, piso mojado, regla de 1,80 m, órbita con mouse y dedo, poses de demostración. |
| `prueba.html` | Página mínima con botones para todo, y `window.lamina(vistas, cols)` para sacar varias vistas en una sola imagen. |
| `capturas/` | Seis láminas finales (abajo). `pruebas/previas/` tiene las de las iteraciones. |
| `pruebas/` | Pruebas numéricas en Node (`nodo.js`, `paso.js`, `capas.js`, `costo.js`, `perfil.js`) y en Chromium (`medir.js`, `robustez.js`, `lamina.js`). |

## Cómo se integra

1. Pegar `ue_modelo.js` dentro del `<script>` del juego.
2. Al cargar: `UEM.calentar(scene,true)`. Después del precalentado: `UEM.calentar(scene,false)`. Pone y saca una muestra de cada rol con linterna, láser, fogonazo, recarga y granada, más una granada suelta, para compilar los 3 programas: cuerpo con piel, efectos con piel y granada suelta.
3. Por soldado: `const u=UEM.crear(rol,{semilla}); scene.add(u.root)`. En cada cuadro la IA escribe `u.e`, mueve `u.root.position` (pies) y `u.root.rotation.y`, y llama `u.update(dt)`.

## Contrato real

```js
UEM.ROLES                 // {jefe|asalto|granadero|tirador: {nombre, arma:'fusil'|'escopeta'|'tirador', desc}}
UEM.crear(rol,{semilla})  // → u   (rol desconocido → 'asalto'; sin semilla → al azar)
UEM.granada()             // → THREE.Mesh nuevo (geometría y material compartidos), centro en el origen
UEM.calentar(scene,on)    // → cantidad de muestras puestas (5) o 0

u.root                    // THREE.Group: el juego pone position (pies) y rotation.y (frente = +Z)
u.e                       // entradas (abajo)
u.update(dt)              // dt en s (se recorta a 0,1; 0 o NaN no rompen). Lee cuánto se movió y giró root
u.disparo()               // patada (resorte), fogonazo 55 ms, vaina; la escopeta bombea y escupe el cartucho
u.golpe(dir,f)            // sacudón. dir: de dónde viene, rad respecto del frente (+ = izquierda del soldado); f 0…1
u.boca(v3) / u.ojos(v3)   // posición mundial, escribe y devuelve v3
u.rayo(o,d)               // null | {t, parte:'cabeza'|'torso'|'brazo'|'pierna'}  (t en metros del mundo)
u.soltarArma()            // el arma cae y queda de costado en el piso
u.dispose()               // saca root de la escena y libera la textura de huesos (geometría y material son compartidos)
```

`u.e` tiene exactamente los campos de 4.2 (`agach, tierra, apunta, mYaw, mPitch, asoma, recarga, salto, lanza, lanzaSale=0.55, senal, senalTipo, culata, radio, aturdido, muerte, luz, laser`).

**Convenciones que fijé** (la SPEC no las decía):
- `mYaw` positivo apunta hacia la izquierda del soldado (+X local), igual que `rotation.y`. `mPitch` positivo apunta hacia arriba. Se recortan a ±1,3 y ±0,9.
- `asoma`: −1 se asoma por su izquierda, +1 por su derecha.
- `muerte.dir` usa la misma convención que `golpe`: indica de dónde vino el tiro. En `atras` gira el plano de caída hasta ±0,6 rad; en `adelante` usa `dir−π`; en `derrumbe` cae hacia el lado contrario al tiro; en `tierra` no se usa.
- `laser` es un `Vector3` mundial que el modelo lee en cada cuadro (no guarda la referencia). Solo lo dibuja el tirador.

**Diferencias con 4.2 (todas compatibles):**
- `u.rayo` devuelve **siempre el mismo objeto** por soldado (no crea basura). Si hay que guardarlo, copiar `t` y `parte`.
- Al empezar `muerte`, el arma se suelta sola. Llamar a `soltarArma()` igual no hace daño.
- El modelo suaviza apenas las entradas (`apunta` ~70 ms; `agach`, `tierra` y `asoma` ~0,1 s; `radio`, `aturdido`) para que un salto de la IA no se vea como tirón. **Los tiempos los sigue manejando la IA.**

**Extras opcionales:** `u.mano(v3)` (palma derecha en el mundo: de ahí sale la granada en `lanza=0.55`), `u.revivir()` (lo usa el visor), `u.malla`, `u.efectos`, `u.rol`, `u.semilla`, `UEM.info(rol)` → `{triangulos, triangulosEfectos, llamadas}`, `UEM.VERSION`. `UEM._interno` es solo para las pruebas y se puede borrar.

**Tiempos recomendados para la IA:** `agach` 0→1 en 0,4–0,5 s. `tierra` 0→1 en 1,2–1,5 s: pasa por rodillas en el piso (0,4) y plancha con la mano izquierda apoyada (0,7); para pararse se hace al revés. `recarga` 2,2–2,8 s: el cargador sale entre 0,17 y 0,33 y el nuevo entra en 0,64; la escopeta mete tres cartuchos. `lanza` 1,1–1,4 s, así quedan ≥0,6 s de gesto antes de que la granada salga en 0,55. `senal` 1,4–1,8 s. `culata` 0,8–1 s, pega en 0,5. `salto` 1–1,2 s, moviendo root ~1,6 m hacia adelante. `muerte.t` 0→1 en 1,1–1,5 s.

## Números (medidos)

| Rol | Triángulos cuerpo + arma | Efectos | Total |
|---|---|---|---|
| jefe | 7.308 | 172 | 7.480 |
| asalto | 7.256 | 172 | 7.428 |
| granadero | 7.402 | 172 | 7.574 |
| tirador | 7.360 | 112 | 7.472 |

- **Llamadas de dibujo:** 2 por soldado con todo prendido (cuerpo + malla aditiva de efectos), medido con `renderer.info` en Chromium: 1 soldado → 2 llamadas, 8 → 16. En r128 `renderer.info` no cuenta la pasada de sombras, porque se reinicia después. El cuerpo suma 1 llamada en cada mapa de sombras que lo incluya; los efectos no proyectan sombra. Peor caso: 3 por soldado.
- **`update` con 8 soldados animándose** (caminar, correr, recargar, granada, seña, a tierra, agachado disparando): **0,15–0,20 ms por cuadro en Chromium** (≈0,02 ms cada uno; varía entre corridas). En Node, con una mezcla parecida, da 0,18–0,25 ms. La escena entera con `updateMatrixWorld` agrega ~0,02 ms. El reloj de esta máquina es más lento que una PC normal: en la GTX 1070 de Facu debería costar igual o menos.
- **`u.rayo`:** 2,2 µs por consulta, con 26 esferas recalculadas solo al preguntar.
- Ninguna luz de Three.js en el modelo. `update` no crea objetos: las claves de las capas son constantes del módulo y no hay cierres ni literales por cuadro.

## Decisiones

- **Una `SkinnedMesh` por soldado** con color, aspereza, metal y emisión por vértice: un solo `MeshStandardMaterial` parchado, compartido por todos. **Otra malla aditiva con piel** lleva linterna, deslumbre, láser, punto, fogonazo, luz de la nuca y el reflejo frío de los lentes. Usa un `ShaderMaterial` propio con niebla; el haz se apaga en los bordes y el deslumbre solo se ve de frente. Los efectos se prenden y apagan escalando huesos a cero, así que no se crea nada.
- **Huesos "planos"** (37): la jerarquía la resuelvo yo. Cada cuadro se arma una **pose** chica: cadera, giros de columna, cuello y cabeza, y objetivos de manos y pies. Sale de mezclar posturas y capas, y después pasa por IK analítica de dos huesos. Cualquier mezcla queda armada y los miembros no se despegan.
- **IK con piso:** si el codo o la rodilla quedarían bajo el piso, el plano de doblez gira lo mínimo necesario. Los borceguíes se chequean contra el piso, con la puntera aparte.
- **Paso:** la fase avanza con la distancia recorrida. Cada pie queda clavado en el mundo mientras apoya y cae donde va a estar el cuerpo (predice con la velocidad). Quieto, si un pie quedó lejos (frenó, giró, cambió de postura) da un paso corto para acomodarse. El talón de atrás se levanta pivotando en la base de los dedos. `pruebas/paso.js` mide **0 mm de patinada** caminando, trotando, corriendo, de costado, hacia atrás, en curva, agachado, frenando y girando quieto.
- **Brazos:** la mano derecha agarra la empuñadura y la izquierda el guardamanos (en la escopeta, la corredera). Los agarres salen de que el cilindro que cruza la palma coincida con el eje de cada pieza. Si el guardamanos queda lejos, la mano se corre hacia atrás sobre él y el hombro se adelanta hasta 4,5 cm. Con el arma al hombro, la mira queda frente al ojo derecho (mejilla en la culata).
- **Miedo:** sin piel a la vista (pasamontañas, guantes). Máscara con lentes redondos de vidrio oscuro y brillo frío tenue, más un reflejo frío que aparece cuando te miran. El hocico apunta hacia abajo, con válvulas como mandíbulas, y el filtro va en la mejilla izquierda. Postura táctica: rodillas apenas flexionadas, torso adelante, el arma nunca baja de "lista". Al apuntar, el índice entra al gatillo; si no, queda recto.
- **Siluetas:** el **jefe** lleva antena de látigo de 1 m con resorte y visores nocturnos levantados (dos tubos sobre el casco). El **asalto** es más liviano: hombreras, canana con cartuchos rojos y escopeta. El **granadero** lleva cuatro granadas en el pecho y un morral grande en la cadera. El **tirador** tiene velo sobre el casco y los hombros, y fusil largo con mira, supresor, bípode que se abre a tierra y láser.
- **Variación por semilla:** altura ±3 %, ancho de pecho y cadera ±4 %, ritmo del paso ±6 %, fase de la respiración y del parpadeo de la nuca.

## Cómo se probó

- `pruebas/nodo.js`: triángulos por pieza. Error de las manos y punto más bajo del cuerpo (piel calculada en CPU) en de pie, apuntando en los cuatro extremos, agachado, a tierra y asomado: manos a 0 cm del objetivo y nada bajo el piso.
- `pruebas/capas.js` y `perfil.js` recorren cada capa y cada muerte de 0 a 1. Manos pegadas al arma en todas las capas: lo peor es 3,7 cm en el culatazo de escopeta y 3,3 cm en la seña "derecha". En las muertes, lo más hundido son 2,7 cm (puntera en el derrumbe).
- `pruebas/costo.js`: `u.rayo` en las tres posturas. Disparando al frente desde 10 m a distintas alturas: de pie da piernas, torso, brazo y cabeza, y nada arriba de 1,82 m. Agachado, la cabeza queda a 1,25 m. A tierra, torso a 5–20 cm y cabeza a 50 cm. También con root movido y girado 90°.
- `pruebas/robustez.js` (Chromium): visor en ronda 95 s con los cuatro y 95 s con uno, todas las poses, rol inválido, `dt` 0 / 5 / NaN, teletransporte, tipo de muerte inventado, todas las capas a la vez, `dispose`, `calentar` y vuelta: sin errores de consola ni NaN.

## Capturas (`capturas/`, láminas de 1280×720)

- `lamina_roles_vistas.png`: los cuatro de pie apuntando, en tres cuartos, perfil y espalda (12 vistas).
- `lamina_luz_plena.png`: los cuatro de frente con luz plena; primer plano de casco y máscara; aturdido, mano a la radio, lo hieren.
- `lamina_posturas.png`: agachado apuntando; tirador a tierra con bípode y láser; yendo al piso (pose intermedia); corriendo; asomándose a la izquierda y a la derecha; caminando; de costado.
- `lamina_acciones.png`: recarga (saca el cargador / mete el nuevo); granada con el brazo atrás; culatazo; las cuatro señas.
- `lamina_muertes.png`: las cuatro muertes a mitad de la caída y en la pose final.
- `lamina_formacion_armas.png`: los cuatro de noche con linternas, también desde los ojos del jugador; caminando; siluetas de perfil; fusil con granada, escopeta y fusil de tirador solos; fogonazo.

## Pendiente o flojo

- Articulaciones rígidas: de cerca, hombros y caderas se ven "de muñeco articulado" (esferas en las articulaciones). A distancia de juego no molesta.
- La mano derecha tiene el agarre fijo (solo se mueve el índice). La izquierda abre y cierra los cuatro dedos como bloque. El pulgar es fijo.
- Arrastrarse cuerpo a tierra es una animación local (patina un poco a propósito). Correr a fondo da zancadas largas.
- El velo del tirador es rígido (sigue a cabeza y pecho, no flamea). Las vainas vuelan en el marco del soldado: si gira rápido, la vaina en el aire gira con él.
- La luz roja de la nuca parpadea también muerto (me pareció inquietante). Si molesta, se apaga con `muerte`.
- El visor, no el modelo, finge el reflejo del piso mojado con una copia espejada del cuerpo: es una llamada más por soldado, solo en el visor.
- No lo probé dentro del juego: solo en el visor y en Node. El integrador tiene que confirmar escala y colores bajo las luces reales del retén.
