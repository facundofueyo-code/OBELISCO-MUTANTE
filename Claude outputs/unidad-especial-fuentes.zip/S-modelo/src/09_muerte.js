
/* ====================================================================================
   MUERTES
   Cuatro caídas armadas como poses clave. La primera clave es una foto de la pose viva en el
   momento de morir, así que arranca desde donde estaba. Los tramos que caen aceleran (gravedad)
   y al tocar el piso hay un rebote chico. 'dir' (de dónde vino el tiro) gira el plano de caída.
   Formato de cada clave: [t, cadera, giroCadera, columna, pecho, cuello, cabeza, manoI, manoD, pieI, pieD, dedos, tramo]
   mano: [posición muñeca, hacia dónde los dedos, hacia dónde la palma, codo]
   pie: 'S' (queda donde estaba) o [tobillo, hacia dónde la punta, hacia dónde el empeine, rodilla]
   tramo: cómo se llega a esta clave: 'o' frena, 'i' cae (acelera), 'e' suave
   ==================================================================================== */
const MUERTES={
  atras:[
    [.16,[0,.93,-.07],[-.18,0,0],[-.15,0,0],[-.25,0,0],[-.2,0,0],[-.3,0,0],
      [[.30,1.30,.22],[.2,.8,.6],[-1,0,0],[1,-.5,-.3]],[[-.30,1.25,.18],[-.2,.8,.6],[1,0,0],[-1,-.5,-.3]],'S','S',[.3,.3,.2],'o'],
    [.42,[0,.42,-.30],[-.75,0,0],[-.05,0,0],[-.1,0,0],[.25,0,0],[.2,0,0],
      [[.34,.95,-.05],[.3,1,0],[0,0,1],[1,0,-1]],[[-.36,.90,-.10],[-.3,1,0],[0,0,1],[-1,0,-1]],
      [[.13,.10,.14],[.15,.55,.82],[0,.83,-.55],[.2,.5,1]],[[-.15,.10,.08],[-.15,.55,.82],[0,.83,-.55],[-.2,.5,1]],[.4,.4,.3],'i'],
    [.70,[0,.205,-.62],[-PI/2,0,0],[.18,0,0],[.16,0,0],[-.12,0,0],[-.1,.35,0],
      [[.55,.06,-1.05],[.7,0,-.7],[0,0,1],[1,.1,0]],[[-.53,.06,-1.03],[-.7,0,-.7],[0,0,1],[-1,.1,0]],
      [[.20,.095,.26],[.45,.88,.1],[0,.1,-1],[0,1,0]],[[-.22,.095,.22],[-.45,.88,.1],[0,.1,-1],[0,1,0]],[.45,.5,.3],'i'],
    [1,[0,.205,-.64],[-PI/2,0,.1],[.17,0,0],[.16,0,0],[-.12,0,0],[-.1,.75,0],
      [[.58,.06,-.98],[.8,0,-.5],[0,0,1],[1,.1,0]],[[-.44,.065,-.80],[-.8,0,.4],[0,0,1],[-1,.2,0]],
      [[.24,.095,.0],[.6,.75,.25],[0,.3,-1],[.6,1,.3]],[[-.22,.095,.22],[-.5,.85,.1],[0,.1,-1],[0,1,0]],[.5,.6,.35],'e']],
  adelante:[
    [.15,[0,.92,.05],[.25,0,0],[.25,0,0],[.25,0,0],[.3,0,0],[.3,0,0],
      [[.24,.95,.25],[0,-1,.3],[-1,0,0],[1,0,-1]],[[-.24,.95,.20],[0,-1,.3],[1,0,0],[-1,0,-1]],'S','S',[.3,.3,.2],'o'],
    [.42,[0,.52,.02],[.35,0,0],[.3,0,0],[.3,0,0],[.4,0,0],[.4,0,0],
      [[.25,.50,.30],[0,-1,.2],[-1,0,0],[1,0,-1]],[[-.25,.50,.28],[0,-1,.2],[1,0,0],[-1,0,-1]],
      [[.13,.175,-.42],[0,-.91,.41],[0,.41,.91],[0,-.3,1]],[[-.13,.175,-.42],[0,-.91,.41],[0,.41,.91],[0,-.3,1]],[.4,.4,.3],'i'],
    [.72,[0,.195,.32],[PI/2,.08,0],[-.1,0,0],[-.12,0,0],[-.25,0,0],[-.1,1.2,0],
      [[.40,.06,.66],[.3,0,1],[-1,0,0],[1,.3,-.3]],[[-.33,.065,.26],[-.1,0,-1],[-1,0,0],[-1,.3,0]],
      [[.20,.07,-.54],[.3,-.45,-.84],[.15,-.88,.45],[.3,-1,0]],[[-.17,.07,-.57],[-.3,-.45,-.84],[-.15,-.88,.45],[-.3,-1,0]],[.45,.5,.35],'i'],
    [1,[0,.195,.33],[PI/2,.1,.05],[-.1,0,0],[-.12,0,0],[-.2,0,0],[-.1,1.35,0],
      [[.42,.06,.62],[.4,0,1],[-1,0,0],[1,.3,-.3]],[[-.32,.065,.28],[-.1,0,-1],[-1,0,0],[-1,.3,0]],
      [[.20,.07,-.54],[.3,-.45,-.84],[.15,-.88,.45],[.3,-1,0]],[[-.45,.08,-.36],[-.5,-.3,-.8],[-.2,-.9,.3],[-1,-.2,.3]],[.5,.6,.4],'e']],
  derrumbe:[
    [.25,[0,.72,-.02],[.3,0,.05],[.35,0,0],[.35,0,0],[.45,0,0],[.4,0,0],
      [[.22,.65,.12],[0,-1,0],[-1,0,0],[1,0,-1]],[[-.22,.65,.12],[0,-1,0],[1,0,0],[-1,0,-1]],'S','S',[.3,.3,.2],'o'],
    [.52,[0,.42,-.06],[.45,0,.12],[.4,0,0],[.35,0,0],[.5,0,0],[.4,0,0],
      [[.24,.30,.22],[0,-.6,1],[-.5,-.8,0],[1,0,-.5]],[[-.24,.30,.22],[0,-.6,1],[.5,-.8,0],[-1,0,-.5]],
      [[.12,.175,-.40],[0,-.91,.41],[0,.41,.91],[0,-.3,1]],[[-.12,.175,-.40],[0,-.91,.41],[0,.41,.91],[0,-.3,1]],[.4,.4,.3],'i'],
    [.82,[.30,.22,.04],[.4,0,-1.45],[.35,0,.12],[.3,0,.12],[.3,0,.15],[.2,0,.2],
      [[.80,.06,.40],[.3,0,1],[-1,0,0],[0,-1,.3]],[[.64,.19,.34],[.3,0,1],[1,0,0],[0,-1,.3]],
      [[-.22,.07,.04],[0,0,1],[1,0,0],[0,0,1]],[[-.25,.22,.0],[0,0,1],[1,0,0],[0,0,1]],[.45,.5,.35],'i'],
    [1,[.30,.22,.04],[.42,0,-1.5],[.38,0,.12],[.32,0,.12],[.35,0,.15],[.25,0,.25],
      [[.82,.06,.38],[.3,0,1],[-1,0,0],[0,-1,.3]],[[.62,.17,.36],[.4,0,1],[1,0,0],[0,-1,.3]],
      [[-.22,.07,.06],[0,0,1],[1,0,0],[0,0,1]],[[-.27,.20,-.02],[0,0,1],[1,0,0],[0,0,1]],[.5,.6,.4],'e']],
  tierra:[
    [.35,[0,.19,-.10],[PI/2,0,0],[-.16,0,0],[-.16,0,0],[.15,0,0],[.35,0,0],
      [[.32,.06,.55],[.2,0,1],[-1,0,0],[1,.2,0]],[[-.30,.065,.50],[-.2,0,1],[1,0,0],[-1,.2,0]],'S','S',[.4,.4,.3],'i'],
    [1,[0,.19,-.10],[PI/2,.1,.18],[-.16,0,.05],[-.15,0,.05],[0,0,0],[0,1.15,0],
      [[.40,.06,.48],[.3,0,1],[-1,0,0],[1,.2,0]],[[-.30,.065,.22],[-.1,0,-1],[-1,0,0],[-1,.3,0]],
      [[.42,.08,-.62],[.5,-.3,-.8],[.2,-.9,.3],[1,-.2,.3]],[[-.24,.075,-.98],[-.3,-.4,-.87],[-.12,-.9,.4],[-.3,-1,0]],[.5,.6,.4],'e']]
};
/* se arman una vez como poses */
const CLAVES_M={};
for(const tipo in MUERTES)CLAVES_M[tipo]=MUERTES[tipo].map(k=>{
  const p=nuevaPose(),v=a=>new V3(...a);
  p.pel.set(...k[1]);qE(p.pelQ,...k[2]);qE(p.col,...k[3]);qE(p.pec,...k[4]);qE(p.cue,...k[5]);qE(p.cab,...k[6]);
  for(let i=0;i<2;i++){const m=k[7+i],o=p.mano[i];o.p.set(...m[0]);qMano(o.q,i===0,v(m[1]),v(m[2]));o.polo.copy(v(m[3]).normalize());}
  const snap=[false,false];
  for(let i=0;i<2;i++){const f=k[9+i],o=p.pie[i];if(f==='S'){snap[i]=true;continue;}o.p.set(...f[0]);qBase(o.q,v(f[1]),v(f[2]));o.polo.copy(v(f[3]).normalize());}
  p.ded[0]=k[11][0];p.ded[1]=k[11][1];p.ded[2]=k[11][2];
  return {t:k[0],pose:p,snap,tramo:k[12]};});
/* índice de la clave en la que el cuerpo pega contra el piso (para el rebote) */
const IMPACTO={};for(const tipo in CLAVES_M)IMPACTO[tipo]=CLAVES_M[tipo].findIndex(c=>c.tramo==='i'&&c.pose.pel.y<.3);

function muerte(st,e,dt){
  const m=e.muerte;
  if(!st.muerto||st.mPedido!==m.tipo){
    /* arranca: foto de la pose viva y claves giradas según de dónde vino el tiro */
    if(!st.muerto)copiarPose(st.sp0,st.sp);
    st.muerto=true;st.mPedido=m.tipo;st.mTipo=MUERTES[m.tipo]?m.tipo:'derrumbe';st.mT=0;
    soltar(st);
    const dir=m.dir||0;let giro=0,espejo=false;
    if(st.mTipo==='atras')giro=clamp(dir,-.6,.6);
    else if(st.mTipo==='adelante')giro=clamp(envol(dir-PI),-.6,.6);
    else if(st.mTipo==='derrumbe')espejo=dir>0;           /* tiro desde la izquierda: cae hacia la derecha */
    const cl=CLAVES_M[st.mTipo];
    for(let i=0;i<cl.length;i++){const c=cl[i],o=st.mk[i];copiarPose(o,c.pose);if(espejo)espejarPose(o);girarPose(o,giro);
      for(let j=0;j<2;j++)if(c.snap[j]){const s=st.sp0.pie[j],d=o.pie[j];d.p.copy(s.p);d.q.copy(s.q);d.polo.copy(s.polo);o.punta[j]=st.sp0.punta[j];}}
  }
  const cl=CLAVES_M[st.mTipo],t=sat(m.t);st.mT=t;
  let j=0;while(j<cl.length-1&&t>cl[j].t)j++;
  const t0=j?cl[j-1].t:0,t1=cl[j].t,u=sat((t-t0)/Math.max(1e-4,t1-t0)),tr=cl[j].tramo;
  const w=tr==='i'?u*u:tr==='o'?1-(1-u)*(1-u):ease(u);
  mezclarPose(st.sp,j?st.mk[j-1]:st.sp0,st.mk[j],w);
  /* rebote al pegar contra el piso (fin del primer tramo que cae hasta abajo) */
  const ki=IMPACTO[st.mTipo];
  if(ki>=0){const tc=cl[ki].t,d=t-tc;if(d>0&&d<.14)st.sp.pel.y+=.035*Math.sin(PI*d/.14)*(1-d/.14);}
  resolverColumna(st,st.sp);resolverMiembros(st,st.sp);
}
/* reflejo en X de una rotación: (x,y,z,w) → (x,-y,-z,w) */
function ref(q){q.y=-q.y;q.z=-q.z;}
/* espejo izquierda-derecha de una pose (para que el derrumbe caiga hacia el otro lado) */
const _qs=new Q4();
function espejarPose(o){
  o.pel.x=-o.pel.x;ref(o.pelQ);ref(o.col);ref(o.pec);ref(o.cue);ref(o.cab);
  for(let j=0;j<2;j++){const par=j?o.pie:o.mano,a=par[0],b=par[1];
    _qs.copy(a.q);a.q.copy(b.q);b.q.copy(_qs);ref(a.q);ref(b.q);
    const px=a.p.x,py=a.p.y,pz=a.p.z;a.p.set(-b.p.x,b.p.y,b.p.z);b.p.set(-px,py,pz);
    const lx=a.polo.x,ly=a.polo.y,lz=a.polo.z;a.polo.set(-b.polo.x,b.polo.y,b.polo.z);b.polo.set(-lx,ly,lz);}
  const t=o.punta[0];o.punta[0]=o.punta[1];o.punta[1]=t;
}
