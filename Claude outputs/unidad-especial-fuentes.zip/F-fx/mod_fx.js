/* =====================================================================================================
   UE · F — efectos, sonido, avisos en pantalla y vista táctica de la unidad especial
   Cuatro módulos: UESND (sonido) · UEFX (trazadoras, impactos, sangre) · UEHUD (radio interceptada,
   detección, dirección del daño, aviso de granada) · UEDBG (vista táctica, F2).
   Es todo lo que hace que el jugador ENTIENDA la pelea: de dónde le tiran, cuándo lo están viendo,
   qué dicen por radio y qué cree el escuadrón. No crea luces ni toca sfx/PRI. Anda aunque falten los
   otros módulos (pregunta typeof antes de usarlos) y aunque falte su HTML (cada parte se apaga sola).
   ===================================================================================================== */

/* ---------- UESND: disparos enemigos, balas que pasan, radio, pasos, equipo ---------- */
const UESND=(()=>{
  /* Perillas para ajustar de oído. Distancias en metros; niveles antes del volumen general del juego. */
  const CFG={
    vol:.85,                 // volumen de todos los disparos enemigos (sale de un compresor propio)
    dRef:22,dExp:1.3,        // caída con la distancia: 1/(1+(d/dRef)^dExp) → 10 m 0,74 · 30 m 0,40 · 80 m 0,16
    lpCerca:16000,lpCaida:45,lpMin:850,  // pasa-bajos según la distancia: 16 kHz·e^(−d/45), nunca menos de 850 Hz
    sonido:340,              // m/s: cada sonido llega con un retardo de distancia/340
    pan:.85,                 // cuánto se abre el paneo estéreo (1 = todo a un lado)
    alcDisparo:260,alcPasos:15,alcEquipo:10,alcCuerpo:32,alcImpacto:34,alcVoz:42,  // hasta dónde se oye cada cosa
    radioVol:.5,             // la radio interceptada (suena «en el oído» del jugador, sin lugar)
    vozVol:.55               // la misma frase saliendo de la radio del soldado, desde donde está
  };
  /* Receta de cada arma: crack [corte Hz, duración, pico] · cuerpo [f0, f1, duración, pico] · golpe [f0, f1, duración, pico]
     · cola [f0, f1, duración, pico, retardo]: el eco entre los edificios, que es lo que se oye de lejos */
  const TIRO={
    fusil:   {g:1,   max:3,win:110,crack:[2400,.035,.5],cuerpo:[4200,300,.16,.85],golpe:[160,48,.09,.7], cola:[500,220,.42,.2,.05]},
    escopeta:{g:1.05,max:2,win:150,crack:[2000,.06,.32],cuerpo:[2600,150,.42,.95],golpe:[118,34,.3,.85], cola:[320,140,.6,.24,.07]},
    tirador: {g:1.2, max:2,win:200,crack:[3000,.045,.7],cuerpo:[5200,200,.3,1],   golpe:[140,36,.22,.85],cola:[700,160,1.3,.34,.06],eco:[.28,.5,.15]}
  };
  /* Ocho voces de radio: tono base (Hz), sílabas por segundo y tamaño de garganta. Sirven para distinguir quién habla. */
  const VOCES=[{f0:96,ritmo:4.8,fs:1},{f0:112,ritmo:5.6,fs:1.06},{f0:88,ritmo:4.2,fs:.94},{f0:124,ritmo:6,fs:1.1},
               {f0:104,ritmo:5,fs:.98},{f0:134,ritmo:5.4,fs:1.04},{f0:80,ritmo:3.9,fs:.9},{f0:118,ritmo:6.4,fs:1.08}];
  const VOCALES=[[800,1150],[400,1700],[270,2290],[450,800],[325,700]];   // primer y segundo formante de a e i o u

  const O={d:0,lado:0,frente:1};
  /* dónde queda un punto respecto del que escucha (la cámara): distancia, lado (−1 izquierda … +1 derecha) y frente (+1 adelante) */
  function oir(pos,alc){
    const c=camera.position,dx=pos.x-c.x,dz=pos.z-c.z,dy=(pos.y===undefined?c.y:pos.y)-c.y,d=Math.sqrt(dx*dx+dy*dy+dz*dz);
    if(!(d<=alc))return null;
    const dh=Math.hypot(dx,dz)||1e-3,sy=Math.sin(P.yaw),cy=Math.cos(P.yaw);
    O.d=d;O.lado=(dx*cy-dz*sy)/dh*Math.min(1,dh/1.5);O.frente=(-dx*sy-dz*cy)/dh;return O;}
  /* ganancia → pasa-bajos según la distancia → paneo → destino. Devuelve el nodo donde se enchufan las fuentes. */
  function cadena(o,gan,dst,tope){
    const g=AC.createGain();g.gain.value=gan;
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.Q.value=.5;
    let f=Math.max(CFG.lpMin,CFG.lpCerca*Math.exp(-o.d/CFG.lpCaida));if(o.frente<0)f*=1+.3*o.frente;   // lo que suena detrás llega un poco más apagado
    lp.frequency.value=Math.min(tope||20000,f);g.connect(lp);
    let n=lp;if(AC.createStereoPanner){const p=AC.createStereoPanner();p.pan.value=clamp(o.lado*CFG.pan,-1,1);lp.connect(p);n=p;}
    n.connect(dst||master);return g;}
  /* ruido filtrado y tono con envolvente, como noise() y tone() del juego pero hacia un destino propio (para poder panear) */
  function ruidoA(dst,t,dur,tipo,f0,f1,pico,q){
    const s=AC.createBufferSource();s.buffer=noiseBuf;if(dur>.45)s.loop=true;
    const f=AC.createBiquadFilter();f.type=tipo;f.frequency.setValueAtTime(f0,t);if(f1)f.frequency.exponentialRampToValueAtTime(f1,t+dur);f.Q.value=q||1;
    const g=AC.createGain();g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(pico,t+.004);g.gain.exponentialRampToValueAtTime(.0001,t+.004+dur);
    s.connect(f);f.connect(g);g.connect(dst);s.start(t,Math.random()*.5);s.stop(t+dur+.06);}
  function tonoA(dst,t,tipo,f0,f1,dur,pico){
    const o=AC.createOscillator();o.type=tipo;o.frequency.setValueAtTime(f0,t);if(f1)o.frequency.exponentialRampToValueAtTime(f1,t+dur);
    const g=AC.createGain();g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(pico,t+.004);g.gain.exponentialRampToValueAtTime(.0001,t+.004+dur);
    o.connect(g);g.connect(dst);o.start(t);o.stop(t+dur+.06);}
  /* compresor propio de los disparos: ocho fusiles a la vez no saturan ni aplastan el resto de la mezcla.
     Son dos nodos que quedan para siempre: se crean fuera de la captura de auOneShot para que no los desconecte. */
  let bus=null;
  function salidaTiros(){
    if(bus&&bus.context===AC)return bus;
    const cap=AUD.cap;AUD.cap=null;
    try{const c=AC.createDynamicsCompressor();c.threshold.value=-16;c.knee.value=8;c.ratio.value=5;c.attack.value=.003;c.release.value=.16;
      const g=AC.createGain();g.gain.value=CFG.vol;c.connect(g);g.connect(master);bus=c;}finally{AUD.cap=cap;}
    return bus;}

  /* disparo enemigo: de cerca asusta (chasquido + cuerpo + golpe grave); de lejos queda el golpe apagado y su eco */
  let escT=-1e9,escX=0,escZ=0;
  const disparo=auOneShot(function(tipo,pos){
    if(!AC||!pos)return;const R=TIRO[tipo]||TIRO.fusil,o=oir(pos,CFG.alcDisparo);if(!o)return;
    if(R===TIRO.escopeta){   // ocho perdigones son un solo estampido, aunque avisen una vez por perdigón
      const n=performance.now();if(n-escT<45&&Math.abs(pos.x-escX)+Math.abs(pos.z-escZ)<1.5)return;escT=n;escX=pos.x;escZ=pos.z;}
    if(!auGate('ue_d_'+(R===TIRO.fusil?'f':R===TIRO.escopeta?'e':'t'),o.d<45?2:1,R.max,R.win))return;
    const d=o.d,t=AC.currentTime+d/CFG.sonido,dst=cadena(o,R.g/(1+Math.pow(d/CFG.dRef,CFG.dExp)),salidaTiros()),
      barato=AUD.voices>60;   // con muchas voces sonando, cada tiro usa menos fuentes
    ruidoA(dst,t,R.cuerpo[2],'lowpass',R.cuerpo[0],R.cuerpo[1],R.cuerpo[3]);
    tonoA(dst,t,'sine',R.golpe[0],R.golpe[1],R.golpe[2],R.golpe[3]);
    if(d<70&&!barato)ruidoA(dst,t,R.crack[1],'highpass',R.crack[0],0,R.crack[2]);
    if((d>22||R.eco)&&!barato){const c=R.cola;ruidoA(dst,t+c[4],c[2],'bandpass',c[0],c[1],c[3]*Math.min(1,.45+d/60),.8);
      if(R.eco)ruidoA(dst,t+R.eco[0],R.eco[1],'bandpass',c[0]*.7,c[1],R.eco[2],.8);}
  });

  /* bala que pasa cerca: el chasquido supersónico y el zumbido que se aleja. pan: −1 izquierda … +1 derecha */
  const silbido=auOneShot(function(pan){
    if(!AC||!auGate('ue_silb',2,2,110))return;
    const t=AC.currentTime,g=AC.createGain();g.gain.value=1;let n=g;
    if(AC.createStereoPanner){const p=AC.createStereoPanner();p.pan.value=clamp(+pan||0,-1,1)*.9;g.connect(p);n=p;}
    n.connect(master);
    ruidoA(g,t,.02,'highpass',5200,0,.5);
    ruidoA(g,t+.004,.15,'bandpass',rand(2800,3600),rand(700,1000),.3,7);
    tonoA(g,t+.004,'sine',rand(2200,2800),rand(600,800),.13,.05);
  });

  /* golpe de una bala contra algo cerca del jugador (lo llama UEFX.impacto): saber que le están pegando a tu cobertura */
  const impacto=auOneShot(function(pos,mat){
    if(!AC||!pos)return;const o=oir(pos,CFG.alcImpacto);if(!o||!auGate('ue_imp',1,3,140))return;
    const k=1-o.d/CFG.alcImpacto,t=AC.currentTime+o.d/CFG.sonido,dst=cadena(o,k*k*.9);
    if(mat==='metal'){ruidoA(dst,t,.045,'highpass',4200,0,.4);tonoA(dst,t,'square',rand(900,1500),rand(500,700),.07,.07);
      if(Math.random()<.25)tonoA(dst,t+.01,'sine',rand(2400,3200),rand(800,1100),.26,.045);}   // a veces rebota y se va silbando
    else if(mat==='carne')ruidoA(dst,t,.09,'bandpass',rand(600,900),240,.45,4);
    else if(mat==='piso'){ruidoA(dst,t,.06,'bandpass',1100,500,.4,1.2);ruidoA(dst,t,.07,'lowpass',380,100,.3);}
    else{ruidoA(dst,t,.05,'bandpass',1600,700,.45,1.5);ruidoA(dst,t,.09,'lowpass',500,120,.35);}
  });

  /* voz de radio: no se entiende lo que dice (eso va en el subtítulo), pero se reconoce quién habla y que es una radio.
     Sierra con dos formantes que saltan de vocal en vocal al ritmo de las sílabas → distorsión → banda angosta.
     Chasquido de apertura, soplido de fondo, consonantes de ruido y pitido de cierre. */
  const activas=[];
  const radio=auOneShot(function(voz,dur,pos){
    if(!AC||!auGate('ue_radio',2,2,350))return;
    const V=VOCES[(((voz|0)%8)+8)%8],D=clamp(+dur||1.4,.5,5),t0=AC.currentTime+.02,fin=t0+D,tHabla=fin-.17;
    for(let i=activas.length-1;i>=0;i--)if(activas[i].fin<t0)activas.splice(i,1);
    const out=AC.createGain();out.gain.value=CFG.radioVol;out.connect(master);
    const hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=480;hp.Q.value=.9;
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2500;lp.Q.value=1.2;hp.connect(lp);lp.connect(out);
    /* la voz */
    const osc=AC.createOscillator();osc.type='sawtooth';osc.frequency.setValueAtTime(V.f0*1.08,t0);
    const f1=AC.createBiquadFilter(),f2=AC.createBiquadFilter();f1.type=f2.type='bandpass';f1.Q.value=5;f2.Q.value=8;
    f1.frequency.setValueAtTime(600*V.fs,t0);f2.frequency.setValueAtTime(1400*V.fs,t0);
    const g1=AC.createGain(),g2=AC.createGain();g1.gain.value=2.2;g2.gain.value=1.5;
    const sil=AC.createGain();sil.gain.setValueAtTime(0,t0);
    const dis=AC.createWaveShaper();dis.curve=shCurve(10);
    osc.connect(f1);osc.connect(f2);f1.connect(g1);f2.connect(g2);g1.connect(sil);g2.connect(sil);sil.connect(dis);
    const vg=AC.createGain();vg.gain.value=.34;dis.connect(vg);vg.connect(hp);
    /* la estática: una sola fuente de ruido para el soplido y para las consonantes */
    const nz=AC.createBufferSource();nz.buffer=noiseBuf;nz.loop=true;
    const nb=AC.createBiquadFilter();nb.type='bandpass';nb.frequency.value=1900;nb.Q.value=.6;
    const ng=AC.createGain();ng.gain.setValueAtTime(.42,t0);ng.gain.exponentialRampToValueAtTime(.035,t0+.06);   // chasquido al abrir el canal
    ng.gain.setValueAtTime(.035,fin-.15);ng.gain.linearRampToValueAtTime(.3,fin-.1);ng.gain.exponentialRampToValueAtTime(.0001,fin);   // cola de estática al soltar
    const cf=AC.createBiquadFilter();cf.type='highpass';cf.frequency.value=2300;const cg=AC.createGain();cg.gain.setValueAtTime(0,t0);
    nz.connect(nb);nb.connect(ng);ng.connect(hp);nz.connect(cf);cf.connect(cg);cg.connect(hp);
    /* las sílabas: cada una elige vocal, altura y fuerza; cada 2 a 4 hay un silencio de palabra */
    let t=t0+.09,n=0,corte=2+(Math.random()*3|0);
    while(t<tHabla-.08){const L=rand(.7,1.3)/V.ritmo,prog=(t-t0)/D,ac=Math.random()<.3?1.16:1,v=VOCALES[Math.random()*5|0];
      osc.frequency.setTargetAtTime(V.f0*ac*(1.1-.22*prog)*rand(.95,1.05),t,.03);   // la frase va bajando de tono hacia el final
      f1.frequency.setTargetAtTime(v[0]*V.fs,t,.02);f2.frequency.setTargetAtTime(v[1]*V.fs,t,.02);
      sil.gain.setTargetAtTime(rand(.7,1)*ac,t,.012);sil.gain.setTargetAtTime(.04,t+L*.62,.022);
      if(Math.random()<.4){cg.gain.setTargetAtTime(.3,t-.02,.004);cg.gain.setTargetAtTime(0,t+.012,.01);}
      t+=L;if(++n>=corte){t+=rand(.07,.16);n=0;corte=2+(Math.random()*3|0);}}
    sil.gain.setTargetAtTime(0,tHabla,.02);
    /* pitido de cierre */
    const bp=AC.createOscillator();bp.type='sine';bp.frequency.value=1180;
    const bg=AC.createGain();bg.gain.setValueAtTime(0,t0);bg.gain.setValueAtTime(0,fin-.14);bg.gain.linearRampToValueAtTime(.1,fin-.13);bg.gain.setValueAtTime(.1,fin-.06);bg.gain.linearRampToValueAtTime(0,fin-.04);
    bp.connect(bg);bg.connect(out);
    osc.start(t0);osc.stop(fin+.05);nz.start(t0);nz.stop(fin+.05);bp.start(fin-.15);bp.stop(fin);
    /* y la voz del soldado detrás de la máscara, bajita, desde donde está: sirve para ubicarlo de oído */
    const cortar=[out];
    if(pos){const o=oir(pos,CFG.alcVoz);if(o){const c=cadena(o,CFG.vozVol/(1+Math.pow(o.d/7,1.5)),master,1100);dis.connect(c);cortar.push(c);}}
    activas.push({cortar,fin});
  });
  /* cuántos segundos dura una frase dicha por radio (para que el sonido y el subtítulo coincidan) */
  const durFrase=texto=>clamp(.45+String(texto||'').length*.058,.7,3.6);
  function cortarRadios(){if(!AC)return;const n=AC.currentTime;
    for(const a of activas)for(const g of a.cortar){try{g.gain.cancelScheduledValues(n);g.gain.setTargetAtTime(0,n,.03);}catch(e){}}
    activas.length=0;}

  /* borcego sobre asfalto mojado. fuerza: 1 caminando · 1,4 corriendo · 0,5 agachado */
  const pasos=auOneShot(function(pos,fuerza){
    if(!AC||!pos)return;const o=oir(pos,CFG.alcPasos);if(!o||!auGate('ue_pasos',0,3,130))return;
    const f=clamp(fuerza===undefined?1:+fuerza,.2,1.6),k=1-o.d/CFG.alcPasos,t=AC.currentTime+o.d/CFG.sonido,dst=cadena(o,f*Math.pow(k,1.6)*.32);
    ruidoA(dst,t,.075,'lowpass',360,110,.5);                       // el taco
    ruidoA(dst,t+.012,.04,'bandpass',rand(1700,2500),0,.16,2);    // el agua que salpica
    if(f>1.1)ruidoA(dst,t+.03,.05,'bandpass',900,400,.1,1.5);     // corriendo: la suela que se despega
  });
  /* roce de correaje y una hebilla: un soldado que se mueve cerca sin tirar */
  const equipo=auOneShot(function(pos){
    if(!AC||!pos)return;const o=oir(pos,CFG.alcEquipo);if(!o||!auGate('ue_equipo',0,2,200))return;
    const k=1-o.d/CFG.alcEquipo,t=AC.currentTime+o.d/CFG.sonido,dst=cadena(o,k*k*.3);
    ruidoA(dst,t,.11,'bandpass',rand(2200,3400),rand(1200,1800),.3,1.2);
    ruidoA(dst,t+rand(.03,.07),.02,'bandpass',rand(3800,5200),0,.2,6);
    if(Math.random()<.5)tonoA(dst,t+.05,'triangle',rand(1900,2600),0,.03,.04);
  });
  /* un cuerpo con veinte kilos de equipo cayendo al asfalto, y el arma atrás */
  const cuerpo=auOneShot(function(pos){
    if(!AC||!pos)return;const o=oir(pos,CFG.alcCuerpo);if(!o||!auGate('ue_cuerpo',1,2,300))return;
    const k=1-o.d/CFG.alcCuerpo,t=AC.currentTime+o.d/CFG.sonido,dst=cadena(o,Math.pow(k,1.5)*.8);
    tonoA(dst,t,'sine',95,38,.2,.7);ruidoA(dst,t,.26,'lowpass',520,80,.75);
    ruidoA(dst,t+.05,.05,'bandpass',1500,700,.3,2);ruidoA(dst,t+.11,.04,'bandpass',2300,0,.22,4);
    ruidoA(dst,t+.17,.06,'bandpass',3200,1800,.2,6);tonoA(dst,t+.17,'triangle',rand(700,900),0,.09,.07);
  });

  return{disparo,silbido,radio,pasos,cuerpo,equipo,impacto,durFrase,CFG,TIRO,VOCES,
    pausa(v){if(v)cortarRadios();},      /* en pausa se corta la frase de radio que esté sonando (lo demás dura menos de 1,5 s) */
    reset(){cortarRadios();escT=-1e9;}};
})();

/* ---------- UEFX: trazadoras, impactos y sangre. Todo en UNA malla (una llamada de dibujo) ---------- */
const UEFX=(()=>{
  const NT=48,NC=96,ND=24,NP=40;          // trazadoras · chispas · destellos · bocanadas de polvo
  const NQ=NT*3+NC+ND+NP;                 // cuadraditos como mucho: cada trazadora usa hasta 3 (estela, cabeza y, la del tirador, el rastro)
  /* cómo se ve la bala de cada arma: vida en segundos, ancho relativo, color, brillo y cuánto dura el rastro que deja */
  const TR={fusil:{vida:.075,ancho:1,col:[1,.86,.6],brillo:1.5,rastro:0},
    escopeta:{vida:.06,ancho:.7,col:[1,.74,.45],brillo:.9,rastro:0},
    tirador:{vida:.11,ancho:1.9,col:[1,.93,.86],brillo:2.2,rastro:.3}};
  const SILBA=1.4,SILBA_MIN=6;            // una bala que pasa a menos de 1,4 m de la cámara silba, si el que tiró está a más de 6 m
  const ROJOS=['#5a0a14','#7a1020','#3a060c','#8a1a24'];

  /* textura: una mancha redonda suave. Las estelas usan su columna del medio (perfil de campana a lo ancho).
     Va premultiplicada (rgb = alfa) porque la malla mezcla así: con alfa 0 suma luz (trazadoras, chispas),
     con alfa > 0 tapa lo de atrás (polvo). Así entra todo en un solo material y una sola llamada de dibujo. */
  const TS=32,td=new Uint8Array(TS*TS*4);
  for(let y=0;y<TS;y++)for(let x=0;x<TS;x++){const r=Math.hypot(x-15.5,y-15.5)/15.5,s=r<1?Math.pow(1-r*r,2):0,v=Math.round(s*255),o=(y*TS+x)*4;td[o]=td[o+1]=td[o+2]=td[o+3]=v;}
  const tex=new THREE.DataTexture(td,TS,TS,THREE.RGBAFormat);tex.magFilter=THREE.LinearFilter;tex.minFilter=THREE.LinearMipmapLinearFilter;tex.generateMipmaps=true;tex.needsUpdate=true;
  const mat=new THREE.MeshBasicMaterial({map:tex,vertexColors:true,transparent:true,depthWrite:false,side:THREE.DoubleSide,fog:false,toneMapped:false,
    blending:THREE.CustomBlending,blendEquation:THREE.AddEquation,blendSrc:THREE.OneFactor,blendDst:THREE.OneMinusSrcAlphaFactor});
  const pos=new Float32Array(NQ*12),uv=new Float32Array(NQ*8),col=new Float32Array(NQ*16),idx=new Uint16Array(NQ*6);
  for(let i=0;i<NQ;i++){const a=i*4,o=i*6;idx[o]=a;idx[o+1]=a+1;idx[o+2]=a+2;idx[o+3]=a;idx[o+4]=a+2;idx[o+5]=a+3;}
  const geo=new THREE.BufferGeometry();
  const aPos=new THREE.BufferAttribute(pos,3),aUv=new THREE.BufferAttribute(uv,2),aCol=new THREE.BufferAttribute(col,4);
  aPos.setUsage(THREE.DynamicDrawUsage);aUv.setUsage(THREE.DynamicDrawUsage);aCol.setUsage(THREE.DynamicDrawUsage);
  geo.setAttribute('position',aPos);geo.setAttribute('uv',aUv);geo.setAttribute('color',aCol);geo.setIndex(new THREE.BufferAttribute(idx,1));geo.setDrawRange(0,0);
  const malla=new THREE.Mesh(geo,mat);malla.frustumCulled=false;malla.renderOrder=6;_sceneAdd(malla);   // _sceneAdd: a la escena, no a una sección del mapa (se oculta al cruzar)

  const tz=[],ch=[],ds=[],pv=[];
  for(let i=0;i<NT;i++)tz.push({on:false,ax:0,ay:0,az:0,bx:0,by:0,bz:0,t:0,vida:.07,ancho:1,r:1,g:1,b:1,brillo:1,rastro:0});
  for(let i=0;i<NC;i++)ch.push({on:false,x:0,y:0,z:0,vx:0,vy:0,vz:0,t:0,vida:.3,k:1,fy:0});   // fy: altura del piso donde rebota
  for(let i=0;i<ND;i++)ds.push({on:false,x:0,y:0,z:0,t:0,vida:.06,tam:.2,r:1,g:1,b:1});
  for(let i=0;i<NP;i++)pv.push({on:false,x:0,y:0,z:0,vx:0,vy:0,vz:0,t:0,vida:.5,t0:.1,t1:.5,r:.5,g:.5,b:.5,a:.4});
  let iT=0,iC=0,iD=0,iP=0,hay=false;
  /* últimos tiros, para que la vista táctica los dibuje un instante (quién le tira a qué) */
  const recientes=[];for(let i=0;i<32;i++)recientes.push({ax:0,az:0,bx:0,bz:0,t:-9,tipo:''});let iR=0;

  /* datos de cámara que se usan al armar los cuadraditos (se refrescan una vez por cuadro) */
  let cx=0,cy=0,cz=0,rx=1,ry=0,rz=0,ux=0,uy=1,uz=0,WP=.002,nq=0;
  const W0=.012;                               // medio ancho mínimo de una estela, en metros
  const _a=new V3(),_n={x:0,y:1,z:0},_p={x:0,y:0,z:0},_vl={x:0,y:0,z:0};
  function vert(o,x,y,z,u,v,r,g,b,a){const p=o*3,q=o*2,c=o*4;pos[p]=x;pos[p+1]=y;pos[p+2]=z;uv[q]=u;uv[q+1]=v;col[c]=r;col[c+1]=g;col[c+2]=b;col[c+3]=a;}
  /* estela entre dos puntos, de cara a la cámara. ka y kb: brillo en cada punta. El ancho crece con la distancia
     para que de lejos siga midiendo un par de píxeles (si no, a 60 m no se vería) */
  function tira(ax,ay,az,bx,by,bz,ancho,r,g,b,ka,kb){
    if(nq>=NQ)return;const dx=bx-ax,dy=by-ay,dz=bz-az,mx=(ax+bx)*.5-cx,my=(ay+by)*.5-cy,mz=(az+bz)*.5-cz;
    let sx=dy*mz-dz*my,sy=dz*mx-dx*mz,sz=dx*my-dy*mx;const sl=Math.sqrt(sx*sx+sy*sy+sz*sz);if(sl<1e-9)return;   // viene derecho a la cámara: no hay estela que mostrar
    sx/=sl;sy/=sl;sz/=sl;
    const da=Math.sqrt((ax-cx)**2+(ay-cy)**2+(az-cz)**2),db=Math.sqrt((bx-cx)**2+(by-cy)**2+(bz-cz)**2),
      wa=Math.max(WP*da,Math.min(W0,.012*da))*ancho,wb=Math.max(WP*db,Math.min(W0,.012*db))*ancho,o=nq*4;
    vert(o,ax-sx*wa,ay-sy*wa,az-sz*wa,.5,0,r*ka,g*ka,b*ka,0);vert(o+1,ax+sx*wa,ay+sy*wa,az+sz*wa,.5,1,r*ka,g*ka,b*ka,0);
    vert(o+2,bx+sx*wb,by+sy*wb,bz+sz*wb,.5,1,r*kb,g*kb,b*kb,0);vert(o+3,bx-sx*wb,by-sy*wb,bz-sz*wb,.5,0,r*kb,g*kb,b*kb,0);nq++;}
  /* mancha de cara a la cámara. a = 0: suma luz · a > 0: tapa (polvo, niebla de sangre) */
  function cartel(x,y,z,m,r,g,b,a){
    if(nq>=NQ)return;const o=nq*4,ax=rx*m,ay=ry*m,az=rz*m,bx=ux*m,by=uy*m,bz=uz*m;
    vert(o,x-ax-bx,y-ay-by,z-az-bz,0,0,r,g,b,a);vert(o+1,x+ax-bx,y+ay-by,z+az-bz,1,0,r,g,b,a);
    vert(o+2,x+ax+bx,y+ay+by,z+az+bz,1,1,r,g,b,a);vert(o+3,x-ax+bx,y-ay+by,z-az+bz,0,1,r,g,b,a);nq++;}

  /* estela de una bala enemiga de a hasta b. La cabeza recorre el camino y la cola la sigue: se ve de dónde vino. */
  function trazadora(a,b,tipo){
    if(!a||!b)return;const k=TR[tipo]||TR.fusil,z=tz[iT];iT=(iT+1)%NT;
    z.on=true;z.ax=a.x;z.ay=a.y;z.az=a.z;z.bx=b.x;z.by=b.y;z.bz=b.z;z.t=0;z.vida=k.vida;z.ancho=k.ancho;z.r=k.col[0];z.g=k.col[1];z.b=k.col[2];z.brillo=k.brillo;z.rastro=k.rastro;hay=true;
    const q=recientes[iR];iR=(iR+1)%recientes.length;q.ax=a.x;q.az=a.z;q.bx=b.x;q.bz=b.z;q.t=T;q.tipo=tipo||'fusil';
    /* ¿pasó cerca de la cabeza del jugador? Punto del segmento más cercano a la cámara */
    const c=camera.position,dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,L2=dx*dx+dy*dy+dz*dz;if(L2<1)return;
    const ox=c.x-a.x,oy=c.y-a.y,oz=c.z-a.z;if(ox*ox+oy*oy+oz*oz<SILBA_MIN*SILBA_MIN)return;
    const u=clamp((ox*dx+oy*dy+oz*dz)/L2,0,1),L=Math.sqrt(L2);
    if(u*L<1||(1-u)*L<.6)return;                 // si termina ahí mismo no pasó de largo: es un impacto (o le pegó al jugador)
    const px=a.x+dx*u-c.x,py=a.y+dy*u-c.y,pz=a.z+dz*u-c.z,dist=Math.sqrt(px*px+py*py+pz*pz);
    if(dist<SILBA)UESND.silbido(clamp((px*Math.cos(P.yaw)-pz*Math.sin(P.yaw))/Math.max(.25,dist),-1,1));}

  /* fy: el piso bajo el impacto (desde la 1.15 la calzada está a −0,15 y la vereda a 0): se calcula una vez por impacto, no por cuadro */
  function chispa(p,vx,vy,vz,vida,k,fy){const c=ch[iC];iC=(iC+1)%NC;c.on=true;c.x=p.x;c.y=p.y;c.z=p.z;c.vx=vx;c.vy=vy;c.vz=vz;c.t=0;c.vida=vida;c.k=k;c.fy=fy;hay=true;}
  function destello(p,tam,vida,r,g,b){const d=ds[iD];iD=(iD+1)%ND;d.on=true;d.x=p.x;d.y=p.y;d.z=p.z;d.t=0;d.vida=vida;d.tam=tam;d.r=r;d.g=g;d.b=b;hay=true;}
  function polvo(p,vx,vy,vz,t0,t1,vida,r,g,b,a){const q=pv[iP];iP=(iP+1)%NP;q.on=true;q.x=p.x;q.y=p.y;q.z=p.z;q.vx=vx;q.vy=vy;q.vz=vz;q.t=0;q.vida=vida;q.t0=t0;q.t1=t1;q.r=r;q.g=g;q.b=b;q.a=a;hay=true;}

  /* impacto de una bala. n: normal (Vector3) o null. mat: 'metal' chispas · 'pared' y 'piso' polvo y cascotes ·
     'carne' es un bicho (salpica verde, como las balas del jugador). Para un soldado herido usar sangre(). */
  function impacto(p,n,mat){
    if(!p)return;const c=camera.position,d=Math.sqrt((p.x-c.x)**2+(p.y-c.y)**2+(p.z-c.z)**2);if(d>180)return;
    const lejos=d>70;
    if(n){_n.x=n.x;_n.y=n.y;_n.z=n.z;}
    else if(mat==='piso'){_n.x=0;_n.y=1;_n.z=0;}
    else{const h=Math.hypot(c.x-p.x,c.z-p.z)||1;_n.x=(c.x-p.x)/h*.8;_n.y=.6;_n.z=(c.z-p.z)/h*.8;}   // sin normal: hacia la cámara y un poco arriba
    if(mat==='metal'){
      const k=lejos?2:6,fy=floorAt(p.x,p.z);for(let i=0;i<k;i++){const s=rand(3,9);chispa(p,_n.x*s+rand(-3,3),_n.y*s+rand(-1,4),_n.z*s+rand(-3,3),rand(.14,.38),rand(.7,1.3),fy);}
      destello(p,lejos?.3:.22,.06,1,.85,.55);}
    else if(mat==='carne'){if(!lejos)for(let i=0;i<3;i++){_vl.x=_n.x*2+rand(-2,2);_vl.y=rand(1,4);_vl.z=_n.z*2+rand(-2,2);spawnPart(p,_vl,rand(.04,.09),pick(GOO),rand(.8,1.8));}}
    else{
      const piso=mat==='piso',g=piso?.3:.52;   // el asfalto levanta polvo más oscuro que el revoque
      polvo(p,_n.x*rand(.6,1.4),_n.y*rand(.6,1.4)+.25,_n.z*rand(.6,1.4),.1,rand(.45,.7),rand(.5,.8),g,g*.96,g*.88,.34);
      if(!lejos){const k=piso?1:2;for(let i=0;i<k;i++){_vl.x=_n.x*2+rand(-2,2);_vl.y=rand(1,3.4);_vl.z=_n.z*2+rand(-2,2);spawnPart(p,_vl,rand(.03,.06),piso?'#6a6a70':'#cfc8b8',rand(.4,.9));}
        if(Math.random()<.35)chispa(p,_n.x*4+rand(-2,2),rand(1,4),_n.z*4+rand(-2,2),rand(.1,.2),.7,floorAt(p.x,p.z));}}
    if(d<UESND.CFG.alcImpacto)UESND.impacto(p,mat);}

  /* soldado herido: salpicadura chica, roja y oscura, hacia donde iba la bala. dir: Vector3 o null */
  function sangre(p,dir){
    if(!p)return;const c=camera.position;if((p.x-c.x)**2+(p.z-c.z)**2>120*120)return;
    let dx=0,dz=0;if(dir){dx=dir.x;dz=dir.z;}else{const a=rand(0,6.283);dx=Math.cos(a)*.5;dz=Math.sin(a)*.5;}
    for(let i=0;i<5;i++){const s=rand(1,3.5);_vl.x=dx*s+rand(-1.1,1.1);_vl.y=rand(.4,2.6);_vl.z=dz*s+rand(-1.1,1.1);spawnPart(p,_vl,rand(.025,.055),pick(ROJOS),rand(.8,1.6));}
    polvo(p,dx*1.3,.3,dz*1.3,.1,.42,.34,.36,.02,.04,.55);
    if(p.y<2.2&&Math.random()<.4)addDecal(p.x+dx*rand(.3,.9),p.z+dz*rand(.3,.9),rand(.35,.7),'#3a0509');}

  function update(dt){
    if(!hay){if(geo.drawRange.count)geo.setDrawRange(0,0);return;}
    const c=camera.position,q=camera.quaternion;cx=c.x;cy=c.y;cz=c.z;
    _a.set(1,0,0).applyQuaternion(q);rx=_a.x;ry=_a.y;rz=_a.z;_a.set(0,1,0).applyQuaternion(q);ux=_a.x;uy=_a.y;uz=_a.z;
    WP=1.6*2*Math.tan(camera.fov*Math.PI/360)/Math.max(240,renderer.domElement.height);   // 1,6 píxeles, en metros por metro de distancia
    nq=0;let viv=0;
    /* 1 · polvo y niebla de sangre (tapan): primero, así lo que brilla queda encima */
    for(let i=0;i<NP;i++){const p=pv[i];if(!p.on)continue;p.t+=dt;if(p.t>=p.vida){p.on=false;continue;}viv++;
      const u=p.t/p.vida,fr=Math.exp(-3*dt);p.vx*=fr;p.vy=p.vy*fr+.25*dt;p.vz*=fr;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;
      const al=p.a*Math.min(1,u*8)*Math.pow(1-u,1.5);cartel(p.x,p.y,p.z,p.t0+(p.t1-p.t0)*Math.sqrt(u),p.r*al,p.g*al,p.b*al,al);}
    /* 2 · chispas: rayitas que caen, rebotan en el piso y se enfrían de blanco a naranja */
    for(let i=0;i<NC;i++){const s=ch[i];if(!s.on)continue;s.t+=dt;if(s.t>=s.vida){s.on=false;continue;}viv++;
      s.vy-=14*dt;s.x+=s.vx*dt;s.y+=s.vy*dt;s.z+=s.vz*dt;if(s.y<s.fy+.02&&s.vy<0){s.y=s.fy+.02;s.vy*=-.35;s.vx*=.6;s.vz*=.6;}
      const k=1-s.t/s.vida,b=k*k*2.2*s.k,e=.022;tira(s.x-s.vx*e,s.y-s.vy*e,s.z-s.vz*e,s.x,s.y,s.z,.55,1,.5+.42*k,.15+.6*k*k,b*.3,b);}
    /* 3 · destellos de impacto */
    for(let i=0;i<ND;i++){const d=ds[i];if(!d.on)continue;d.t+=dt;if(d.t>=d.vida){d.on=false;continue;}viv++;
      const k=1-d.t/d.vida;cartel(d.x,d.y,d.z,d.tam*(.6+.4*k),d.r*k,d.g*k,d.b*k,0);}
    /* 4 · trazadoras: la cabeza llega al 60 % de la vida; la cola sale al 30 % y llega al final */
    for(let i=0;i<NT;i++){const z=tz[i];if(!z.on)continue;z.t+=dt;if(z.t>=z.vida+z.rastro){z.on=false;continue;}viv++;
      const dx=z.bx-z.ax,dy=z.by-z.ay,dz=z.bz-z.az;
      if(z.rastro>0){const u=z.t/(z.vida+z.rastro),hp=Math.min(1,z.t/(z.vida*.6)),ke=.26*z.brillo*(1-u)*(1-u);   // el tiro del tirador deja la línea marcada un momento
        tira(z.ax,z.ay,z.az,z.ax+dx*hp,z.ay+dy*hp,z.az+dz*hp,z.ancho*.55,z.r,z.g*.8,z.b*.7,ke,ke);}
      if(z.t<z.vida){const hp=Math.min(1,z.t/(z.vida*.6)),tp=clamp((z.t-z.vida*.3)/(z.vida*.7),0,1),k=z.brillo*Math.min(1,(z.vida-z.t)/(z.vida*.3));
        let hx=z.ax+dx*hp,hy=z.ay+dy*hp,hz=z.az+dz*hp;const tx=z.ax+dx*tp,ty=z.ay+dy*tp,tzz=z.az+dz*tp;
        const dc=Math.sqrt((hx-cx)**2+(hy-cy)**2+(hz-cz)**2);
        if(dc<.7){const L=Math.sqrt(dx*dx+dy*dy+dz*dz)||1,r=Math.min(.7-dc,hp*L-tp*L)/L;hx-=dx*r;hy-=dy*r;hz-=dz*r;}   // la punta no se mete adentro de la cámara
        tira(tx,ty,tzz,hx,hy,hz,z.ancho,z.r,z.g,z.b,k*.12,k);
        const dh=Math.sqrt((hx-cx)**2+(hy-cy)**2+(hz-cz)**2);
        cartel(hx,hy,hz,Math.max(WP*dh,Math.min(W0,.012*dh))*z.ancho*2.6,z.r*k*.8,z.g*k*.8,z.b*k*.8,0);}}
    geo.setDrawRange(0,nq*6);aPos.needsUpdate=true;aUv.needsUpdate=true;aCol.needsUpdate=true;hay=viv>0;}

  function reset(){for(const l of [tz,ch,ds,pv])for(const o of l)o.on=false;for(const r of recientes)r.t=-9;hay=false;nq=0;geo.setDrawRange(0,0);}
  return{trazadora,impacto,sangre,update,reset,recientes,TR,malla,get vivos(){return nq;}};
})();

/* ---------- UEHUD: radio interceptada, detección, dirección del daño y aviso de granada ---------- */
const UEHUD=(()=>{
  const caja=$('#ueRadio'),svg=$('#ueRet');
  const SVGNS='http://www.w3.org/2000/svg';
  const mk=(tag,attrs,padre)=>{const e=document.createElementNS(SVGNS,tag);for(const k in attrs)e.setAttribute(k,attrs[k]);if(padre)padre.appendChild(e);return e;};
  /* escrituras al DOM solo cuando el valor cambia: todo se recalcula cada cuadro, pero si no se toca nada
     el navegador no recalcula estilos ni repinta el SVG (el valor anterior queda guardado en el propio elemento) */
  const css=(el,k,v)=>{const c='_c'+k;if(el[c]!==v){el[c]=v;el.style[k]=v;}};
  const att=(el,k,v)=>{const c='_a'+k;if(el[c]!==v){el[c]=v;el.setAttribute(k,v);}};
  const vuelta=a=>Math.atan2(Math.sin(a),Math.cos(a));               // ángulo a −π…π
  /* ángulo de un punto del mundo respecto de adonde mira el jugador: 0 adelante, + a la derecha */
  const angulo=(x,z)=>{const dx=x-P.pos.x,dz=z-P.pos.z,sy=Math.sin(P.yaw),cy=Math.cos(P.yaw);return Math.atan2(dx*cy-dz*sy,-dx*sy-dz*cy);};

  /* ===== radio interceptada: hasta 3 renglones, el más nuevo abajo ===== */
  /* frases de peligro (resaltadas): las que piden que el jugador haga algo YA. «Está recargando. ¡Voy!» también:
     el asalto se le viene encima. «¡Granada! ¡Al piso!» no: es la granada del jugador, el peligro es para ellos */
  const PELIGRO_CLAVE={granada:1,tirador_mira:1,auto_fuego:1,recarga_jugador:1},PELIGRO_TXT=/granada va|en la mira|va a volar|está recargando/i;
  const lineas=[];
  /* quien: 'Ceniza 2' · texto: la frase · clave (opcional): la clave de la sección 9; si no viene, el peligro se deduce del texto */
  function radio(quien,texto,clave){
    if(!caja||!texto)return;
    if(quien&&typeof quien==='object')quien=quien.nombre||'';
    const pel=clave!==undefined&&clave!==null?!!PELIGRO_CLAVE[clave]||clave===true:PELIGRO_TXT.test(texto);
    const el=document.createElement('div');el.className='ue-rl'+(pel?' pel':'');
    if(quien){const b=document.createElement('b');b.textContent=String(quien).toUpperCase();el.appendChild(b);}
    el.appendChild(document.createTextNode(String(texto)));caja.appendChild(el);
    lineas.push({el,t:clamp(1.3+String(texto).length*.055,2.2,6),f:0,sale:false});
    while(lineas.length>3)lineas.shift().el.remove();
    caja.classList.add('on');}
  function updRadio(dt){
    for(let i=lineas.length-1;i>=0;i--){const l=lineas[i];
      if(l.f<2){if(++l.f===2)l.el.classList.add('in');}          // un cuadro después de crearlo, para que la entrada se anime
      l.t-=dt;if(l.t<=0&&!l.sale){l.sale=true;l.el.classList.add('out');}
      if(l.t<-.4){l.el.remove();lineas.splice(i,1);}}
    if(!lineas.length)caja.classList.remove('on');}

  /* ===== indicador de detección: un arco alrededor de la mira que se llena y apunta a quien te está viendo ===== */
  const R_DET=27,ARCO=1.92;                                           // radio en unidades del SVG y abertura total (110°)
  const HUESO=[239,230,210],ROJO=[255,74,58];
  let det=null,dPista,dPistaB,dRell,dRellB,dPunta,dAni,dAniB,dTxt;
  let aNivel=0,aRumbo=null,aComb=false,vNivel=0,vAng=0,vRojo=0,vistoT=0,armado=true,calmaT=0,combT=0,detOn=false;
  const arco=h=>{const s=Math.sin(h)*R_DET,c=-Math.cos(h)*R_DET;return 'M'+(-s).toFixed(2)+' '+c.toFixed(2)+'A'+R_DET+' '+R_DET+' 0 0 1 '+s.toFixed(2)+' '+c.toFixed(2);};
  if(svg){
    det=mk('g',{id:'ueDet'},svg);det.style.display='none';
    dPistaB=mk('path',{class:'b',d:arco(ARCO/2),'stroke-width':3.4},det);dPista=mk('path',{class:'pista',d:arco(ARCO/2),'stroke-width':1.3},det);
    dRellB=mk('path',{class:'b','stroke-width':4.6},det);dRell=mk('path',{class:'rell','stroke-width':2.6},det);
    dPunta=mk('path',{class:'punta',d:'M0 -36.6l-3 4.6h6z'},det);
    dAniB=mk('circle',{class:'b',r:R_DET,'stroke-width':4.6},det);dAni=mk('circle',{class:'rell',r:R_DET,'stroke-width':2.6},det);
    dTxt=mk('text',{id:'ueVisto',y:47},svg);dTxt.textContent='TE VIERON';dTxt.style.display='none';}
  /* nivel 0…1 · ang: rad respecto de adonde mira el jugador (0 adelante, + derecha) o null · combate: ya te vieron.
     El ángulo se guarda como rumbo en el mundo: si el jugador gira, el arco sigue apuntando al mismo lugar aunque no lo vuelvan a llamar. */
  function alerta(nivel,ang,combate){aNivel=clamp(+nivel||0,0,1);aComb=!!combate;aRumbo=(ang===null||ang===undefined||isNaN(ang))?null:ang-P.yaw;}
  function updDet(dt){
    const lleno=aComb||aNivel>=.995,obj=lleno?1:aNivel;
    if(lleno){calmaT=0;combT+=dt;if(armado){armado=false;vistoT=1.9;}}
    else{combT=0;if(aNivel<.05){calmaT+=dt;if(calmaT>3)armado=true;}else calmaT=0;}   // se rearma si pasan 3 s sin que nadie sospeche
    vNivel+=(obj-vNivel)*(1-Math.exp(-dt*(obj>vNivel?12:5)));if(Math.abs(obj-vNivel)<.002)vNivel=obj;
    vRojo+=((lleno?1:0)-vRojo)*(1-Math.exp(-dt*10));
    if(vistoT>0){vistoT-=dt;css(dTxt,'display',vistoT>0?'':'none');css(dTxt,'opacity',Math.min(1,vistoT*2.5,(1.9-vistoT)*9).toFixed(2));}
    if(vNivel<.004){if(detOn){detOn=false;css(det,'display','none');}return;}
    if(!detOn){detOn=true;css(det,'display','');if(aRumbo!==null)vAng=aRumbo+P.yaw;}   // al aparecer, ya apuntando: sin barrido desde un ángulo viejo
    const dir=aRumbo!==null,vd=dir?'':'none',va=dir?'none':'';
    if(dir){vAng+=vuelta(aRumbo+P.yaw-vAng)*(1-Math.exp(-dt*16));att(det,'transform','rotate('+(vAng*57.29578).toFixed(1)+')');}
    else att(det,'transform','');
    css(dPista,'display',vd);css(dPistaB,'display',vd);css(dRell,'display',vd);css(dRellB,'display',vd);css(dPunta,'display',vd);css(dAni,'display',va);css(dAniB,'display',va);
    if(dir){const d=arco(Math.max(.02,ARCO/2*vNivel));att(dRell,'d',d);att(dRellB,'d',d);}
    else{const seg=2*Math.PI*R_DET/16,on=seg*.72*vNivel,d=on.toFixed(2)+' '+(seg-on).toFixed(2);   // sin dirección: anillo de 16 rayitas que se van completando
      att(dAni,'stroke-dasharray',d);att(dAniB,'stroke-dasharray',d);}
    const k=vRojo;css(det,'color','rgb('+Math.round(HUESO[0]+(ROJO[0]-HUESO[0])*k)+','+Math.round(HUESO[1]+(ROJO[1]-HUESO[1])*k)+','+Math.round(HUESO[2]+(ROJO[2]-HUESO[2])*k)+')');
    /* en combate el arco queda, pero a los 2,5 s baja de intensidad para no molestar al apuntar */
    css(det,'opacity',(lleno?(combT<2.5?1:Math.max(.55,1-(combT-2.5)*.6)):.45+.55*vNivel).toFixed(2));}

  /* ===== dirección del daño: cuñas rojas sobre un círculo alrededor de la mira ===== */
  const VIDA_G=.8,cunas=[];
  if(svg){const gg=mk('g',{id:'ueGolpes'},svg);
    for(let i=0;i<6;i++){const el=mk('path',{class:'cuna',d:'M-19.3 -63.1A66 66 0 0 1 19.3 -63.1Q0 -87 -19.3 -63.1Z'},gg);el.style.display='none';cunas.push({el,t:0,rumbo:0});}}
  /* ang: de dónde vino el daño, en rad respecto de adonde mira el jugador (0 adelante, + derecha) */
  function golpe(ang){
    if(!svg||ang===null||ang===undefined||isNaN(ang))return;const rumbo=ang-P.yaw;let libre=null,vieja=null;
    for(const w of cunas){if(w.t>0){if(Math.abs(vuelta(w.rumbo-rumbo))<.35){w.t=VIDA_G;w.rumbo=rumbo;return;}if(!vieja||w.t<vieja.t)vieja=w;}else if(!libre)libre=w;}
    const w=libre||vieja;w.t=VIDA_G;w.rumbo=rumbo;css(w.el,'display','');}
  const golpeDesde=(x,z)=>golpe(angulo(x,z));
  function updGolpes(dt){for(const w of cunas){if(w.t<=0)continue;w.t-=dt;if(w.t<=0){css(w.el,'display','none');continue;}
    att(w.el,'transform','rotate('+((w.rumbo+P.yaw)*57.29578).toFixed(1)+')');css(w.el,'opacity',Math.min(1,w.t/VIDA_G*1.7).toFixed(2));}}

  /* ===== aviso de granada: ícono, flecha y metros, del lado en que está; parpadea más rápido cuanto menos falta ===== */
  const R_GR=88,D_AVISO=12,D_LETAL=7,avisos=[];
  if(svg){const gg=mk('g',{id:'ueGranadas'},svg);
    for(let i=0;i<3;i++){const g=mk('g',{class:'gr'},gg);g.style.display='none';
      const fl=mk('g',{},g);mk('path',{class:'fl',d:'M0 -113l-6.5 8.5h13z'},fl);   // la punta queda afuera del círculo del ícono (r 88+11,5)
      const ic=mk('g',{},g);
      mk('circle',{class:'fondo',r:11.5},ic);
      mk('path',{class:'ic',d:'M-4.6 -1.2a4.9 5.6 0 1 0 9.2 0l-1.4 -2.1h-6.4zM-2.3 -6.4h4.6v2.6h-4.6zM2.3 -6.1l4.4 3.3'},ic);   // cuerpo, cuello y palanca
      const tx=mk('text',{y:21.5},ic);
      avisos.push({g,fl,ic,tx,fase:0,ult:''});}}
  function updGranadas(dt){
    let n=0;
    if(typeof GRAN!=='undefined'&&GRAN&&GRAN.lista&&GRAN.lista.length){
      const sy=Math.sin(P.yaw),cy=Math.cos(P.yaw);
      for(const gr of GRAN.lista){if(n>=avisos.length)break;if(!gr||!gr.p||gr.tipo==='humo')continue;
        const dx=gr.p.x-P.pos.x,dz=gr.p.z-P.pos.z,d=Math.hypot(dx,dz);if(d>D_AVISO)continue;
        if(gr.de==='jugador'&&gr.v&&gr.v.x*dx+gr.v.z*dz>2*d)continue;      // la propia no se avisa mientras se aleja: recién si rebota o queda cerca
        const a=avisos[n++],cerca=d<1.2,rel=cerca?Math.PI:Math.atan2(dx*cy-dz*sy,-dx*sy-dz*cy),falta=gr.t===undefined?1.5:gr.t;
        css(a.g,'display','');a.fase+=dt*clamp(2.2+7*(1-falta/3),2.2,9.5);
        css(a.g,'opacity',(a.fase%1)<.6?'1':'.38');
        att(a.g,'class',d<=D_LETAL+.3?'gr letal':'gr');
        att(a.fl,'transform','rotate('+(rel*57.29578).toFixed(1)+')');css(a.fl,'display',cerca?'none':'');
        att(a.ic,'transform','translate('+(Math.sin(rel)*R_GR).toFixed(1)+' '+(-Math.cos(rel)*R_GR).toFixed(1)+')');
        const s=cerca?'A TUS PIES':Math.max(1,Math.round(d))+' m';if(s!==a.ult){a.ult=s;a.tx.textContent=s;}}}
    for(let i=n;i<avisos.length;i++){const a=avisos[i];if(a.g._cdisplay!=='none'){css(a.g,'display','none');a.fase=0;}}}

  /* ===== cada cuadro ===== */
  const estadoVacio=UEB.estado;
  function update(dt){
    if(caja&&lineas.length)updRadio(dt);
    if(!svg)return;
    /* si el integrador llenó UEB.estado, se lee solo. Entiende la forma de la SPEC 4.1 ({alerta,ang,combate}) y también la que
       devuelve UE.estado() de la IA ({sospecha,x,z,combate}: x,z es el soldado que más sospecha; de ahí sale el ángulo) */
    if(UEB.estado!==estadoVacio){const e=UEB.estado();
      if(e){if(e.alerta!==undefined)alerta(e.alerta,e.ang,e.combate);else if(e.sospecha!==undefined)alerta(e.sospecha,e.sospecha>0&&isFinite(e.x)?angulo(e.x,e.z):null,e.combate);}}
    if(aNivel>0||aComb||vNivel>0||vistoT>0||!armado)updDet(dt);
    updGolpes(dt);updGranadas(dt);}
  function reset(){
    for(const l of lineas)l.el.remove();lineas.length=0;if(caja)caja.classList.remove('on');
    aNivel=0;aRumbo=null;aComb=false;vNivel=0;vRojo=0;vistoT=0;armado=true;calmaT=0;combT=0;detOn=false;
    if(svg){css(det,'display','none');css(dTxt,'display','none');for(const w of cunas){w.t=0;css(w.el,'display','none');}for(const a of avisos){css(a.g,'display','none');a.fase=0;}}}
  return{radio,alerta,golpe,golpeDesde,angulo,update,reset};
})();

/* ---------- UEDBG: vista táctica (F2). Para ver qué sabe y qué decide el escuadrón ---------- */
const UEDBG=(()=>{
  const raiz=$('#ueTac');
  if(!raiz)return{tecla(){},update(){},poner(){},modo:0};
  const cv=raiz.querySelector('canvas'),g=cv.getContext('2d'),tx=raiz.querySelector('.ue-tx'),cab=raiz.querySelector('.ue-cab span');
  const RADIO=[0,70,110];                 // metros que se ven hacia cada lado: apagada · chica · grande
  const CADA=1/15;                        // se redibuja 15 veces por segundo: sobra para leerla y casi no cuesta
  const COL={jefe:'#ffa23a',asalto:'#b792ff',granadero:'#a6e22e',tirador:'#5fd4ff'},GRIS='#8d8d94',HUESO='#efe6d2',AMARILLO='#ffe14a',ROJO='#ff4a3a';
  /* el estado de cada soldado y de cada escuadrón, dicho en palabras */
  const EST={puesto:'en su puesto',ronda:'de ronda',alerta:'alerta',revisar:'va a mirar',a_cubierto:'corre a cubrirse',cubierto:'cubierto',asomado:'asomado, tira',
    suprimir:'tira al último lugar',avanzar:'avanza',flanquear:'flanquea',recargar:'recarga',lanzar:'lanza granada',tierra:'cuerpo a tierra',replegar:'se repliega',
    esquivar:'esquiva',culata:'culatazo',buscar:'busca',aturdido:'aturdido',radio:'pide refuerzo',muerto:'muerto',
    bicho:'pelea con bichos',llegando:'llega',volver:'vuelve a su puesto'};
  /* en la vista chica el lienzo mide ~340 px: cada soldado lleva una o dos palabras */
  const EST_C={puesto:'puesto',ronda:'ronda',alerta:'alerta',revisar:'revisa',a_cubierto:'a cubierto',cubierto:'cubierto',asomado:'tira',suprimir:'suprime',avanzar:'avanza',
    flanquear:'flanquea',recargar:'recarga',lanzar:'granada',tierra:'a tierra',replegar:'repliega',esquivar:'esquiva',culata:'culata',buscar:'busca',aturdido:'aturdido',
    radio:'radio',muerto:'muerto',bicho:'bichos',llegando:'llega',volver:'vuelve'};
  const ESC={guardia:['EN GUARDIA','no saben que estás'],sospecha:['SOSPECHAN','vieron u oyeron algo'],combate:['EN COMBATE',''],busqueda:['TE BUSCAN','te perdieron y barren la zona']};
  /* órdenes del escuadrón: las palabras clave de la IA (ue_ia.js) y algunas genéricas. Lo que no está acá se muestra tal cual
     (la IA ya escribe algunas en castellano: «granada (…)», «avance sobre el lugar viejo», «sin lugar conocido»…) */
  const ORD={fijar:'fijarte con fuego',flanquear:'flanquear',flanco_izq:'flanquear por izquierda',flanco_der:'flanquear por derecha',replegar:'replegarse',refuerzo:'pedir refuerzo',
    buscar:'barrer la zona',aguantar:'aguantar la posición',avanzar:'avanzar',empujar:'empujar: estás recargando',granada:'sacarte con granada',suprimir:'tirar al último lugar conocido',
    barrido:'barrer la zona',combate:'combatir',desorden:'ninguna: sin jefe, cada uno por su cuenta',empuje:'empujar: estás recargando',llegando:'llegar al retén',
    repliegue:'replegarse','base de fuego':'base de fuego: te fijan mientras otro se mueve','flanqueo der':'rodearte por la derecha','flanqueo izq':'rodearte por la izquierda'};
  const palabra=(tabla,k)=>k===undefined||k===null||k===''?'':(tabla[k]||String(k).replace(/_/g,' '));
  const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const corto=n=>{n=String(n||'?');const m=n.match(/(\d+)\s*$/);return m?n[0].toUpperCase()+m[1]:n.slice(0,3).toUpperCase();};   // «Ceniza 2» → C2
  const muerto=s=>s.estado==='muerto'||s.hp<=0;

  let modo=0;try{modo=+localStorage.getItem('obelisco-ue-tac')||0;}catch(e){}if(modo!==1&&modo!==2)modo=0;
  let acc=1,lado=0,dpr=1,ultTx='',txN=0;
  /* fondo: la grilla de navegación alrededor del jugador, un píxel por metro. Se rehace cuando el jugador se movió
     más de 10 m, cuando cambia el tamaño o cada 3 s (por si explotó un auto y cambió la grilla) */
  const fondo=document.createElement('canvas'),fg=fondo.getContext('2d');let fImg=null,fPx=null,fX=0,fZ=0,fL=0,fT=-9,fCx=1e9,fCz=1e9;
  const C_LIBRE=0xff2e2a27,C_MURO=0xff14100e,C_COB=0xff2c6c96,C_BAJO=0xff304a5c;   // ABGR: calle · edificio · cobertura (1 m o más) · obstáculo bajo
  function hacerFondo(R){
    const m=Math.ceil(R)+14,L=m*2;if(fL!==L){fondo.width=fondo.height=L;fImg=fg.createImageData(L,L);fPx=new Uint32Array(fImg.data.buffer);fL=L;}
    const x0=Math.floor(P.pos.x)-m,z0=Math.floor(P.pos.z)-m,i0=Math.floor(x0+.5-EX0),j0=Math.floor(z0+.5-EZ0);   // lo mismo que eCell(x0+i+.5,z0+j+.5), fila por fila
    for(let j=0;j<L;j++){const jj=j0+j,f=j*L;if(jj<0||jj>=EH){fPx.fill(C_MURO,f,f+L);continue;}const base=jj*EW;
      for(let i=0;i<L;i++){const ii=i0+i;if(ii<0||ii>=EW){fPx[f+i]=C_MURO;continue;}const k=base+ii,b=enB[k];fPx[f+i]=b===0?C_LIBRE:b===2?C_MURO:enH[k]>=10?C_COB:C_BAJO;}}
    fg.putImageData(fImg,0,0);fX=x0;fZ=z0;fT=T;fCx=P.pos.x;fCz=P.pos.z;}

  function poner(m){
    modo=m;try{localStorage.setItem('obelisco-ue-tac',String(m));}catch(e){}
    raiz.hidden=!m;raiz.classList.toggle('gr',m===2);document.body.classList.toggle('ue-tac',m===1);
    lado=0;acc=1;ultTx='';if(m)dibujar();}
  /* F2 prende y apaga · Shift+F2 cambia entre chica y grande (y la prende si estaba apagada) */
  function tecla(e){
    if(e.code!=='F2')return;e.preventDefault();if(e.repeat)return;
    if(e.shiftKey){if(running&&!paused)MOV.toggleRun();   // el Shift ya había cambiado correr/caminar: se deshace
      poner(modo===2?1:2);}
    else poner(modo?0:1);}

  /* --- dibujo --- */
  let PM=1,AN=0,px=0,pz=0;const cajas=[],rotulos=[];
  const mx=x=>AN/2+(x-px)*PM,my=z=>AN/2+(z-pz)*PM;
  function libre(x,y,w,h){if(x<2||y<2||x+w>AN-2||y+h>AN-2)return false;for(const c of cajas)if(x<c[0]+c[2]&&x+w>c[0]&&y<c[1]+c[3]&&y+h>c[1])return false;return true;}
  function rotulo(x,y,str,color,opcional){rotulos.push([x,y,str,color,!!opcional]);}
  /* dónde probar cada rótulo, en orden: x = x + a + b·ancho · y = y + c + d·alto (a la derecha, a la izquierda, arriba, abajo y más lejos) */
  const LUG=[[9,0,0,-.5],[-9,-1,0,-.5],[0,-.5,-10,-1],[0,-.5,10,0],[9,0,-3,-1],[9,0,3,0],[-9,-1,-3,-1],[-9,-1,3,0],[16,0,0,-1.9],[16,0,0,.9],[-16,-1,0,-1.9],[-16,-1,0,.9],
    [9,0,0,-2.8],[9,0,0,1.8],[-9,-1,0,-2.8],[-9,-1,0,1.8]];
  function ponerRotulos(fs){
    g.font='600 '+fs+'px "Chakra Petch",ui-monospace,Menlo,Consolas,monospace';g.textBaseline='middle';
    for(const [x,y,str,color,opc] of rotulos){const w=g.measureText(str).width+7,h=fs+5;let cx=0,cy=0,ok=false;
      for(const q of LUG){cx=x+q[0]+q[1]*w;cy=y+q[2]+q[3]*h;if(libre(cx,cy,w,h)){ok=true;break;}}
      if(!ok){if(opc)continue;cx=clamp(x+9,2,AN-w-2);cy=clamp(y-h/2,2,AN-h-2);}   // los obligatorios (granada, último lugar conocido) van igual
      cajas.push([cx,cy,w,h]);g.fillStyle='rgba(8,9,11,.82)';g.fillRect(cx,cy,w,h);g.fillStyle=color;g.fillText(str,cx+3.5,cy+h/2+.5);}}
  function flechaBorde(x,y,color,str,opcional){   // lo que queda fuera del mapa se marca en el borde, hacia donde está
    const dx=x-AN/2,dy=y-AN/2,k=(AN/2-9)/Math.max(Math.abs(dx),Math.abs(dy)),bx=AN/2+dx*k,by=AN/2+dy*k,a=Math.atan2(dy,dx);
    g.save();g.translate(bx,by);g.rotate(a);g.fillStyle=color;g.strokeStyle='#000';g.lineWidth=1;g.beginPath();g.moveTo(7,0);g.lineTo(-4,-5);g.lineTo(-4,5);g.closePath();g.fill();g.stroke();g.restore();
    cajas.push([bx-7,by-7,14,14]);rotulo(bx-dx/Math.hypot(dx,dy)*4,by-dy/Math.hypot(dx,dy)*4,str,color,opcional);}
  const dentro=(x,y)=>x>4&&y>4&&x<AN-4&&y<AN-4;

  function dibujar(){
    /* el ancho del lienzo se lee del DOM solo al prender, al cambiar de tamaño o de ventana: leerlo cada vez obliga al navegador a recalcular el diseño */
    const R=RADIO[modo],grande=modo===2;let w=lado;if(!w){w=cv.clientWidth;if(!w)return;}
    const d0=Math.min(window.devicePixelRatio||1,grande?1.5:2);
    if(w!==lado||d0!==dpr){lado=w;dpr=d0;cv.width=cv.height=Math.round(w*dpr);}
    let D=null,falla='';try{D=UEB.debug();}catch(e){falla=String(e&&e.message||e);}
    AN=lado;PM=AN/(2*R);px=D&&D.jugador?D.jugador.x:P.pos.x;pz=D&&D.jugador?D.jugador.z:P.pos.z;
    const fs=grande?12:10,rs=grande?6.5:5;
    if(Math.abs(P.pos.x-fCx)>10||Math.abs(P.pos.z-fCz)>10||fL!==(Math.ceil(R)+14)*2||T-fT>3||T<fT)hacerFondo(R);
    g.setTransform(dpr,0,0,dpr,0,0);g.fillStyle='#0e1014';g.fillRect(0,0,AN,AN);
    g.imageSmoothingEnabled=false;g.drawImage(fondo,mx(fX),my(fZ),fL*PM,fL*PM);
    cajas.length=0;rotulos.length=0;g.lineCap='round';g.lineJoin='round';
    /* anillos de distancia cada 25 m: para juzgar a cuánto te detectan */
    g.font='600 '+(fs-1)+'px "Chakra Petch",ui-monospace,Menlo,Consolas,monospace';g.textBaseline='middle';g.textAlign='center';
    for(let m=25;m<R*1.42;m+=25){g.strokeStyle='rgba(239,230,210,.13)';g.lineWidth=1;g.beginPath();g.arc(AN/2,AN/2,m*PM,0,6.2832);g.stroke();
      if(m<R){g.fillStyle='rgba(239,230,210,.4)';g.fillText(m+' m',AN/2,AN/2-m*PM-(fs-1)*.5-1);}}
    g.fillStyle='rgba(255,162,58,.9)';g.fillText('N',AN/2,fs*.5+3);g.textAlign='left';
    if(D){
      /* zonas iluminadas por los reflectores del retén: ahí te ven desde más lejos */
      if(typeof RETEN!=='undefined'&&RETEN&&RETEN.datos&&RETEN.datos.luz){g.fillStyle='rgba(255,225,74,.07)';g.strokeStyle='rgba(255,225,74,.25)';g.lineWidth=1;g.setLineDash([3,3]);
        for(const z of RETEN.datos.luz){g.fillRect(mx(z.x0),my(z.z0),(z.x1-z.x0)*PM,(z.z1-z.z0)*PM);g.strokeRect(mx(z.x0),my(z.z0),(z.x1-z.x0)*PM,(z.z1-z.z0)*PM);}g.setLineDash([]);}
      /* granadas: el círculo es hasta donde hace daño (7 m) */
      for(const q of D.granadas||[]){const x=mx(q.x),y=my(q.z);g.fillStyle='rgba(255,74,58,.14)';g.strokeStyle=ROJO;g.lineWidth=1.2;g.beginPath();g.arc(x,y,7*PM,0,6.2832);g.fill();g.stroke();
        g.fillStyle=ROJO;g.beginPath();g.arc(x,y,2.5,0,6.2832);g.fill();if(dentro(x,y))rotulo(x,y,(grande?'granada ':'')+(+q.t||0).toFixed(1).replace('.',',')+' s',ROJO);}
      const sol=D.soldados||[];
      /* caminos y coberturas elegidas */
      for(const s of sol){if(muerto(s))continue;const c=COL[s.rol]||GRIS;
        if(s.camino&&s.camino.length){g.strokeStyle=c;g.globalAlpha=.55;g.lineWidth=1.3;g.setLineDash([4,3]);g.beginPath();g.moveTo(mx(s.x),my(s.z));for(const q of s.camino)g.lineTo(mx(q.x),my(q.z));g.stroke();g.setLineDash([]);
          const u=s.camino[s.camino.length-1];g.beginPath();g.arc(mx(u.x),my(u.z),2,0,6.2832);g.fillStyle=c;g.fill();g.globalAlpha=1;}
        if(s.cob){const x=mx(s.cob.x),y=my(s.cob.z),q=rs+1;g.strokeStyle=c;g.lineWidth=1.4;g.strokeRect(x-q,y-q,q*2,q*2);}}
      /* quién te está viendo: una línea fina hasta el jugador */
      g.strokeStyle='rgba(239,230,210,.5)';g.lineWidth=1;
      for(const s of sol)if(s.ve&&!muerto(s)){g.beginPath();g.moveTo(mx(s.x),my(s.z));g.lineTo(AN/2,AN/2);g.stroke();}
      /* el láser del tirador (si la IA lo informa): hasta dónde apunta */
      g.strokeStyle='rgba(255,40,40,.85)';g.lineWidth=1.2;
      for(const s of sol)if(s.laser&&!muerto(s)){g.beginPath();g.moveTo(mx(s.x),my(s.z));g.lineTo(mx(s.laser.x),my(s.laser.z));g.stroke();}
      /* tiros del último medio segundo */
      for(const q of UEFX.recientes){const ed=T-q.t;if(ed<0||ed>.5)continue;g.strokeStyle='rgba(255,214,150,'+(.75*(1-ed/.5)).toFixed(2)+')';g.lineWidth=q.tipo==='tirador'?2:1;g.beginPath();g.moveTo(mx(q.ax),my(q.az));g.lineTo(mx(q.bx),my(q.bz));g.stroke();}
      /* ÚLTIMO LUGAR CONOCIDO: la regla más importante. Una cruz donde el escuadrón cree que estás, y hace cuánto */
      const vistos=[],EE=grande?EST:EST_C;
      for(const e of D.escuadrones||[]){const u=e.uc;if(!u||vistos.some(v=>Math.hypot(v.x-u.x,v.z-u.z)<1.5))continue;vistos.push(u);
        const x=mx(u.x),y=my(u.z),ed=+u.edad||0,lejos=Math.hypot(u.x-px,u.z-pz),str=ed<1&&lejos<2?(grande?'TE TIENEN UBICADO':'ahora'):(grande?'CREEN QUE ESTÁS ACÁ · hace ':'hace ')+Math.round(ed)+' s';
        if(!dentro(x,y)){flechaBorde(x,y,AMARILLO,str);continue;}
        if(lejos>2){g.strokeStyle='rgba(255,225,74,.6)';g.lineWidth=1;g.setLineDash([2,3]);g.beginPath();g.moveTo(x,y);g.lineTo(AN/2,AN/2);g.stroke();g.setLineDash([]);}   // lo que separa lo que creen de la verdad
        const q=grande?9:7;for(const [lw,st] of [[5,'#000'],[2.4,AMARILLO]]){g.strokeStyle=st;g.lineWidth=lw;g.beginPath();g.moveTo(x-q,y-q);g.lineTo(x+q,y+q);g.moveTo(x+q,y-q);g.lineTo(x-q,y+q);g.stroke();}
        g.strokeStyle=AMARILLO;g.lineWidth=1.2;g.beginPath();g.arc(x,y,q*1.6,0,6.2832);g.stroke();
        cajas.push([x-q,y-q,q*2,q*2]);rotulo(x,y,str,AMARILLO);}
      /* soldados */
      for(const s of sol){const x=mx(s.x),y=my(s.z);if(dentro(x,y))cajas.push([x-rs-1,y-rs-1,rs*2+2,rs*2+2]);}
      cajas.push([AN/2-8,AN/2-8,16,16]);
      for(const s of sol){const x=mx(s.x),y=my(s.z),c=COL[s.rol]||GRIS,nom=corto(s.nombre);
        if(muerto(s)){if(!dentro(x,y))continue;g.strokeStyle=GRIS;g.lineWidth=1.6;g.beginPath();g.moveTo(x-3.5,y-3.5);g.lineTo(x+3.5,y+3.5);g.moveTo(x+3.5,y-3.5);g.lineTo(x-3.5,y+3.5);g.stroke();if(grande)rotulo(x,y,nom+' caído',GRIS);continue;}
        if(!dentro(x,y)){flechaBorde(x,y,c,grande?nom+' '+palabra(EE,s.estado):nom,!grande);continue;}
        const ru=+s.rumbo||0,fx=Math.sin(ru),fy=Math.cos(ru);
        g.strokeStyle='#000';g.lineWidth=3.6;g.beginPath();g.moveTo(x,y);g.lineTo(x+fx*rs*2.5,y+fy*rs*2.5);g.stroke();
        g.strokeStyle=c;g.lineWidth=1.9;g.beginPath();g.moveTo(x,y);g.lineTo(x+fx*rs*2.5,y+fy*rs*2.5);g.stroke();   // hacia dónde mira
        g.fillStyle=c;g.strokeStyle='#000';g.lineWidth=1.3;g.beginPath();g.arc(x,y,rs,0,6.2832);g.fill();g.stroke();
        if(s.suprimido){g.strokeStyle=HUESO;g.lineWidth=1.2;g.setLineDash([2,2.5]);g.beginPath();g.arc(x,y,rs+2.6,0,6.2832);g.stroke();g.setLineDash([]);}
        if(s.ficha){g.strokeStyle=ROJO;g.lineWidth=2.2;g.beginPath();g.arc(x,y,rs+4.6,0,6.2832);g.stroke();}   // permiso de tirar a pegar
        rotulo(x,y,nom+' '+palabra(EE,s.estado),c,!grande);}
    }
    /* el jugador de verdad: triángulo que mira hacia donde mira, con su campo de visión */
    {const fx=-Math.sin(P.yaw),fy=-Math.cos(P.yaw),x=AN/2,y=AN/2;
      g.fillStyle='rgba(239,230,210,.1)';g.beginPath();g.moveTo(x,y);g.arc(x,y,Math.min(AN*.2,45*PM),Math.atan2(fy,fx)-.65,Math.atan2(fy,fx)+.65);g.closePath();g.fill();
      g.save();g.translate(x,y);g.rotate(Math.atan2(fy,fx));g.fillStyle='#fff';g.strokeStyle='#000';g.lineWidth=1.4;g.beginPath();g.moveTo(8,0);g.lineTo(-5,-5.5);g.lineTo(-2.5,0);g.lineTo(-5,5.5);g.closePath();g.fill();g.stroke();g.restore();}
    ponerRotulos(fs);
    if(!D){g.font='700 '+(grande?20:14)+'px "Chakra Petch",ui-monospace,Menlo,Consolas,monospace';g.textAlign='center';const s=falla?'error en UEB.debug()':'sin escuadrón';
      g.fillStyle='rgba(8,9,11,.8)';const tw=g.measureText(s).width+18;g.fillRect(AN/2-tw/2,AN*.27-14,tw,28);g.fillStyle=falla?ROJO:HUESO;g.fillText(s,AN/2,AN*.27);g.textAlign='left';}
    /* texto: se arma 5 veces por segundo y solo se toca el DOM si cambió */
    if(++txN%3===1||!ultTx){const h=texto(D,falla,grande);if(h!==ultTx){ultTx=h;tx.innerHTML=h;}
      const c=grande?'norte arriba · '+R+' m · F2 cierra · Shift+F2 achica':R+' m · Shift+F2 agranda';if(cab.textContent!==c)cab.textContent=c;}
  }
  const punto=c=>'<i style="background:'+c+'"></i>';
  const nw=t=>'<span class="nw">'+t+'</span>';                         // un dato que no se corta en dos renglones
  function texto(D,falla,grande){
    let h='';
    if(falla)h+='<p class="al">'+esc(falla)+'</p>';
    if(D){const sol=D.soldados||[],escs=D.escuadrones||[];
      /* la regla 2 en una línea: qué creen y qué tan lejos está eso de la verdad */
      const ucTxt=(e,E)=>{if(!e.uc)return esc(E[1]||'No saben dónde estás.');const ed=Math.round(+e.uc.edad||0),dl=Math.round(Math.hypot(e.uc.x-px,e.uc.z-pz));
        if(ed<1&&dl<2)return 'Te tienen ubicado ahora mismo.';
        return grande?'Creen que estás donde te vieron u oyeron hace <b>'+ed+' s</b>: a <b>'+dl+' m</b> de donde estás de verdad.':'✕ Te ubican a <b>'+dl+' m</b> de donde estás · hace <b>'+ed+' s</b>';};
      const EE=escs.map(e=>ESC[e.estado]||[String(e.estado||'').toUpperCase(),'']),ucs=escs.map((e,i)=>ucTxt(e,EE[i]));
      const ucUna=!grande&&escs.length>1&&ucs.every(u=>u===ucs[0]);     // en la chica, si todos creen lo mismo, se dice una vez
      escs.forEach((e,i)=>{
        const mios=sol.filter(s=>s.esc===e.nombre||s.esc===i||s.esc===e.id||(s.nombre&&e.nombre&&String(s.nombre).toLowerCase().indexOf(String(e.nombre).toLowerCase())===0)),
          vivos=mios.filter(s=>!muerto(s)).length,pegan=mios.filter(s=>s.ficha&&!muerto(s)).length,E=EE[i];
        h+='<p class="es"><b>'+esc(String(e.nombre||'Escuadrón').toUpperCase())+'</b> <em class="'+(e.estado==='combate'?'ro':e.estado==='guardia'?'':'am')+'">'+esc(E[0])+'</em>'+
          (mios.length?' · '+(grande?'quedan '+vivos+' de '+mios.length:nw(vivos+' de '+mios.length)):'')+(pegan?' · '+nw('<span class="ro">'+pegan+' tira'+(pegan>1?'n':'')+' a pegar</span>'):'')+'</p>';
        if(!ucUna)h+='<p class="uc">'+ucs[i]+'</p>';
        let l='';const ord=e.orden?palabra(ORD,e.orden):'';
        if(ord)l+=grande?'Orden: <b>'+esc(ord)+'</b>':esc(ord.split(':')[0]);
        if(e.sinJefe)l+=(l?' · ':'')+'<span class="am">'+nw(grande?'SIN JEFE: desorden':'sin jefe')+'</span>';
        if(typeof e.refuerzoEn==='number'&&isFinite(e.refuerzoEn)&&e.refuerzoEn>0)l+=(l?' · ':'')+'<span class="am">'+nw('refuerzo en '+Math.ceil(e.refuerzoEn)+' s')+'</span>';
        if(l)h+='<p>'+l+'</p>';
        if(grande){h+='<table>';for(const s of mios){const c=COL[s.rol]||GRIS,m=muerto(s),hp=clamp(Math.round(+s.hp||0),0,100),f=[];
            if(!m){if(s.ve)f.push('te ve');if(s.ficha)f.push('<span class="ro">tira a pegar</span>');if(s.suprimido)f.push('suprimido');if(s.blanco==='bicho')f.push('<span class="ve">a los bichos</span>');}
            /* el rol ya lo dicen el color y la leyenda: sin esa columna cada soldado entra en un renglón. La postura, solo si no está de pie */
            h+='<tr'+(m?' class="mu"':'')+' title="'+esc(s.rol||'')+'"><td>'+punto(m?GRIS:c)+esc(corto(s.nombre))+'</td><td>'+esc(palabra(EST,s.estado))+(typeof s.postura==='string'&&s.postura!=='pie'&&!m?' <u>'+esc(s.postura.replace(/_/g,' '))+'</u>':'')+'</td><td><span class="vb"><span style="width:'+hp+'%"></span></span></td><td>'+
              f.map(nw).join(' ')+'</td></tr>';}
          h+='</table>';}
      });
      if(ucUna)h+='<p class="uc">'+ucs[0]+'</p>';
      if(!escs.length)h+='<p class="uc">Sin escuadrones.</p>';}
    else if(!falla)h+='<p class="uc">No hay escuadrón: la IA todavía no creó ninguno.</p>';
    h+=grande?'<p class="ley">'+punto(COL.jefe)+'jefe '+punto(COL.asalto)+'asalto '+punto(COL.granadero)+'granadero '+punto(COL.tirador)+'tirador<br>'+
      '<i class="an"></i>tira a pegar <i class="cr">✕</i>dónde creen que estás <i class="li"></i>te está viendo<br>'+
      '<i class="cu"></i>su cobertura <i class="ca"></i>su camino <i class="la"></i>láser <i class="tr"></i>jugador <i class="co"></i>cobertura (1 m o más)</p>'
      :'<p class="ley">'+punto(COL.jefe)+'jefe '+punto(COL.asalto)+'asalto '+punto(COL.granadero)+'granadero '+punto(COL.tirador)+'tirador<br>'+
      '<i class="an"></i>tira a pegar <i class="cr">✕</i>dónde creen que estás <i class="li"></i>te ve</p>';
    return h;}

  function update(dt){if(!modo)return;acc+=dt;if(acc<CADA)return;acc=acc%CADA;dibujar();}
  raiz.hidden=!modo;raiz.classList.toggle('gr',modo===2);document.body.classList.toggle('ue-tac',modo===1);
  addEventListener('resize',()=>{lado=0;});
  return{tecla,update,poner,dibujar,get modo(){return modo;}};
})();
