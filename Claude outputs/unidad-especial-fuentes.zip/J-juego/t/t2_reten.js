// Prueba 2: retén sin bichos. Puestos, apoyo en el piso, detección, radio, combate, fichas, tope de daño,
// el jugador los mata apuntando, granada con aviso, refuerzo, y resetGame() deja todo como al principio.
const H=require('../../harness.js'),fs=require('fs');
const INST=require('./inst.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
const OUT=process.argv[3]||__dirname+'/t2.json';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto');const R={};
  const ev=c=>h.ev(c);
  try{
    await h.start();
    lg('ir',JSON.stringify(await ev("(()=>{RETEN.ir({bichos:false});return [P.pos.x,P.pos.z,STAGE,intermission]})()")));
    await ev(INST);await h.step(.5);
    /* 1. puestos, nido y piso */
    R.puestos=await ev(`UE.soldados.map(s=>({n:s.nombre,rol:s.rol,x:+s.x.toFixed(2),z:+s.z.toFixed(2),y:+s.y.toFixed(3),piso:+floorAt(s.x,s.z).toFixed(3),
      root:s.vista?+s.vista.root.position.y.toFixed(3):null,elev:!!s.elev,estado:s.estado,tarea:s.tarea}))`);
    R.estado0=await ev("UE.estado()");lg('puestos',JSON.stringify(R.puestos));
    /* 2. se acerca caminando por el medio de la avenida, de pie y sin linterna, hasta que lo ven */
    let det=null;
    for(let k=0;k<40&&!det;k++){
      await h.step(.5,1/60,"keys.KeyW=true;P.yaw=Math.PI/2;__fich()");
      const e=await ev("(()=>{const e=UE.estado();return {x:+P.pos.x.toFixed(1),z:+P.pos.z.toFixed(1),T:+T.toFixed(2),sosp:+e.sospecha.toFixed(2),comb:e.combate,esc:UE.escuadrones.map(q=>q.estado)}})()");
      if(e.comb||e.sosp>=1)det=e;else if(k%4==0)lg('anda',JSON.stringify(e));
    }
    await ev("keys.KeyW=false;1");R.deteccion=det;lg('det',JSON.stringify(det));
    /* 3. a cubierto detrás del auto más cercano (al este del jugador), agachado, 7 s quieto: provoca granada */
    R.cubierto=await ev(`(()=>{let b=null,bd=1e9;for(const c of VCARS){if(c.st>=3)continue;if(c.x<P.pos.x-6||c.x>P.pos.x+30||Math.abs(c.z-607)>9)continue;const d=Math.abs(c.x-P.pos.x);if(d<bd){bd=d;b=c;}}
      if(!b)return null;const x=b.x+Math.max(b.L,b.W)*.5+1.2,z=b.z;P.pos.set(x,floorAt(x,z),z);P.vel.set(0,0,0);return {auto:[+b.x.toFixed(1),+b.z.toFixed(1)],jug:[+x.toFixed(1),+z.toFixed(1)]};})()`);
    lg('cubierto',JSON.stringify(R.cubierto));
    await ev("window.__inmortal=true;switchTo(2);1");
    for(let k=0;k<8;k++){await h.step(1,1/60,"keys.KeyC=true;__fich()");}
    lg('tras cubrirse',JSON.stringify(await ev("({T:+T.toFixed(1),hp:P.hp,gran:__L.ev.granada||0,aviso:__L.ev.granada_aviso||0,expl:__L.expl.length,radio:__L.radio.length})")));
    /* 4. se para y les tira: elige uno que se vea, le apunta y tira con la Uzi; repite hasta voltear a 2 */
    R.tiros=[];
    for(let k=0;k<26;k++){
      const s=await ev(`(()=>{keys.KeyC=false;const L=UE.soldados.filter(s=>s.vivo&&s.activo&&__ve(s)).sort((a,b)=>Math.hypot(a.x-P.pos.x,a.z-P.pos.z)-Math.hypot(b.x-P.pos.x,b.z-P.pos.z));
        const s=L[0];if(!s)return null;return {id:s.id,n:s.nombre,hp:Math.round(s.hp),d:+Math.hypot(s.x-P.pos.x,s.z-P.pos.z).toFixed(1),cajas:pickups.length};})()`);
      if(!s){await h.step(1,1/60,"keys.KeyC=false;__fich()");continue;}
      await h.step(1.2,1/60,`{const s=UE.soldados.find(q=>q.id===${s.id});if(s&&s.vivo){__apuntar(s);mouseDown=true;aiming=true;}else mouseDown=false;W[2].res=200;__fich();}`);
      await ev("mouseDown=false;aiming=false;1");
      const d=await ev(`(()=>{const s=UE.soldados.find(q=>q.id===${s.id});return {hp:Math.round(s.hp),vivo:s.vivo,cajas:pickups.length,T:+T.toFixed(1)}})()`);
      R.tiros.push([s.n,s.d,s.hp,d.hp,d.vivo,s.cajas,d.cajas]);lg('tiro',JSON.stringify(R.tiros[R.tiros.length-1]));
      await h.step(1.5,1/60,"keys.KeyC=true;__fich()");      // se vuelve a cubrir
      const m=await ev("UE.soldados.filter(s=>!s.vivo).length");if(m>=2)break;
    }
    /* 5. espera al refuerzo (sigue a cubierto, asomándose de a ratos) */
    for(let k=0;k<70;k++){
      await h.step(1,1/60,"keys.KeyC=true;__fich()");
      const e=await ev("UE.estado()");if(e.refuerzo==='llego'){R.llego=await ev("({T:+T.toFixed(1),n:UE.soldados.length,tizon:UE.soldados.filter(s=>s.esc.nombre==='Tizón').map(s=>[s.nombre,+s.x.toFixed(1),+s.z.toFixed(1),s.estado])})");break;}
    }
    lg('refuerzo',JSON.stringify(R.llego||null));
    await h.step(6,1/60,"keys.KeyC=true;__fich()");
    R.L=await ev("({hp:__L.hp,radio:__L.radio,bala:__L.bala,danos:__L.danos,ev:__L.ev,fichMax:__L.fichMax,log:__L.log,expl:__L.expl,cuadros:__L.cuadros,pegaJ:__L.pegaJ.length,T:+T.toFixed(1)})");
    R.ajustes=await ev("UEG.ajustes");
    /* 6. resetGame(): todo como al principio */
    R.reset=await ev(`(()=>{window.__inmortal=false;resetGame();RETEN.alEmpezar();return {n:UE.soldados.length,vivos:UE.soldados.filter(s=>s.vivo).length,
      sold:UE.soldados.map(s=>[s.nombre,+s.x.toFixed(2),+s.z.toFixed(2),+s.y.toFixed(2),s.estado,Math.round(s.hp)]),est:UE.estado(),gran:GRAN.lista.length,
      modelos:UEG.modelos.length,escena:scene.children.filter(o=>/^UE /.test(o.name)).length,cajas:pickups.length}})()`);
    await h.step(2);
    R.reset2=await ev("({est:UE.estado(),esc:UE.escuadrones.map(e=>[e.nombre,e.estado,e.activo])})");
    lg('reset',JSON.stringify(R.reset));
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(OUT,JSON.stringify(R));
  await h.close();lg('cerrado');
})();
