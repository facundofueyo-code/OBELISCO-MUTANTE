/* Saca una lámina: node lamina.js <archivo-de-vistas.js> <salida.png>
   El archivo de vistas exporta {cols, vistas:[…]} (las funciones fn/fn2 viajan como texto). */
const H=require('../../harness.js'),path=require('path');
const [,,def,salida]=process.argv;
const L=require(path.resolve(def));
(async()=>{
  const t0=Date.now();const h=await H.openPage(path.join(__dirname,'..','prueba.html'),{width:L.ancho||1280,height:L.alto||720});
  await h.page.waitForFunction(()=>window.lamina&&window.V);
  const vistas=L.vistas.map(v=>({...v,fn:v.fn?v.fn.toString():undefined,fn2:v.fn2?v.fn2.toString():undefined}));
  const r=await h.page.evaluate(({vistas,cols})=>{
    for(const v of vistas){if(v.fn)v.fn=eval('('+v.fn+')');if(v.fn2)v.fn2=eval('('+v.fn2+')');}
    return window.lamina(vistas,cols);},{vistas,cols:L.cols});
  await h.shotPage(path.resolve(salida));
  console.log('lámina',salida,'llamadas',r,'ms',Date.now()-t0,'errores',JSON.stringify(h.errors));
  await h.close();
})().catch(e=>{console.error('FALLA',e);process.exit(1);});
