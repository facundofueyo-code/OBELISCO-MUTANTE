# Tarea A — la IA de escuadrón

Leé primero `../SPEC.md` entero. Tu carpeta es `A-ia/`. Sos la pieza central: lo que Facu pidió, textual, es «que su IA sea muy compleja, difíciles pero justos».

## Qué tenés que lograr

Un núcleo de IA en **JavaScript puro** (sin Three.js ni DOM), que maneja escuadrones de soldados contra un jugador y contra mutantes, y un **simulador en Node** que lo corre sobre el mapa real del retén con jugadores automáticos, verifica las reglas de juego limpio y mide la dificultad.

La idea rectora: un escuadrón parece inteligente y a la vez justo no por tener muchas reglas, sino porque **se coordina y avisa lo que va a hacer**. El jugador tiene que poder entender por qué perdió y qué podría haber hecho. Cada vez que dudes entre «más letal» y «más legible», elegí legible.

## Entregables

1. **`ue_ia.js`**: define `function crearUE(ENV,TUNE){…}` y `const UE_TUNE={…}` (los números por defecto, cada uno con su comentario en español). Contrato en 4.7 de la SPEC. Va a ir pegado adentro del script del juego, así que nada de `import`/`export`; al final, solo esto para Node: `if(typeof module!=='undefined')module.exports={crearUE,UE_TUNE};`.
2. **`sim/`**: el simulador (detalle abajo), con un comando único que corre todo: `node sim/correr.js`.
3. **`trazas/`**: imágenes de corridas vistas desde arriba, para revisar el comportamiento a ojo.
4. **`INFORME.md`** (sección 8 de la SPEC) con las tablas de resultados.

## El mundo que ve la IA

Solo a través de `ENV` (4.7). Nada de acceder al jugador «de verdad» por otro lado: la IA lee `ENV.jugador()` únicamente dentro de la percepción, y todo lo demás trabaja con lo que cada soldado y el escuadrón **saben**. Esto es la regla 2 y se prueba.

- **Línea de visión rápida**: sobre la grilla (`B`,`H`), como campo de alturas. Entre el ojo de uno y un punto del otro, avanzá de a 0,5 m: si el obstáculo del casillero es más alto que el rayo en ese punto, tapa (`B=2` tapa siempre; `B=1` tapa hasta `H` decímetros). Salteá los primeros y últimos 0,6 m. Usala para percepción, elección de cobertura y exposición.
- **Bala real**: `ENV.rayo(...)`. Antes de tirar a pegar, confirmá con un rayo desde la boca del arma hasta la parte del jugador que querés pegar. La bala siempre se resuelve con rayo real (mundo, bichos, jugador): nunca atraviesa nada.
- El jugador es una cápsula: radio 0,35, de `y` a `y+alto` (`alto` 1,8 de pie, 1,15 agachado). Puntos a mirar: cabeza (`y+alto-0,12`) y pecho (`y+alto*0,62`). Si solo ves la cabeza, está «medio visible».
- Alturas del soldado en la SPEC (sección 5). La boca del arma: si `s.vista` existe usá `s.vista.boca(v)`; si no, aproximá.

## Cada soldado

Datos (objeto plano): identidad (`id`, `nombre` «Ceniza 2», `rol`, `esc`), cuerpo (`x,z,y,rumbo,vx,vz`), postura (`agach`, `tierra` de 0 a 1, con los tiempos de transición de la SPEC: mientras se para desde el piso no puede tirar ni correr), salud, estado, arma (balas en el cargador, recargando), puntería (`asiento` 0…1), supresión (0…1), lo que sabe, camino, cobertura, blanco, relojes. Si `ENV.vista(s)` devuelve un modelo, en cada cuadro escribí sus entradas (`s.vista.e.*`, 4.2) y llamá `s.vista.update(dt)`; la posición y el rumbo se los ponés vos en `s.vista.root`.

**Pensar poco y repartido.** `pensar()` corre unas 8 veces por segundo por soldado, escalonado entre soldados. `actuar(dt)` corre en cada cuadro: mueve, gira, apunta, lleva la cadencia de tiro. Un solo A* por cuadro en total (cola). Presupuesto: menos de 1 ms por cuadro con 8 soldados en una PC normal.

**Moverse.** Velocidad deseada y aceleración (que no cambien de dirección de golpe). Caminos con A* sobre la grilla de 1 m en una ventana alrededor del soldado: pasan por casilleros libres; las vallas y cosas de hasta 1,2 m se saltan con costo (campo `salto` del modelo, 0,5 s); los autos se rodean. Con «costo de exposición»: pasar por donde el último lugar conocido del jugador tiene línea de visión cuesta 3 o 4 veces más (así salen solos los flanqueos por donde no se los ve). Mirá cómo lo resolvió el Shajar en `../base-view.txt` (líneas 10476–10530: A*, suavizado, seguimiento con mirada adelante, anti-trabado) y mejoralo: calculá la exposición una vez por escuadrón y compartila mientras el lugar conocido no cambie. Separación entre compañeros (que no se encimen ni compartan cobertura: a menos de 3 m es blanco de granada). Anti-trabado: si quiere moverse y en 1 s no avanzó, replantea; nunca queda clavado.

**Coberturas.** Candidatas: casilleros libres pegados a algo de 1 m o más. Baja (1 a 1,5 m, un auto): se cubre agachado y tira parándose o por arriba. Alta (pared, furgón, columna): se cubre de pie y tira asomándose a un costado (un punto a 0,7–1,4 m con línea de visión; `asoma` del modelo). Puntuá: que tape contra el último lugar conocido, que tenga desde dónde tirar, distancia al blanco según el rol, que no esté flanqueada (expuesta de costado), que no quede cerca de un compañero, costo del camino. Si el jugador pasa a ver su cobertura (lo flanqueó), se da cuenta y cambia.

**Estados** (nombres orientativos): `puesto`, `ronda`, `alerta` (gira hacia el estímulo, levanta el arma, prende la linterna), `revisar` (va a mirar), `a_cubierto` (corre a la cobertura), `cubierto`, `asomado` (tira ráfagas 1,2–2,5 s y vuelve), `suprimir` (tira al último lugar conocido sin ver al jugador), `avanzar`, `flanquear`, `recargar`, `lanzar`, `tierra` (tirador siempre; cualquiera que quede bajo fuego en descampado sin cobertura a menos de 6 m), `replegar` (herido o flanqueado), `esquivar` (granada o auto por explotar: corre y se tira al piso), `culata`, `buscar`, `aturdido`, `radio` (pidiendo refuerzo: 3 s, a cubierto, se interrumpe si lo hieren), `muerto`.

**Percepción** (cada 0,1–0,15 s por soldado, escalonado):

- Ve al jugador si está dentro del alcance y del cono y hay línea de visión a la cabeza o al pecho. Alcance y modificadores en la SPEC (linterna, zona iluminada con `ENV.luz`, agachado y quieto).
- En guardia no lo detecta de inmediato: **sospecha** de 0 a 1 que sube según distancia, exposición, luz, postura y movimiento (tiempos de la SPEC) y baja si deja de verlo. Entre 0,4 y 1: gira, alumbra, dice `sospecha`; si no se confirma, `nada`. Al llegar a 1: `contacto`.
- Oye: `UE.ruido` (disparos del jugador con error de posición, pasos corriendo cerca), balas que le pasan cerca (`UE.balaCerca`), explosiones.
- Ve bichos a 30 m con línea de visión, o si lo atacan.
- Lo que uno ve, el escuadrón lo sabe 0,5 s después (avisa por radio). Un soldado muerto antes de avisar no avisa.

**Elegir blanco.** Entre el jugador (si se sabe dónde está) y los bichos visibles: amenaza según distancia, si lo está atacando a él o a un compañero cercano, y tipo. Un bicho a menos de 7 m manda. A los bichos les tira sin ficha y con buena puntería, retrocediendo si se le vienen encima.

**Tirar.**

- Con **ficha** («tira a pegar»): apunta a la parte visible del jugador con atraso (el punto de mira lo sigue con ~0,18 s de retraso y adelanta la mitad), dispersión según el arma y el `asiento`. El `asiento` sube mientras lo sigue viendo y cae si el jugador corta la visión, si el soldado se mueve, recibe un impacto o está suprimido.
- Sin ficha, o en la ráfaga de aviso: **tira a suprimir**: apunta a propósito a 0,9–1,5 m del jugador (del lado de la cobertura, o al objeto que lo tapa) con poca dispersión, para que las balas se vean pasar pero no peguen. Si una bala de supresión igual le pegaría, se sortea de nuevo una vez.
- Tope de daño por segundo (SPEC): si se pasa, los que tienen ficha tiran a suprimir un rato.
- Cada bala: resolvé contra mundo, bichos y jugador; aplicá el daño (`ENV.herirJugador`, `ENV.herirBicho`) y avisá con `ENV.bala({...})`. Llamá `s.vista.disparo()` si hay modelo.
- Escopeta: 8 perdigones; el daño cae con la distancia. Tirador: ver abajo.

**El tirador.** Busca un puesto lejano con buena línea a la zona del jugador (o usa el `nido`). Cuerpo a tierra. Ciclo: `tirador_mira` → láser prendido siguiendo al jugador (con el atraso y adelanto de la SPEC) durante 1,3 s **continuos** de línea de visión → destello 0,25 s → tiro al punto donde está el láser. Si la línea se corta, se cancela (`tirador_fallo`) y vuelve a empezar. Si lo flanquean o le cae una granada cerca, se levanta (tarda) y se reubica. A menos de 12 m tira rápido y mal, sin láser.

**Suprimido.** Las balas del jugador que le pasan cerca le suben la supresión: se agacha o se esconde, pierde la puntería y dice `suprimido`. Así el jugador también puede clavarlos y moverse. Un impacto fuerte (escopeta de cerca) lo deja `aturdido` medio segundo.

**Herido** (menos del 35 %): se repliega a una cobertura más atrás y dice `herido`. Tira menos.

## El cerebro del escuadrón

Una «pizarra» compartida: estado (`guardia`, `sospecha`, `combate`, `busqueda`), **último lugar conocido** (`uc`: posición, hora, si es por vista o por oído, error), fichas, quién flanquea, enfriamientos (granada, flanqueo), bichos avistados, jefe actual, desorden, refuerzo.

Corre unas 2 a 3 veces por segundo:

1. **Actualiza lo que se sabe** con lo que avisaron los soldados.
2. **Reparte roles** en combate: `tirador` al puesto de tiro; `jefe` y `granadero` hacen la **base de fuego** (fijar); `asalto` **flanquea** cuando toca (elige el lado con mejor camino tapado; avisa `orden_flanco` y `flanco_izq/der`; va agachado, con la linterna apagada) o **empuja** si el jugador está recargando (`recarga_jugador`). Con 3 o menos, no hay flanqueo: aguantan. Con 2 o menos: se repliegan a `reunion` y piden refuerzo.
3. **Reparte fichas**: como mucho `TUNE.fichas` soldados con permiso de tirar a pegar; se la da al que mejor lo ve y rota. El que flanquea y llega tiene prioridad, pero igual necesita asentar la puntería.
4. **Fuego y movimiento**: un soldado que quiere cambiar de cobertura pide permiso; se le da si otro está tirando o suprimiendo (dice `muevo` / `tecubro`), o si hace más de 2 s que nadie ve al jugador. No se mueven todos a la vez.
5. **Granada** (regla 3): si el jugador lleva quieto o cubierto el tiempo de la SPEC cerca del `uc`, hay arco libre (`ENV.arco`), ningún compañero a menos de 8 m del blanco y pasó el enfriamiento: el granadero (u otro con granada) la tira **al último lugar conocido**. Avisa `granada`, entra en `lanzar`, la suelta a los 0,65 s o más con `ENV.granada(...)`. También contra 3 o más bichos juntos.
6. **Peligros** (`ENV.peligros()`): los que están en el radio de una granada o de un auto por explotar corren y se tiran al piso (`granada_enemiga`, `auto_fuego`).
7. **Pérdida de contacto**: tiempos de la SPEC. `perdido` → suprimen el `uc` → granada o avance → `busqueda`: de a dos, revisan el `uc` y las coberturas de alrededor que no se ven desde donde están, con linternas → `limpio` y vuelven a los puestos, más alertas (detectan más rápido).
8. **Jefe caído**: `baja`, `jefe_caido`, desorden unos segundos (sin órdenes nuevas, una ficha, cada uno aguanta donde está), después manda el siguiente (granadero, asalto, tirador).
9. **Refuerzo**: lo pide el jefe en estado `radio`; `refuerzo_pide`, `refuerzo_va`; a los 25 s entra el segundo escuadrón por `sale` y `camino`, ya en combate y sabiendo el `uc` que tenga el primero; `refuerzo_llega`.
10. **Bichos**: `bichos` la primera vez; los blancos los elige cada uno. Si los bichos son muchos y cercanos, el escuadrón les da prioridad sobre el jugador.
11. **Jugador muerto**: `muerto_jugador`, vuelven a guardia.

Las frases salen por `ENV.radio(s,clave,texto)`, con prioridades y enfriamientos para que no hablen todos a la vez (una frase cada ~1,2 s por escuadrón como mucho; las de aviso de peligro pasan siempre). Textos y claves en la sección 9.

`UE.objetivos()` devuelve los soldados vivos como blancos de los bichos (4.1). `UE.rayo(o,d,maxT)`: bala del jugador; si hay modelo usá `s.vista.rayo`, si no, cápsulas según la postura. `UE.herir`: multiplicadores por parte, reacción, muerte (elegí el tipo de caída), `ENV.evento('baja',…)`. `UE.estado()`: la sospecha más alta y su ángulo, si hay combate, cuántos quedan. `UE.debug()`: la estructura de 4.7.

Cuando el jugador está a más de 160 m de todos y el escuadrón está en guardia, casi no gastes: una actualización lenta alcanza.

## El simulador

`sim/` en Node, sin dependencias (podés usar Python con PIL para dibujar).

- **Mundo**: cargá `../mapa-reten.json` y sumale a la grilla la disposición provisoria del retén (sección 6 de la SPEC): furgones como bloqueados, vallas de 1,1 m, autos de la fila de 1,5 m. Implementá `ENV` completo: `rayo` y línea de visión contra la grilla como campo de alturas, `luz` con la zona iluminada, granadas con física simple y `arco`, bichos simples (corren al blanco más cercano y muerden), azar con semilla.
- **Jugadores automáticos**: (a) parado al descubierto; (b) a cubierto, se asoma 1 s cada 3 s y tira con puntería razonable; (c) escondido y quieto, y a los 10 s se va 20 m sin que lo vean; (d) sigilo: se acerca agachado por la vereda, sin linterna y con linterna; (e) rodea por Hipólito Yrigoyen y aparece por San José; (f) «jugador decente»: usa coberturas, tira ráfagas, se mueve cuando avisan granada, avanza cuando recargan. Las armas del jugador: pistola (26 de daño, 0,17 s), escopeta (10×15, a quemarropa), Uzi (10, 0,072 s), fusil (22, 0,09 s).
- **Verificaciones automáticas** (que `correr.js` falle con mensaje claro si alguna no se cumple, en 20 semillas por escenario):
  1. Nunca más de `TUNE.fichas` soldados tirando a pegar a la vez (más el tirador).
  2. Toda granada de soldado: aviso por radio al menos 0,6 s antes de soltarla y al menos 3 s en total hasta la explosión.
  3. Todo tiro de tirador: láser continuo sobre el jugador al menos 1,2 s antes.
  4. Con el jugador fuera de vista y sin ruido, el `uc` no se mueve aunque el jugador sí. Granadas y supresión van al `uc`.
  5. Primera ráfaga de cada soldado tras el primer contacto: no pega.
  6. El daño de balas de fusil y escopeta al jugador no pasa el tope por segundo.
  7. Ningún soldado tira antes de 0,35 s de haberlo visto.
  8. Ninguna bala le pega al jugador con una cobertura en el medio.
  9. En 5 minutos de combate, ningún soldado con orden de moverse queda más de 3 s sin avanzar.
  10. Sin `NaN` ni excepciones; ningún soldado dentro de un casillero bloqueado.
- **Medidas** (mediana y rango sobre 20 semillas): cuánto dura cada jugador automático; daño recibido por fuente (fusil, escopeta, tirador, granada, culata); soldados que mata el «jugador decente» antes de morir, con las armas base y con fusil; a qué distancia lo detectan en sigilo, con y sin linterna; segundos hasta la primera granada contra el escondido y si cae en el lugar viejo; cuántas veces flanquean y cuánto tardan; qué pasa con 6 y con 12 bichos saliendo detrás del retén; desorden al caer el jefe; refuerzo. Y **costo**: ms por `UE.update` con 8 soldados en combate (media, percentil 99, máximo) y cuántos A* por segundo.
- **Trazas**: para cuatro o cinco corridas representativas, una tira de imágenes vistas desde arriba (una cada 2 s de juego: grilla, soldados con rol y estado, caminos, `uc`, jugador, granadas, balas del último instante). Miralas. Si ves algo tonto (se amontonan, flanquean por delante del jugador, se quedan parados al descubierto, corren a una cobertura que da al jugador), arreglalo.

## Afinado

Los números de la SPEC son un punto de partida. Objetivo de dificultad, con un escuadrón de 4 y el «jugador decente» con armas base:

- Parado al descubierto a 30 m, muere en 4 a 7 s.
- Jugando bien desde cobertura, mata 2 o 3 antes de morir la mitad de las veces y a veces a los 4; el refuerzo lo complica.
- Casi nunca muere sin haber tenido un aviso antes (láser, grito de granada, primera ráfaga que erra).

Ajustá `UE_TUNE` hasta acercarte y dejá en el informe qué cambiaste y por qué. Dejá también tres perillas simples para Facu: `fichas`, `punteria` (multiplica la dispersión) y `daño` (multiplica el daño).

## Qué no hacer

- No uses Three.js, DOM ni nada del juego directamente: solo `ENV`.
- No leas la posición real del jugador fuera de la percepción.
- No toques nada fuera de `A-ia/`.
- No entregues números inventados: lo que va al informe sale de correr el simulador.
