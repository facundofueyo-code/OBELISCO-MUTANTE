/* Pruebas de GRAN. Uso: node t_gran.js [juego.html] [capturas:0|1] */
const H=require('../harness.js');
const file=process.argv[2]||__dirname+'/juego.html',SHOTS=process.argv[3]==='1'||process.argv[3]==='2',SOLO=process.argv[3]==='2';
const t0=Date.now(),log=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
(async()=>{
  const h=await H.open(file);log('abierto');const out={};
  try{
    await h.start();log('start');
    /* ayudantes adentro del juego */
    await h.ev(`(()=>{
      window.__run=(sec,fn)=>{let t=window.__simT;const n=Math.round(sec*60);for(let i=0;i<n;i++){t+=1000/60;if(fn)fn();frame(t);}window.__simT=t;};
      window.__ex=[];const ex0=UEB.explosion;UEB.explosion=(p,r,d,de)=>{window.__ex.push({x:+p.x.toFixed(3),y:+p.y.toFixed(3),z:+p.z.toFixed(3),r,d,de:de&&typeof de==='object'?'obj':de,T:+T.toFixed(3),v3:p.isVector3===true});ex0(p,r,d,de);};
      const lz0=GRAN.lanzar;GRAN.lanzar=o=>{const g=lz0(o);if(g)g.__pv=null;return g;};
      window.__distPared=(x,z)=>{let m=9;for(let i=Math.floor((x-2)/HC);i<=Math.floor((x+2)/HC);i++)for(let j=Math.floor((z-2)/HC);j<=Math.floor((z+2)/HC);j++){const a=allHash.get(hk(i,j));if(a)for(const idx of a){const w=WALLS_ALL[idx],ex=w[2]-w[0],ez=w[3]-w[1],L2=ex*ex+ez*ez;if(L2<1e-9)continue;const t=Math.max(0,Math.min(1,((x-w[0])*ex+(z-w[1])*ez)/L2));m=Math.min(m,Math.hypot(x-w[0]-ex*t,z-w[1]-ez*t));}}return m;};
      window.__ru=[];const ru0=UEB.ruido;UEB.ruido=(p,tipo,f)=>{window.__ru.push([tipo,f]);ru0(p,tipo,f);};
      const R=GRAN.TUNE.R;
      /* invariantes en cada cuadro: debajo del piso, adentro de un edificio, adentro de un auto, atravesó una pared */
      window.__viol={piso:0,edif:0,auto:0,pared:0,n:0,ej:[]};
      window.__chk=()=>{const V=window.__viol;for(const g of GRAN.lista){V.n++;const p=g.p,fl=floorAt(p.x,p.z);
        if(p.y-R<fl-.005){V.piso++;if(V.ej.length<6)V.ej.push(['piso',+p.x.toFixed(2),+p.y.toFixed(3),+p.z.toFixed(2),+fl.toFixed(3)]);}
        if(isSolid(p.x,p.z)&&p.y<bldH(p.x,p.z)-.05&&window.__distPared(p.x,p.z)>.5){V.edif++;if(V.ej.length<6)V.ej.push(['edif',+p.x.toFixed(2),+p.y.toFixed(2),+p.z.toFixed(2)]);}
        for(const c of VCARS){if(c.st>=3)continue;const rx=p.x-c.x,rz=p.z-c.z;if(rx*rx+rz*rz>c.L*c.L)continue;const ca=Math.cos(c.a),sa=Math.sin(c.a),lx=rx*ca-rz*sa,lz=rx*sa+rz*ca;
          if(Math.abs(lx)<c.W/2-.01&&Math.abs(lz)<c.L/2-.01){const top=c.crushed?c.by+c.H*.4:(MOV.carOK(c)?MOV.carTop(c,-lz):c.by+c.H*.97);if(p.y<top-.05){V.auto++;if(V.ej.length<6)V.ej.push(['auto',VCARS.indexOf(c),+p.x.toFixed(2),+p.y.toFixed(2),+p.z.toFixed(2),+top.toFixed(2)]);}}}
        if(g.__pv){const d=new THREE.Vector3().subVectors(p,g.__pv),len=d.length();if(len>1e-4){d.multiplyScalar(1/len);if(rayWalls(g.__pv,d,len)<len-1e-4){V.pared++;if(V.ej.length<6)V.ej.push(['pared',+p.x.toFixed(2),+p.y.toFixed(2),+p.z.toFixed(2)]);}}}
        (g.__pv||(g.__pv=new THREE.Vector3())).copy(p);}};
      window.__hasta=(sec)=>{let k=0;const n=Math.round(sec*60);while(GRAN.lista.length&&k<n){window.__run(1/60,()=>{P.hp=100;window.__chk();});k++;}return k;};
      return 1;})()`);
    if(!SOLO){
    /* ---------- 1. partida normal de 30 s con oleada ---------- */
    out.p1=await h.ev(`(()=>{const e0=enemies.length;window.__run(30,()=>{P.hp=100;});
      return {T:+T.toFixed(1),oleada:wave,bichos:enemies.length,muertos:kills,lista:GRAN.lista.length,estado:GRAN.estado()};})()`);
    log('p1',JSON.stringify(out.p1));
    /* 1b. granadas sobre los bichos de la oleada */
    out.p1b=await h.ev(`(()=>{const vivos=enemies.filter(e=>e.hp>0).slice(0,4);const hp0=vivos.map(e=>e.hp);
      for(const e of vivos){const p=e.obj.position;GRAN.lanzar({pos:new THREE.Vector3(p.x+.5,floorAt(p.x+.5,p.z)+1,p.z),vel:new THREE.Vector3(0,0,0),mecha:.6,de:'jugador'});}
      const n=GRAN.lista.length;window.__run(1,()=>{P.hp=1e4;});P.hp=100;   /* el jugador está entre los bichos: que no muera por 4 explosiones juntas */
      return {bichos:vivos.length,lanzadas:n,hp0:hp0.map(v=>Math.round(v)),hp1:vivos.map(e=>Math.round(e.hp)),explosiones:window.__ex.length,ruido:window.__ru.length,lista:GRAN.lista.length};})()`);
    log('p1b',JSON.stringify(out.p1b));
    /* ---------- 2. arco en Av. de Mayo ---------- */
    await h.ev(`(()=>{resetGame();running=true;return 1;})()`);await h.alReten();await h.step(.5);
    out.autos=await h.ev(`VCARS.map((c,i)=>[i,+c.x.toFixed(1),+c.z.toFixed(1),+c.W.toFixed(2),+c.L.toFixed(2),+c.H.toFixed(2),+c.by.toFixed(2),c.st]).filter(a=>a[1]>-470&&a[1]<-330&&a[2]>585&&a[2]<625)`);
    log('autos',JSON.stringify(out.autos));
    out.p2=await h.ev(`(()=>{window.__ex.length=0;window.__viol={piso:0,edif:0,auto:0,pared:0,n:0,ej:[]};
      const V=THREE.Vector3,S=new V(-405,0,606);S.y=floorAt(S.x,S.z)+1.75;
      const enAuto=(x,z)=>VCARS.some(c=>c.st<3&&Math.hypot(x-c.x,z-c.z)<c.L*.5+.6);
      const T0=[];const add=(nom,x,z)=>T0.push({nom,x,z});
      /* detrás de autos: del otro lado, mirando desde S */
      const cs=VCARS.filter(c=>c.st<3&&Math.hypot(c.x-S.x,c.z-S.z)>9&&Math.hypot(c.x-S.x,c.z-S.z)<25&&c.z>598&&c.z<616).sort((a,b)=>Math.hypot(a.x-S.x,a.z-S.z)-Math.hypot(b.x-S.x,b.z-S.z));
      const usados=[];for(const c of cs){if(usados.length>=2)break;const dx=c.x-S.x,dz=c.z-S.z,d=Math.hypot(dx,dz);const x=c.x+dx/d*(c.W/2+1.6),z=c.z+dz/d*(c.W/2+1.6);if(VCARS.some(o=>o!==c&&o.st<3&&Math.hypot(x-o.x,z-o.z)<o.L*.5+.6))continue;usados.push(VCARS.indexOf(c));add('detras_auto_'+VCARS.indexOf(c),x,z);}
      /* los demás, corridos al oeste hasta que no caigan sobre un auto */
      const libre=(nom,x,z)=>{for(let i=0;i<12&&(enAuto(x,z)||isSolid(x,z));i++)x-=1.5;add(nom,x,z);};
      libre('calzada_8',S.x-8,S.z);libre('calzada_13',S.x-11,S.z+7);libre('calzada_20',S.x+19,S.z-6);libre('calzada_30',S.x-30,S.z+2);
      libre('vereda_N',S.x+8,594.5);libre('vereda_S',S.x-20,619.5);
      const R=[];
      for(const tg of T0){let x=tg.x,z=tg.z;const y=floorAt(x,z),hasta=new V(x,y,z);
        const a0=performance.now(),r=GRAN.arco(S,hasta),ms=performance.now()-a0;
        const e0=window.__ex.length;const g=GRAN.lanzar({pos:S,vel:r.vel,mecha:3,de:'soldado'});const pasos=window.__hasta(4);const e=window.__ex[e0];
        R.push({nom:tg.nom,dist:+Math.hypot(x-S.x,z-S.z).toFixed(1),yObj:+y.toFixed(2),ok:r.ok,ang:Math.round(r.ang*57.3),v:+r.vel.length().toFixed(1),t:+r.t.toFixed(2),errPrev:+r.err.toFixed(2),
          err:e?+Math.hypot(e.x-x,e.z-z).toFixed(2):null,difPrev:e?+Math.hypot(e.x-r.fin.x,e.z-r.fin.z).toFixed(3):null,yFin:e?+e.y.toFixed(3):null,ms:+ms.toFixed(2),pasos});}
      /* pared en el medio: un punto adentro de la manzana norte, detrás de la fachada */
      const W1=new V(-412,0,584);W1.y=floorAt(W1.x,W1.z);const a1=performance.now(),rw=GRAN.arco(S,W1),msw=performance.now()-a1;
      const W2=new V(-386,0,632);W2.y=floorAt(W2.x,W2.z);const rw2=GRAN.arco(S,W2);
      const sol=R.filter(r=>r.err!==null).map(r=>r.err),okr=R.filter(r=>r.ok&&r.err!==null).map(r=>r.err);
      return {S:[S.x,+S.y.toFixed(2),S.z],R,pared:{ok:rw.ok,err:+rw.err.toFixed(1),ms:+msw.toFixed(2),solido:isSolid(W1.x,W1.z)},pared2:{ok:rw2.ok,solido:isSolid(W2.x,W2.z)},
        errMedio:+(sol.reduce((a,b)=>a+b,0)/sol.length).toFixed(3),errMax:Math.max(...sol),errMedioOk:+(okr.reduce((a,b)=>a+b,0)/Math.max(1,okr.length)).toFixed(3),viol:window.__viol,
        autosDanados:VCARS.map((c,i)=>[i,c.hits|0,c.st]).filter(a=>a[1]>0)};})()`);
    log('p2',JSON.stringify(out.p2));
    /* ---------- 3. rebotes: pared, auto, y 40 tiros al azar ---------- */
    await h.ev(`(()=>{resetGame();running=true;return 1;})()`);await h.alReten();await h.step(.2);
    out.p3=await h.ev(`(()=>{window.__viol={piso:0,edif:0,auto:0,pared:0,n:0,ej:[]};const V=THREE.Vector3,R=GRAN.TUNE.R;
      /* contra la fachada norte: tiro horizontal hacia el norte desde la vereda */
      const A=new V(-405,0,595);A.y=floorAt(A.x,A.z)+1.0;const dw=rayWalls(A,new V(0,0,-1),20);
      const g=GRAN.lanzar({pos:A,vel:new V(0,1.5,-10),mecha:2.5,de:'soldado'});let zmin=1e9,ymin=1e9;
      let k=0;while(GRAN.lista.length&&k<200){window.__run(1/60,()=>{P.hp=100;window.__chk();if(GRAN.lista[0]){zmin=Math.min(zmin,GRAN.lista[0].p.z);}});k++;}
      const fin1=window.__ex[window.__ex.length-1];
      const pared={paredZ:+(A.z-dw).toFixed(3),zMin:+zmin.toFixed(3),separacion:+(zmin-(A.z-dw)).toFixed(3),fin:[fin1.x,fin1.y,fin1.z]};
      /* contra el costado de un auto a 1 m de altura */
      const c=VCARS.filter(c=>c.st<3&&c.x>-470&&c.x<-330&&c.z>598&&c.z<616)[2];const ca=Math.cos(c.a),sa=Math.sin(c.a);
      /* eje local x del auto en el mundo: (ca,-sa) */
      const ax=ca,az=-sa,B=new V(c.x+ax*(c.W/2+4),0,c.z+az*(c.W/2+4));B.y=floorAt(B.x,B.z)+.8;
      const g2=GRAN.lanzar({pos:B,vel:new V(-ax*10,1,-az*10),mecha:2.5,de:'soldado'});let dmin=1e9;k=0;
      while(GRAN.lista.length&&k<200){window.__run(1/60,()=>{P.hp=100;window.__chk();const q=GRAN.lista[0];if(q){const rx=q.p.x-c.x,rz=q.p.z-c.z,lx=rx*ca-rz*sa;dmin=Math.min(dmin,Math.abs(lx)-c.W/2);}});k++;}
      const fin2=window.__ex[window.__ex.length-1];
      const auto={auto:VCARS.indexOf(c),minDistAlCostado:+dmin.toFixed(3),fin:[fin2.x,fin2.y,fin2.z],hits:c.hits|0,st:c.st};
      /* 40 tiros al azar en la cuadra (de a 8) */
      let n=0;const rnd=(a,b)=>a+Math.random()*(b-a);
      for(let lote=0;lote<5;lote++){for(let i=0;i<8;i++){const p=new V(rnd(-460,-350),0,rnd(594,620));if(isSolid(p.x,p.z))continue;p.y=floorAt(p.x,p.z)+rnd(.3,1.8);
          if(VCARS.some(c=>c.st<3&&Math.hypot(p.x-c.x,p.z-c.z)<c.L*.5+.4))continue;
          const sp=rnd(4,17),az2=rnd(0,6.28),el=rnd(-.2,1);GRAN.lanzar({pos:p,vel:new V(Math.cos(az2)*Math.cos(el)*sp,Math.sin(el)*sp,Math.sin(az2)*Math.cos(el)*sp),mecha:rnd(2,4),de:'soldado'});n++;}
        window.__hasta(5);}
      return {pared,auto,azar:n,viol:window.__viol,autosPrendidos:VCARS.filter(c=>c.st>=2&&c.x>-470&&c.x<-330).length};})()`);
    log('p3',JSON.stringify(out.p3));
    /* ---------- 4. explosión: daño ---------- */
    await h.ev(`(()=>{resetGame();running=true;return 1;})()`);await h.alReten();await h.step(.2);
    out.p4=await h.ev(`(()=>{const V=THREE.Vector3,R=GRAN.TUNE.R;window.__ex.length=0;intermission=1e9;
      const una=(gp,px,pz)=>{P.pos.set(px,floorAt(px,pz),pz);P.vel.set(0,0,0);P.hp=100;shake=0;P.onGround=true;
        const g=GRAN.lanzar({pos:new V(gp.x,floorAt(gp.x,gp.z)+R,gp.z),vel:new V(0,0,0),mecha:.05,de:'soldado'});const enLista=GRAN.lista.length;
        let k=0;while(GRAN.lista.length&&k<20){window.__run(1/60);k++;}
        return {dReal:+Math.hypot(P.pos.x-gp.x,P.pos.z-gp.z).toFixed(2),dano:100-P.hp,vel:[+P.vel.x.toFixed(2),+P.vel.y.toFixed(2),+P.vel.z.toFixed(2)],shake:+shake.toFixed(2),enLista,despues:GRAN.lista.length};};
      /* sin cobertura: jugador en la calzada, granada al oeste */
      const libre=[];for(const d of [2,4,6]){const r=una({x:-352-d,z:607},-352,607);r.esperado=Math.round(80*(1-r.dReal/7));libre.push(r);}
      /* con un auto en el medio: granada pegada a un costado, jugador del otro lado */
      const c=VCARS.filter(c=>c.st<3&&c.x>-470&&c.x<-330&&c.z>598&&c.z<616)[3];const ca=Math.cos(c.a),sa=Math.sin(c.a),ax=ca,az=-sa;
      const gp={x:c.x-ax*(c.W/2+.15),z:c.z-az*(c.W/2+.15)};const tapado=[];const ag=GRAN.TUNE.autoGolpes;GRAN.TUNE.autoGolpes=0;
      for(const d of [2.4,4,6]){const px=gp.x+ax*d,pz=gp.z+az*d;const r=una(gp,px,pz);r.esperado=Math.round(80*(1-r.dReal/7)*.3);tapado.push(r);}
      GRAN.TUNE.autoGolpes=ag;const autoTapa={auto:VCARS.indexOf(c),hits:c.hits|0,st:c.st};
      /* bichos: un baboso a 3 m (sobrevive) y una rata a 2 m (muere) */
      P.pos.set(-340,floorAt(-340,607),607);
      const b=spawnEnemy('baboso',[-362,607]);const r0=spawnEnemy('rata',[-358,611]);let kk=0;while(b.state==='rise'&&kk<300){window.__run(1/60,()=>{P.hp=100;});kk++;}
      const bp=b.obj.position.clone(),hp0=b.hp,rhp0=r0.hp;const gb={x:bp.x-3,z:bp.z};
      let bEx=null;const exB=UEB.explosion;UEB.explosion=(p,r,d,de)=>{bEx=b.obj.position.clone();exB(p,r,d,de);};
      GRAN.lanzar({pos:new V(gb.x,floorAt(gb.x,gb.z)+R,gb.z),vel:new V(0,0,0),mecha:.05,de:'jugador'});
      r0.obj.position.set(gb.x,r0.obj.position.y,gb.z+2);const rp=r0.obj.position.clone();
      let k=0;while(GRAN.lista.length&&k<20){window.__run(1/60,()=>{P.hp=100;});k++;}
      UEB.explosion=exB;const dB=Math.hypot(bEx.x-gb.x,bEx.z-gb.z),dR=Math.hypot(rp.x-gb.x,rp.z-gb.z);
      const bichos={baboso:{d:+dB.toFixed(2),r:b.c.r,hp0,hp1:+b.hp.toFixed(1),dano:+(hp0-b.hp).toFixed(1),esperado:+(80*(1-Math.hypot(Math.max(0,dB-b.c.r),Math.max(0,(floorAt(gb.x,gb.z)+GRAN.TUNE.R)-(bEx.y+b.c.height),bEx.y-(floorAt(gb.x,gb.z)+GRAN.TUNE.R)))/7)).toFixed(1),yB:+bEx.y.toFixed(2),estado:b.state},
        rata:{d:+dR.toFixed(2),hp0:rhp0,hp1:+r0.hp.toFixed(1),viva:enemies.includes(r0)}};
      /* autos: una granada a 1 m del costado (humea), otra igual (se prende) */
      const c2=VCARS.filter(c=>c.st<3&&c.x>-470&&c.x<-330&&c.z>598&&c.z<616)[5];const ca2=Math.cos(c2.a),sa2=Math.sin(c2.a);
      const g2={x:c2.x+ca2*(c2.W/2+1),z:c2.z-sa2*(c2.W/2+1)};const h0=c2.hits|0;P.pos.set(-330,0,607);
      GRAN.lanzar({pos:new V(g2.x,floorAt(g2.x,g2.z)+R,g2.z),vel:new V(0,0,0),mecha:.05,de:'soldado'});window.__run(.2,()=>{P.hp=100;});const h1=c2.hits,st1=c2.st;
      GRAN.lanzar({pos:new V(g2.x,floorAt(g2.x,g2.z)+R,g2.z),vel:new V(0,0,0),mecha:.05,de:'soldado'});window.__run(.2,()=>{P.hp=100;});
      const autos={auto:VCARS.indexOf(c2),hits0:h0,hits1:h1,st1,hits2:c2.hits,st2:c2.st,mecha:+(c2.fuse||0).toFixed(1)};
      /* lista y reset */
      const L0=GRAN.lista.length;for(let i=0;i<3;i++)GRAN.lanzar({pos:new V(-345+i,1.5,607),vel:new V(0,3,0),mecha:3,de:'soldado'});const L1=GRAN.lista.length,mismo=GRAN.lista===GRAN.lista;
      window.__run(.2,()=>{P.hp=100;});const t1=GRAN.lista.map(g=>+g.t.toFixed(3));
      GRAN.lanzar({pos:new V(-345,floorAt(-345,612)+R,612),vel:new V(0,0,0),mecha:.05,de:'soldado'});window.__run(.1,()=>{P.hp=100;});
      const antes=GRAN.estado();GRAN.reset();const despues=GRAN.estado();
      /* fondo común: 8 y la novena da null */
      let nulas=0;for(let i=0;i<9;i++){if(!GRAN.lanzar({pos:new V(-345,3,607),vel:new V(0,0,0),mecha:5,de:'soldado'}))nulas++;}const llenas=GRAN.lista.length;GRAN.reset();
      return {libre,tapado,autoTapa,bichos,autos,explosiones:window.__ex.slice(0,3),totalEx:window.__ex.length,lista:{L0,L1,t1,mismo},reset:{antes,despues},fondo:{llenas,nulas}};})()`);
    log('p4',JSON.stringify(out.p4));
    /* ---------- 5. costo ---------- */
    await h.ev(`(()=>{resetGame();running=true;return 1;})()`);await h.alReten();await h.step(.2);
    out.p5=await h.ev(`(()=>{const V=THREE.Vector3;intermission=1e9;
      const S=new V(-405,floorAt(-405,606)+1.75,606);
      for(let i=0;i<4;i++){const r=GRAN.arco(S,new V(-420-i*4,floorAt(-420-i*4,603+i*3),603+i*3));GRAN.lanzar({pos:S,vel:r.vel,mecha:9,de:'soldado'});}
      GRAN.update(1/60);const tv=[];let ac=0;for(let i=0;i<240;i++){const a=performance.now();GRAN.update(1/60);const b=performance.now()-a;tv.push(b);ac+=b;}
      const vuelo=tv.slice(0,150),quietas=tv.slice(180),ord=tv.slice().sort((a,b)=>a-b);
      const avg=a=>+(a.reduce((x,y)=>x+y,0)/a.length).toFixed(4);
      GRAN.reset();
      const ta=[],okn=[];for(let i=0;i<20;i++){const d=8+22*Math.random(),an=Math.PI*(.5+Math.random());const x=S.x+Math.cos(an)*d,z=Math.min(615,Math.max(599,S.z+Math.sin(an)*d*.4));
        const a=performance.now();const r=GRAN.arco(S,new V(x,floorAt(x,z),z));ta.push(performance.now()-a);okn.push(r.ok);}
      const tc=[];for(let i=0;i<20;i++){const a=performance.now();GRAN.arco(S,new V(-420,floorAt(-420,606),606));tc.push(performance.now()-a);}
      return {update4:{medio:avg(tv),vuelo:avg(vuelo),quietas:avg(quietas),p99:+ord[237].toFixed(3),max:+Math.max(...tv).toFixed(3)},arco20:{total:+ta.reduce((x,y)=>x+y,0).toFixed(2),medio:avg(ta),max:+Math.max(...ta).toFixed(2),ok:okn.filter(Boolean).length},arcoCache:{medio:avg(tc.slice(1))}};})()`);
    log('p5',JSON.stringify(out.p5));
    }
    if(SHOTS){
      /* ---------- 6. capturas ---------- */
      await h.ev(`(()=>{resetGame();running=true;return 1;})()`);await h.alReten();await h.step(.2);
      await h.ev(`(()=>{over=false;$('#scr-over').hidden=true;const V=THREE.Vector3;intermission=1e9;const gx=-392,gz=609,R=GRAN.TUNE.R;
        GRAN.lanzar({pos:new V(gx,floorAt(gx,gz)+.5,gz),vel:new V(0,0,0),mecha:6,de:'soldado'});
        window.__run(1.0,()=>{P.hp=100;P.pos.set(gx+2.2,floorAt(gx+2.2,gz+.6),gz+.6);P.vel.set(0,0,0);P.yaw=Math.atan2(2.2,.6);P.pitch=-.62;});return 1;})()`);
      /* que el pitido (y la luz) acabe de sonar */
      await h.ev(`(()=>{let k=0;while(k<90){window.__run(1/60,()=>{P.hp=100;});k++;if(GRAN.lista[0]&&GRAN.lista[0].luz>.8)break;}return 1;})()`);
      await h.shot(__dirname+'/cap_granada.png');log('cap1');
      await h.ev(`(()=>{GRAN.lista[0].t=.02;window.__run(4/60,()=>{P.hp=100;});return GRAN.estado();})()`);
      await h.shot(__dirname+'/cap_explosion.png');log('cap2');
    }
  }catch(e){out.error=String(e&&e.stack||e).slice(0,1500);}
  finally{out.errors=h.errors.slice(0,12);console.log('RESULT '+JSON.stringify(out));await h.close();log('cerrado');}
})();
