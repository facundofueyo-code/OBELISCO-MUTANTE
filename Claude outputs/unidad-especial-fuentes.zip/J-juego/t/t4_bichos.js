// Prueba 4: retén con bichos, 90 s. Bichos contra soldados y soldados contra bichos; nadie trabado; sin errores.
const H=require('../../harness.js'),fs=require('fs');
const INST=require('./inst.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
const OUT=process.argv[3]||__dirname+'/t4.json';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto');const R={};const ev=c=>h.ev(c);
  try{
    await h.start();await ev("RETEN.ir({bichos:true});1");await ev(INST);
    await ev(`(()=>{window.__inmortal=true;window.__B={herirBicho:0,danoBicho:0,bichosMuertosSold:0,soldHeridosBicho:0,danoASold:0};
      const E=UEG.ENV,hb=E.herirBicho;E.herirBicho=(r,d,x,z)=>{__B.herirBicho++;__B.danoBicho+=d;const vivo=r&&r.hp>0;hb(r,d,x,z);if(vivo&&r.hp<=0)__B.bichosMuertosSold++;};
      const e0=E.evento;E.evento=(n,d)=>{if(n==='herido'&&d.de==='bicho'){__B.soldHeridosBicho++;__B.danoASold+=d.dano;}e0(n,d);};
      window.__M=[];return 1;})()`);
    for(let k=0;k<90;k++){
      await h.step(1,1/60,"__fich()");
      await ev(`__M.push([+T.toFixed(1),UE.soldados.map(s=>[s.id,+s.x.toFixed(2),+s.z.toFixed(2),s.vivo?1:0,s.estado,s.blanco||'']),enemies.map(e=>[e.id||0,+e.obj.position.x.toFixed(1),+e.obj.position.z.toFixed(1),e.type,e.tg?1:0]),wave]);1`);
    }
    R.B=await ev("__B");R.L=await ev("({bala:__L.bala,ev:__L.ev,fichMax:__L.fichMax,expl:__L.expl.length,radio:__L.radio.length,radios:__L.radio.slice(-12).map(r=>r[1]+': '+r[3])})");
    R.M=await ev("__M");
    R.fin=await ev("({T:+T.toFixed(1),wave,bichos:enemies.length,hp:Math.round(P.hp),running,sold:UE.soldados.map(s=>[s.nombre,s.vivo,Math.round(s.hp),s.estado]),est:UE.estado()})");
    lg('B',JSON.stringify(R.B));lg('fin',JSON.stringify(R.fin));
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(OUT,JSON.stringify(R));
  await h.close();lg('cerrado');
})();
