
/* ====================================================================================
   ESQUELETO
   Huesos "planos": todos cuelgan del mismo grupo y en cada cuadro se les escribe la
   transformación en el espacio del modelo. La jerarquía la resolvemos nosotros (PADRE/OFF),
   así podemos mezclar poses, hacer IK y soltar el arma sin pelear con la de Three.
   En la pose de enlace todos los huesos tienen rotación identidad y están en su articulación:
   la geometría se arma directamente en esa pose (brazos colgando, palmas hacia el muslo).
   Los huesos que nacen en el origen (arma, cargador, FX…) tienen su geometría en coordenadas
   propias: el arma apunta a +Z con el origen en la cantonera.
   ==================================================================================== */
const HUESOS=[
  /* nombre        padre          articulación (x,y,z) */
  ['cadera',     null,          0,    .975,  0],
  ['columna',    'cadera',      0,    1.10, -.005],
  ['pecho',      'columna',     0,    1.27, -.01],
  ['cuello',     'pecho',       0,    1.505,-.015],
  ['cabeza',     'cuello',      0,    1.585, 0],
  ['brazoI',     'pecho',       .19,  1.45, -.025],
  ['antebrazoI', 'brazoI',      .19,  1.15, -.025],
  ['manoI',      'antebrazoI',  .19,  .885, -.025],
  ['dedosI',     'manoI',       .19,  .79,  -.025],   /* nudillos: falanges proximales */
  ['dedosI2',    'dedosI',      .19,  .745, -.025],   /* falanges medias y distales */
  ['brazoD',     'pecho',      -.19,  1.45, -.025],
  ['antebrazoD', 'brazoD',     -.19,  1.15, -.025],
  ['manoD',      'antebrazoD', -.19,  .885, -.025],
  ['indiceD',    'manoD',      -.19,  .79,   .005],   /* índice derecho: fuera del gatillo o adentro */
  ['musloI',     'cadera',      .095, .93,   0],
  ['piernaI',    'musloI',      .095, .50,   0],
  ['pieI',       'piernaI',     .095, .085,  0],
  ['punteraI',   'pieI',        .095, .025,  .135],
  ['musloD',     'cadera',     -.095, .93,   0],
  ['piernaD',    'musloD',     -.095, .50,   0],
  ['pieD',       'piernaD',    -.095, .085,  0],
  ['punteraD',   'pieD',       -.095, .025,  .135],
  /* sueltos (origen propio) */
  ['arma',null,0,0,0],['cargador',null,0,0,0],['corredera',null,0,0,0],['bipode',null,0,0,0],
  ['granada',null,0,0,0],['vaina1',null,0,0,0],['vaina2',null,0,0,0],
  ['antena1',null,0,0,0],['antena2',null,0,0,0],['antena3',null,0,0,0],
  ['haz',null,0,0,0],['fogonazo',null,0,0,0],['laser',null,0,0,0],['laserPunto',null,0,0,0],['led',null,0,0,0]
];
const NH=HUESOS.length,H={},PADRE=[],BIND=[],OFF=[];
HUESOS.forEach((h,i)=>{H[h[0]]=i;});
HUESOS.forEach((h,i)=>{PADRE[i]=h[1]===null?-1:H[h[1]];BIND[i]=new V3(h[2],h[3],h[4]);});
HUESOS.forEach((h,i)=>{OFF[i]=PADRE[i]<0?BIND[i].clone():BIND[i].clone().sub(BIND[PADRE[i]]);});
const NCUERPO=H.punteraD+1;                 /* los primeros NCUERPO huesos forman el cuerpo */
/* inversas de enlace: solo traslación (rotación identidad en la pose de enlace) */
const INVERSAS=BIND.map(b=>new M4().makeTranslation(-b.x,-b.y,-b.z));

/* largos de los segmentos (salen de las articulaciones de arriba) */
const L_BRAZO=.30,L_ANTEBRAZO=.265,L_MUSLO=.43,L_PIERNA=.415;
const ALTO_TOBILLO=.085;                     /* tobillo sobre la suela con el pie plano */

/* esferas de impacto: [hueso, x,y,z en el marco del hueso, radio, parte]. Un 10 % más grandes
   que el cuerpo; se recalculan solo cuando alguien pregunta (u.rayo) */
const ESFERAS=[
  ['cabeza',0,.085,.012,.135,'cabeza'],['cuello',0,.035,0,.075,'cabeza'],
  ['pecho',0,.07,.015,.205,'torso'],['pecho',0,.19,-.005,.175,'torso'],['columna',0,.06,0,.185,'torso'],['cadera',0,-.03,-.005,.195,'torso'],
  ['brazoI',0,-.08,0,.075,'brazo'],['brazoI',0,-.21,0,.065,'brazo'],['antebrazoI',0,-.07,0,.06,'brazo'],['antebrazoI',0,-.19,0,.052,'brazo'],['manoI',0,-.07,0,.058,'brazo'],
  ['brazoD',0,-.08,0,.075,'brazo'],['brazoD',0,-.21,0,.065,'brazo'],['antebrazoD',0,-.07,0,.06,'brazo'],['antebrazoD',0,-.19,0,.052,'brazo'],['manoD',0,-.07,0,.058,'brazo'],
  ['musloI',0,-.1,0,.105,'pierna'],['musloI',0,-.3,0,.088,'pierna'],['piernaI',0,-.1,0,.075,'pierna'],['piernaI',0,-.3,0,.066,'pierna'],['pieI',0,-.03,.06,.078,'pierna'],
  ['musloD',0,-.1,0,.105,'pierna'],['musloD',0,-.3,0,.088,'pierna'],['piernaD',0,-.1,0,.075,'pierna'],['piernaD',0,-.3,0,.066,'pierna'],['pieD',0,-.03,.06,.078,'pierna']
].map(e=>({b:H[e[0]],o:new V3(e[1],e[2],e[3]),r:e[4],parte:e[5]}));
