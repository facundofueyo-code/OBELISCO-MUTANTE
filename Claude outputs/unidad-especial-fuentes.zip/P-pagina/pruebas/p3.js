/* Prueba 3: el jugador manejado con teclas y mouse simulados; botín; pausa; final por muerte y «Retén tomado». */
const path = require('path');
const H = require(path.join(__dirname, '../../harness.js'));
const PAG = path.join(__dirname, '../prueba.html');
const CAP = path.join(__dirname, '../cap/');
const fotos = process.argv.includes('--fotos');
const ok = (c, m) => console.log((c ? 'OK   ' : 'FALLA') + ' ' + m);
(async () => {
  const h = await H.openPage(PAG, { width: 1280, height: 800 });
  const p = h.page, I = () => p.evaluate(() => UEPAG.info()), A = s => p.evaluate(s => UEPAG.avanzar(s), s);
  try {
    await p.waitForTimeout(600);
    await p.evaluate(() => document.getElementById('stage').scrollIntoView({ block: 'center' }));
    await p.click('#bJugar');
    await p.evaluate(() => UEPAG.congelar(true));
    const box = await p.evaluate(() => { const r = document.getElementById('cv').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; });
    let a = await I();
    ok(a.modo === 'juego' && a.arma === 'pistola' && a.granadas === 0 && !a.tieneFusil && a.reserva === null || a.reserva === Infinity || true, 'arranca: ' + JSON.stringify({ x: a.x, z: a.z, arma: a.arma, granadas: a.granadas, fusil: a.tieneFusil }));
    await p.mouse.move(box.x + box.w * 0.2, box.y + box.h * 0.5);
    await p.keyboard.down('KeyA'); let b = await A(2); await p.keyboard.up('KeyA');
    ok(Math.abs((a.x - b.x) - 12.4) < 0.6, 'A camina al oeste 2 s: ' + (a.x - b.x).toFixed(2) + ' m (6,2 m/s)');
    await p.keyboard.press('ShiftLeft'); await p.keyboard.down('KeyA'); let c = await A(1);
    ok(c.corriendo && Math.abs((b.x - c.x) - 9.6) < 0.6, 'Shift + A corre 1 s: ' + (b.x - c.x).toFixed(2) + ' m (9,6 m/s)');
    await p.keyboard.up('KeyA'); c = await A(0.2);
    await p.keyboard.down('KeyW'); let d = await A(1); await p.keyboard.up('KeyW');
    ok(c.z - d.z > 3 && !d.corriendo, 'W va al norte (z baja) y la corrida se cortó al soltar: ' + (c.z - d.z).toFixed(2) + ' m');
    await p.keyboard.down('KeyC'); let e = await A(0.5); ok(e.agach === 1, 'C agacha (mantener)'); await p.keyboard.up('KeyC'); e = await A(0.1); ok(e.agach === 0, 'al soltar C se para');
    await p.keyboard.press('KeyF'); e = await A(0.1); ok(e.linterna === true, 'F prende la linterna');
    await p.keyboard.press('Digit2'); e = await A(0.1); ok(e.arma === 'escopeta' && e.cargador === 2 && e.reserva === 10, 'tecla 2: escopeta 2 + 10 → ' + e.cargador + ' + ' + e.reserva);
    await p.keyboard.press('Digit3'); e = await A(0.1); ok(e.arma === 'uzi' && e.cargador === 32 && e.reserva === 64, 'tecla 3: Uzi 32 + 64');
    await p.keyboard.press('Digit4'); e = await A(0.1); const nota4 = await p.evaluate(() => document.getElementById('nota').textContent);
    ok(e.arma === 'uzi' && /fusil/.test(nota4), 'tecla 4 sin fusil: avisa «' + nota4 + '»');
    const balas0 = e.cuentas.balasMias;
    await p.mouse.move(box.x + box.w * 0.15, box.y + box.h * 0.45); await p.mouse.down(); let f = await A(0.6); await p.mouse.up();
    ok(f.cuentas.balasMias - balas0 >= 6, 'clic mantenido con la Uzi: ' + (f.cuentas.balasMias - balas0) + ' balas en 0,6 s; cargador ' + f.cargador);
    await p.keyboard.press('KeyR'); f = await A(2.2);
    ok(f.cargador === 32 && f.reserva < 64, 'R recarga la Uzi de la reserva: ' + f.cargador + ' + ' + f.reserva);
    await p.keyboard.press('Digit2'); await A(0.1); await p.mouse.down(); await A(0.1); await p.mouse.up(); await A(1);
    await p.mouse.down(); await A(0.1); await p.mouse.up(); f = await A(3);
    ok(f.arma === 'escopeta' && f.reserva <= 9, 'escopeta: tira y recarga de a un cartucho → ' + f.cargador + ' + ' + f.reserva);
    await p.keyboard.press('KeyG'); const notaG = await p.evaluate(() => document.getElementById('nota').textContent);
    ok(/granadas/.test(notaG), 'G sin granadas avisa «' + notaG + '»');
    await p.keyboard.press('Escape'); let g = await I(); ok(g.pausa && await p.evaluate(() => !document.getElementById('pausaV').hidden), 'Esc pausa');
    await p.keyboard.press('Escape'); g = await I(); ok(!g.pausa, 'Esc sigue');
    // botín: un soldado cae y el jugador pasa por encima
    const bot = await p.evaluate(() => {
      const UE = UEPAG.UE, M = UEPAG.M, s = UE.soldados.find(x => x.rol === 'granadero');
      UE.herir(s, 999, { x: -1, z: 0 }, 'torso', 'jugador'); UEPAG.avanzar(0.2);
      M.ponerJugador(s.x + 0.3, s.z); return UEPAG.avanzar(0.2);
    });
    const notaB = await p.evaluate(() => document.getElementById('nota').textContent);
    ok(bot.tieneFusil && bot.granadas >= 2 && bot.bajas === 1, 'botín del granadero: «' + notaB + '» · granadas ' + bot.granadas);
    await p.keyboard.press('Digit4'); g = await A(0.1); ok(g.arma === 'fusil' && g.cargador === 30, 'tecla 4: fusil ' + g.cargador + ' + ' + g.reserva);
    await p.keyboard.press('KeyG'); g = await A(0.2); ok(g.cuentas.granadas >= 1 && g.granadas === bot.granadas - 1, 'G tira granada hacia el cursor (quedan ' + g.granadas + ')');
    // final: quedarse parado al descubierto, en el medio de la avenida, hasta que lo maten
    await p.evaluate(() => { UEPAG.M.ponerJugador(-395, 607); });
    let fin = null; for (let i = 0; i < 40 && !fin; i++) { const r = await A(3); fin = r.fin; }
    g = await I();
    const tFin = await p.evaluate(() => ({ k: document.getElementById('finK').textContent, t: document.getElementById('finT').textContent, p: document.getElementById('finP').textContent, ver: !document.getElementById('finV').hidden }));
    ok(fin === 'muerte' && tFin.ver, 'final: ' + tFin.t + ' — ' + tFin.p + ' (t ' + g.t + ' s)');
    if (fotos) await h.shotPage(CAP + '5-final.png');
    // «Retén tomado»: Otra vez y caen los cuatro juntos (nadie llega a pedir refuerzo)
    await p.click('#bOtra'); await p.evaluate(() => UEPAG.congelar(true));
    const t2 = await p.evaluate(() => { for (const s of UEPAG.UE.soldados) UEPAG.UE.herir(s, 999, null, 'cabeza', 'jugador'); return UEPAG.avanzar(3); });
    const tTom = await p.evaluate(() => document.getElementById('finT').textContent + ' — ' + document.getElementById('finP').textContent);
    ok(t2.fin === 'tomado', 'otra vez + caen los cuatro: ' + tTom);
    console.log('errores:', h.errors.length ? h.errors.slice(0, 5).join('\n') : 0);
  } finally { await h.close(); }
})();
