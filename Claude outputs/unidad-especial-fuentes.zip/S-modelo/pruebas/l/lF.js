const L4=require('./l4.js');const solo=L4.vistas[6].fn2,limpiar=L4.limpiar;
const v=(rol,pose,t,az,el,txt,o={})=>Object.assign({rol,pose,t,az,el,dist:.8,obj:[0,1.62,0],txt},o);
module.exports={cols:4,vistas:[
  v('todos','Apunta',2,.45,.12,'los cuatro de noche, con linternas',{luz:true,obj:[-.3,.9,-.4],dist:8,
    fn:I=>{const n=UEM.calentar(I.scene,true);UEM.calentar(I.scene,false);window.__calentar=n;}}),
  v('todos','Apunta',2,.2,.02,'desde el jugador (ojos a 1,6 m)',{luz:true,obj:[-.3,1.3,-.4],dist:9}),
  v('todos','Camina',2.2,.3,.25,'los cuatro caminando (noche)',{luz:true,obj:[0,.9,-.6],dist:9}),
  v('todos','De pie',2,1.0,.05,'siluetas de perfil (luz plena)',{plena:true,obj:[-.3,.9,-.4],dist:8}),
  v('jefe','De pie',.5,1.57,.0,'fusil y granada',{plena:true,obj:[0,1.02,-.12],dist:2.15,fn2:solo}),
  v('asalto','De pie',.5,1.57,.0,'escopeta',{plena:true,obj:[0,.98,-.07],dist:2.15,fn2:solo}),
  v('tirador','De pie',.5,1.57,.0,'fusil de tirador (bípode plegado)',{plena:true,obj:[0,1.0,.07],dist:2.7,fn2:solo}),
  v('jefe','Dispara',.21,1.15,.05,'ráfaga: fogonazo y vaina',{obj:[-.1,1.35,.55],dist:1.9,fn:limpiar})]};
