
/* ====================================================================================
   MATERIALES Y GEOMETRÍAS COMPARTIDAS
   Un material para el cuerpo (color por vértice; aspereza, metal y emisión también por vértice
   en el atributo 'uem') y uno aditivo para los efectos. Se crean una vez y los comparten todos.
   ==================================================================================== */
const MAT={};
function parcheUem(sh){
  sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nattribute vec3 uem;\nvarying vec3 vUem;')
    .replace('#include <begin_vertex>','#include <begin_vertex>\n\tvUem = uem;');
  sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nvarying vec3 vUem;')
    .replace('#include <roughnessmap_fragment>','float roughnessFactor = roughness * vUem.x;')
    .replace('#include <metalnessmap_fragment>','float metalnessFactor = metalness * vUem.y;')
    .replace('#include <emissivemap_fragment>','totalEmissiveRadiance += diffuseColor.rgb * vUem.z;');
}
const FX_VS=`
#include <common>
#include <skinning_pars_vertex>
#include <fog_pars_vertex>
attribute vec3 uem;
varying vec3 vCol; varying vec3 vN; varying vec3 vV; varying vec2 vModo;
void main(){
  #include <beginnormal_vertex>
  #include <skinbase_vertex>
  #include <skinnormal_vertex>
  #include <defaultnormal_vertex>
  #include <begin_vertex>
  #include <skinning_vertex>
  #include <project_vertex>
  #include <fog_vertex>
  vCol = color; vN = transformedNormal; vV = -mvPosition.xyz; vModo = uem.xy;
}`;
const FX_FS=`
#include <common>
#include <fog_pars_fragment>
uniform float uInt;
varying vec3 vCol; varying vec3 vN; varying vec3 vV; varying vec2 vModo;
void main(){
  vec3 n = normalize(vN), v = normalize(vV);
  float d = dot(n, v), k = 1.0;
  if (vModo.x > 1.5) k = pow(max(d, 0.0), vModo.y);          /* resplandor: solo de frente */
  else if (vModo.x > 0.5) k = pow(abs(d), vModo.y);          /* volumen: se apaga en los bordes */
  vec3 c = vCol * k * uInt;
  #ifdef USE_FOG
    #ifdef FOG_EXP2
      float f = 1.0 - exp(-fogDensity * fogDensity * fogDepth * fogDepth);
    #else
      float f = smoothstep(fogNear, fogFar, fogDepth);
    #endif
    c *= 1.0 - f * 0.85;                                     /* la niebla lo apaga menos que a un objeto: lo dispersa */
  #endif
  gl_FragColor = vec4(c, 1.0);
}`;
function materiales(){
  if(MAT.cuerpo)return MAT;
  const m=new THREE.MeshStandardMaterial({vertexColors:true,roughness:1,metalness:1});
  m.skinning=true;m.onBeforeCompile=parcheUem;m.customProgramCacheKey=()=>'uem-piel';m.name='UEM cuerpo';
  const g=new THREE.MeshStandardMaterial({vertexColors:true,roughness:1,metalness:1});
  g.onBeforeCompile=parcheUem;g.customProgramCacheKey=()=>'uem-suelto';g.name='UEM suelto';
  const f=new THREE.ShaderMaterial({name:'UEM efectos',uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.fog,{uInt:{value:1}}]),
    vertexShader:FX_VS,fragmentShader:FX_FS,vertexColors:true,fog:true,transparent:true,depthWrite:false,
    blending:THREE.AdditiveBlending,side:THREE.DoubleSide});
  f.skinning=true;
  MAT.cuerpo=m;MAT.suelto=g;MAT.fx=f;
  return MAT;
}

/* ---------- efectos: todo lo que brilla, en una sola malla aditiva atada a sus huesos ---------- */
function armarFx(G,rol,ficha){
  G.lado(1).varia(0);
  const radial=(R,f0,f1=0)=>(x,y,z)=>lerp(f0,f1,Math.min(1,Math.hypot(x,y)/R));
  /* linterna: cono exterior de ~14 m y núcleo más angosto, más el deslumbre en el foco */
  if(ficha.luz){
    G.hueso('haz').mat('fxHaz',.34).tinte((x,y,z)=>z<1.5?lerp(1,.62,z/1.5):lerp(.62,0,(z-1.5)/12.5));
    enZ(G,0,0,0).cil(.022,.25,1.5,12,0);enZ(G,0,0,1.5).cil(.25,1.9,12.5,12,0);
    G.mat('fxNucleo',.42).tinte((x,y,z)=>z<1?lerp(1,.6,z):lerp(.6,0,(z-1)/8));
    enZ(G,0,0,0).cil(.016,.075,1,10,0);enZ(G,0,0,1).cil(.075,.5,8,10,0);
    G.mat('fxDeslumbre',4).tinte(radial(.07,1));enZ(G,0,0,.004).disco(.07,12);
    G.mat('fxHalo',.9).tinte(radial(.34,1));enZ(G,0,0,.006).disco(.34,12);
    G.tinte(null);
  }
  /* fogonazo: estrella de tres hojas hacia adelante y un disco de frente */
  G.hueso('fogonazo');
  for(let i=0;i<3;i++){const a=i*PI/3;G.mat('fxFogonazo',3).tinte((x,y,z)=>lerp(1,.05,z/.24));
    G.en(0,0,0,0,0,a).crudo([0,0,0, .04,0,.08, 0,0,.24, -.04,0,.08],[0,1,2,0,2,3]);}
  G.mat('fxFogoFrente',3).tinte(radial(.09,1));enZ(G,0,0,.02).disco(.09,10);G.tinte(null);
  /* láser: hilo fino y un halo, de z=0 a z=1 (el hueso se estira hasta el punto) */
  if(ficha.laser){
    G.hueso('laser').mat('fxLaser',1.6);enZ(G,0,0,0).cil(.0045,.0045,1,5,0);
    G.mat('fxLaserHalo',.32);enZ(G,0,0,0).cil(.02,.02,1,6,0);
    G.hueso('laserPunto');
    for(const [rx,ry] of [[0,0],[PI/2,0],[0,PI/2]]){G.mat('fxPunto',2.4).tinte(radial(.035,1));G.en(0,0,0,rx,ry,0).disco(.035,10);}
    G.tinte(null);
  }
  /* luz roja de la nuca */
  G.hueso('led');
  for(const [rx,ry] of [[0,0],[PI/2,0],[0,PI/2]]){G.mat('fxLed',2.2).tinte(radial(.026,1));G.en(0,0,0,rx,ry,0).disco(.026,8);}
  G.tinte(null);
  /* reflejo frío de los lentes: se ve cuando te miran */
  G.hueso('cabeza');
  for(const s of [1,-1]){G.lado(s);const dx=.30,l=Math.hypot(dx,1),ux=dx/l,uz=1/l,cx=.037,cy=1.69,cz=.103;
    G.mat('fxLente',1.1).tinte(radial(.025,1,.25));G.dir(cx+ux*.024,cy,cz+uz*.024,ux,0,uz).disco(.025,10);}
  G.lado(1).tinte(null).varia(.06);
}

/* geometría por rol (se arma una vez y se comparte) */
const GEO={};
function geometriaDe(rol){
  if(GEO[rol])return GEO[rol];
  const G=Constructor(H);
  torso(G,rol);brazo(G,1,rol);brazo(G,-1,rol);mano(G,1);mano(G,-1);pierna(G,1);pierna(G,-1);cabeza(G,rol);
  const arma=ROLES[rol].arma,ficha=arma==='escopeta'?escopeta(G):arma==='tirador'?tirador(G):fusil(G);
  granadaGeo(G,'granada');
  /* vainas: latón (o cartucho rojo en la escopeta) */
  for(const v of ['vaina1','vaina2']){G.hueso(v);
    if(arma==='escopeta'){G.mat('cart').en(0,-.023,0).cil(.0095,.0095,.046,6,1);G.mat('laton').en(0,.023,0).cil(.0098,.0098,.012,6,2);}
    else G.mat('laton').en(0,-.022,0).cil(.0048,.0042,.045,6,2);}
  if(rol==='jefe'){  /* antena de látigo: tres tramos de 0,34 m sobre +Y */
    G.hueso('antena1').mat('goma').en(0,0,0).cil(.0075,.0055,.06,6,1);G.mat('arma').en(0,.05,0).cil(.0062,.0055,.29,5,0);
    G.hueso('antena2').en(0,0,0).cil(.0055,.0045,.34,5,0);
    G.hueso('antena3').en(0,0,0).cil(.0045,.003,.33,5,0);G.mat('goma').en(0,.335,0).esfera(.007,.007,.007,6,3);
  }
  const cuerpo=G.fin();cuerpo.boundingSphere=new THREE.Sphere(new V3(0,.6,0),2.4);cuerpo.boundingBox=new THREE.Box3(new V3(-2.4,-.2,-2.4),new V3(2.4,2.2,2.4));
  const F=Constructor(H);armarFx(F,rol,ficha);const fx=F.fin();fx.boundingSphere=new THREE.Sphere(new V3(0,.6,0),60);
  return GEO[rol]={cuerpo,fx,ficha,tris:cuerpo.userData.tris,trisFx:fx.userData.tris};
}
let GEO_GRANADA=null;
function granada(){
  materiales();
  if(!GEO_GRANADA){const G=Constructor(H);granadaGeo(G,'cadera');GEO_GRANADA=G.fin();
    GEO_GRANADA.deleteAttribute('skinIndex');GEO_GRANADA.deleteAttribute('skinWeight');GEO_GRANADA.computeBoundingSphere();}
  const m=new THREE.Mesh(GEO_GRANADA,MAT.suelto);m.castShadow=true;m.name='UEM granada';return m;
}
