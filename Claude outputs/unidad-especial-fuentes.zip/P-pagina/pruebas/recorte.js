/* ¿El mundo arranca y corre igual con el mapa recortado? Compara foto() segundo a segundo. */
const fs = require('fs'), R = '../../';
const { crearUE, UE_TUNE } = require(R + 'A-ia/ue_ia.js');
const { crearMundo } = require(R + 'A-ia/sim/mundo.js');
const { crearJugadores } = require(R + 'A-ia/sim/jugadores.js');
const { desarmarMapa } = require('../src/mapa.js');
const entero = JSON.parse(fs.readFileSync(__dirname + '/../../mapa-reten.json', 'utf8'));
const recorte = desarmarMapa(JSON.parse(fs.readFileSync(__dirname + '/mapa_recortado.json', 'utf8')));
function correr(mapa, sem, esc, tmax) {
  const M = crearMundo(mapa, { semilla: sem }); const UE = crearUE(M.ENV, UE_TUNE); M.conectar(UE); M.armarReten();
  const JG = crearJugadores(M, UE); const bot = esc === 'f0' ? JG.decente({ inicio: { x: -326, z: 606 } }) : null;
  if (esc === 'bichos') M.soltarBichos(6, { desde: 3 });
  const fotos = []; let evs = [], nEv = 0, dt = 1 / 60, sig = 0;
  while (M.t < tmax) {
    if (bot) bot.paso(dt, evs); M.paso(dt); evs = M.sacarEventos(); nEv += evs.length;
    if (M.t >= sig) { sig += 1; const f = M.foto();
      fotos.push(JSON.stringify([f.jugador.x.toFixed(4), f.jugador.z.toFixed(4), f.jugador.hp, f.soldados.map(s => [s.x.toFixed(4), s.z.toFixed(4), s.hp, s.estado]), f.bichos.length, nEv])); }
    if (!M.jugador.vivo && esc === 'f0') break;
  }
  return { fotos, t: M.t, vivo: M.jugador.vivo, quedan: UE.estado().quedan };
}
for (const [esc, sem, tmax] of [['quieto', 1, 40], ['f0', 1, 150], ['f0', 2, 150], ['f0', 3, 150], ['bichos', 4, 60]]) {
  const a = correr(entero, sem, esc, tmax), b = correr(recorte, sem, esc, tmax);
  let d = -1; for (let i = 0; i < Math.max(a.fotos.length, b.fotos.length); i++) if (a.fotos[i] !== b.fotos[i]) { d = i; break; }
  console.log(esc, 'semilla', sem, '→', d < 0 ? 'IGUAL' : 'distinto desde t=' + d + ' s', '| entero: t', a.t.toFixed(1), 'vivo', a.vivo, 'quedan', a.quedan, '| recorte: t', b.t.toFixed(1), 'vivo', b.vivo, 'quedan', b.quedan);
}
