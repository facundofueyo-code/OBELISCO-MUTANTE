"""Recorta mapa-reten.json a la zona del retén y lo comprime (tramos repetidos + base64).

Recorte: x en [-570, -296), z en [536, 694). Alcanza para el retén, las bocas del subte,
el pasaje del Barolo y la vuelta por Hipólito Yrigoyen.

Formato de cada arreglo (B, Hh, G): una lista de tramos «valor, largo», con el largo en
varint (7 bits por byte, el bit alto dice que sigue), pasada a base64. La página la
desarma con `desarmarMapa` (src/tablero.js) y rearma {X0,Z0,W,H,B,Hh,G,cars,sub,mh}.
"""
import base64
import json

X0, X1, Z0, Z1 = -570, -296, 536, 694


def tramos(arr):
    out = bytearray()
    i, n = 0, len(arr)
    while i < n:
        v = arr[i]
        j = i
        while j < n and arr[j] == v:
            j += 1
        largo = j - i
        out.append(v)
        while True:
            b = largo & 0x7F
            largo >>= 7
            if largo:
                out.append(b | 0x80)
            else:
                out.append(b)
                break
        i = j
    return base64.b64encode(bytes(out)).decode('ascii')


def desarmar(txt, n):
    """Lo mismo que hace la página, para comprobar acá."""
    data = base64.b64decode(txt)
    out = []
    i = 0
    while i < len(data):
        v = data[i]
        i += 1
        largo, corr = 0, 0
        while True:
            b = data[i]
            i += 1
            largo |= (b & 0x7F) << corr
            corr += 7
            if not b & 0x80:
                break
        out.extend([v] * largo)
    assert len(out) == n, (len(out), n)
    return out


def recortar(ruta):
    m = json.load(open(ruta, encoding='utf-8'))
    W0 = m['W']
    w, h = X1 - X0, Z1 - Z0
    i0, j0 = X0 - m['X0'], Z0 - m['Z0']
    assert i0 >= 0 and j0 >= 0 and i0 + w <= W0 and j0 + h <= m['H']
    sub = {}
    for clave in ('B', 'Hh', 'G'):
        a = m[clave]
        sub[clave] = [a[(j0 + j) * W0 + i0 + i] for j in range(h) for i in range(w)]
    adentro = lambda o: X0 <= o['x'] < X1 and Z0 <= o['z'] < Z1
    autos = [{'id': c['id'], 'x': round(c['x'], 2), 'z': round(c['z'], 2), 'a': round(c['a'], 3),
              'L': c['L'], 'W': c['W'], 'H': c['H']} for c in m['cars'] if adentro(c)]
    comp = {'X0': X0, 'Z0': Z0, 'W': w, 'H': h,
            'B': tramos(sub['B']), 'Hh': tramos(sub['Hh']), 'G': tramos(sub['G']),
            'cars': autos,
            'sub': [s for s in m['sub'] if adentro(s)],
            'mh': [s for s in m['mh'] if adentro(s)]}
    for clave in ('B', 'Hh', 'G'):
        assert desarmar(comp[clave], w * h) == sub[clave]
    return comp, sub


if __name__ == '__main__':
    import sys
    comp, sub = recortar(sys.argv[1] if len(sys.argv) > 1 else '../../mapa-reten.json')
    txt = json.dumps(comp, separators=(',', ':'), ensure_ascii=False)
    print('bytes', len(txt), {k: len(comp[k]) for k in ('B', 'Hh', 'G')}, 'autos', len(comp['cars']))
