# PROGRESO — tarea F (efectos, sonido, avisos, vista táctica)

Estado: TERMINADO sobre la base 1.16.0. Ver INFORME.md.

## Archivos (todo en F-fx/)
- `mod_fx.js`        módulo: UESND, UEFX, UEHUD, UEDBG (va en /*UE:modulos*/)
- `patch_fx.py`      parche sobre base.html (CSS, HUD, capas, ayuda, enganches). Solo marcadores
- `t_juego.js`       pruebas adentro del juego 1.16.0 (arnés); resultados en `pruebas_juego.json`
- `juego_fx.html`    v116/base.html + parche (idéntico a lo que se probó en la última corrida)
- `capturas/j01–j03` en el juego · `capturas/p00–p10` página suelta (1.ª etapa)
- `prueba_fx.html` + `armar_prueba.py` + `t_humo.js`: página suelta (rearmada con el módulo nuevo, carga sin errores)
- `INFORME.md`       informe final (sección 8 de la SPEC + cómo está armado cada sonido)

## Hecho
- Etapa 1 (sesión anterior): módulo, parche y página suelta.
- Revisión (esta sesión): chispas sobre el piso real (calzada −0,15); escrituras al DOM solo si cambian;
  `recarga_jugador` como peligro; flecha de granada afuera del ícono; vista chica compacta (cabe a 720p sin tapar
  las armas, rótulos sin encimarse); tabla de la grande en un renglón; fondo de la grilla 2,4 → 0,2 ms;
  estados/órdenes reales de ue_ia.js; láser; UEB.estado acepta la forma de UE.estado() de la IA.
- 4 corridas completas en el juego (la última: 128 s, 0 errores). 5 imágenes miradas: j01 y j03 de la 1.ª corrida, j02 de la 1.ª, 2.ª y 3.ª. Las capturas finales (4.ª) no se miraron: entre la 3.ª y la 4.ª solo cambió la tabla de la grande (verificada midiendo el DOM: 8 filas de 19 px) y la lectura de UEB.estado.

## Falta (no bloquea)
- Escuchar los sonidos (no hay parlantes): ajustar CFG.vol y radioVol de oído.
