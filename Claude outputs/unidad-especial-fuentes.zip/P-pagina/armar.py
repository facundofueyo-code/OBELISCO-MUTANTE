#!/usr/bin/env python3
"""Arma la página de concepto de la Unidad Especial en UN archivo.

    python3 armar.py

Salidas (en esta carpeta):
  unidad-especial-concepto.html  la que se publica: Three.js r128 desde cdnjs
  prueba.html                    idéntica, pero carga ../three.r128.min.js (para probar sin red)

Entra: src/pagina.html (maquetado), src/estilo.css, src/*.js propios, el mapa recortado
(src/mapa.py) y, pegados tal cual, A-ia/ue_ia.js, A-ia/sim/mundo.js, A-ia/sim/jugadores.js,
S-modelo/ue_modelo.js y S-modelo/ue_visor.js.
"""
import json
import os
import re
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
EQUIPO = os.path.dirname(AQUI)
sys.path.insert(0, os.path.join(AQUI, 'src'))
import mapa  # noqa: E402

CDN = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js'
LOCAL = '../three.r128.min.js'
AJENOS = ['A-ia/ue_ia.js', 'A-ia/sim/mundo.js', 'A-ia/sim/jugadores.js', 'S-modelo/ue_modelo.js', 'S-modelo/ue_visor.js']
PROPIOS = ['src/sonido.js', 'src/tablero.js', 'src/visor.js', 'src/tarjetas.js']


def leer(ruta):
    with open(ruta, encoding='utf-8') as f:
        return f.read()


def script(nombre, codigo):
    if re.search(r'</script', codigo, re.I):
        raise SystemExit('ERROR: ' + nombre + ' tiene «</script» adentro')
    return '<script>\n/* ===== ' + nombre + ' ===== */\n' + codigo.rstrip() + '\n</script>'


def armar():
    pagina = leer(os.path.join(AQUI, 'src/pagina.html'))
    estilo = leer(os.path.join(AQUI, 'src/estilo.css'))
    comp, _ = mapa.recortar(os.path.join(EQUIPO, 'mapa-reten.json'))
    datos = ('/* mapa real recortado: x en [' + str(mapa.X0) + ', ' + str(mapa.X1) + '), z en [' + str(mapa.Z0) + ', ' + str(mapa.Z1)
             + '); B, Hh y G en tramos «valor, largo» y base64 (ver src/mapa.py) */\n'
             + 'const UE_MAPA_RECORTE = ' + json.dumps(comp, separators=(',', ':'), ensure_ascii=False) + ';\n'
             + leer(os.path.join(AQUI, 'src/mapa.js')))
    partes = [script(r, leer(os.path.join(EQUIPO, r))) for r in AJENOS]
    partes.append(script('mapa', datos))
    partes += [script(r, leer(os.path.join(AQUI, r))) for r in PROPIOS]
    cuerpo = pagina.replace('{{ESTILO}}', estilo.strip())
    salidas = {}
    for nombre, src in (('unidad-especial-concepto.html', CDN), ('prueba.html', LOCAL)):
        html = cuerpo.replace('{{SCRIPTS}}', '<script src="' + src + '"></script>\n' + '\n'.join(partes))
        assert html.startswith('<title>Unidad Especial</title>\n<style>'), 'tiene que empezar con <title> y <style>'
        for prohibido in (r'<!doctype', r'<html[\s>]', r'<head[\s>]', r'<body[\s>]', r'\balert\(', r'\bconfirm\(', r'\bprompt\('):
            if re.search(prohibido, html, re.I):
                print('OJO: aparece', prohibido, 'en', nombre)
        with open(os.path.join(AQUI, nombre), 'w', encoding='utf-8') as f:
            f.write(html)
        salidas[nombre] = len(html.encode('utf-8'))
    for n, b in salidas.items():
        print(n, round(b / 1024, 1), 'KB')


if __name__ == '__main__':
    armar()
