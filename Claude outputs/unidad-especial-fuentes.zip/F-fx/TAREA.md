# Tarea F — efectos, sonido, avisos en pantalla y vista táctica

Leé primero `../SPEC.md` entero (sobre todo 0, 1.3, 2, 3, 4.1, 4.4, 4.7, 7, 8 y 9). Tu carpeta es `F-fx/`.

## Qué tenés que lograr

Todo lo que hace que el jugador **entienda** la pelea contra los soldados. La IA va a ser «difícil pero justa» solo si el jugador ve y oye lo que pasa: de dónde le tiran, cuándo lo están viendo, que viene una granada, qué dicen por radio. Sos responsable de que esa información llegue clara, sin tapar la pantalla y sin romper el clima de terror.

Cuatro módulos, en un solo `mod_fx.js`, con un parche sobre `../base.html` (protocolo en 3.3):

1. `UEFX`: trazadoras, impactos, sangre.
2. `UESND`: disparos enemigos, balas que pasan cerca, radio, pasos y equipo.
3. `UEHUD`: subtítulos de radio, indicador de detección, dirección del daño, aviso de granada.
4. `UEDBG`: vista táctica (F2) para que Facu vea a la IA pensar.

Contratos en 4.4 de la SPEC. Lo que entregues lo va a llamar el integrador desde la IA: respetá las firmas.

## Antes de escribir

Leé en `../base-view.txt`: partículas y calcomanías (~7370–7390: `spawnPart`, `burst`, `addDecal`), chispas y humo del arma del jugador (~9555–9580), el audio completo (~7388–7430 y ~7562–7607: `AUD`, `auGate`, `auOneShot`, `noise`, `tone`, `S`, `sfx`), `vSfx` (~3293) como ejemplo de sonido con distancia, el HUD (HTML al principio del archivo y su CSS: `#hud`, `#feed`, `#announce`, `#hurt`, `#compass`, variables `--bone`, `--sodium`, `--bile`, tipografía `--hud`), el contador de FPS y el benchmark (final del archivo) como ejemplo de capa de diagnóstico con tecla propia.

## UEFX

- `trazadora(a,b,tipo)`: estela fina y brillante de `a` a `b`, aditiva, que dura 60–90 ms y se desvanece; un fondo común de 48 como máximo (una sola malla o `LineSegments` para todas: una llamada de dibujo). `tirador`: más gruesa y larga. Además, calculá la distancia de la cámara al segmento: si pasa a menos de 1,4 m y el tirador está a más de 6 m, llamá `UESND.silbido(pan)` con el lado por el que pasó.
- `impacto(p,n,mat)`: chispas en metal, polvo en pared y piso, usando las partículas del juego. Barato: va a haber muchos.
- `sangre(p,dir)`: salpicadura chica y oscura (roja, no verde: son personas).
- Sin luces reales. `update(dt)` va en `/*UE:fx*/`; `reset()` en `/*UE:reset*/`.

## UESND

Todo sintetizado, con las reglas de la sección 2.1 de la SPEC (`auOneShot`, `auGate`, nada de editar `sfx`).

- `disparo(tipo,pos)`: `fusil` seco y fuerte, `escopeta` grave, `tirador` un estampido con cola. **Con distancia**: volumen, filtro pasa-bajos que se cierra con los metros, retardo de `distancia/340` s, y paneo estéreo según dónde está respecto de adonde mira el jugador. A 80 m se tiene que oír lejano pero claro; a 10 m, que asuste. Con ocho tirando a la vez no tiene que saturar ni cortar: prioridad y tope por ventana.
- `silbido(pan)`: el chasquido y zumbido de una bala que pasa cerca.
- `radio(voz,dur,pos)`: chasquido de apertura, **voz ininteligible** (dientes de sierra con formantes que se mueven, pasada por un filtro de banda angosta de radio y algo de distorsión; `voz` 0…7 cambia el tono y el ritmo para distinguir quién habla), ruido de fondo y pitido de cierre. `dur` en segundos. Si viene `pos`, además se oye bajito desde ese lugar (la radio del soldado), con paneo: sirve para ubicarlos de oído.
- `pasos(pos,fuerza)`: borcego sobre asfalto mojado, audible hasta unos 14 m, con paneo. `equipo(pos)`: roce de correaje. `cuerpo(pos)`: un cuerpo que cae.
- Respetá la pausa (`/*UE:pausa*/`) si dejás algo sonando largo.

## UEHUD

Con el estilo del HUD del juego (mismas variables de color y tipografía). Todo dentro de `<!--UE:hud-->` salvo lo que deba verse siempre.

- `radio(quien,texto)`: subtítulo de **radio interceptada**. Abajo a la izquierda, arriba de la salud, sin tapar la mira: etiqueta chica `◉ RADIO`, nombre del que habla (`CENIZA 2`) y la frase. Hasta 3 líneas, la más nueva abajo; cada una dura según su largo (mínimo 2,2 s) y se va sola. Las de peligro (`¡Granada va!`) resaltadas. No uses el `#feed` existente: es de otra cosa.
- `alerta(nivel,ang,combate)`: **indicador de detección**. Un arco fino alrededor de la mira que se va llenando con `nivel` y apunta hacia `ang` (de dónde te están viendo). Vacío: invisible. Subiendo: color hueso. Lleno o `combate`: rojo, con un texto corto `TE VIERON` que aparece un instante la primera vez. Suave: nada de saltos entre cuadros.
- `golpe(ang)`: una cuña roja en el borde de un círculo alrededor del centro, del lado del que vino el daño; se desvanece en 0,8 s. Varias a la vez si pegan de varios lados.
- **Aviso de granada**: en `update(dt)`, si existe `GRAN` y hay granadas en `GRAN.lista` a menos de 12 m del jugador, un ícono de granada con una flecha hacia donde está y los metros, parpadeando más rápido cuanto menos falta. Si `GRAN` no existe, nada.
- `reset()` limpia todo.

Probá que se lea sobre fondo oscuro y sobre fondo claro (un farol, una explosión).

## UEDBG — vista táctica

Con **F2** se prende y se apaga (agregala en `/*UE:teclas*/` y en la ayuda de la pantalla de inicio: «F2 · Vista táctica: ver qué sabe y qué decide el escuadrón»). Es una herramienta para que Facu juzgue la IA: tiene que ser clara para alguien que no programa.

- Un `canvas` 2D en una esquina (unos 420 px), visto desde arriba, centrado en el jugador, con unos 70 m de radio y el norte arriba. Con **Shift+F2** pasa a grande (casi toda la pantalla, 110 m de radio) y vuelve.
- Fondo: la grilla de navegación del juego alrededor (`enB`/`enH` con `eCell`): libre, trepable y bloqueado en tres tonos. Dibujala en un lienzo aparte y rehacela solo cuando el jugador se movió más de 10 m.
- Encima, lo que devuelve `UEB.debug()` (estructura en 4.7): cada soldado con un color por rol, una flecha de rumbo, su nombre corto y su estado en palabras (`cubierto`, `flanquea`, `recarga`…); un anillo rojo en los que tienen **permiso de tirar a pegar**; su camino y su cobertura; el **último lugar conocido** del jugador como una cruz con el tiempo que tiene («hace 4 s»), bien visible, porque es la regla más importante; las granadas con su radio; el jugador real.
- Al costado o abajo, en texto: por escuadrón, estado, cuántos quedan, qué orden hay, si están sin jefe, cuánto falta para el refuerzo. Y una leyenda corta.
- Si `UEB.debug()` devuelve `null`, mostrá «sin escuadrón».
- Que no cueste casi nada apagada, y menos de 1 ms por cuadro prendida (dibujá a 15 cuadros por segundo si hace falta).

## Pruebas

1. **Página suelta de prueba** (`prueba_fx.html`, con `../three.r128.min.js`, sin el juego): una escena mínima donde se disparan trazadoras e impactos, y los cuatro elementos del HUD con datos de mentira (incluida una `UEB.debug()` falsa con 8 soldados en estados variados). Sacale capturas con `H.openPage` y miralas. Es la forma rápida de iterar lo visual.
2. **En el juego** (tu copia parcheada, con `../harness.js`): partida normal de 30 s sin errores. Después, en Av. de Mayo (`h.alReten()`): llamá a mano cada función con valores reales (trazadoras hacia y cerca del jugador, impactos, subtítulos de radio, alerta subiendo de 0 a 1, golpes desde cuatro lados, una `UEB.debug` falsa con posiciones reales cerca de `x=-438, z=608`). Capturas del HUD en acción y de la vista táctica chica y grande.
3. Sonido: no hay parlantes, así que verificá lo que se puede: que cada función corre con `AC` activo sin errores, cuántos nodos crea y que los libera (`AUD.made`, `AUD.reaped`, `AUD.voices` vuelven a su nivel), y que 40 disparos en 2 s no pasan el tope de voces. Describí en el informe cómo está armado cada sonido para que el integrador pueda ajustarlo de oído después.
4. Costo: tiempo de `UEFX.update` + `UEHUD.update` con 30 trazadoras por segundo, y de la vista táctica prendida.

## Qué no hacer

- No agregues luces reales ni edites `sfx`/`PRI`.
- No uses `alert`, `confirm`, ni `localStorage` para nada necesario (para recordar si la vista táctica estaba prendida podés usarlo con `try/catch`, como hace el contador de FPS).
- No toques nada fuera de `F-fx/`.
