/* Compara dos grabaciones de reg_run.js. Uso: node reg_cmp.js a.bin b.bin
   Si son idénticas byte a byte lo dice y muestra qué cubrió la partida; si no, muestra el primer cuadro que difiere. */
const fs=require('fs');const [,,fa,fb]=process.argv;
const A=fs.readFileSync(fa),B=fs.readFileSync(fb);
const fA=new Float64Array(A.buffer,A.byteOffset,A.length/8),fB=new Float64Array(B.buffer,B.byteOffset,B.length/8);
const HDR=26,PE=12,TN=['rata','bagayo','baboso','escupidor','mole','boss'];
function cuadros(f){const L=[];let p=0;while(p<f.length){if(f[p]!==-777)throw new Error('marca perdida en '+p);const nE=f[p+2],nP=f[p+16],nK=f[p+17];L.push(p);p+=HDR+PE*nE+3*nP+2*nK;}return L;}
function resumen(f){const C=cuadros(f);let maxE=0,minHp=1e9,tipos={},proy=0,cajas=0,maxDyn=0,stMax=0;
  for(const p of C){const nE=f[p+2];maxE=Math.max(maxE,nE);minHp=Math.min(minHp,f[p+3]);proy=Math.max(proy,f[p+16]);cajas=Math.max(cajas,f[p+17]);maxDyn=Math.max(maxDyn,f[p+25]);stMax=Math.max(stMax,f[p+23]);
    for(let i=0;i<nE;i++){const t=TN[f[p+HDR+i*PE]];tipos[t]=(tipos[t]||0)+1;}}
  const u=C[C.length-1];
  return {cuadros:C.length,valores:f.length,maxBichos:maxE,cuadrosPorTipo:tipos,vidaMinJugador:minHp,puntaje:f[u+9],bajas:f[u+10],miembros:f[u+21],oleada:f[u+12],azar:f[u+15],maxEscupitajos:proy,maxCajas:cajas,autosMovidos:maxDyn,sumaEstadoAutosMax:stMax,corriendoAlFinal:f[u+20]};}
console.log('A',fa,JSON.stringify(resumen(fA)));console.log('B',fb,JSON.stringify(resumen(fB)));
const igual=A.length===B.length&&A.equals(B);
if(igual){console.log('IDÉNTICAS byte a byte:',A.length,'bytes,',fA.length,'valores');process.exit(0);}
let d=0;const n=Math.min(fA.length,fB.length);while(d<n&&(fA[d]===fB[d]||(fA[d]!==fA[d]&&fB[d]!==fB[d])))d++;
const CA=cuadros(fA);let k=0;while(k+1<CA.length&&CA[k+1]<=d)k++;
console.log('DIFIEREN. tamaños',fA.length,fB.length,'· primer valor distinto: índice',d,'· cuadro',k,'· posición dentro del cuadro',d-CA[k]);
const show=(f,p)=>{const nE=f[p+2];console.log('  cabecera',Array.from(f.subarray(p,p+HDR)).map(v=>+v.toFixed(6)).join(' '));for(let i=0;i<nE;i++)console.log('  bicho',i,Array.from(f.subarray(p+HDR+i*PE,p+HDR+(i+1)*PE)).map(v=>+v.toFixed(6)).join(' '));};
console.log(' A:');show(fA,CA[k]);console.log(' B:');try{show(fB,CA[k]);}catch(e){console.log('  (no se puede mostrar)');}
process.exit(1);
