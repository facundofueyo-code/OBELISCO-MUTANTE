/* Prueba 1 del retén (solo lógica, sin dibujar). Uso: node t1.js [juego.html] */
const path = require('path'), fs = require('fs');
const UE = path.resolve(__dirname, '..', '..');
const H = require(path.join(UE, 'harness.js'));
const t0 = Date.now(); const log = (...a) => console.log(((Date.now() - t0) / 1000).toFixed(0) + 's', ...a);
const J = o => JSON.stringify(o);
(async () => {
  const h = await H.open(process.argv[2] || path.join(__dirname, 'juego.html'));
  log('abierto, errores', h.errors.length);
  try {
    /* posiciones de todos los autos antes de armar el retén (para ver que solo se mueven los de la fila) */
    await h.ev("(()=>{const a=RETEN.armar;RETEN.armar=function(){window.__orig=VCARS.map(c=>[c.x,c.z,c.a]);const t=performance.now();const r=a.apply(this,arguments);window.__msArmar=performance.now()-t;return r;};return 1;})()");
    const st = await h.start();
    log('start', J(st), 'errores', h.errors.length, h.errors.slice(0, 3).join(' | '));
    log('armar ms', await h.ev('Math.round(window.__msArmar)'), 'avisos', J(await h.ev('RETEN.avisos')));
    log('datos', J(await h.ev('RETEN.datos')));
    log('verificar', J(await h.ev('RETEN.verificar()')));
    /* autos movidos */
    log('autos movidos', J(await h.ev("VCARS.map((c,i)=>{const o=window.__orig[i];return (Math.abs(o[0]-c.x)+Math.abs(o[1]-c.z)+Math.abs(o[2]-c.a))>1e-6?i:-1;}).filter(i=>i>=0)")));
    log('fila', J(await h.ev("RETEN.autos.map(c=>({vi:VCARS.indexOf(c),id:c.S.id,x:+c.x.toFixed(2),z:+c.z.toFixed(2),a:+c.a.toFixed(3),by:c.by,cs:c.cs.map(q=>[+q.x.toFixed(2),+q.z.toFixed(2),+q.r.toFixed(2),+q.h.toFixed(2)])}))")));
    /* choques de la fila: con otros círculos (árboles, faroles...), con otros autos y ruedas en la calzada */
    log('chequeo fila', J(await h.ev(`(()=>{const out=[];const F=RETEN.autos;
      for(const c of F){const pr=[];for(const q of c.cs){for(const o of circles){if(o.dead||c.cs.includes(o))continue;const d=Math.hypot(o.x-q.x,o.z-q.z)-o.r-q.r;if(d<.15)pr.push([(o.brk&&o.brk.k)||'?',+d.toFixed(2),+o.x.toFixed(1),+o.z.toFixed(1)]);}}
        const S=c.S,sa=Math.sin(c.a),ca=Math.cos(c.a);let fuera=0;for(const [f,l] of [[.96,.96],[.96,-.96],[-.96,.96],[-.96,-.96]]){const px=c.x+sa*f*c.L/2+ca*l*c.W/2,pz=c.z+ca*f*c.L/2-sa*l*c.W/2;if(!PISO.calzada(px,pz))fuera++;}
        out.push({vi:VCARS.indexOf(c),pegados:pr,ruedasFuera:fuera});}return out;})()`)));
    /* grilla alrededor del retén */
    const grid = await h.ev(`(()=>{const rows=[];for(let z=592;z<=623;z++){let r='';for(let x=-452;x<=-365;x++){const k=eCell(x+.5,z+.5);const b=enB[k],p=enP[k];r+=isSolid(x+.5,z+.5)?'X':b===2?'#':p?'c':b===1?'+':'.';}rows.push(z+' '+r);}return rows.join('\\n');})()`);
    fs.writeFileSync(path.join(__dirname, 'grilla1.txt'), grid);
    log('luz', J(await h.ev("[[-425,606],[-410,606],[-400,608],[-392,608],[-380,606],[-415,610],[-445,607],[-405.7,601.9],[-410.8,600.2]].map(([x,z])=>[x,z,+RETEN.luz(x,z).toFixed(2)])")));
    log('mallas', J(await h.ev("(()=>{const o=[];RETEN.grupo.traverse(m=>{if(m.isMesh||m.isPoints||m.isSprite)o.push([m.type,m.isMesh?(m.geometry.attributes.position.count/3)|0:m.isPoints?m.geometry.attributes.position.count:2]);});return {n:o.length,o,tris:RETEN.datos.tris};})()")));

    /* --- caminar por la avenida hacia la barricada --- */
    const S = "JSON.stringify({x:+P.pos.x.toFixed(2),y:+P.pos.y.toFixed(2),z:+P.pos.z.toFixed(2)})";
    await h.alReten(-326, 606);
    await h.ev("P.pos.y=floorAt(P.pos.x,P.pos.z);P.yaw=Math.PI/2;1");
    let r = await h.step(16, 1 / 60, "keys.KeyW=true;P.yaw=Math.PI/2;P.hp=100");
    log('camina 16 s por z=606', J(r), await h.ev(S));
    r = await h.step(1.5, 1 / 60, "keys.KeyW=true;P.yaw=Math.PI/2;P.hp=100");
    log('sigue empujando 1,5 s', await h.ev(S));
    /* saltar la valla */
    await h.step(.5, 1 / 60, "keys.KeyW=true;keys.Space=true;P.yaw=Math.PI/2;P.hp=100");
    await h.step(2.5, 1 / 60, "keys.KeyW=true;keys.Space=false;P.yaw=Math.PI/2;P.hp=100");
    log('después de saltar (espera x<-439)', await h.ev(S));
    await h.ev("keys.KeyW=false;keys.Space=false;1");
    /* contra el furgón norte y contra un auto de la fila */
    for (const [x, z, yaw, nom] of [[-431, 603, Math.PI / 2, 'furgón norte'], [-431, 612, Math.PI / 2, 'furgón sur'], [-416, 603.3, Math.PI / 2, 'auto 779 (-428;603,3)'], [-404, 611.4, Math.PI / 2, 'auto 784 (-399;611,4) desde el este'], [-445, 598.3, -Math.PI / 2, 'valla norte desde atrás']]) {
      await h.ev(`P.pos.set(${x},floorAt(${x},${z}),${z});P.vel.set(0,0,0);P.yaw=${yaw};MOV.reset();1`);
      await h.step(4, 1 / 60, `keys.KeyW=true;P.yaw=${yaw};P.hp=100`);
      log('choca con', nom, await h.ev(S));
    }
    await h.ev("keys.KeyW=false;1");

    /* --- balas: con la Uzi contra el furgón 782 de la fila hasta que explote --- */
    const tgt = await h.ev("(()=>{const c=RETEN.autos.find(c=>c.S.id==='furgon'&&c.x<-400);return {x:c.x,z:c.z,i:VCARS.indexOf(c)};})()");
    await h.ev(`P.pos.set(-414,floorAt(-414,608.5),608.5);P.vel.set(0,0,0);const dx=${tgt.x}-P.pos.x,dz=${tgt.z}-P.pos.z;P.yaw=Math.atan2(-dx,-dz);P.pitch=-.12;switchTo(2);W[2].res=9999;1`);
    await h.step(1, 1 / 60, "P.hp=100");
    r = await h.step(8, 1 / 60, `P.hp=100;mouseDown=true;W[2].res=9999;{const dx=${tgt.x}-P.pos.x,dz=${tgt.z}-P.pos.z;P.yaw=Math.atan2(-dx,-dz);P.pitch=-.12;}`);
    log('tiros 8 s', await h.ev(`(()=>{const c=VCARS[${tgt.i}];return {hits:c.hits,st:c.st,fuse:+(c.fuse||0).toFixed(1)};})()`));
    await h.ev("mouseDown=false;1");
    await h.ev("P.pos.set(-380,floorAt(-380,607),607);1");
    r = await h.step(8, 1 / 60, "P.hp=100;mouseDown=false");
    log('8 s después', await h.ev(`(()=>{const c=VCARS[${tgt.i}];return {st:c.st,cs:c.cs.map(q=>q.dead),rg:c.rg.length,puertasY:(()=>{const m=RETEN.grupo;let y=null;m.traverse(o=>{if(o.isMesh&&o.material.vertexColors&&o.geometry.attributes.position.count>1000&&y===null){const e=c.rg.find(r=>r[0].mesh===o);if(e)y=o.geometry.attributes.position.array[e[1]*3+1];}});return y;})()};})()`));
    /* tiros contra el furgón norte del retén: la bala para en la caja */
    log('rayo al furgón norte', J(await h.ev(`(()=>{const o=new THREE.Vector3(-425,1.5,603.3),d=new THREE.Vector3(-1,0,0);let best=1e9,k=null;for(const b of obstacles){const t=rayBox(o,d,b);if(t<best){best=t;k=b.k||'?';}}return {t:+best.toFixed(2),k,rw:+rayWalls(o,d,60).toFixed(2)};})()`)));

    /* --- reinicio --- */
    await h.ev("resetGame();1");
    log('después de resetGame', await h.ev(`(()=>{const c=VCARS[${tgt.i}];const F=RETEN.autos;return {st:c.st,hits:c.hits,cs:c.cs.map(q=>q.dead),x:+c.x.toFixed(2),z:+c.z.toFixed(2),wrecks:VWRECK.length,
      igual:F.every(c=>c.cs.every(q=>!q.dead)&&c.st===0),obsReten:RETEN.obs.every(b=>obstacles.includes(b)),grupo:!!RETEN.grupo.parent};})()`));
    log('verificar tras reset', J(await h.ev('RETEN.verificar().ok')));

    /* --- partida normal 30 s con oleada en la zona A --- */
    await h.ev("resetGame();running=true;over=false;intermission=.1;1");
    for (let i = 0; i < 6; i++) { r = await h.step(5, 1 / 60, 'P.hp=100'); }
    log('30 s zona A', await h.ev("JSON.stringify({wave,en:enemies.length,toSpawn,STAGE,T:+T.toFixed(1)})"), 'errores', h.errors.length);
    log('errores', h.errors.length ? h.errors.join('\n').slice(0, 3000) : 'ninguno');
  } finally { await h.close(); log('cerrado'); }
})().catch(e => { log('FALLA', e.message.slice(0, 2000)); process.exit(1); });
