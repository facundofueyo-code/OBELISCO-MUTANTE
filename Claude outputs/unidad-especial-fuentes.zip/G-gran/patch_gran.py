# Parche GRAN (granadas de mano) para Obelisco Mutante 1.16.0 + marcadores UE.
# Uso: python3 patch_gran.py entrada.html salida.html
# Solo usa marcadores: inserta el módulo y sus cuatro llamadas, y deja cada marcador en su lugar.
import sys,os
src,dst=sys.argv[1],sys.argv[2]
s=open(src,encoding='utf-8').read()
AQUI=os.path.dirname(os.path.abspath(__file__))
def rep(viejo,nuevo,n=1):
    global s
    c=s.count(viejo)
    assert c==n,f'ancla: esperaba {n}, hay {c}: {viejo[:80]!r}'
    s=s.replace(viejo,nuevo)
def antes(marca,codigo):            # inserta delante de un marcador y lo deja
    rep(marca,codigo+marca)
mod=open(os.path.join(AQUI,'mod_gran.js'),encoding='utf-8').read()
for m in ('/*UE:','<!--UE:'):
    assert m not in mod,'el módulo no puede contener texto de marcadores'
antes('/*UE:modulos*/',mod+'\n')
antes('/*UE:update*/','GRAN.update(dt);')   # física, mecha, pitido y explosión (solo con partida en curso)
antes('/*UE:fx*/','GRAN.fx(dt);')           # fuego y humo de la explosión: siguen aunque el jugador muera
antes('/*UE:reset*/','GRAN.reset();')
open(dst,'w',encoding='utf-8').write(s)
