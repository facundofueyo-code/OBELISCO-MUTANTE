/* muertes: mitad de la caída y pose final de las cuatro */
const v=(rol,t,az,el,txt,o={})=>Object.assign({rol,pose:'Cae',t,az,el,dist:3.3,obj:[0,.35,0],txt},o);
module.exports={cols:4,vistas:[
  v('jefe',1.19,1.35,.18,'atrás: cayendo',{obj:[0,.6,-.3]}),v('asalto',3.6+1.19,1.2,.18,'adelante: cayendo',{obj:[0,.6,.2]}),
  v('granadero',7.2+1.19,.9,.18,'derrumbe: cayendo',{obj:[-.2,.6,0]}),v('tirador',10.8+1.19,1.1,.3,'a tierra: se desploma',{obj:[0,.3,0]}),
  v('jefe',2.6,1.35,.5,'atrás: final',{obj:[0,.2,-.5]}),v('asalto',3.6+2.6,1.2,.5,'adelante: final',{obj:[0,.2,.2]}),
  v('granadero',7.2+2.6,.9,.5,'derrumbe: final',{obj:[-.3,.2,0]}),v('tirador',10.8+2.6,1.1,.5,'a tierra: final',{obj:[0,.2,0]})]};
