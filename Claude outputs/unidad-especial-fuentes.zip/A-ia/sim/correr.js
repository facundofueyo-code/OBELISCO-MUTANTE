/* =====================================================================================================
   sim/correr.js — corre los escenarios con jugadores automáticos, las 10 verificaciones y las medidas.

     node sim/correr.js                    todo (12 semillas por escenario)
     node sim/correr.js --esc a,f0 --semillas 4 --trazas --fps 30 --costo
   Imprime un resumen corto; el detalle va a sim/salida/detalle.txt y sim/salida/resultados.json.
   Termina con código 1 y un mensaje claro si se rompe alguna regla de juego limpio.
   ===================================================================================================== */
const fs = require('fs'), path = require('path');
const AQUI = __dirname;
const { crearUE, UE_TUNE } = require(path.join(AQUI, '..', 'ue_ia.js'));
const { crearMundo } = require(path.join(AQUI, 'mundo.js'));
const { crearVerificador } = require(path.join(AQUI, 'verificar.js'));
const { crearJugadores } = require(path.join(AQUI, 'jugadores.js'));
const mapa = JSON.parse(fs.readFileSync(path.join(AQUI, '..', '..', 'mapa-reten.json'), 'utf8'));

const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i < 0 ? d : (process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true); };
const NSEM = +arg('semillas', 12), FPS = +arg('fps', 30), TRAZAS = !!arg('trazas', false), COSTO = !!arg('costo', false) || !arg('esc', false);
const TUNE = arg('tune', false) ? Object.assign({}, UE_TUNE, JSON.parse(arg('tune'))) : UE_TUNE;
const SALIDA = path.join(AQUI, 'salida'); if (!fs.existsSync(SALIDA)) fs.mkdirSync(SALIDA);
const TRZ = path.join(AQUI, '..', 'trazas'); if (!fs.existsSync(TRZ)) fs.mkdirSync(TRZ);

/* ---------- escenarios ---------- */
const ESC = {
  a: { nombre: 'parado al descubierto a 30 m', tmax: 60, refuerzo: false, bot: JG => JG.parado({ x: -411, z: 601.5 }) },
  b: { nombre: 'a cubierto, se asoma 1 s cada 3 s (pistola)', tmax: 150, bot: JG => JG.asoma({ x: -394.5, z: 610 }) },
  c: { nombre: 'escondido; a los 10 s se va 20 m', tmax: 75, refuerzo: false, fin: (M, bot) => bot.info.tEsconde !== null && M.t - bot.info.tEsconde > 45,
    bot: JG => JG.escondido({ inicio: { x: -394, z: 603.5 }, escondite: { x: -394.5, z: 610 }, nuevo: { x: -375.5, z: 613 } }) },
  d0: { nombre: 'sigilo por la vereda, sin linterna', tmax: 70, refuerzo: false, fin: (M, bot) => bot.info.dContacto !== null && M.t > bot._tFin, bot: JG => JG.sigilo({ inicio: { x: -326, z: 594.5 }, fin: { x: -436, z: 596 }, linterna: false }) },
  d1: { nombre: 'sigilo por la vereda, con linterna', tmax: 70, refuerzo: false, fin: (M, bot) => bot.info.dContacto !== null && M.t > bot._tFin, bot: JG => JG.sigilo({ inicio: { x: -326, z: 594.5 }, fin: { x: -436, z: 596 }, linterna: true }) },
  e: { nombre: 'rodea por H. Yrigoyen y aparece por San José', tmax: 240, bot: JG => JG.rodeo({}) },
  f0: { nombre: 'jugador decente, armas base', tmax: 300, bot: JG => JG.decente({ inicio: { x: -326, z: 606 } }) },
  f1: { nombre: 'jugador decente, con fusil', tmax: 300, bot: JG => JG.decente({ inicio: { x: -326, z: 606 }, arma: 'fusil' }) },
  g6: { nombre: '6 bichos detrás del retén (jugador lejos)', tmax: 80, refuerzo: false, bichos: 6, inmortal: true, bot: JG => JG.parado({ x: -330, z: 594.5 }) },
  g12: { nombre: '12 bichos detrás del retén (jugador lejos)', tmax: 80, refuerzo: false, bichos: 12, inmortal: true, bot: JG => JG.parado({ x: -330, z: 594.5 }) },
  h: { nombre: 'jefe caído a los 15 s de combate (decente, base)', tmax: 120, jefe: 15, bot: JG => JG.decente({ inicio: { x: -326, z: 606 } }) }
};
const lista = arg('esc', false) ? String(arg('esc')).split(',') : Object.keys(ESC);

/* ---------- una corrida ---------- */
function correr(clave, semilla, traza) {
  const E = ESC[clave], dt = 1 / FPS;
  const M = crearMundo(mapa, { semilla: semilla * 7919 + clave.charCodeAt(0) });
  const UE = crearUE(M.ENV, TUNE); M.conectar(UE);
  M.armarReten({ refuerzo: E.refuerzo !== false });
  const V = crearVerificador(M, UE);
  const JG = crearJugadores(M, UE);
  const bot = E.bot(JG); bot._tFin = 1e9;
  const J = M.jugador;
  const R = { esc: clave, semilla, tContacto: null, tMuerte: null, muertes: 0, dano: null, flancos: 0, flancoT: [], granadas: 0, primeraGranada: null,
    granadasPos: [], refPedido: null, refEntra: null, refLlega: null, avisos: [], jefeT: null, desorden: null, bichosMuertos: 0, bajasPorBicho: 0, tLimpio: null,
    radio: {}, ordenes: [], ultimaFuente: null, frases: 0, tFin: 0, cortes: 0, bajasCeniza: 0 };
  let evs = [], frames = [], ultBalas = [], tSig = 0, fichasDes = 0, ordenesDes = 0;
  if (E.bichos) M.soltarBichos(E.bichos, { desde: 3 });
  if (E.inmortal) M.jugador.hp = 1e9;                                               // acá interesa soldados contra bichos
  try {
    while (M.t < E.tmax) {
      bot.paso(dt, evs);
      M.paso(dt);
      evs = V.paso(M.sacarEventos());
      for (const e of evs) {
        if (e.tipo === 'evento') {
          const n = e.nombre;
          if ((n === 'combate' || n === 'contacto') && R.tContacto === null) R.tContacto = e.t;
          if (n === 'flanco') { R.flancos++; R.ordenes.push(['flanco', e.t]); }
          if (n === 'flanco_llego') R.flancoT.push(e.datos.t);
          if (n === 'granada_orden') { R.ordenes.push(['granada', e.t]); R._obj = { x: e.datos.x, z: e.datos.z }; }
          if (n === 'avance' || n === 'empuje') R.ordenes.push([n, e.t]);
          if (n === 'refuerzo') { if (e.datos.fase === 'pedido' && R.refPedido === null) R.refPedido = e.t; if (e.datos.fase === 'entra') R.refEntra = e.t; if (e.datos.fase === 'llega' && R.refLlega === null) R.refLlega = e.t; if (e.datos.fase === 'interrumpido') R.cortes++; }
          if (n === 'baja') { if (e.datos.de === 'jugador' || e.datos.de === 'granada') { R.muertes++; if (e.datos.s.esc.nombre === 'Ceniza') R.bajasCeniza++; } if (e.datos.de === 'bicho') R.bajasPorBicho++; }
          if (n === 'jefe_caido') { R.jefeT = e.t; R.desorden = { hasta: e.datos.hasta, fichasMax: 0, ordenes: 0 }; }
          if (n === 'limpio' && R.tLimpio === null) R.tLimpio = e.t;
        }
        if (e.tipo === 'granada' && e.de !== 'jugador') { R.granadas++; if (R.primeraGranada === null) R.primeraGranada = e.t; }
        if (e.tipo === 'explosion' && e.de !== 'jugador') R.granadasPos.push({ t: e.t, x: e.x, z: e.z, dJ: Math.hypot(e.x - J.x, e.z - J.z), dObj: R._obj ? Math.hypot(e.x - R._obj.x, e.z - R._obj.z) : null });
        if (e.tipo === 'radio') { R.radio[e.clave] = (R.radio[e.clave] || 0) + 1; R.frases++; }
        if (e.tipo === 'herida' && e.a === 'jugador') R.ultimaFuente = e.fuente;
        if (e.tipo === 'muerte' && e.a === 'bicho' && e.por === 'soldado') R.bichosMuertos++;
        if (e.tipo === 'muerte' && e.a === 'jugador') R.tMuerte = e.t;
        if (traza && e.tipo === 'bala') ultBalas.push({ t: e.t, ox: e.ox, oz: e.oz, hx: e.hx, hz: e.hz, de: e.de, pega: e.pega, modo: e.modo || '' });
      }
      /* jefe caído a mano (escenario h) */
      if (E.jefe && R.jefeT === null && R.tContacto !== null && M.t - R.tContacto > E.jefe) {
        const j = UE.soldados.find(s => s.rol === 'jefe' && s.vivo && s.esc.nombre === 'Ceniza');
        if (j) UE.herir(j, 999, { x: 1, y: 0, z: 0 }, 'cabeza', 'jugador'); else R.jefeT = -1;
      }
      if (R.desorden && M.t < R.desorden.hasta) {
        R.desorden.fichasMax = Math.max(R.desorden.fichasMax, UE.red.fichas.length);
        for (const e of evs) if (e.tipo === 'evento' && /^(flanco|granada_orden|avance|empuje)$/.test(e.nombre) && e.datos && (!e.datos.s || e.datos.s.esc.nombre === 'Ceniza')) R.desorden.ordenes++;
      }
      if (traza && M.t >= tSig) {
        tSig += 2; const f = M.foto(); f.balas = ultBalas.filter(b => b.t > M.t - 0.6); f.uc = UE.red.uc ? { x: UE.red.uc.x, z: UE.red.uc.z, tipo: UE.red.uc.tipo } : null; frames.push(f);
      }
      if (ultBalas.length > 400) ultBalas = ultBalas.slice(-200);
      if (!J.vivo && M.t - J.tMuerte > 1.5) break;
      if (E.fin && E.fin(M, bot)) break;
      if (bot.info.dContacto !== undefined && bot.info.dContacto !== null && bot._tFin > 1e8) bot._tFin = M.t + 3;
      if (E.bichos && M.t > 10 && !M.bichos.some(b => b.vivo) ) { R.tLimpio = R.tLimpio || M.t; break; }
    }
  } catch (err) { V.excepcion(err); }
  R.tFin = M.t; R.dano = Object.assign({}, J.dano); R.vivo = J.vivo; R.hp = J.hp; R.info = bot.info;
  R.soldadosVivos = UE.soldados.filter(s => s.vivo).length; R.soldados = UE.soldados.length;
  R.fallas = V.fallas.slice(); R.cuenta = Object.assign({}, V.cuenta); R.chequeos = Object.assign({}, V.chequeos);
  if (traza) fs.writeFileSync(path.join(TRZ, clave + '.json'), JSON.stringify({ esc: clave, nombre: E.nombre, semilla, frames: frames.map(redondear), reten: M.reten, luz: M.zonaLuz }));
  return R;
}
function redondear(o) { return JSON.parse(JSON.stringify(o, (k, v) => typeof v === 'number' ? Math.round(v * 100) / 100 : v)); }

/* ---------- estadística ---------- */
const med = v => { if (!v.length) return null; const w = v.slice().sort((a, b) => a - b); const m = w.length >> 1; return w.length % 2 ? w[m] : (w[m - 1] + w[m]) / 2; };
const rango = v => v.length ? Math.min(...v).toFixed(1) + '–' + Math.max(...v).toFixed(1) : '—';
const f1 = x => x === null || x === undefined || Number.isNaN(x) ? '—' : (+x).toFixed(1);
const MR = (v) => v.length ? f1(med(v)) + ' (' + rango(v) + ')' : '—';

/* ---------- correr todo ---------- */
const t0 = Date.now(), todos = {}, det = [];
let fallasTot = 0; const cuentaTot = {}, chequeosTot = {};
for (const k of lista) {
  if (!ESC[k]) { console.log('escenario desconocido: ' + k); continue; }
  todos[k] = [];
  for (let s = 1; s <= NSEM; s++) {
    const R = correr(k, s, TRAZAS && s === 1);
    todos[k].push(R);
    for (const n in R.cuenta) { cuentaTot[n] = (cuentaTot[n] || 0) + R.cuenta[n]; chequeosTot[n] = (chequeosTot[n] || 0) + R.chequeos[n]; }
    fallasTot += R.fallas.length;
    det.push(k + ' s' + s + ': fin ' + f1(R.tFin) + ' contacto ' + f1(R.tContacto) + ' muerte ' + f1(R.tMuerte) + ' bajas ' + R.muertes + ' daño ' + JSON.stringify(Object.fromEntries(Object.entries(R.dano).map(([a, b]) => [a, Math.round(b)]))) +
      ' flancos ' + R.flancos + ' granadas ' + R.granadas + ' ref ' + f1(R.refPedido) + '/' + f1(R.refEntra) + ' info ' + JSON.stringify(R.info, (kk, v) => typeof v === 'number' ? Math.round(v * 10) / 10 : v) + (R.fallas.length ? '\n   ' + R.fallas.join('\n   ') : ''));
  }
}

/* ---------- costo: 8 soldados en combate ----------
   Jugador que no se muere ni tira (se asoma cada 3 s detrás de un auto), refuerzo pedido enseguida: 8 vivos peleando.
   Se mide cada llamada a UE.update a 60 cuadros/s mientras haya 8 vivos y los dos escuadrones estén en combate. */
let costo = null;
if (COSTO) {
  const M = crearMundo(mapa, { semilla: 99 }); const UE = crearUE(M.ENV, Object.assign({}, TUNE, { refuerzoCombate: 0, refuerzoLlega: 2, perfil: !!arg('perfil', false) })); M.conectar(UE); M.armarReten();
  const JG = crearJugadores(M, UE), bot = JG.asoma({ x: -394.5, z: 610, noTira: true }), dt = 1 / 60;
  M.jugador.hp = 1e9;
  const tiempos = []; let a0 = 0, tA = 0, tB = 0, evs = [];
  const upd = UE.update;
  UE.update = function (d) {
    const h = process.hrtime.bigint(); upd(d); const ms = Number(process.hrtime.bigint() - h) / 1e6;
    if (UE.soldados.filter(s => s.vivo && s.activo).length >= 8 && UE.escuadrones.every(e => !e.activo || e.estado === 'combate')) { tiempos.push(ms); if (!tA) { tA = M.t; a0 = UE.astar; } tB = M.t; }
  };
  while (M.t < 150 && tiempos.length < 60 * 90) { bot.paso(dt, evs); M.paso(dt); evs = M.sacarEventos(); }
  const w = tiempos.slice(120).sort((a, b) => a - b);
  if (UE.interno.prof) console.log('perfil de trabajos (n, ms medio, ms máx): ' + Object.entries(UE.interno.prof).map(([k, p]) => k + ' ' + p.n + ' ' + (p.ms / p.n).toFixed(2) + ' ' + p.max.toFixed(2) + ' lentos[t,ms,líneas,itA*]=' + JSON.stringify(p.lentos.slice(0, 6))).join('\n   '));
  costo = w.length ? { n: w.length, media: w.reduce((a, b) => a + b, 0) / w.length, p99: w[Math.floor(w.length * 0.99)], max: w[w.length - 1], astarSeg: (UE.astar - a0) / Math.max(1, tB - tA) } : { n: 0 };
}

/* ---------- resumen ---------- */
const L = [];
L.push('UE — simulador del retén · ' + NSEM + ' semillas · ' + FPS + ' cuadros/s · ' + ((Date.now() - t0) / 1000).toFixed(0) + ' s');
L.push('esc  | dura (s) med (rango)        | contacto→muerte     | bajas  | fusil/esc/tir/gran/culata/bicho (med)  | otros');
for (const k of Object.keys(todos)) {
  const v = todos[k], dur = v.map(r => r.tMuerte !== null ? r.tMuerte : r.tFin), cm = v.filter(r => r.tMuerte !== null && r.tContacto !== null).map(r => r.tMuerte - r.tContacto);
  const dm = f => f1(med(v.map(r => r.dano[f] || 0)));
  let otros = 'muere ' + v.filter(r => r.tMuerte !== null).length + '/' + v.length;
  if (k === 'c') { const ok = v.filter(r => r.info.tEsconde !== null), G = [].concat(...v.map(r => r.granadasPos.filter(g => r.info.tMueve && g.t > r.info.tMueve))); otros += ' · 1ª gran. ' + MR(ok.filter(r => r.primeraGranada !== null).map(r => r.primeraGranada - r.info.tEsconde)) + ' s tras esconderse · granadas después de que se movió: ' + G.length + ', al lugar viejo (≤3 m del objetivo y ≥4 m del jugador) ' + G.filter(g => g.dObj !== null && g.dObj < 3 && g.dJ >= 4).length + ' · lo vieron moverse ' + v.filter(r => r.info.vistoMoviendo).length + '/' + v.length; }
  if (k[0] === 'd') { const q = {}; v.forEach(r => { if (r.info.quien) q[r.info.quien] = (q[r.info.quien] || 0) + 1; }); otros += ' · sospecha a ' + MR(v.filter(r => r.info.dSospecha !== null).map(r => r.info.dSospecha)) + ' m · contacto a ' + MR(v.filter(r => r.info.dContacto !== null).map(r => r.info.dContacto)) + ' m del que lo vio, a ' + MR(v.filter(r => r.info.dBarricada !== null).map(r => r.info.dBarricada)) + ' m de la barricada · lo vio ' + JSON.stringify(q); }
  if (k === 'e') otros += ' · visto antes de la esquina ' + v.filter(r => r.info.detectadoAntes).length;
  if (k[0] === 'f' || k === 'e' || k === 'b' || k === 'h') otros += ' · bajas Ceniza ' + MR(v.map(r => r.bajasCeniza)) + ' · bajas≥2: ' + v.filter(r => r.muertes >= 2).length + ' ≥4: ' + v.filter(r => r.muertes >= 4).length + ' · flancos ' + f1(med(v.map(r => r.flancos))) + ' (llegan en ' + f1(med([].concat(...v.map(r => r.flancoT)))) + ' s) · refuerzo pedido ' + v.filter(r => r.refPedido !== null).length + ' (a los ' + f1(med(v.filter(r => r.refPedido !== null && r.tContacto !== null).map(r => r.refPedido - r.tContacto))) + ' s de combate, cortado ' + v.reduce((n, r) => n + r.cortes, 0) + ') llega ' + v.filter(r => r.refEntra !== null).length + ' · bajas por corrida ' + v.map(r => r.muertes).join(',');
  if (k[0] === 'g') otros += ' · bichos muertos ' + MR(v.map(r => r.bichosMuertos)) + ' · soldados muertos por bichos ' + MR(v.map(r => r.bajasPorBicho)) + ' · limpio a ' + MR(v.filter(r => r.tLimpio).map(r => r.tLimpio)) + ' s';
  if (k === 'h') otros += ' · desorden: fichas máx ' + MR(v.filter(r => r.desorden).map(r => r.desorden.fichasMax)) + ' órdenes ' + MR(v.filter(r => r.desorden).map(r => r.desorden.ordenes));
  L.push((k + '   ').slice(0, 4) + ' | ' + (MR(dur) + '                    ').slice(0, 26) + ' | ' + (MR(cm) + '              ').slice(0, 19) + ' | ' + (MR(v.map(r => r.muertes)) + '      ').slice(0, 6) + ' | ' + [dm('fusil'), dm('escopeta'), dm('tirador'), dm('granada'), dm('culata'), dm('bicho')].join('/') + ' | ' + otros);
}
if (costo) L.push('costo UE.update con 8 en combate: ' + (costo.n ? 'media ' + costo.media.toFixed(3) + ' ms · p99 ' + costo.p99.toFixed(3) + ' · máx ' + costo.max.toFixed(2) + ' · A*/s ' + costo.astarSeg.toFixed(1) + ' (' + costo.n + ' cuadros)' : 'no se llegó a 8 en combate'));
const V0 = crearVerificador({ jugador: {}, grilla: {} }, { T: UE_TUNE, soldados: [] });
L.push('verificaciones: ' + Object.keys(V0.NOMBRE).map(n => n + (cuentaTot[n] ? ' FALLA×' + cuentaTot[n] : ' ok') + '(' + (chequeosTot[n] || 0) + ')').join(' · '));
console.log(L.join('\n'));
fs.writeFileSync(path.join(SALIDA, 'detalle.txt'), L.join('\n') + '\n\n' + det.join('\n') + '\n');
fs.writeFileSync(path.join(SALIDA, 'resultados.json'), JSON.stringify({ todos: Object.fromEntries(Object.entries(todos).map(([k, v]) => [k, v.map(r => Object.assign({}, r, { info: JSON.parse(JSON.stringify(r.info, (kk, x) => (x && typeof x === 'object' && x.esc) ? undefined : x)) }))])), costo }, null, 0));
if (fallasTot) {
  console.log('\nFALLA el juego limpio (' + fallasTot + '):');
  for (const n in cuentaTot) if (cuentaTot[n]) console.log('  [' + n + '] ' + V0.NOMBRE[n] + ': ' + cuentaTot[n] + ' veces');
  console.log('  detalle: grep "^\\s*\\[" ' + path.relative(process.cwd(), path.join(SALIDA, 'detalle.txt')));
  process.exitCode = 1;
}
