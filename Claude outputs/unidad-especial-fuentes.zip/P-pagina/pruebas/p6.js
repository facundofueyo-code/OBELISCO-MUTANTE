/* Prueba 6: una captura jugando de verdad (teclas y mouse), con linterna y «Ver lo que saben», en combate. */
const path = require('path');
const H = require(path.join(__dirname, '../../harness.js'));
const PAG = path.join(__dirname, '../prueba.html');
const CAP = path.join(__dirname, '../cap/');
(async () => {
  const h = await H.openPage(PAG, { width: 1280, height: 800 });
  const p = h.page;
  try {
    await p.waitForTimeout(600);
    await p.evaluate(() => document.getElementById('stage').scrollIntoView({ block: 'center' }));
    await p.click('#bJugar'); await p.evaluate(() => UEPAG.congelar(true));
    const box = await p.evaluate(() => { const r = document.getElementById('cv').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; });
    await p.mouse.move(box.x + box.w * 0.22, box.y + box.h * 0.5);
    await p.keyboard.press('KeyF');
    await p.keyboard.down('KeyA'); await p.evaluate(() => UEPAG.avanzar(4.5)); await p.keyboard.up('KeyA');
    let i = 0, info;
    for (; i < 40; i++) { info = await p.evaluate(() => UEPAG.avanzar(0.5)); if (info.combate && info.t > 9) break; }
    await p.keyboard.press('KeyT');
    await p.mouse.down();
    const r = await p.evaluate(() => { for (let k = 0; k < 240; k++) { UEPAG.avanzar(1 / 60); const P = UEPAG.P; if (P.trazas.length >= 2 && UEPAG.M.t > 12) return { k, t: UEPAG.M.t }; } return null; });
    await p.mouse.up();
    info = await p.evaluate(() => UEPAG.info());
    console.log('juego:', JSON.stringify({ r, t: info.t, hp: info.hp, x: info.x, z: info.z, combate: info.combate, linterna: info.linterna, verSaben: info.verSaben, balas: info.cuentas.balasMias }));
    await p.screenshot({ path: CAP + '8-jugando.png', clip: { x: box.x - 1, y: box.y - 1, width: box.w + 2, height: box.h + 2 } });
    console.log('errores:', h.errors.length ? h.errors.slice(0, 5).join('\n') : 0);
  } finally { await h.close(); }
})();
