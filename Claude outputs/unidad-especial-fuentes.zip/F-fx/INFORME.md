# Informe F: efectos, sonido, avisos y vista táctica (base 1.16.0)

Lo hice en dos sesiones: la primera escribió el módulo y lo probó en una página suelta (sobre la 1.14). Esta lo revisó, lo corrigió y lo probó adentro del juego 1.16.0 con el arnés. Todo lo que figura acá como probado salió de `t_juego.js` (última corrida: `pruebas_juego.json`, 128 s, 0 errores de página o de consola).

## 1. Archivos (todo en `F-fx/`)

| Archivo | Qué es |
|---|---|
| `mod_fx.js` | El módulo (UESND, UEFX, UEHUD, UEDBG), tal como entra en `/*UE:modulos*/` |
| `patch_fx.py` | Parche `entrada.html salida.html`. Usa solo marcadores y no reescribe ninguna línea del juego |
| `t_juego.js` | Pruebas en el juego: `node F-fx/t_juego.js [sin-capturas]` (~2 min con capturas). Ocupa 1 turno |
| `pruebas_juego.json` | Resultados de la última corrida. Las corridas anteriores quedaron como `_corrida1/2/3` |
| `juego_fx.html` | `v116/base.html` con el parche aplicado (lo rehace `patch_fx.py`) |
| `capturas/j01_hud.png`, `j02_tactica_chica.png`, `j03_tactica_grande.png` | Capturas en el juego, a 1280×720, en el retén |
| `prueba_fx.html`, `armar_prueba.py`, `prueba_plantilla.html`, `t_pagina.js`, `t_humo.js`, `capturas/p*.png` | Página suelta de la 1.ª etapa. La rearmé con el módulo nuevo y carga sin errores (`t_humo.js`) |

## 2. Contrato real

Las firmas de 4.4 están todas y son exactas. Lo que va **después** de ellas es agregado y opcional.

```js
UEFX.trazadora(a,b,tipo)          // a,b: {x,y,z}. tipo 'fusil'|'escopeta'|'tirador' (otro → fusil)
UEFX.impacto(p,n,mat)             // n: {x,y,z} o null. mat 'metal'|'pared'|'piso'|'carne'
UEFX.sangre(p,dir)                // dir: {x,y,z} o null
UEFX.update(dt); UEFX.reset()
  + UEFX.recientes (últimos 32 tiros, los usa la vista táctica) · UEFX.TR (aspecto por arma) · UEFX.malla · UEFX.vivos (cuadraditos dibujados)
UESND.disparo(tipo,pos); UESND.silbido(pan); UESND.radio(voz,dur,pos)
UESND.pasos(pos,fuerza); UESND.cuerpo(pos); UESND.equipo(pos)
  + UESND.impacto(pos,mat) (lo llama UEFX.impacto solo, a menos de 34 m) · UESND.durFrase(texto) → s
  + UESND.pausa(v) · UESND.reset() · UESND.CFG / TIRO / VOCES (perillas, ver §7)
UEHUD.radio(quien,texto[,clave]); UEHUD.alerta(nivel,ang,combate); UEHUD.golpe(ang)
UEHUD.update(dt); UEHUD.reset()
  + UEHUD.golpeDesde(x,z) (golpe desde un punto del mundo) · UEHUD.angulo(x,z) (rad respecto de la mirada)
UEDBG.tecla(e); UEDBG.update(dt); UEDBG.poner(0|1|2); UEDBG.dibujar(); UEDBG.modo
```

En qué me aparté de 4.4, y por qué:
- `UEHUD.radio` acepta un 3.er parámetro `clave` (la clave de §9) para marcar peligro. Si no viene, el peligro se deduce del texto. `quien` puede ser texto o el soldado (usa `.nombre`). Resaltadas: `granada`, `tirador_mira`, `auto_fuego` y **`recarga_jugador`** («Está recargando. ¡Voy!»: el asalto se le viene encima). `granada_enemiga` no se resalta, porque el peligro es para ellos.
- `UEFX.impacto(…,'carne')` es un bicho: salpica verde, como las balas del jugador. Para un soldado herido va `sangre()`. Si le pegan al jugador no hace falta nada: el aviso lo da `golpe`.
- `UEHUD.update` lee `UEB.estado()` solo, si el integrador lo reemplazó. Entiende la forma de 4.1 (`{alerta,ang,combate}`) **y también la que devuelve hoy `UE.estado()` de `ue_ia.js`** (`{sospecha,x,z,combate}`, que no coincide con 4.1). Con la segunda, el arco apunta al soldado (x,z). Probado: con Ceniza 4 da 11,8°, que es lo esperado.
- La vista táctica usa, si vienen, dos extras de `UE.debug()`: `laser` del soldado (dibuja una línea roja) y `RETEN.datos.luz` (zonas iluminadas). Traduce a palabras los estados y las órdenes **reales** de `ue_ia.js` (`bicho`, `llegando`, `volver`, `barrido`, `empuje`, `desorden`, `repliegue`, `base de fuego`, `flanqueo der/izq`…). Lo que no conoce lo muestra tal cual.

## 3. Qué agrega al juego

- **Teclas:** `F2` prende y apaga la vista táctica. `Shift+F2` cambia entre chica y grande, y si estaba apagada la prende grande. El Shift ya había cambiado correr/caminar, así que `UEDBG.tecla` lo deshace (probado: `P.sprintOn` queda igual). Recuerda el modo en `localStorage['obelisco-ue-tac']` con try/catch. La ayuda de inicio dice «F2 · Vista táctica: ver qué sabe y qué decide el escuadrón (Shift+F2: grande)».
- **Dentro de `#hud`** (se oculta con el HUD):
  - `#ueRadio`: subtítulos abajo a la izquierda, arriba de la salud.
  - `#ueRet`: un SVG centrado con el arco de detección `#ueDet`, «TE VIERON» `#ueVisto`, las cuñas de daño `#ueGolpes` (6 a la vez) y los avisos de granada `#ueGranadas` (3 a la vez).
- **Fuera del HUD** (`<!--UE:capas-->`): `#ueTac`, la vista táctica. Mientras está la chica, `body.ue-tac` corre el `#feed` a la izquierda.
- **3D:** una sola malla, una llamada de dibujo, `renderOrder` 6, con 304 cuadraditos como máximo. Cada fondo común tiene su tope: 48 trazadoras, 96 chispas, 24 destellos y 40 bocanadas. La textura y el material se crean al cargar. Ni luces reales, ni `sfx`, ni `PRI`.

## 4. Anclas del parche

Ninguna reescribe código del juego: todas insertan **delante** de un marcador: `/*UE:css*/`, `<!--UE:hud-->`, `<!--UE:capas-->`, `<!--UE:ayuda-->`, `/*UE:modulos*/`, `/*UE:fx*/` (`UEFX.update(dt);UEHUD.update(dt);UEDBG.update(dt);`), `/*UE:reset*/` (`UEFX.reset();UEHUD.reset();UESND.reset();`), `/*UE:pausa*/` (`UESND.pausa(v);`) y `/*UE:teclas*/` (`UEDBG.tecla(e);`). Las delicadas:
- `/*UE:teclas*/` tiene que seguir **antes** de la línea del Shift (`MOV.toggleRun()`), y el Shift tiene que seguir siendo un interruptor. Si alguien lo pasa a «mantener para correr», hay que sacar la compensación de `tecla()`.
- `/*UE:pausa*/` usa la variable `v` de `setPaused(v)` y `/*UE:teclas*/` usa la `e` del `keydown`.
- `/*UE:fx*/` está adentro de `if(!paused)`: en pausa, el HUD y la vista táctica se quedan quietos. Es a propósito.

## 5. Cómo conectarlo (sugerencia para el integrador)

- `ENV.bala(ev)` → `UEFX.trazadora(o,h,tipo)` + `UESND.disparo(tipo,o)`. Según `pega`: `'mundo'` → `UEFX.impacto(h,n,mat)`; `'bicho'` → `UEFX.impacto(h,null,'carne')`; `'jugador'` → nada. El silbido lo dispara la trazadora sola.
- `ENV.herirJugador(d,x,z,tipo)` → `UEHUD.golpeDesde(x,z)`.
- `ENV.radio(s,clave,texto)` → `UEHUD.radio(s.nombre,texto,clave)` + `UESND.radio(voz 0…7 fija por soldado, UESND.durFrase(texto), {x:s.x,y:s.y+1.6,z:s.z})`.
- `UE.herir` → `UEFX.sangre(p,dir)`. Si muere → `UESND.cuerpo(pos)`. Al moverse → `UESND.pasos(pos,1|1.4|.5)` por paso y `UESND.equipo(pos)` cada tanto.
- `UEB.estado=()=>UE.estado()` y `UEB.debug=()=>UE.debug()`.

## 6. Pruebas (en el juego 1.16.0, 1280×720, arnés)

- **Partida normal de 30 s con oleada:** 0 errores, 8 bichos en la oleada 1. El jugador, quieto, muere: es normal.
- **AC nulo** (antes de `initAudio`): se llamaron las 10 funciones de sonido, más trazadora, impacto, pausa y reset. Resultado: 0 nodos, 0 errores. Sin `GRAN` y con `UEB.debug()` nulo, tampoco hubo errores. La vista muestra «sin escuadrón». Si `debug` tira error, muestra «error en UEB.debug()».
- **Trazadoras** desde soldados reales del retén (jugador en −392;609, sobre la calzada a −0,15):
  - una que le pega en el pecho no silba;
  - roce a 0,7 m por la derecha: silbido con pan +0,99;
  - roce a 0,9 m por la izquierda: pan −0,98;
  - pasa a 3 m: no silba;
  - tirador a 3,8 m: no silba (la regla es más de 6 m);
  - 8 perdigones que rozan: 8 llamadas, que la compuerta de sonido deja en 2.

  Todas juntas dibujan 28 cuadraditos. A los 0,2 s quedan 5: el rastro del tirador.
- **Impactos:**
  - metal: 6 chispas y 1 destello;
  - pared: 2 partículas del juego, más polvo;
  - piso: 1, más polvo;
  - carne: 3 verdes;
  - sangre ×4: 20 partículas rojas y entre 0 y 2 manchas en el piso (40 % de probabilidad cada una).
  - **Chispas sobre la calzada:** la más baja queda en y = −0,18 con el piso a −0,15. Antes rebotaban en +0,02, flotando.
- **Radio:** de 5 frases quedan 3, la más nueva abajo. Las dos de peligro salen resaltadas. A los 2,7 s ya se fue «¡Granada va!» (dura el mínimo, 2,2 s). A los 6,7 s no queda ninguna.
- **Detección:** rampa continua de 0 a 1 en 2 s, desde 0,6 rad.
  - El arco crece en color hueso, con opacidad de 0,56 a 0,97, apuntando a 34,4°.
  - Al pasar a combate: rojo (254,82,66) y «TE VIERON».
  - Si el jugador gira 0,3 rad, el arco pasa a 51,5° (esperado 51,6°): sigue el lugar del mundo.
  - Con 3,9 s de combate baja a opacidad 0,55. Sin dirección, es un anillo de rayitas.
  - Con 1,2 s de calma se oculta.
- **Golpes:** desde los cuatro lados salen 4 cuñas a 0°, 90°, 180° y −90°. Otro golpe a 0,1 rad reusa la cuña de 0°. A los 0,9 s no queda ninguna. Desde Ceniza 4: 11,8°.
- **Granada** (un `GRAN` de mentira a 6 m adelante a la derecha):
  - ícono rojo («letal», ≤ 7,3 m) con «6 m», del lado correcto;
  - con poca mecha parpadea 13 veces por segundo;
  - pegada a los pies: «A TUS PIES» abajo;
  - a 20 m no se ve;
  - la propia, quieta, se avisa; la de humo, no;
  - si se borra `GRAN`, desaparece.
- **Reset:** con todo prendido, `resetGame()` deja 0 cuadraditos, 0 renglones de radio, el arco, las cuñas y las granadas ocultos, y `recientes` vacío.
- **Sonido con AC andando** (44,1 kHz; el reloj avanza en tiempo real). Cada función, sin errores, crea esto:

  | Llamada | Nodos | Fuentes | JS |
  |---|---|---|---|
  | disparo fusil a 10 / 40 / 80 / 200 m | 13 / 14 / 11 / 11 | 3–4 | ~0,5 ms |
  | disparo a 300 m | 0 | 0 | — |
  | escopeta: 8 llamadas = 1 tiro | 11 | 3 | — |
  | tirador | 17 | 5 | — |
  | silbido | 10 | 3 | — |
  | impacto | 6–10 | 1–3 | — |
  | radio sin lugar / desde 20 m | 18 / 21 | 3 | — |
  | pasos caminando / corriendo / a 20 m | 9 / 12 / 0 | — | — |
  | equipo | 9 | 2 | — |
  | cuerpo | 19 | 6 | — |

  Creó 209 nodos y liberó 207. Los otros 2 son el compresor de los disparos, que queda para siempre. Las voces vuelven a 4 (las del ambiente del juego).
- **40 disparos en 2 s** (8 tiradores de 10 a 90 m, armas mezcladas, la escopeta avisa por perdigón, una trazadora de cada tres): pico de **46 voces**. El tope más bajo es 70 (prioridad 0), así que no se descartó ningún sonido. Creó 655 nodos y liberó los 655. Al final, 4 voces.
- **Costo FX + HUD** (900 cuadros con 30 trazadoras/s, 15 impactos/s, alerta moviéndose, golpes, radio y granada a ratos):

  | | Medio | p99 | Más de 1 ms |
  |---|---|---|---|
  | Solo JS | 0,026 ms | 0,3 ms | 2 de 900 |
  | JS + estilos y diseño forzados | 0,095 ms | 0,7 ms | 5 de 900 |

  Los picos parecen del recolector de basura. Apagado cuesta 0,0006 ms. Cada trazadora cuesta 2–10 µs y cada impacto 7–18 µs.
- **Costo de la vista táctica** (8 soldados, a 15 dibujos/s):

  | Vista | Lienzo | Por cuadro | Con rasterizado forzado | Rehacer fondo | Prender |
  |---|---|---|---|---|---|
  | Chica | 329 px | 0,062 ms | 0,32 ms | 0,2 ms (antes 2,4) | 3 ms una vez |
  | Grande | 634 px | 0,031 ms | 0,56 ms | 0,7 ms | 3 ms una vez |

  Apagada cuesta 0,0002 ms. El rasterizado forzado (`getImageData`) acá es por software; con aceleración (lo normal en Chrome con GPU) lo hace la GPU, fuera del hilo del juego.
- **Diseño (medido en el DOM):**
  - La chica ocupa de y 84 a 584 y las armas empiezan en 591: no las tapa. Su cabecera no se corta.
  - La grande: las 8 filas de la tabla miden 19 px, un renglón cada una.
  - Nada tapa la mira: el arco va a 27 de 200 unidades (43 px a 720p), las cuñas a 66–87 y las granadas a 88.

**Capturas para mirar:**
- `capturas/j01_hud.png`: radio (2 de peligro), arco a 0,65, dos golpes, granada a 6 m, trazadoras e impacto.
- `capturas/j02_tactica_chica.png`: combate, «TE VIERON» y vista chica.
- `capturas/j03_tactica_grande.png`: vista grande con la tabla.

Las tres son de la corrida final. `j02` la miré con el código final de la vista chica. `j01` y `j03` las miré en la 1.ª corrida, antes de mover la flecha de la granada y de dejar la tabla en un renglón; esos dos cambios los verifiqué en `j02` y midiendo el DOM.

## 7. Cómo está armado cada sonido (para ajustar de oído)

Todo pasa por `auGate(clave,prioridad,máximo,ventana_ms)` y va envuelto en `auOneShot`.

**Cadena común** (`cadena`): ganancia según la distancia → pasa-bajos (Q 0,5) → paneo estéreo → destino.
- La frecuencia de corte es `max(850, 16000·e^(−d/45))` Hz. Si suena detrás, se multiplica por `1+0,3·frente`.
- El paneo es `lado·0,85`, y se achica a menos de 1,5 m.
- Retardo: `d/340` s.
- Perillas en `UESND.CFG`: `vol` .85 (bus de disparos), `dRef` 22 y `dExp` 1,3 (caída `1/(1+(d/22)^1,3)`: 10 m → 0,74 · 30 m → 0,40 · 80 m → 0,16), `lpCerca` 16000, `lpCaida` 45, `lpMin` 850, `sonido` 340, `pan` .85, alcances (`alcDisparo` 260, `alcPasos` 15, `alcEquipo` 10, `alcCuerpo` 32, `alcImpacto` 34, `alcVoz` 42), `radioVol` .5, `vozVol` .55.

**Disparos** (`UESND.TIRO`, una receta por arma). Salen por un compresor propio (−16 dB, 5:1, 3/160 ms) con ganancia `CFG.vol`, que se aplica al crearlo (una vez). Capas:
- **cuerpo**: ruido pasa-bajos que barre f0→f1 Hz. Fusil 4200→300 en 0,16 s, pico .85.
- **golpe**: seno que cae. Fusil 160→48 Hz en 0,09 s, pico .7. Es el «bum».
- **crack**: ruido pasa-altos a 2400 Hz, 35 ms, pico .5. Solo a menos de 70 m: el chasquido supersónico.
- **cola**: ruido pasa-banda 500→220 Hz, 0,42 s, pico .2·min(1, .45+d/60), 50 ms después. Va a más de 22 m, y en el tirador siempre: es el eco entre edificios, lo que queda de lejos.
- **eco**: solo el tirador, otro pasa-banda a los 0,28 s, de 0,5 s.

Cómo cambia cada arma:
- **Escopeta:** más grave y larga (cuerpo 2600→150 en 0,42 s, golpe 118→34 en 0,3 s). Llamadas a menos de 45 ms y 1,5 m cuentan como un solo tiro.
- **Tirador:** crack 3000 Hz con pico .7, cuerpo 5200→200 en 0,3 s, cola 1,3 s más el eco.

Compuertas: `ue_d_f` 3 por 110 ms, `ue_d_e` 2 por 150 ms, `ue_d_t` 2 por 200 ms. Prioridad 2 a menos de 45 m y 1 más lejos. Con más de 60 voces sonando, cada tiro usa solo cuerpo y golpe.

**Silbido:** tres capas, abiertas con pan·0,9.
- chasquido: pasa-altos a 5200 Hz, 20 ms;
- zumbido que se aleja: pasa-banda 2800–3600 → 700–1000 Hz, 0,15 s, Q 7;
- tono: seno 2200–2800 → 600–800 Hz, 0,13 s, muy bajo (.05).

Compuerta `ue_silb` 2 por 110 ms.

**Impacto:** a menos de 34 m, ganancia (1−d/34)²·.9. Compuerta `ue_imp` 3 por 140 ms.
- metal: pasa-altos 4200 Hz, 45 ms, más un cuadrado 900–1500 → 500–700 Hz. Uno de cada cuatro rebota con un seno 2400–3200 → 800–1100 Hz de 0,26 s.
- pared: pasa-banda 1600→700 más pasa-bajos 500→120.
- piso: 1100→500 más 380→100.
- carne: pasa-banda 600–900 → 240.

**Radio** (`ue_radio`, 2 por 350 ms). Sale con `radioVol` por una banda de radio (pasa-altos 480 Hz → pasa-bajos 2500 Hz).
- **La voz:** una sierra a f0 pasa por dos formantes pasa-banda (Q 5 y 8, ganancias 2,2 y 1,5), después por una puerta de sílabas, una distorsión `shCurve(10)` y una ganancia .34.
- **Sílabas:** cada una elige vocal (F1/F2 de a e i o u), con acento ×1,16 el 30 % de las veces. La frase baja un 22 % de tono hasta el final. Hay 2 a 4 sílabas por palabra, con pausas de 70–160 ms. En el 40 % de las sílabas suena una consonante (ruido pasa-altos 2300 Hz, 12 ms).
- **Estática:** un solo ruido en lazo, pasa-banda 1900 Hz. Abre en .42 (el chasquido), en 60 ms baja a .035 (el soplido) y en los últimos 100 ms sube a .3 (al soltar).
- **Pitido de cierre:** seno de 1180 Hz, .1, unos 90 ms.
- **Las 8 voces** (`UESND.VOCES`: tono, ritmo y formantes):

  | Voz | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
  |---|---|---|---|---|---|---|---|---|
  | f0 (Hz) | 96 | 112 | 88 | 124 | 104 | 134 | 80 | 118 |
  | sílabas/s | 4,8 | 5,6 | 4,2 | 6 | 5 | 5,4 | 3,9 | 6,4 |
  | formantes | ×1 | ×1,06 | ×,94 | ×1,1 | ×,98 | ×1,04 | ×,9 | ×1,08 |

- `dur` va de 0,5 a 5 s. `durFrase(texto)` = .45 + .058·letras, entre 0,7 y 3,6 s.
- Si viene `pos`, la misma voz distorsionada sale también desde el soldado: pasa-bajos ≤ 1100 Hz, ganancia `vozVol/(1+(d/7)^1,5)`, con paneo, hasta 42 m. Sirve para ubicarlo de oído.
- La pausa y el reset cortan la radio: la ganancia baja a 0 en 30 ms.

**Pasos** (`ue_pasos`, prioridad 0, 3 por 130 ms). Hasta 15 m, ganancia fuerza·(1−d/15)^1,6·.32.
- taco: pasa-bajos 360→110 Hz, 75 ms;
- salpicadura: pasa-banda 1700–2500 Hz, 40 ms, 12 ms después;
- corriendo (fuerza > 1,1): suela que se despega, pasa-banda 900→400, a los 30 ms.

**Equipo** (`ue_equipo`, prioridad 0, 2 por 200 ms). Hasta 10 m.
- roce: pasa-banda 2200–3400 → 1200–1800 Hz, 0,11 s;
- hebilla: Q 6, 3800–5200 Hz, 20 ms, entre 30 y 70 ms después;
- la mitad de las veces, un tic metálico: triángulo 1900–2600 Hz.

**Cuerpo** (`ue_cuerpo`, prioridad 1, 2 por 300 ms). Hasta 32 m.
- golpe: seno 95→38 Hz, 0,2 s;
- el cuerpo: ruido pasa-bajos 520→80, 0,26 s;
- el arma que rebota después: tres golpecitos pasa-banda a los 50, 110 y 170 ms, más un triángulo de 700–900 Hz.

**Para ajustar:** `UESND` no es global (vive adentro del juego). Se cambian los números en `mod_fx.js`: `CFG` para niveles y distancias, `TIRO` para el carácter de cada arma, `VOCES` para quién habla. Para subir o bajar todo lo de los soldados, `CFG.vol` (disparos) y `radioVol`.

## 8. Qué cambió en la revisión de esta sesión

- **Piso de la 1.15:** las chispas rebotaban en +0,02 y ahora rebotan en el piso real. Se usa `floorAt`, una vez por impacto.
- **HUD:** toda escritura al DOM pasa por `css()` y `att()`, que solo tocan si el valor cambió. La flecha de la granada quedaba tapada por el ícono y ahora va afuera.
- **Vista chica, que a 720p no se leía** (rótulos encimados y texto que tapaba las armas):
  - mide `min(420px,46vh,40vw)` desde y 84;
  - estados de una o dos palabras;
  - los rótulos de soldados se omiten si no hay lugar libre, y fuera del mapa va solo el nombre;
  - el último lugar conocido se dice una sola vez si lo comparten todos;
  - la leyenda es corta.
- **Vista grande:** la tabla quedó sin columna de rol (lo dicen el color y la leyenda) y la columna de texto pasó a 422 px.
- **Fondo de la grilla:** se recorre fila por fila en vez de llamar a `eCell` por casillero. Bajó de 2,4 a 0,2 ms.
- **El ancho del lienzo** se lee del DOM solo al prender o al cambiar la ventana.
- **IA real:** se suman los estados y órdenes de `ue_ia.js`, la línea del láser y la lectura de `UE.estado()` tal como viene.
- **Peligro:** se suma `recarga_jugador`.

## 9. Pendientes y dudas

- **No hay parlantes:** los números de sonido son de nodos y voces. El timbre no está escuchado. Lo primero para ajustar de oído: el volumen de los disparos contra los del jugador (`CFG.vol`) y que la radio no tape la música (`radioVol`).
- **Costo en un tiroteo:** armar cada sonido cuesta unos 0,5 ms de JS por tiro (13 nodos) en esta máquina. Con 8 tirando (~20 tiros/s), eso suma ~0,2–0,3 ms por cuadro solo en crear nodos. Si hace falta bajarlo, se puede compartir una sola fuente de ruido entre las capas de cada tiro (2–3 nodos menos).
- **La vista táctica**, prendida, crea arreglos chicos para los rótulos en cada dibujo (15 por segundo). Apagada no cuesta nada.
- **Sin probar sobre fondo claro adentro del juego:** el retén de noche es oscuro. Las pruebas sobre fondo claro son de la página suelta (`p06_hud_claro.png`, `p10_det_llena_claro.png`): el contorno negro del arco y de las cuñas las sostiene.
- **Avisos al integrador:**
  - `UE.estado()` de la IA no tiene la forma de 4.1. UEHUD la entiende igual, pero conviene unificar la SPEC.
  - `debug().escuadrones[].uc` es el mismo para los dos escuadrones (es de la red). La vista lo dibuja una vez.
  - La vista dibuja las granadas con un radio fijo de 7 m, porque `debug().granadas` no trae el radio.
