# M · los bichos contra la unidad especial — informe (base 1.16.0)

## 1. Archivos

- `M-bichos/mod_bichos.js`: el código nuevo (va delante de `/*UE:modulos*/`).
- `M-bichos/patch_bichos.py`: `python3 patch_bichos.py entrada.html salida.html`. 22 reemplazos anclados (el módulo + 21 ediciones
  marcadas `/*UE:M*/`); falla sin escribir si un ancla no aparece exactamente una vez. Aplica entero sobre `v116/base.html`.
- `M-bichos/t/`: pruebas (no van al juego). `prep.py` arma `juego_m.html` (base 1.16 + parche), `base_det.html` y `mod_det.html`
  (las dos con un preludio determinista: azar con semilla, sin cuadros reales, reloj simulado). `reg_run.js` + `reg_cmp.js`
  (regresión cuadro por cuadro), `t_sold.js` (soldados de mentira), `t_costo.js` (costo). Logs: `reg_base116.log`,
  `reg_mod116.log`, `t_sold116.log`, `t_costo_mod.log`. `t_sold114.log` es la corrida vieja sobre 1.14 (74 OK, 6 FALLA).

## 2. Contrato real (SPEC 4.1 y 4.6)

- **Blanco de cada bicho**: `e.tg` = `null` (el jugador) o uno de los objetos de `UEB.objetivos()`. Lo revisa cada 0,5 s,
  escalonado de a 8. Candidatos: el jugador y los soldados vivos a menos de 24 m a los que puede llegar (línea recta libre con
  `enLine` o un camino corto A* acotado) y les llega con el golpe en altura. Gana el más cercano, con la distancia a un soldado ×1,15.
  Histéresis: otro blanco (soldado o jugador) gana solo si su distancia pesada es menor que 0,75 × la del actual. Lo suelta si muere, si se aleja a
  más de 30 m, si no hay camino (veto de 4 s a ese soldado) o si se traba dos revisiones seguidas yendo hacia él. El Engendro sigue
  siempre con el jugador; su pisotón y los autos que barre o arroja les pegan a los soldados.
- **Qué espera de `UEB.objetivos()`**: un arreglo (vacío = hoy) de objetos `{x,z,y,r,vivo,herir(daño,bicho)}`. Se pide **una vez
  por cuadro**. Requisitos:
  - **Identidad estable**: el mismo objeto para el mismo soldado de un cuadro a otro, con `x,z,y` al día. El bicho guarda la
    referencia (histéresis, enfriamiento de autos por soldado). Si se crean objetos nuevos cada cuadro, persigue una foto vieja.
  - `y` = altura de los **pies** (`floorAt(x,z)`; en la calzada −0,15). Todo se mide desde los pies del bicho (`e.gy`) y del soldado.
  - `r` opcional (0,4 si falta). Al morir: `vivo=false` (lo suelta en el acto). Si solo se lo saca de la lista, lo nota en la
    revisión siguiente (hasta 0,5 s) y en ese lapso `herir` todavía puede llegar: que la IA ignore daño a un soldado muerto.
  - `herir(daño,bicho)`: `bicho` es el que pega (mordida, salto, escupitajo, pisotón) o `null` (auto que se desliza).
    Daños: los de `TYPES` (rata 7, bagayo 6 y 12 en la caída del salto, baboso 14, escupidor 10 por escupitajo, mole 28,
    Engendro 38 por pisotón; los golpes van × `e.dmgMul`, como con el jugador); auto deslizándose `round(6+3·velocidad)`.
- `rayoBichos(o,d,maxT) → null | {e,t,p,ojo}`: `o`, `d` Vector3 (`d` unitaria). Misma cuenta que `fire()` (no se tocó `fire()`).
  El objeto devuelto **se reutiliza** en cada llamada: copiar lo que haga falta antes de volver a llamar. `t` puede ser apenas
  negativo si el origen está dentro del bicho. Actualiza las esferas de las partes una vez por cuadro como mucho. No mira paredes
  ni autos (eso lo hace quien llama, como en `fire()`).
- `bichosVivos() → [{ref,x,y,z,r,tipo,hp,tg,est}]`: centro del cuerpo (`y` = `position.y+bodyY`), siempre el mismo arreglo y los
  mismos objetos. Extras: `tg` (a quién persigue; `null` = jugador) y `est` (`'rise'`/`'climb'` = todavía está saliendo).
- `damageEnemy(e,dm,dir,de)`: `dir` es Vector3 (obligatorio, como antes). Con `de==='soldado'`: sin puntos, bajas, combo ni frase;
  se actualiza el contador de bichos; puede dejar caja; si es el Engendro, cierra la barra y anuncia «Lo reventaron ellos».
  Solo aplica daño al cuerpo: romper partes u ojos es lógica de `fire()` que no pasa por acá.
- Explosión de auto: `UEB.explosion(W0,8,70,'auto')`, una vez por explosión, con `W0` = centro del auto (`c.x, c.by+0,8, c.z`):
  el mismo radio y daño que recibe el jugador.

## 3. Ediciones dentro de funciones existentes (anclas)

| Función | Ancla | Qué hace |
|---|---|---|
| `updateEnemies` | `const dx=P.pos.x-o.position.x,dz=P.pos.z-o.position.z,dist=Math.hypot(dx,dz)\|\|1e-3;` (reemplazo) | `tg=bchBlanco(e,dt)`, `tgx,tgz,tgy`; `dx,dz,dist` hacia el blanco; `distP` al jugador |
| `updateEnemies` | delante de `if(Math.hypot(P.pos.x-o.position.x,P.pos.z-o.position.z)<c.r+1.3&&P.pos.y<1.2)` | caída del salto del bagayo sobre el soldado |
| `updateEnemies` | `P.pos.y-e.gy<c.height+1&&e.gy-P.pos.y<1.2` | empezar a pegar: altura del blanco |
| `updateEnemies` | `if(dist<26&&e.moanCd<=0` · `else if((dist<30\|\|e.type==='boss')&&growlCd<=0` | sonidos: `distP` |
| `enSteer` | detrás de `function enSteer(e,x,z,out){const cls=isBig(e)?1:0;` | con soldado: `bchSteer` |
| `atkTick` | detrás de la cabecera; delante de `A.tgt.set(P.pos.x,…`; `_w.set(P.pos.x-o.x,0,P.pos.z-o.z)…T.lunge);`; `if(d<c.r+1.45&&P.pos.y<c.height+1&&e.hp>0){hurtPlayer(…)…}}` | punto del golpe, envión y daño hacia el blanco; pisotón del Engendro en área |
| `spit` | `const tgt=_v.set(P.pos.x+P.vel.x*.4+` · `projs.push({m,v:vel,dmg:e.type==='boss'?16:10}` | apunta al soldado; anota quién escupió |
| `updateProjs` | detrás de `if(dx*dx+dy*dy+dz*dz<1.1*p.m.scale.x){hurtPlayer(p.dmg,true);hit=true;}` | **ancla nueva** (la del piso cambió en la 1.15): escupitajo contra soldados |
| `damageEnemy` / `killEnemy` | cabeceras; `if(e.hp<=0)killEnemy(e);else painSound(e);}`; `kills++;if(comboT>0)…comboT=3;`; la línea del `feed(…)`; `announce('¡Lo reventaste!',` | cuarto parámetro `de` |
| `carBoom` | detrás de `if(dp<8)hurtPlayer(Math.round(70*Math.pow(1-dp/8,1.3)),false);` | `UEB.explosion` |
| `carHitsDynamic` | detrás de `P.vel.x+=dx*sp*.9;P.vel.z+=dz*sp*.9;p.hitP=.7;break;}}` | `bchAuto`: el auto deslizándose golpea soldados (techo con `c.by`, como el jugador) |

**Anclas delicadas**: las de `killEnemy` (puntaje, `feed`, `announce`: F o R podrían tocarlas), la línea de daño de `carBoom`
(cualquiera que agregue efectos a la explosión) y la primera línea del bucle de `updateEnemies`. De los demás, solo F entregó
parche (`F-fx/patch_fx.py`, solo marcadores): F+M y M+F aplican sobre `v116/base.html` en los dos órdenes.

## 4. Pruebas (todas sobre la base 1.16.0)

- **Regresión sin soldados** (`reg_run.js` sobre `base_det.html` y `mod_det.html`, misma semilla, jugador automático que camina,
  salta, cambia de arma y dispara): 11 400 cuadros (oleadas 1, 2, 4, 5 con el Engendro, y 6 en el retén con un auto que explota),
  1 528 558 valores en total (por cuadro: posición, giro, vida, estado y ataque de cada bicho, jugador, puntaje, combo, azar consumido,
  escupitajos, cajas, autos). **Idénticas byte a byte** (mismo md5), 0 errores en las dos. Se corrió con el código final.
- **Soldados de mentira** (`t_sold.js`, `t_sold116.log`): **83 OK, 0 FALLA**, 0 errores de página. Por grupo: A (los 5 tipos
  eligen al más cercano, llegan, pegan con el daño de `TYPES`, no tocan al jugador) 30 · A2 salto del bagayo 4 · B camino corto
  (rata, mole y baboso rodeando un auto) 6 · C muere su soldado y pasa a otro (tres formas de avisar la muerte) 6 · D jugador vs
  soldado más cerca 2 · E histéresis y sesgo 8 · F inalcanzables (edificio, techo) 3 · G suelta a 30 m 1 · H escupidor a 8, 16
  y 23 m (6/6, 7/7 y 6/7 aciertos; el que falta estaba en el aire; no lo suelta en 20 s) 3 · L pisotón del Engendro (3 soldados
  a <6,4 m reciben 38 en cada uno de los 4 pisotones; el de 14 m, nada) 4 · M auto arrojado → `UEB.explosion` 2 · N auto barrido
  golpea a un soldado (32) 1 · O muerte por soldado (sin puntos ni combo; 161 cajas en 300 muertes) 5 · P `rayoBichos` = `fire()`
  en 6000 rayos (3074 cuerpo, 1212 parte, 338 ojo, 1376 nada; 0 diferencias) 3 · Q explosión 2 · R `bichosVivos` 2 · errores 1.
- **Las 6 que fallaban en 1.14**:
  - `A bagayo: salta` y `la caída pega doble`: **la prueba**. Arrancaba a 10 m y llegaba antes de que se le cargara el salto
    (`leapCd` inicial 1–3 s); pegado al blanco (<1,8 m) ya no salta. Con el jugador quieto pasa lo mismo: nueva prueba A2 con
    control (con el salto listo a 0,5 s: 1 salto y 12 de daño contra el soldado y contra el jugador; con el salto a 3 s: 0 y 0).
  - `C (lista filtrada)`: **el código**. La primera revisión de «trabado» después de un golpe da en falso (la ventana de 1 s
    incluye el golpe) y bastaba una para soltar al soldado 4 s. Ahora hacen falta dos seguidas.
  - `H 16 m` y `H 23 m`: **el código**. El escupidor, al rodear al soldado, chocaba la vereda o un auto, contaba como trabado y lo
    soltaba por el jugador. Ahora el escupidor no suelta por trabarse ni por falta de camino mientras lo tenga a menos de 30 m.
  - `R`: **la prueba**. El baboso tarda 1,1 s en salir y se miraba a los 1,2 s. Ahora a los 0,6 s.
  - Por el mapa nuevo se movieron B (el clásico ya no está: taxi 784 y sedán 786), E (el furgón 781 quedó donde se paraba el
    jugador), F (la fachada quedó justo en el soldado), M y N (autos que no tocaron pruebas anteriores) y Q (explosión en `c.by+0,8`).
- Además, también cambié: si el soldado muere en medio del golpe, el bicho termina el golpe en el lugar (antes giraba y el envión
  podía salir hacia el jugador).
- **Costo** (`t_costo.js`, 20 bichos: 5 ratas, 4 bagayos, 5 babosos, 3 escupidores, 3 moles; 480 cuadros por corrida, 3 corridas
  de cada una, reloj real con resolución de 0,1 ms): `updateEnemies` 1,52 ms sin soldados · 1,71 ms con 8 soldados lejos (a más
  de 24 m: mismo comportamiento, solo el costo de elegir) · 1,68 ms con 8 soldados entre los bichos (20 de 20 los persiguen).
  Entre corridas iguales varía ±0,3 ms: la diferencia no se distingue del ruido. Microcostos: elegir blanco 0,25 µs por bicho
  (con 8 soldados; sin elegir 0,1 µs; sin soldados 0,15 µs), camino corto 11,8 µs (rodear un taxi) a 15,9 µs (40 m), 0,6 µs si el
  soldado está adentro de un edificio; `rayoBichos` 4,6 µs por rayo con 20 bichos; `bichosVivos` 0,8 µs. El A* corre solo para
  bichos con soldado y sin línea recta, cada 0,14–0,24 s: con 20 en ese caso son <0,1 ms por cuadro. No se crean arreglos por cuadro.

## 5. Pendientes y dudas

- No probado con la IA real: todo con soldados de mentira quietos. Lo más importante para el integrador es la identidad estable
  de los objetos de `UEB.objetivos()` (punto 2).
- `enUnstick` (el antitrabado del juego) sigue usando el campo hacia el jugador para el paso al costado y para reacomodar al
  bicho si el jugador no lo ve; con un soldado de blanco puede corrérselo hacia el lado del jugador. No lo toqué (la tarea lo pide).
- El escupidor rodeando a su blanco se traba seguido contra la vereda o los autos (en H, 6 a 8 s de 20); con el jugador hace lo mismo.
- No cubierto: `popSac` (el saco del escupidor que revienta salpica 8 al jugador a <3,5 m) no les pega a los soldados.
- Las pruebas de `t_sold.js` comparten estado entre grupos (autos empujados o golpeados en un grupo siguen así en el siguiente):
  por eso M, N y Q usan autos que nadie tocó antes.
