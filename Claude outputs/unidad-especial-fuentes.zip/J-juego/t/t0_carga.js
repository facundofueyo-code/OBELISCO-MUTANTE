// Prueba 0: carga, arranca, 10 s de partida y 10 s en el retén. Errores y estado básico.
const H=require('../../harness.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto',h.errors.length);
  try{
    lg('start',JSON.stringify(await h.start()));
    lg('ueg',JSON.stringify(await h.ev("({creado:UEG.creado,sold:UE.soldados.length,modelos:UEG.modelos.length,ajustes:UEG.ajustes,v:GAME_VERSION})")));
    lg('paso',JSON.stringify(await h.step(10)));
    lg('A',JSON.stringify(await h.ev("({T,wave,bichos:enemies.length,hp:P.hp,est:UE.estado()})")));
    await h.alReten();
    lg('reten',JSON.stringify(await h.step(10)));
    lg('B',JSON.stringify(await h.ev("({pos:[P.pos.x,P.pos.z],est:UE.estado(),sold:UE.soldados.map(s=>[s.nombre,s.rol,+s.x.toFixed(2),+s.y.toFixed(2),+s.z.toFixed(2),s.estado,s.vista?s.vista.vis:null])})")));
  }catch(e){lg('EXC',e.message.slice(0,500));}
  lg('errores',JSON.stringify(h.errors.slice(0,8)));
  await h.close();lg('cerrado');
})();
