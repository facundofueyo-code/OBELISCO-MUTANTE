/* Prueba de regresión «sin soldados, nada cambia»: corre una partida guionada y determinista y graba, cuadro por cuadro,
   el estado de los bichos, del jugador, de los escupitajos, de las cajas y de los autos. Se corre igual sobre
   t/base_det.html y t/mod_det.html y después se comparan los dos archivos byte a byte (reg_cmp.js).
   Uso: node reg_run.js <copia_det.html> <salida.bin> */
const H=require('../../harness.js');const fs=require('fs');
const [,,file,out]=process.argv;const t0=Date.now();const log=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(1)+'s',...a);
const INSTALAR=String.raw`(()=>{
  const TI={rata:0,bagayo:1,baboso:2,escupidor:3,mole:4,boss:5};
  let buf=new Float64Array(1<<21),n=0,fr=0;
  const put=v=>{if(n>=buf.length){const b=new Float64Array(buf.length*2);b.set(buf);buf=b;}buf[n++]=v;};
  function rec(){
    put(-777);put(fr);put(enemies.length);put(P.hp);put(P.pos.x);put(P.pos.y);put(P.pos.z);put(P.yaw);put(P.pitch);put(score);put(kills);put(combo);put(wave);put(toSpawn);
    put(Math.min(intermission,1e6));put(__rng.n);put(projs.length);put(pickups.length);put(T);put(shake);put(running?1:0);put(limbs);
    let a=0,b=0,c=0;for(const v of VCARS){a+=v.hits||0;b+=v.st||0;}for(const v of VDYN){c+=v.x+2*v.z+3*v.a;}put(a);put(b);put(c);put(VDYN.length);
    for(const e of enemies){const o=e.obj;put(TI[e.type]);put(e.hp);put(o.position.x);put(o.position.y);put(o.position.z);put(o.rotation.y);put(e.gy);put(e.phase);put(e.state==='chase'?2:e.state==='rise'?1:0);put(e.atk);put(e.slow);put(e.spitCd);}
    for(const p of projs){put(p.m.position.x);put(p.m.position.y);put(p.m.position.z);}
    for(const p of pickups){put(p.g.position.x);put(p.g.position.z);}
    fr++;}
  /* jugador automático: apunta al bicho más cercano y tira en ráfagas; camina, retrocede y se corre de costado por turnos;
     salta, cambia de arma, repone munición y salud con reglas fijas (iguales en las dos corridas) */
  function jugador(i){
    let b=null,bd=1e9;for(const e of enemies){if(e.state!=='chase')continue;const d=Math.hypot(e.obj.position.x-P.pos.x,e.obj.position.z-P.pos.z);if(d<bd){bd=d;b=e;}}
    if(b&&bd<50){const p=b.obj.position,dx=p.x-P.pos.x,dz=p.z-P.pos.z,dy=p.y+b.m.bodyY-(P.pos.y+1.6);P.yaw=Math.atan2(-dx,-dz);P.pitch=Math.max(-1.4,Math.min(1.4,Math.atan2(dy,Math.hypot(dx,dz))));mouseDown=(i%100)<75;}
    else{mouseDown=false;P.yaw+=.012;P.pitch=0;}
    if(i%7===0)shotLatch=false;
    const ph=Math.floor(i/300)%4;keys.KeyW=ph===0;keys.KeyS=ph===1||ph===3;keys.KeyA=ph===2;keys.KeyD=ph===3;
    keys.Space=(i%240)===10;
    if(i%600===450)switchTo((wi+1)%3);
    if(i%900===0){W[1].res=W[1].maxRes;W[2].res=W[2].maxRes;hudAmmo();}
    if(P.hp<35){P.hp=100;hudHP();}
    /* en el retén: prender fuego el auto más cercano una vez, para que explote (carBoom) */
    if(window.__K.quemar===i){let c=null,cd=1e9;for(const v of VCARS){if(v.st>=1)continue;const d=Math.hypot(v.x-P.pos.x,v.z-P.pos.z);if(d>9&&d<cd){cd=d;c=v;}}if(c)carDamage(c,25);}
  }
  function paso(nF,dtms){let t=window.__simT;for(let i=0;i<nF;i++){t+=dtms;__timers.adv(dtms);jugador(fr);frame(t);rec();}window.__simT=t;return {fr,n,T:+T.toFixed(2),wave,en:enemies.length,hp:P.hp,score,kills,over,rng:__rng.n};}
  function trozo(a,b){const u=new Uint8Array(buf.buffer,a*8,(Math.min(b,n)-a)*8);let s='';for(let i=0;i<u.length;i+=32768)s+=String.fromCharCode.apply(null,u.subarray(i,i+32768));return btoa(s);}
  window.__K={paso,trozo,quemar:-1,get n(){return n;},get fr(){return fr;}};return 1;})()`;
(async()=>{
  const h=await H.open(file);log('abierto',file);
  try{
    await h.ev(INSTALAR);
    await h.ev("SHJ.init();1");                               // como hace el precalentado del juego real
    await h.ev("__rng.seed(987654321);window.__simT=1e6;T=500;1");   // mismo azar, mismo reloj en todas las corridas
    log('start',JSON.stringify(await h.start()));
    const F=1000/60;
    /* tramo 1: partida normal desde el Obelisco, oleadas 1 y 2 */
    log('t1',JSON.stringify(await h.ev(`__K.paso(${40*60},${F})`)));
    /* tramo 2: oleada 4 (ya salen escupidores y moles) */
    await h.ev("wave=3;toSpawn=0;intermission=.5;1");
    log('t2',JSON.stringify(await h.ev(`__K.paso(${40*60},${F})`)));
    /* tramo 3: oleada 5, el Engendro */
    await h.ev("wave=4;toSpawn=0;intermission=.5;1");
    log('t3',JSON.stringify(await h.ev(`__K.paso(${60*60},${F})`)));
    /* tramo 4: Av. de Mayo, cerca del retén, oleada 6; se limpia lo que quedó en el Obelisco */
    await h.ev("(()=>{enemies.slice().forEach(e=>{scene.remove(e.obj);if(e.rig)scene.remove(e.rig.group);});enemies.length=0;bossAlive=null;$('#bossbar').hidden=true;GATE.open=true;STAGE='B';P.pos.set(-330,0,608);P.vel.set(0,0,0);wave=5;toSpawn=0;intermission=1;__K.quemar=__K.fr+600;return 1;})()");
    log('t4',JSON.stringify(await h.ev(`__K.paso(${50*60},${F})`)));
    const n=await h.ev("__K.n");const parts=[];const CH=400000;
    for(let a=0;a<n;a+=CH)parts.push(Buffer.from(await h.ev(`__K.trozo(${a},${a+CH})`),'base64'));
    fs.writeFileSync(out,Buffer.concat(parts));log('grabado',out,n,'valores');
    log('errores',h.errors.length,h.errors.slice(0,5).join(' | '));
  }finally{await h.close();}
})().catch(e=>{console.error('FAIL',e.stack||e.message);process.exit(1);});
