
/* ====================================================================================
   ARMAS (en coordenadas propias: origen en el centro de la cantonera, +Z hacia la boca,
   +Y arriba, +X a la izquierda del arma). Genéricas: ningún modelo de fábrica.
   Cada una devuelve su FICHA: dónde van las manos, la boca, la linterna, el cargador…
   ==================================================================================== */
const enZ=(G,x,y,z)=>G.en(x,y,z,PI/2,0,0);                 /* lo que sigue, a lo largo de +Z */
const perfil=(G,x,y,z)=>G.en(x,y,z,0,-PI/2,0);              /* polígono en (z,y), espesor en X */
const dientes=f=>(x,y,z)=>(Math.floor(z/.0105)%2?.62:1.12)*f;  /* rieles con dientes */

/* agarre: arma la rotación y la posición de la muñeca (en el arma) para que el cilindro que
   cruza la palma (AGARRE) coincida con el eje C,a del arma, con la palma mirando hacia p */
function agarre(izq,C,a,p){
  const ag=izq?AGARRE.I:AGARRE.D,ah=new V3(0,-Math.sin(ag.d),Math.cos(ag.d)),ph=new V3(izq?-1:1,0,0),Ch=ag.c.clone();if(!izq)Ch.x=-Ch.x;
  const e1=ah.normalize(),e2=ph.addScaledVector(e1,-ph.dot(e1)).normalize(),e3=new V3().crossVectors(e1,e2);
  const f1=a.clone().normalize(),f2=p.clone().addScaledVector(f1,-p.dot(f1)).normalize(),f3=new V3().crossVectors(f1,f2);
  const R=new M4().makeBasis(f1,f2,f3).multiply(new M4().makeBasis(e1,e2,e3).transpose());
  const q=new Q4().setFromRotationMatrix(R);
  return {q,p:C.clone().sub(Ch.applyQuaternion(q))};
}

function fusil(G){
  G.lado(1).hueso('arma').varia(.03);
  G.mat('goma').en(0,-.008,.01).caja(.044,.135,.02,.006);
  G.mat('poli');perfil(G,0,0,0).prisma([[.02,.062],[.15,.055],[.19,.04],[.195,.012],[.15,-.03],[.02,-.072]],.04,.007);
  G.mat('metal').en(0,.045,.12).caja(.012,.012,.03,.003);
  G.mat('arma');G.en(0,0,0).tubo(0,.035,.13,0,.035,.27,.0155,.0155,10,0);
  G.mat('arma');perfil(G,0,0,0).prisma([[.255,.03],[.40,.03],[.40,0],[.385,-.025],[.335,-.03],[.30,-.028],[.262,-.018]],.03,.003);
  G.mat('poli').en(0,-.03,.355).caja(.03,.04,.07,.006);
  G.mat('arma').en(0,.051,.36).caja(.032,.042,.235,.005);
  G.tinte(dientes(1)).en(0,.078,.495).caja(.022,.011,.49,.002).tinte(null);
  G.mat('metal').en(-.0175,.048,.37).caja(.003,.018,.058,0);
  G.mat('arma').en(0,.07,.258).caja(.038,.008,.02,0);
  G.mat('poli');perfil(G,0,0,0).prisma([[.272,-.02],[.307,-.022],[.295,-.075],[.288,-.13],[.258,-.128],[.255,-.09],[.262,-.04]],.03,.008);
  G.mat('arma').en(0,-.05,.335).caja(.008,.006,.055,.002);
  G.mat('metal').en(0,-.036,.323,.25,0,0).caja(.004,.02,.006,0);
  G.mat('poli').tinte((x,y,z)=>(Math.floor(z/.022)%2?.8:1.05));enZ(G,0,.04,.47).cil(.0265,.0265,.275,8,3);G.tinte(null);
  G.mat('arma');G.en(0,0,0).tubo(0,.035,.745,0,.035,.86,.0085,.0085,8,0);
  enZ(G,0,.035,.86).torno([[.0085,0],[.0115,.002],[.0115,.064],[.006,.07],[0,.07]],8);
  /* mira de punto rojo */
  G.mat('arma').en(0,.093,.385).caja(.026,.02,.045,.004);
  enZ(G,0,.116,.358).torno([[0,0],[.0175,.002],[.0175,.05],[.019,.06],[.016,.06]],10);
  G.mat('vidrio');enZ(G,0,.116,.412).disco(.0145,10);
  G.mat('arma').en(-.019,.116,.385,0,0,PI/2).cil(.006,.006,.008,6,2);
  /* linterna al costado izquierdo del guardamanos */
  G.mat('arma').en(.03,.04,.70).caja(.012,.022,.03,.003);
  enZ(G,.043,.04,.63).torno([[0,0],[.0125,.003],[.0125,.095],[.0165,.102],[.0165,.13]],8);
  G.mat('foco');enZ(G,.043,.04,.7605).disco(.0145,10);
  /* cargador curvo de 30 (hueso propio: en la recarga pasa a la mano) */
  G.hueso('cargador').mat('poli');
  perfil(G,0,0,0).prisma([[-.017,.004],[.019,.004],[.024,-.07],[.037,-.15],[.054,-.212],[.022,-.224],[.006,-.16],[-.008,-.08]],.024,.004);
  G.mat('arma').en(0,-.216,.038,-.3,0,0).caja(.028,.012,.042,.003);
  G.varia(.06);
  return {tipo:'fusil',
    agD:agarre(false,new V3(0,-.075,.283),new V3(0,.944,.33),new V3(1,0,.25)),
    agI:agarre(true,new V3(0,.04,.585),new V3(0,0,1),new V3(-.5,.86,0)),
    boca:new V3(0,.035,.93),luz:new V3(.043,.04,.762),ojo:new V3(0,.116,.30),cargador:new V3(0,-.035,.355),
    eyeccion:new V3(-.02,.048,.37),guarda:new V3(0,.04,.585),patada:1,culataLargo:.19};
}

function escopeta(G){
  G.lado(1).hueso('arma').varia(.03);
  G.mat('goma').en(0,-.01,.011).caja(.045,.14,.022,.007);
  G.mat('poli');perfil(G,0,0,0).prisma([[.02,.058],[.24,.042],[.275,.025],[.275,-.02],[.21,-.03],[.02,-.08]],.042,.008);
  perfil(G,0,0,0).prisma([[.25,-.02],[.285,-.022],[.275,-.075],[.268,-.13],[.238,-.128],[.235,-.09],[.24,-.04]],.03,.008);
  G.mat('arma').en(0,.017,.39).caja(.038,.075,.22,.008);
  G.mat('metal').en(-.0195,.03,.40).caja(.003,.022,.06,0);
  G.mat('suela').en(0,-.021,.42).caja(.022,.004,.07,0);
  G.mat('arma').en(0,-.03,.31).caja(.008,.006,.05,.002);
  G.mat('metal').en(0,-.026,.30,.25,0,0).caja(.004,.018,.006,0);
  G.mat('arma');G.en(0,0,0).tubo(0,.04,.50,0,.04,.95,.0115,.0115,10,0);
  G.mat('suela');enZ(G,0,.04,.9502).disco(.0115,10);
  G.mat('arma');G.en(0,0,0).tubo(0,.011,.50,0,.011,.875,.0105,.0105,8,0);
  enZ(G,0,.011,.875).torno([[.0105,0],[.0115,.003],[.0115,.02],[.008,.024],[0,.024]],8);
  G.mat('arma').en(0,.026,.86).caja(.02,.05,.022,.004);
  G.mat('metal').en(0,.055,.94).esfera(.003,.003,.003,6,3);
  G.mat('arma').en(0,.062,.47).caja(.022,.016,.012,.003);
  /* portacartuchos al costado izquierdo, con cuatro cartuchos */
  G.mat('equipo').en(.0215,.012,.40).caja(.006,.052,.10,.002);
  for(let i=0;i<4;i++){const z=.362+i*.025;
    G.mat('cart').en(.031,-.024,z).cil(.0095,.0095,.046,6,1);G.mat('laton').en(.031,.022,z).cil(.0098,.0098,.012,6,2);}
  /* linterna abrazada al cañón */
  G.mat('arma').en(.026,.03,.81).caja(.014,.024,.028,.003);
  enZ(G,.038,.03,.76).torno([[0,0],[.0125,.003],[.0125,.09],[.0165,.097],[.0165,.124]],8);
  G.mat('foco');enZ(G,.038,.03,.8845).disco(.0145,10);
  /* corredera (hueso propio: el guardamanos que bombea) */
  G.hueso('corredera').mat('poli').tinte((x,y,z)=>(Math.floor((z+.2)/.012)%2?.75:1.08)).en(0,0,0).caja(.048,.044,.17,.014).tinte(null);
  /* un cartucho suelto en el hueso del cargador: es el que la mano mete en la recarga */
  G.hueso('cargador').mat('cart').en(0,-.023,0).cil(.0095,.0095,.046,6,1);G.mat('laton').en(0,.023,0).cil(.0098,.0098,.012,6,2);
  G.varia(.06);
  return {tipo:'escopeta',
    agD:agarre(false,new V3(0,-.075,.262),new V3(0,.944,.33),new V3(1,0,.25)),
    agI:agarre(true,new V3(0,.014,.645),new V3(0,0,1),new V3(-.55,.83,0)),agIcorredera:true,
    boca:new V3(0,.04,.952),luz:new V3(.038,.03,.886),ojo:new V3(0,.064,.30),corredera:new V3(0,.014,.645),
    cargador:new V3(0,-.03,.42),eyeccion:new V3(-.02,.03,.40),guarda:new V3(0,.014,.645),patada:1.7,culataLargo:.24};
}

function tirador(G){
  G.lado(1).hueso('arma').varia(.03);
  G.mat('goma').en(0,-.01,.011).caja(.045,.14,.022,.007);
  G.mat('poli');perfil(G,0,0,0).prisma([[.02,.062],[.07,.08],[.20,.08],[.23,.06],[.25,.04],[.25,.005],[.19,-.035],[.03,-.088],[.02,-.088]],.042,.008);
  G.mat('arma');G.en(0,0,0).tubo(0,.035,.20,0,.035,.28,.0155,.0155,10,0);
  perfil(G,0,0,0).prisma([[.275,.03],[.43,.03],[.43,0],[.415,-.025],[.355,-.03],[.32,-.028],[.282,-.018]],.03,.003);
  G.en(0,.052,.39).caja(.034,.044,.25,.005);
  G.tinte(dientes(1)).en(0,.08,.575).caja(.022,.011,.61,.002).tinte(null);
  G.mat('metal').en(-.0185,.05,.40).caja(.003,.018,.06,0);
  G.mat('poli');perfil(G,0,0,0).prisma([[.292,-.02],[.327,-.022],[.315,-.075],[.308,-.13],[.278,-.128],[.275,-.09],[.282,-.04]],.03,.008);
  G.mat('arma').en(0,-.05,.355).caja(.008,.006,.055,.002);
  G.mat('poli').tinte((x,y,z)=>(Math.floor(z/.024)%2?.8:1.05));enZ(G,0,.04,.50).cil(.0275,.0275,.38,8,3);G.tinte(null);
  G.mat('arma');G.en(0,0,0).tubo(0,.035,.88,0,.035,1.0,.0095,.0095,8,0);
  enZ(G,0,.035,.995).torno([[.0095,0],[.021,.004],[.021,.222],[.018,.23],[.008,.23],[0,.23]],12);
  /* mira telescópica con anillas y torretas */
  G.mat('arma');for(const z of [.37,.48]){G.en(0,.096,z).caja(.024,.026,.02,.004);enZ(G,0,.122,z-.009).cil(.0185,.0185,.018,10,0);}
  enZ(G,0,.122,.305).torno([[0,0],[.019,0],[.021,.005],[.021,.035],[.0155,.05],[.0155,.25],[.025,.29],[.0255,.33],[.024,.335],[0,.335]],10);
  G.mat('vidrio');enZ(G,0,.122,.6405).disco(.021,10);
  G.mat('arma').en(0,.137,.45).cil(.012,.012,.022,8,2);
  G.en(-.0145,.122,.45,0,0,PI/2).cil(.011,.011,.02,8,2);
  /* módulo láser a la derecha del guardamanos */
  G.mat('poli').en(-.036,.042,.80).caja(.022,.026,.05,.005);
  G.mat('vidrio');enZ(G,-.036,.046,.8255).disco(.006,8);
  /* bípode (hueso propio): patas plegadas hacia adelante, se bajan rotando */
  G.hueso('bipode').mat('arma').en(0,-.004,0).caja(.034,.02,.03,.005);
  for(const s of [1,-1]){G.en(0,0,0).tubo(s*.012,-.01,.004,s*.045,-.012,.215,.0058,.005,6,2);G.mat('goma').en(s*.045,-.012,.218).esfera(.008,.008,.008,6,3);G.mat('arma');}
  /* cargador recto de 10 */
  G.hueso('cargador').mat('poli');perfil(G,0,0,0).prisma([[-.026,.004],[.024,.004],[.026,-.105],[-.024,-.105]],.026,.004);
  G.mat('arma').en(0,-.107,0).caja(.03,.01,.054,.003);
  G.varia(.06);
  return {tipo:'tirador',
    agD:agarre(false,new V3(0,-.075,.303),new V3(0,.944,.33),new V3(1,0,.25)),
    agI:agarre(true,new V3(0,.04,.66),new V3(0,0,1),new V3(-.5,.86,0)),
    boca:new V3(0,.035,1.225),laser:new V3(-.036,.046,.827),ojo:new V3(0,.122,.27),cargador:new V3(0,-.035,.395),bipode:new V3(0,.005,.84),
    eyeccion:new V3(-.02,.05,.40),guarda:new V3(0,.04,.66),patada:1.35,culataLargo:.25};
}

/* granada de mano: cuerpo, espoleta, palanca y anilla (origen en el centro) */
function granadaGeo(G,hueso){
  G.lado(1).hueso(hueso).mat('granada').en(0,0,0).esfera(.031,.036,.031,10,6);
  G.mat('metal').en(0,.03,0).cil(.0105,.0095,.024,8,2);
  G.en(0,0,0).cinta([[.006,.054,0],[.02,.051,0],[.033,.03,0],[.034,.0,0],[.027,-.02,0]],.012,.003,(i,p)=>[p[0],p[1]*.3,0]);
  G.en(-.017,.046,0,PI/2,0,0).toro(.011,.0017,10,3);
}
