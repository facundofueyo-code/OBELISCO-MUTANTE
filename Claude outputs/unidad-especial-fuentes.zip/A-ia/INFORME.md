# INFORME — A-ia: IA de escuadrón de la Unidad Especial

Todo lo que dice este informe sale de correr `node sim/correr.js` (12 semillas por escenario, 30 cuadros/s; el costo, a 60). El resumen completo de la última corrida está en `sim/salida/resumen.txt`; el detalle por corrida, en `sim/salida/detalle.txt`.

## 1. Archivos

| Archivo | Qué es |
|---|---|
| `ue_ia.js` | El núcleo: `UE_TUNE`, frases, `crearUE(ENV,TUNE)`. JS puro, sin Three ni DOM. Termina con `if(typeof module!=='undefined')module.exports={crearUE,UE_TUNE};`. La cabecera resume el contrato. |
| `sim/mundo.js` | El retén simulado. JS puro **sin `require`**: sirve tal cual en el navegador para la página de la vista desde arriba. API documentada en la cabecera. |
| `sim/verificar.js` | Las 10 verificaciones de juego limpio (también JS puro: la página puede usarlas en vivo). |
| `sim/jugadores.js` | Jugadores automáticos a–f. |
| `sim/correr.js` | Corre todo (Node). `--esc a,f0 --semillas N --fps 30 --trazas --costo --perfil --tune '{json}'`. Sale con código 1 y un mensaje si se rompe una regla. |
| `sim/prueba_modelo.js` | Prueba los caminos del juego que el simulador no usa: modelo falso en `ENV.vista`, `THREE` presente, `debug`, `estado`, `reset` con `dispose`. |
| `sim/dibujar.py` | Láminas desde arriba: `python3 sim/dibujar.py trazas/f0.json --desde 12 --cada 4 --n 8 --caja x0,x1,z0,z1`. |
| `trazas/` | `a c e f0 g12 .png` (más los `.json` de todos los escenarios, semilla 1). |
| `partes/p1…p7.js` | El borrador original (p1–p6) y lo que agregué (p7). Quedan como historia: **lo que vale es `ue_ia.js`**, que tiene encima todas las correcciones. |

## 2. API

### crearUE / UE (SPEC 4.7, con agregados)

```js
const UE = crearUE(ENV, TUNE)          // TUNE se mezcla con UE_TUNE campo por campo; acepta `daño` o `dano`
UE.escuadron({nombre, roles, puestos, ronda, nido, reunion}) → esc
   // roles ['jefe','asalto','granadero','tirador'] · puestos {rol:{x,z,rumbo}} o [{x,z,rumbo}] alineado con roles
   // ronda [{x,z}] la camina el asalto · nido {x,z,y,rumbo,r}: techo (y = altura del techo; r = tope de la plataforma, 4 m)
   // reunion {x,z} · rumbo = atan2(dx,dz) (π/2 = al este)
UE.refuerzo({nombre, roles, sale:{x,z}, camino:[{x,z}]})   // sus soldados se CREAN cuando llegan (no están antes en UE.soldados)
UE.update(dt) · UE.reset()             // reset llama vista.dispose() y rehace lo pedido con escuadron/refuerzo
UE.soldados                            // todos, vivos y muertos
UE.rayo(o, d, maxT) → null|{s,t,parte} // o,d {x,y,z}; con modelo usa s.vista.rayo(o,d); si no, cápsulas por postura
UE.herir(s, daño, dir, parte, de)      // parte 'cabeza'|'torso'|'brazo'|'pierna' (×2,2 / ×0,85 / ×0,7) · de 'jugador'|'bicho'|'granada'|'auto'
UE.balaCerca(o, d, t) · UE.explosion(pos, radio, daño, de)
UE.ruido(pos, tipo, fuerza)            // pos = PIES de quien hizo el ruido. Solo 'disparo','pasos','jugador' ubican al testigo
                                       // (con error que crece con la distancia); 'explosion','impacto', otros: alarman y hacen mirar
UE.objetivos() → soldados vivos        // tienen x,y,z,r,vivo,herir(daño,bicho) (UEB.objetivos)
UE.estado() → {sospecha, x, z, angulo, combate, busqueda, quedan, refuerzo:'no'|'pedido'|'llego', refuerzoEn}
UE.debug()  → lo de la SPEC + por soldado (y, tarea, vivo, sosp, laser, luz) y por escuadrón (fase, flanco)
// extras: UE.escuadrones, UE.red (lo que sabe la unidad), UE.T, UE.astar, UE.interno (pruebas y perfil)
```

`ENV` es el de la SPEC. Agregados que la IA usa si están: `peligros()` puede traer `{de, tipo:'granada'|'auto'}` (con `de` = el soldado, sus compañeros se corren sin gritar «¡Granada!»); `bala(ev)` trae además `{modo:'pegar'|'suprimir'|'aviso'|'bicho'|'laser', ficha, raf, px,py,pz}` y **el objeto se reusa** (copiarlo si se guarda); `radio(s,…)` para «Tizón en camino» recibe una voz virtual `{virtual:true, nombre}`; `evento(nombre, datos)` con: contacto, combate, sospecha, nada, perdido, busqueda, limpio, guardia, jugador_muerto, baja, jefe_caido, herido, refuerzo{fase: pide|pedido|interrumpido|entra|llega}, granada_orden, granada_aviso, granada, flanco, flanco_sale, flanco_llego, flanco_fin, flanco_no, avance, empuje, recarga, bichos, tirador_mira. El modelo (4.2): `laser` es un objeto plano `{x,y,z}`; `mYaw>0` = arma a la izquierda del cuerpo; `asoma` −1/+1.

### sim/mundo.js

```js
const M = crearMundo(mapa, {semilla, reten:true}); const UE = crearUE(M.ENV, UE_TUNE); M.conectar(UE); M.armarReten({refuerzo, roles, rolesRefuerzo});
// cada cuadro:
M.moverJugador(vx, vz, dt, {agach, correr})  // tope 3,0 agachado · 6,2 · 9,6 corriendo; choca y desliza con la grilla
M.dispararJugador(x, y, z) → null | [{pega, s, parte, hx,hy,hz}]   // arma actual: 'pistola'|'escopeta'|'uzi'|'fusil' (M.armaJugador)
M.recargarJugador() · M.lanzarGranadaJugador(x, z) · M.linterna(on) · M.soltarBichos(n, {cada, desde})
M.paso(dt)                                 // reloj, UE.update, granadas (física simple + arco), bichos
M.sacarEventos() → [{tipo:'bala'|'radio'|'herida'|'granada'|'explosion'|'laser'|'evento'|'muerte', t, …}]
M.foto() → {t, jugador, soldados, escuadrones, bichos, granadas, laseres}
M.rayo, M.lv, M.camino, M.libre, M.celda, M.grilla, M.reten, M.zonaLuz, M.jugador, M.t, M.ENV
```

## 3. Resultados (12 semillas; mediana y rango)

| Esc. | Jugador automático | Resultado |
|---|---|---|
| a | parado al descubierto a 30 m (−411; 601,5), iluminado | muere 12/12, **7,5 s** después del contacto (7,3–7,8). Daño: tirador 48 · granada 35 · escopeta 18 · fusil 3,5 |
| b | a cubierto, se asoma 1 s cada 3 s **siempre por el mismo lado**, pistola | muere 12/12 a los 19 s del contacto; mata 0 (0–4) |
| c | escondido y quieto; a los 10 s se va 20 m agachado | 1.ª granada **4,4 s** después de esconderse (4,1–4,5). Lo ven moverse 12/12 (a los 7 s el escuadrón avanza sobre el lugar viejo). De las 10 granadas tiradas después de que se movió, 4 cayeron en el lugar viejo (≤3 m del objetivo y ≥4 m de donde estaba él) |
| d0 | sigilo agachado por la vereda norte, sin linterna | 1.ª sospecha a **42,6 m** (el tirador); contacto a 6,5 m del asalto que hace la ronda, a 40,6 m de la barricada |
| d1 | igual, con linterna | 1.ª sospecha a **59 m**; contacto a 21,5 m del asalto, a 56 m de la barricada |
| e | rodea por H. Yrigoyen y entra por San José (por detrás) y pelea | nunca lo ven antes de la esquina; mata 4 (2–7; 3,5 de Ceniza), muere 8/12 |
| f0 | **jugador decente, armas base** | mata **2,5** (0–8) antes de morir, muere 10/12. Bajas por corrida: 4,1,4,1,0,8,3,0,2,3,4,0 |
| f1 | jugador decente con fusil | mata 6,5 (2–8), muere 5/12 |
| g6 | 6 bichos salen del subte detrás del retén | los 6 muertos en 29 s; muere 1 soldado (0–2) |
| g12 | 12 bichos | matan 5 (4–7); mueren 3 soldados (el tirador en el techo sobrevive); no limpian en 80 s |
| h | f0 + el jefe muere a los 15 s de combate | desorden: fichas como máximo **1** (mediana 0), **0** órdenes nuevas durante los 7 s; después manda el siguiente |

Con 24 semillas, f0 queda: bajas 0 → 5 corridas, 1 → 2, 2 → 1, 3 → 5, 4 → 6, 5 o más → 5; muere 18/24.

Otras medidas: flanqueos por combate 2–3,5; tardan 5–8 s en llegar (mediana). Refuerzo: lo piden a los 45 s de combate (o antes si quedan 2), llega en 5 a 12 de 12 corridas según el escenario; el pedido se cortó hiriendo al que hablaba 1 vez. Radio: 17–20 frases por minuto de combate (una cada ~3 s). Granadas por pelea: 2–5.

**Contra los objetivos de la TAREA:** «parado a 30 m muere en 4–7 s» → 7,5 s (apenas arriba; ver 7). «Jugando bien mata 2 o 3 la mitad de las veces y a veces a los 4» → mediana 2,5; la distribución es ancha (ver 7). «Casi nunca muere sin un aviso antes» → garantizado por construcción y medido por las verificaciones 2, 3 y 5: ninguna granada sin grito, ningún tiro de tirador sin 1,2 s de láser, ninguna primera ráfaga que pegue.

## 4. Las 10 verificaciones

Las 10 pasan en las 12 semillas × 11 escenarios, y también con **30 semillas** (330 corridas, más de 3 millones de chequeos). Cómo se juzga cada una (contra el mundo real del simulador, no contra las banderas de la IA):

1. Cantidad de soldados con ficha por cuadro ≤ `fichas`; cada bala `pegar` sale de uno con ficha (en el momento del tiro); un solo láser a la vez. El tirador va aparte, como dice la SPEC.
2. Por cada granada de soldado: su grito «¡Granada va!» ≥0,6 s antes de soltarla, mecha ≥3 s, explosión ≥3 s después del grito.
3. Cada tiro del tirador a más de 12 m: láser prendido y sobre el jugador (≤2,5 m del cuerpo actual o de donde estaba 0,25 s antes, con línea real) ≥1,2 s seguidos.
4. Cada vez que cambia el último lugar conocido tiene que haber una señal real a esa hora (alguien con línea real al jugador, o un disparo o pasos corriendo) y el lugar tiene que coincidir con donde estaba (≤0,8 m por vista, ≤2·error+2 por oído). Granadas: al lugar conocido (≤2 m: ver 6). Supresión sin verlo: cerca del lugar conocido.
5. La primera ráfaga de cada soldado tras un contacto nuevo no pega.
6. Ventana deslizante de 1 s sobre el daño de fusil y escopeta: ≤32.
7. Ningún tiro antes de 0,35 s de enterarse (el reloj vuelve a cero cada vez que el escuadrón vuelve a entrar en combate).
8. Toda bala que pegó se recorre de a 5 cm contra la grilla real: nada en el medio.
9. Ningún soldado que quiere moverse recorre menos de 0,4 m en 3 s.
10. Sin NaN, sin excepciones (también se probó con un modelo falso y `THREE` presente), nadie dentro de un casillero bloqueado.

Tolerancias que tuve que poner (y por qué): la línea «real» para la 4 acepta el ojo corrido 0,25 m y cualquier punto de la cápsula del jugador, y saltea los primeros 0,6 m como pide la TAREA para la línea de visión, porque la grilla entra inflada 0,3 m y un rayo que roza la esquina inflada de un auto no ve menos en el juego.

## 5. Costo

`UE.update` con 8 soldados peleando (jugador que no muere, refuerzo inmediato), 60 cuadros/s, 5280 cuadros: **media 0,03–0,05 ms · p99 0,35–0,75 ms · máximo 1,2–4,3 ms · 0,7 A\* por segundo** (rangos de varias corridas iguales: la máquina tiene 2 núcleos compartidos y mide con ruido). Los picos son los cuadros con un trabajo pesado (A\* con exposición, búsqueda de cobertura); por eso cada trabajo tiene ahora tope de casilleros de A\* (`aMaxIt` 3000) y de líneas de visión nuevas (`presuLineas` 500). Con `--perfil` se ve cada trabajo.

## 6. Qué cambié y por qué

**Números de `UE_TUNE`.** Los de la SPEC quedaron como estaban; probé daño de fusil 6 contra 7 con 24 semillas y no movió la aguja (f0: mediana 3 contra 3,5), así que quedó 7. Agregué:
- `reaccionEspera` 0,36 s, `esperaT` 4 s, `asientoEspera` 0,2/s: **«lo están esperando»**. El que lo vio esconderse y sigue en su lugar no pierde la puntería y, si reaparece en el mismo lugar, reacciona en 0,36 s en vez de 0,45. Asomarse siempre por el mismo lado se paga; cambiar de lugar se la resetea. Es la causa de que b muera rápido.
- `reaccionCerca` 18 m: si lo ve más cerca que eso, primero devuelve el fuego agachado y después se cubre (no corre dando la espalda).
- `aMaxIt` 3000, `presuLineas` 500 (costo), `tirador.cadencia` 1,2 (cuando se defiende de bichos), `perfil` (medir).
- Perillas para Facu: `fichas`, `punteria`, `dano`. Medido: `punteria` 1,2 → el decente mata 4 en vez de 2,5; `fichas` 1 casi no cambia.

**Correcciones al borrador (p1–p6), además de completar el cerebro y la API:** al soldado le faltaban campos (`pend`, `_laser`, etc.: se rompía en el primer encolado); subir al nido nunca ponía `elev` y el techo propio le tapaba la vista (ahora la plataforma es «los casilleros ocupados seguidos desde sus pies»); la línea de visión muestreada cada 0,5 m veía a través de esquinas de autos: ahora recorre la grilla exacta; la boca del arma de pie (1,42 m) no pasaba por arriba de un auto de 1,5 m: ahora 1,56; tiraban a los pies de los bichos; el tirador contra un bicho daba `NaN` (sin cadencia); `c.tiro` nulo rompía al tirador fuera del nido; «Tizón en camino» lo decía un soldado que no existía; las respuestas de radio dirigidas no se procesaban; la ráfaga de aviso se «gastaba» si se cortaba antes de la primera bala (ahora cuenta recién cuando sale); las fichas tenían un hueco de 0,4 s sin motivo.

**Comportamiento agregado:** la base de fuego exige cobertura **con tiro** (con un prefiltro barato de «línea de fuego» en el caché de exposición) y la busca más adelante si atrás de la barricada no hay; cuando alguien lo ve, los que tienen tiro se asoman enseguida («¡ahí está!»); el que lo tiene encarado y bien apuntado alarga la asomada; la granada «quieto o escondido 3,5 s» también vale después de «lo perdí», y si pegado a un auto no hay arco cae hasta 1,8 m más allá, del lado de atrás de su cobertura; nadie declara «lo perdí» ni arranca un barrido mientras un compañero lo está viendo; el refuerzo primero llega por su camino y, si está lejos, se acerca de a saltos de cobertura; con 2 o menos o en repliegue nadie avanza solo; un flanqueo tiene que mover al menos 5 m; las frases que avisan algo (flanqueo, recarga, refuerzo…) esperan su turno en vez de perderse y vencen a los 2,5 s; «Lo perdí» cada 8 s como mucho; el tirador en el nido se defiende de bichos a menos de 15 m.

## 7. Decisiones, dudas y pendientes

- **SPEC contra TAREA:** la TAREA dice «con 3 o menos no hay flanqueo»; la SPEC, «flanqueo si quedan 3 o más». Seguí la SPEC.
- **Aviso:** la primera ráfaga avisa en cada contacto nuevo desde guardia o sospecha (no al volver de una búsqueda). El tirador también avisa con su primer tiro; de cerca (<12 m) tira sin láser, como pide la TAREA, y eso queda fuera de la verificación 3.
- **Disposición provisoria:** desde los puestos del jefe y el granadero (x −441) **no se ve el este**: los tapan los furgones y el auto clásico que ya estaba en (−432,6; 608,7). Por eso en (a) los fusiles tardan ~4 s en llegar a una cobertura con tiro y el que mata es el tirador más la granada (7,5 s contra el objetivo de 4–7). Con la disposición definitiva de W conviene que los puestos tengan línea a la avenida.
- **f0 tiene mucha dispersión** (0 bajas en ~20 % de las corridas, 5 o más en otro 20 %). Parte es el jugador automático: se acerca un tramo al descubierto, se asoma desde una o dos coberturas, avanza cuando oye «recargando». Un humano decente probablemente quede más cerca del objetivo; habría que confirmarlo jugando.
- **Con fusil (f1) el jugador gana demasiado** (mata 6,5 y muere 5/12): 22 de daño cada 0,09 s contra 100 de vida. Es del módulo R; sugiero bajar el daño del fusil del jugador o dárselo con poca munición.
- **Sigilo:** a oscuras y agachado la vista es 45 m, así que nadie lo nota antes; el que lo descubre siempre es el asalto de ronda, a 6,5 m. Si Facu lo quiere más difícil: `vistaDist` o la ronda.
- **12 bichos superan al escuadrón**: las granadas no sirven contra bichos rápidos (en 0,7 s + 3 s de mecha ya se fueron).
- En **c** siempre lo ven al moverse: a los 7 s sin señal el escuadrón avanza sobre el lugar viejo. Que la granada y la supresión van al lugar viejo se ve igual (4 de 10 granadas cayeron lejos de él, en el lugar conocido) y lo controla la verificación 4.
- **Sin probar:** en un navegador de verdad (sí corrí núcleo, mundo, verificador y jugadores juntos en un contexto aislado sin `require` ni `module`, 60 s sin errores) y contra el modelo, la grilla y `GRAN.arco` reales. El integrador tiene que pasar en `UE.ruido` los pies del jugador, en `ENV.rayo` incluir autos, y en `ENV.peligros` el campo `de` para las granadas propias.
