# UNIDAD ESPECIAL — especificación compartida

Documento común para todos los que trabajan en esta función. Leelo entero antes de empezar: tu tarea puntual está en tu mensaje, acá están el diseño, las reglas del juego por dentro y los contratos entre módulos. Si algo de tu tarea choca con este documento, manda este documento, y avisalo en tu informe.

## 0. Qué estamos haciendo

**Obelisco Mutante** es un juego de terror en primera persona hecho en un solo archivo HTML (Three.js r128 incluido, sin dependencias). Lo hace Facu, que no programa: lo dirige y lo prueba. Transcurre de noche, con niebla, en el centro de Buenos Aires a escala real. Hasta hoy todos los enemigos son mutantes que te corren o te escupen.

Facu pidió un enemigo nuevo: **unidades especiales** que eliminan a cualquier testigo del incidente. Decisiones que ya tomó:

1. **Quiénes son:** una unidad secreta sin insignias. De negro, con máscara antigás, sin identificación. Nadie sabe quién los manda.
2. **Con los mutantes:** pelean contra todos. Matan bichos y testigos por igual; se arman combates de a tres.
3. **Dónde:** un retén en Av. de Mayo, a la altura del Palacio Barolo, camino al Congreso. Al principio no saben que el jugador está: se los puede espiar, emboscar o esquivar.
4. **Botín:** el jugador puede levantar su fusil y sus granadas.
5. Quiere que la IA sea muy compleja, y **difíciles pero justos**.

Lo que se entrega ahora es un **concepto**: el archivo del juego NO se toca. Se arma una **copia de prueba** del juego (v1.14.0) con todo esto adentro, para que Facu lo juegue y corrija. Cuando lo apruebe pasa al juego como v1.15.0. Todo lo que escribas tiene que quedar listo para ese pase: es código del juego, no una maqueta.

Reparto del trabajo (cada uno en su carpeta, nadie toca la de otro):

| Carpeta | Módulo | Qué es |
|---|---|---|
| `S-modelo/` | `UEM` | Modelo 3D de los soldados, armas en tercera persona, animación, página de concepto con el visor |
| `A-ia/` | `UE` | IA de escuadrón (JS puro, sin Three) + simulador en Node |
| `R-fusil/` | fusil, `GRAN`, botín | Fusil en primera persona, granadas del jugador y sistema de granadas, cajas de botín |
| `F-fx/` | `UEFX` `UESND` `UEHUD` `UEDBG` | Trazadoras, impactos, sonidos, radio, avisos en pantalla, vista táctica |
| `W-reten/` | `RETEN` | Escenografía del retén en el mapa real, datos de puestos, botón para ir directo |
| `M-bichos/` | enganches | Que los mutantes ataquen a los soldados y reciban sus balas |
| (integrador) | pegamento | Une todo, conecta la IA con el juego, prueba final |

## 1. El diseño

### 1.1 Identidad y aspecto

- Humanos de 1,80 m, atléticos, cargados de equipo. Uniforme y equipo negro mate y gris carbón, sin ninguna insignia, bandera ni número. Donde iría un parche hay velcro vacío.
- Casco balístico de corte alto con rieles. **Máscara antigás** de cara completa con dos lentes redondos y filtro lateral: no se les ve la cara nunca.
- Tienen que **leerse de noche y con niebla** (si no, es injusto): los lentes de la máscara devuelven un brillo frío tenue, llevan **linterna en el arma** con haz visible en la niebla, y una luz roja chica que parpadea en la nuca del casco. El tirador tiene **láser rojo** visible.
- Indicativo de radio del primer escuadrón: **«Ceniza»** (Ceniza 1 a 4). El refuerzo es **«Tizón»**. La base es **«Central»**. Al jugador le dicen **«el testigo»**. A los mutantes, **«bichos»** o «hostil no humano».

### 1.2 Roles (escuadrón de 4)

| Rol | Arma | Cómo se lo reconoce | Qué hace |
|---|---|---|---|
| `jefe` | fusil | antena larga de radio en la espalda; hace señas con la mano | Se queda atrás de la base de fuego, da las órdenes. Si cae, el escuadrón se desordena unos segundos. |
| `asalto` | escopeta | más liviano, canana de cartuchos | Flanquea por donde el jugador no ve; empuja cuando el jugador recarga. Peligroso a menos de 15 m. |
| `granadero` | fusil | portagranadas en el pecho y morral | Saca al jugador de la cobertura con granadas (con aviso). |
| `tirador` | fusil de tirador con mira, bípode y láser | capucha/velo sobre el casco, fusil largo | Cuerpo a tierra, lejos. Láser visible antes de cada tiro. |

Hasta dos escuadrones (8) en el pico del encuentro: el segundo llega como refuerzo, a pie, desde el lado del Congreso.

### 1.3 Reglas de juego limpio (son obligatorias: se prueban)

1. **Un cerebro de escuadrón reparte roles.** Unos fijan al jugador con fuego, otro flanquea por donde no se lo ve, el tirador cubre de lejos. Se mueven de a uno mientras otro cubre.
2. **No saben dónde está el jugador por arte de magia.** Deciden sobre el **último lugar conocido**: donde lo vieron o lo escucharon por última vez. Si el jugador corta la línea de visión y se mueve, la granada y el fuego van al lugar viejo.
3. **Todo lo peligroso se avisa.** Granada: grito por radio + gesto de lanzar al menos 0,6 s antes de soltarla, y al menos 3 s en total hasta que explota. Tirador: láser sobre el jugador al menos 1,2 s seguidos antes del tiro; si el jugador corta la línea de visión, el tiro se cancela. Flanqueo, recarga, pérdida de contacto, pedido de refuerzos: se dicen por radio.
4. **Como mucho 2 «tiran a pegar» a la vez** (fichas de ataque). Los demás tiran a suprimir: las balas pasan cerca a propósito. La primera ráfaga de cada soldado tras el primer contacto es de aviso. La puntería arranca mala y mejora mientras el jugador sigue expuesto.
5. **Tiempos humanos.** Reaccionan en ~0,45 s, recargan (ventana para avanzar), tardan en pararse desde el piso, se agachan si les pasan balas cerca, se repliegan heridos.
6. **Las balas son reales:** paran en paredes, autos y coberturas. Nunca le pegan al jugador a través de algo.
7. **Tope de daño:** las balas de fusil y escopeta no le sacan al jugador más de ~32 de salud por segundo.
8. **El jugador es más rápido** que ellos (camina a 6,2 m/s y corre a 9,6; ellos corren a 5,6).

### 1.4 El encuentro

- Estados del escuadrón: `guardia` (puestos y ronda, no saben nada) → `sospecha` (vieron u oyeron algo: miran, alumbran, mandan a uno a revisar) → `combate` → `busqueda` (perdieron al jugador: barren el último lugar conocido) → vuelven a `guardia` pero alertas.
- El jugador llega desde el este por Av. de Mayo. Puede acercarse agachado y sin linterna, rodear por Hipólito Yrigoyen o por el pasaje del Barolo, o entrar a los tiros.
- Los mutantes salen de las bocas del subte que quedan **detrás** del retén (estación Sáenz Peña): los soldados pueden quedar entre dos fuegos.
- Refuerzo: lo pide por radio el jefe (o el que quede) cuando quedan 2 o menos, o a los 45 s de combate. Tarda 3 s en pedirlo, a cubierto, y se lo puede interrumpir hiriéndolo. Llega 25 s después. Una sola vez.
- Al morir sueltan botín (ver 4.3).

## 2. El juego por dentro

### 2.1 Convenciones

- Unidades en metros. `y` es arriba. El piso es `y=0` salvo escalinatas (`floorAt(x,z)`). Norte es `-z`, este es `+x`.
- Av. de Mayo corre de este a oeste con la calzada en `z≈598…616` a la altura del Barolo. El jugador viene desde `x≈0` y el Congreso está en `x≈-935`.
- Jugador: `P.pos` (pies, `THREE.Vector3`), `P.vel`, `P.yaw` (mira hacia `(-sin yaw, 0, -cos yaw)`), `P.pitch`, `P.ch` (agachado 0…1), `P.hp` (0…100). Altura de ojos `1.7 - 0.68*P.ch`. Radio de choque 0,45.
- Enemigos: miran hacia `+Z` de su modelo; `obj.rotation.y = Math.atan2(dx,dz)`.
- Todo el juego vive en un solo `<script>` envuelto en `(()=>{ 'use strict'; … })()`. No hay módulos ni `import`. Nada es global salvo `THREE` y `GAME_VERSION`.
- Estilo del código: denso, una función por línea o pocas líneas, comentarios en español. Escribí tu código **legible** (no hace falta compactarlo así), con comentarios en español que expliquen el porqué. Nombres en español o inglés corto, como el resto del juego.
- Textos para el jugador: español rioplatense, voseo («Recargá», «Tenés»). Sin emojis.
- **Luces reales: prohibido crear o quitar luces en plena partida.** Three.js recompila todos los shaders cuando cambia la cantidad de luces. Tampoco sumes luces nuevas «siempre prendidas»: cada una encarece todos los materiales. Luz de fogonazo, linternas, reflectores y láser se resuelven con mallas aditivas, sprites y materiales emisivos.
- **Materiales y geometrías se crean al cargar**, no en plena partida, para que el precalentado de shaders los compile (el juego registra solo todo material creado durante la carga). Usá fondos comunes («pools») para lo que aparece y desaparece.
- **Sonido:** todo sintetizado con Web Audio, sin archivos. Usá los ayudantes del juego `noise(dur,tipo,f0,f1,pico,q,retardo)` y `tone(tipo,f0,f1,dur,pico,retardo)` (línea ~7417). Cada sonido nuevo se define **en tu módulo**, envuelto en `auOneShot(fn)` (así se liberan sus nodos al terminar) y pasando antes por `auGate(clave,prioridad,máximo,ventana_ms)` (límite de voces: prioridad 0 adorno · 1 impacto · 2 acción · 3 siempre suena). Si creás nodos propios (paneo, filtros), que sea adentro de una función envuelta en `auOneShot`. **No edites el objeto `sfx` ni la tabla `PRI`** (línea ~7562 y ~7602): si el código existente necesita `sfx.algo`, asignalo desde tu módulo (`sfx.fusil=auOneShot(()=>{…})`). `AC` es nulo hasta que el jugador arranca: preguntá `if(!AC)return`.
- La PC de Facu tiene una GTX 1070 y el juego ya es pesado. Presupuesto de toda la función: **menos de 1 ms por cuadro de lógica con 8 soldados** y **menos de 60 llamadas de dibujo extra**.
- El piso tiene **un solo nivel por punto** (`floorAt`). Nadie camina por balcones ni techos, salvo capó y techo de autos de hasta 1,7 m.

### 2.2 Índice del código (números de línea de `base-view.txt`)

`base-view.txt` es `base.html` con las líneas gigantes recortadas (three.js y los datos del mapa): usalo para leer y buscar. **No uses grep sobre `base.html` sin filtrar**: su línea 289 es three.js minificado (600 KB) y las líneas 338 y 882 son los datos del mapa: te llenan la salida. Buscá en `base-view.txt`, que tiene los mismos números de línea.

| Línea | Qué |
|---|---|
| 298 | `UEB`: enlace entre módulos (ver 4.1) |
| 1276 | secciones del mapa A (Obelisco) y B (Av. de Mayo): `SECDEF`, `STAGE`, `GATE` |
| 1526–1575 | `WALLS`, hash de paredes, `addCircle`, `wallCollide`, `rayWalls(o,d,maxT)` |
| 2366 | `floorAt(x,z)`, `FLOORFN` |
| 2593 / 2982 | `VEH` (generador de vehículos) / `TEX` (texturas) |
| 3178–3360 | autos: `VCARS`, `bCars`, `rayCars(o,d,maxT)→{car,t}`, `carShot`, `carDamage`, `carBoom`, `vehUpdate` |
| 7334 | `buildSectionB()` |
| 7370–7390 | partículas y calcomanías: `spawnPart`, `burst`, `addDecal` |
| 7415–7660 | audio: `initAudio`, `noise`, `tone`, `sfx`, `PRI`, voces |
| 7663 / 7804 | `TYPES` (bichos) / `makeMutant` |
| 9191 | `P` (jugador) |
| 9300–9480 | armas: materiales `WM`, `buildPistol/Shotgun/Uzi`, `anim*`, `reload*`, `W=[…]` (9465), linterna |
| 9582–9630 | retroceso `REC`, HUD (`hudAmmo`, `hudHP`, `announce`, `feed`) |
| 9632–9660 | `spawnEnemy`, `pickType`, `startWave` |
| 9660–9722 | `reload`, `switchTo`, `fire()` |
| 9724–9752 | `damageEnemy(e,dm,dir)`, `killEnemy(e)`, `hurtPlayer(n)` |
| 10035–10072 | cajas (`addPickup`, `addAmmo`, `updatePickups`) y escupitajos (`spit`, `updateProjs`) |
| 10074–10740 | `SHJ`: el Shajar. Buena referencia de IA con cobertura, A* con costo de exposición (10476), elección de cobertura (10504), impactos por esferas sobre huesos |
| 10743 | `collide(pos,rad,feetY)` |
| 10762–10865 | navegación de los bichos: grilla de 1 m `enB`/`enH`, `eCell`, `enRaster`, `enDirty`, campo hacia el jugador, `enSteer` |
| 10867–11200 | `MOV`: movimiento del jugador, manos, brazos y cuerpo en primera persona |
| 11275–11340 | `updatePlayer`, `updateWeapon`, `updateWaves` |
| 11338–11558 | `updateEnemies(dt)`: toda la lógica de los bichos |
| 11560–11650 | `resetGame`, `prewarmSections`, `startGame`, `gameOver`, `setPaused` |
| 11654 | teclado. Ocupadas: WASD, flechas, Espacio, Ctrl, C, Shift, R, 1 2 3, Q, F, B, P, Esc, F3, F4, rueda |
| 11687 | `/*UE:modulos*/`: acá van los módulos nuevos |
| 11716 | `frame(now)`: el bucle |

### 2.3 Grilla de navegación (la usan los bichos, el Shajar y ahora los soldados)

- `enB[k]`: 0 libre, 1 trepable (auto, valla, banco: hasta 1,7 m), 2 bloqueado. `enH[k]`: altura de lo trepable en decímetros.
- `eCell(x,z)` → índice o -1. `EX0=-1116, EZ0=-336, EW=2212, EH=1402`. Casillero de 1 m; `k = j*EW+i`, centro en `(EX0+i+.5, EZ0+j+.5)`.
- Los obstáculos entran **inflados 0,3 m**. Los autos entran con una sola altura (la del techo).
- `enReady` dice si está lista. `enDirty(x0,z0,x1,z1)` pide rehacer una zona cuando cambia algo.
- Las mamparas de vidrio no figuran. El interior de los edificios es `2`.

### 2.4 Autos como cobertura

Los autos frenan balas (`rayCars`). Reciben daño con `carDamage(c,n)`: a los 12 golpes humean, a los 20 se prenden fuego y explotan en 4,5–6,5 s (`carBoom`). Una cobertura no dura para siempre, ni para el jugador ni para los soldados.

## 3. Cómo se arma todo

### 3.1 Archivos compartidos (solo lectura)

- `base.html`: el juego v1.14.0 más los **marcadores** de enganche y `UEB`. **No lo edites.** Es la base sobre la que se aplican todos los parches.
- `base-view.txt`: lo mismo, legible.
- `three.r128.min.js`: Three.js suelto, para páginas de prueba y para Node.
- `harness.js`: arnés para correr el juego sin pantalla (sección 7).
- `mapa-reten.json` / `.png`: volcado real de la grilla y los autos alrededor del retén (sección 6).
- `conceptos/movimiento-concepto.html`: un concepto anterior aprobado por Facu, como referencia de estilo de página.
- `CHANGELOG.md`: historial del juego. Útil para entender qué hace cada sistema.

### 3.2 Marcadores en `base.html`

Para enganchar tu código en los lugares compartidos, **insertá delante del marcador y dejá el marcador**, así los parches de todos se componen en cualquier orden:

```
/*UE:update*/   →   GRAN.update(dt);/*UE:update*/
```

| Marcador | Dónde está | Para qué |
|---|---|---|
| `/*UE:css*/` | fin del `<style>` | CSS nuevo |
| `<!--UE:hud-->` | adentro de `#hud` | elementos del HUD (se ocultan con el HUD) |
| `<!--UE:capas-->` | fuera del HUD | capas que se ven siempre (vista táctica) |
| `<!--UE:ayuda-->` | lista de teclas de la pantalla de inicio | `<dt>…</dt><dd>…</dd>` nuevos |
| `<!--UE:inicio-->` | después del botón de inicio | botones nuevos de la pantalla de inicio |
| `/*UE:modulos*/` | antes del bucle | código de los módulos nuevos |
| `/*UE:update*/` | `frame()`, adentro de `if(running){…}` | `X.update(dt);` de lógica de partida |
| `/*UE:fx*/` | `frame()`, adentro de `if(!paused){…}` | efectos que siguen aunque no haya partida |
| `/*UE:reset*/` | fin de `resetGame()` | `X.reset();` |
| `/*UE:start*/` | `startGame()` | al empezar la partida |
| `/*UE:fin*/` | inicio de `gameOver()` | al morir el jugador |
| `/*UE:pausa*/` | `setPaused(v)` | pausar sonidos propios |
| `/*UE:teclas*/` | manejador de `keydown` (hay `e`) | teclas nuevas |
| `/*UE:warm-on*/` `/*UE:warm-off*/` | precalentado de shaders | mostrar y ocultar muestras para compilar shaders |
| `/*UE:brujula*/` | `compassTargets()` (hay `L`) | marcas en la brújula |
| `/*UE:rayo-jugador*/` | `fire()`, por cada perdigón o bala | **reservado al integrador**: bala del jugador contra soldados |

Si necesitás tocar otra parte del juego (tu propia zona: las armas, `updateEnemies`, los autos…), hacelo con ediciones chicas y puntuales. No reformatees ni reordenes código existente.

### 3.3 Protocolo de parches (para los que modifican el juego: R, F, W, M)

Entregás **dos cosas**:

1. `mod_<nombre>.js`: el código nuevo de tu módulo, tal como va insertado en `/*UE:modulos*/` (JS suelto, sin `<script>`; va adentro del `(()=>{…})()` del juego y ve todas sus variables).
2. `patch_<nombre>.py`: un script que recibe `entrada.html salida.html`, y aplica tus cambios con reemplazos anclados. Usá esta forma, que falla fuerte si un ancla no aparece exactamente las veces que esperás:

```python
import sys,os
src,dst=sys.argv[1],sys.argv[2]
s=open(src,encoding='utf-8').read()
AQUI=os.path.dirname(os.path.abspath(__file__))
def rep(viejo,nuevo,n=1):
    global s
    c=s.count(viejo)
    assert c==n,f'ancla: esperaba {n}, hay {c}: {viejo[:80]!r}'
    s=s.replace(viejo,nuevo)
def antes(marca,codigo):            # inserta delante de un marcador y lo deja
    rep(marca,codigo+marca)
antes('/*UE:modulos*/',open(os.path.join(AQUI,'mod_<nombre>.js'),encoding='utf-8').read()+'\n')
antes('/*UE:update*/','X.update(dt);')
# … ediciones propias con rep(…)
open(dst,'w',encoding='utf-8').write(s)
```

Reglas:

- Anclas **cortas y únicas**. Preferí agregar una llamada a reescribir una línea. Marcá cada edición fuera de tu módulo con un comentario `/*UE:<tu letra>*/` donde no rompa nada, para poder encontrarlas después.
- El parche se aplica sobre `base.html`, pero después se va a aplicar junto con los de los demás. **Asumí que otros también editan** HUD, teclas, `frame()`, `resetGame()`: por eso los marcadores. Si tu ancla cae en una línea que otro puede tocar, avisalo en tu informe.
- Tu módulo tiene que **funcionar aunque los otros no estén**: usá `UEB` (4.1) y preguntá `typeof X!=='undefined'` antes de usar un módulo ajeno.
- Nada de `console.log` de depuración en lo que entregás.
- Probá aplicando tu parche sobre una copia limpia de `base.html` y corriéndola con el arnés: sin errores de página ni de consola, y con una partida normal de 30 s con oleada (los bichos no tienen que romperse).

## 4. Contratos entre módulos

### 4.1 `UEB` (ya está en `base.html`)

```js
const UEB={
  objetivos:()=>[],                  // soldados vivos como blancos de los bichos: [{x,z,y,r,vivo,herir(daño,bicho)}]   (lo llena el integrador desde la IA; lo consume M)
  explosion:(pos,radio,dano,de)=>{}, // TODA explosión avisa acá (granadas: R; autos: M). pos: Vector3. de: 'jugador'|'soldado'|'auto'. La IA daña y alerta a los soldados
  ruido:(pos,tipo,fuerza)=>{},       // ruidos del jugador. Ya se llama con 'disparo' en fire(). R avisa 'granada' al lanzar
  botin:(x,z,rol)=>{},               // lo implementa R; lo llama el integrador cuando muere un soldado
  estado:()=>({alerta:0,ang:0,combate:false,vivos:0}), // lo llena el integrador; lo consume F para el indicador de detección
  debug:()=>null                     // lo llena el integrador; lo consume F para la vista táctica
};
```

Los módulos **asignan** lo que implementan (`UEB.botin=function(x,z,rol){…}`) y **llaman** lo que consumen.

### 4.2 `UEM` — modelo (S)

```js
const UEM=(()=>{ … return {ROLES,crear,granada,calentar}; })();

UEM.ROLES   // {jefe:{nombre,arma,desc}, asalto:…, granadero:…, tirador:…}
UEM.crear(rol, {semilla}) → u
  u.root            // THREE.Group. El juego le pone position (pies) y rotation.y (rumbo; frente = +Z)
  u.e               // ENTRADAS de animación: las escribe la IA en cada cuadro (valores abajo)
  u.update(dt)      // aplica la pose. El paso sale de la distancia que recorrió root desde el cuadro anterior (no patina)
  u.disparo()       // un tiro: patada del arma, fogonazo, vaina
  u.golpe(dir,f)    // sacudida por impacto. dir: rad respecto del frente; f: 0…1
  u.boca(v3)        // posición mundial de la boca del arma (devuelve v3)
  u.ojos(v3)        // posición mundial de los ojos
  u.rayo(o,d)       // rayo (Vector3 origen y dirección unitaria, mundo) contra el cuerpo en la pose actual
                    //   → null | {t, parte:'cabeza'|'torso'|'brazo'|'pierna'}
  u.soltarArma()    // al morir: el arma queda en el piso
  u.dispose()
UEM.granada()       // malla de la granada de mano (la usa el sistema de granadas)
UEM.calentar(scene,on)  // on=true: agrega una muestra de cada rol con todo prendido para compilar shaders; false: la quita

u.e = {
  agach:0, tierra:0,       // 0…1 cada uno: mezcla hacia agachado y hacia cuerpo a tierra (tierra manda). La IA maneja los tiempos
  apunta:0,                // 0 arma baja lista · 1 al hombro apuntando
  mYaw:0, mPitch:0,        // hacia dónde apunta el arma respecto del frente del cuerpo (rad; ±1,3 y ±0,9)
  asoma:0,                 // -1…1: se inclina para asomarse por la izquierda o la derecha de una cobertura
  recarga:-1,              // -1 nada · 0…1 progreso
  salto:-1,                // -1 nada · 0…1: pasa por arriba de una valla de 1,1 m apoyando una mano
  lanza:-1,                // -1 nada · 0…1 progreso. La granada sale de la mano en 0,55 (u.e.lanzaSale = 0.55)
  senal:-1, senalTipo:'avanzar', // seña de mano del jefe: 'avanzar' | 'izq' | 'der' | 'alto'
  culata:-1,               // golpe de culata 0…1 (pega en 0,5)
  radio:0,                 // 0…1: mano al pulsador de la radio mientras habla
  aturdido:0,              // 0…1
  muerte:null,             // null | {tipo:'atras'|'adelante'|'derrumbe'|'tierra', t:0…1, dir:rad}
  luz:false,               // linterna del arma prendida (haz visible)
  laser:null               // null | Vector3 mundial donde termina el láser (el modelo dibuja el haz desde el arma hasta ahí)
}
```

### 4.3 Fusil, granadas y botín (R)

```js
// fusil: W[3], id 'fusil', tecla 4. El jugador no lo tiene hasta que lo levanta (w.owned)
GRAN.lanzar({pos,vel,mecha,de,tipo}) → g   // pos y vel: Vector3. mecha: s. de: 'jugador' | objeto soldado. tipo: 'frag' ('humo' es opcional)
GRAN.lista           // granadas vivas: [{p:Vector3, v:Vector3, t:segundos que faltan, de, tipo}]
GRAN.arco(desde,hasta,opt) → {vel:Vector3, ok:boolean, t:tiempo de vuelo}   // tiro por elevación que cae en «hasta», chequeando que no choque antes
GRAN.update(dt)      // física, mecha, explosión
GRAN.reset()
GRAN.G               // gravedad que usa (m/s²)
// Al explotar: daña al jugador (con caída por distancia y descuento por cobertura), a los bichos y a los autos, y llama UEB.explosion(pos,radio,daño,de)
UEB.botin=(x,z,rol)=>{…}   // suelta cajas según el rol
```

### 4.4 Efectos, sonido y avisos (F)

```js
UEFX.trazadora(a,b,tipo)     // estela de una bala enemiga de a hasta b (Vector3). tipo: 'fusil'|'escopeta'|'tirador'
UEFX.impacto(p,n,mat)        // chispas y polvo en un impacto. n: normal o null. mat: 'metal'|'pared'|'piso'|'carne'
UEFX.sangre(p,dir)           // salpicadura chica (soldado herido)
UEFX.update(dt); UEFX.reset()
UESND.disparo(tipo,pos)      // disparo enemigo con distancia, retardo y paneo
UESND.silbido(pan)           // bala que pasa cerca de la cámara (lo dispara UEFX.trazadora sola)
UESND.radio(voz,dur,pos)     // voz de radio distorsionada, ininteligible. voz: 0…7 (tono de cada soldado)
UESND.pasos(pos,fuerza); UESND.cuerpo(pos); UESND.equipo(pos)
UEHUD.radio(quien,texto)     // subtítulo de «radio interceptada»
UEHUD.alerta(nivel,ang,combate) // indicador de detección. nivel 0…1; ang: rad respecto de adonde mira el jugador (0 = adelante, + derecha) o null
UEHUD.golpe(ang)             // marca de dirección del daño recibido
UEHUD.update(dt); UEHUD.reset()   // también dibuja el aviso de granada leyendo GRAN.lista si existe
UEDBG                        // vista táctica: F2 la prende y apaga. Lee UEB.debug()
```

### 4.5 Retén (W)

```js
RETEN.armar()      // se llama una vez, al construir la sección B. Devuelve RETEN.datos
RETEN.datos = {
  centro:{x,z},                 // medio de la barricada
  frente:{x,z},                 // dirección unitaria hacia donde mira el retén (el este)
  puestos:[{x,z,rumbo,rol}],    // dónde se para cada uno en guardia. rumbo en rad (como rotation.y). Uno por rol
  ronda:[{x,z},…],              // recorrido cerrado de la patrulla (lo camina el asalto)
  nido:{x,z,y,rumbo}|null,      // puesto alto del tirador (techo del furgón). y = altura de los pies
  reunion:{x,z},                // adonde se repliegan
  refuerzo:{sale:{x,z}, camino:[{x,z},…]},  // por dónde entra el segundo escuadrón
  luz:[{x0,z0,x1,z1}],          // zonas iluminadas por los reflectores (el jugador ahí se ve más)
  cuerpos:[{x,z}]               // dónde hay bolsas y autos baleados (para la búsqueda y la ambientación)
}
RETEN.luz(x,z)     // 0…1: qué tan iluminado está ese punto por los reflectores
RETEN.reset()      // deja todo como al principio
RETEN.ir(opt)      // modo concepto: lleva al jugador a Av. de Mayo y Santiago del Estero con munición. opt.bichos: con o sin oleadas
```

### 4.6 Mutantes contra soldados (M)

- Cada bicho elige blanco entre el jugador y `UEB.objetivos()`. A un soldado lo daña con `obj.herir(daño,bicho)`.
- `rayoBichos(o,d,maxT) → null | {e,t,p,ojo}`: bala de soldado contra bichos (misma cuenta que en `fire()`). `o` y `d` son `Vector3`.
- `damageEnemy(e,dm,dir,de)`: el cuarto parámetro es nuevo y opcional; con `'soldado'` el bicho muere sin darle puntos ni combo al jugador.
- `bichosVivos() → [{ref,x,y,z,r,tipo,hp}]`: los mutantes como los necesita la IA (centro del cuerpo). Reutiliza el mismo arreglo.
- Toda explosión de auto llama `UEB.explosion(pos,radio,daño,'auto')`.

### 4.7 IA (A)

```js
function crearUE(ENV,TUNE) → UE
UE.escuadron({nombre,roles,puestos,ronda,nido,reunion}) → esc      // crea un escuadrón en guardia
UE.refuerzo({nombre,roles,sale,camino})                          // lo deja listo para cuando lo pidan
UE.update(dt); UE.reset()
UE.soldados                                                       // todos, vivos y muertos
UE.rayo(o,d,maxT) → null|{s,t,parte}                              // bala del jugador
UE.herir(s,daño,dir,parte,de)                                     // de: 'jugador'|'bicho'|'granada'|'auto'
UE.balaCerca(o,d,t)                                               // una bala del jugador pasó: los que están cerca de la línea se sienten suprimidos
UE.ruido(pos,tipo,fuerza); UE.explosion(pos,radio,daño,de)
UE.objetivos(); UE.estado(); UE.debug()
```

`ENV` es todo lo que la IA sabe del mundo. En el juego lo arma el integrador; en Node, un simulador:

```js
ENV = {
  B, H, EW, EH, EX0, EZ0,                      // la grilla (2.3)
  jugador() → {x,y,z,vx,vz,agach,ojoY,alto,hp,vivo,linterna,recargando,corriendo},
  piso(x,z) → y,
  rayo(ox,oy,oz,dx,dy,dz,max) → t,             // distancia al primer choque contra el mundo fijo (paredes, obstáculos, autos) o Infinity
  luz(x,z) → 0…1,                              // qué tan iluminado está ese punto
  bichos() → [{ref,x,y,z,r,tipo,hp}],          // mutantes vivos
  rayoBichos(ox,oy,oz,dx,dy,dz,max) → null|{ref,t},
  herirBicho(ref,daño,dx,dz),
  peligros() → [{x,z,r,t}],                    // granadas vivas y autos por explotar: de dónde hay que correrse y en cuánto tiempo
  herirJugador(daño,desdeX,desdeZ,tipo),
  bala(ev),                                    // {s,ox,oy,oz,hx,hy,hz,tipo,pega:'jugador'|'bicho'|'mundo'|'nada'}: el juego dibuja la trazadora, suena, daña autos
  granada(s,ox,oy,oz,vx,vy,vz,mecha,tipo),     // el juego la crea en su sistema de granadas
  arco(ox,oy,oz,hx,hy,hz) → null|{vx,vy,vz,t}, // solución de lanzamiento (GRAN.arco)
  radio(s,clave,texto),                        // frase por radio: subtítulo y sonido
  evento(tipo,datos),                          // 'contacto','perdido','baja','refuerzo','limpio'…
  vista(s) → u|null,                           // crea el modelo (UEM.crear) para ese soldado, o null en Node
  azar() → 0…1, ahora() → s
}
```

`UE.debug()` (para la vista táctica):

```js
{ soldados:[{id,nombre,rol,esc,x,z,rumbo,estado,postura,hp,ficha,ve,suprimido,camino:[{x,z}],cob:{x,z}|null,blanco:'jugador'|'bicho'|null}],
  escuadrones:[{nombre,estado,uc:{x,z,edad}|null,fichas,orden,sinJefe,refuerzoEn}],
  jugador:{x,z}, granadas:[{x,z,t}] }
```

## 5. Números iniciales

Van todos juntos en un objeto `TUNE` con comentario en español en cada uno, para que Facu o cualquier chat los pueda ajustar. Son un punto de partida: A los afina con el simulador.

| Qué | Valor |
|---|---|
| Vida del soldado | 100. Cabeza ×2,2 · torso ×0,85 · brazo y pierna ×0,7 |
| Velocidades (m/s) | ronda 1,6 · avance agachado 3,2 · correr 5,6 · escapar 6,6 |
| Posturas | de pie↔agachado 0,25 s · agachado→tierra 0,6 s · tierra→agachado 0,9 s |
| Altura de ojos | de pie 1,62 · agachado 1,05 · cuerpo a tierra 0,30 |
| Reacción | 0,45 s desde que ve hasta que tira. Giro 4 rad/s |
| Vista | cono de 110° en guardia y 200° en combate. 45 m de noche · ×1,5 si el jugador está iluminado o con linterna · ×0,6 agachado y quieto a oscuras · tope 80 m |
| Tiempo para detectar (en guardia) | 0,35 s a 8 m · 0,9 s a 15 m · 2 s a 30 m · 4 s a 45 m. La sospecha baja 0,25 por segundo si deja de verlo |
| Oído | disparo del jugador 120 m · pasos corriendo 14 m · impacto de bala a 3 m · explosión 150 m |
| Aviso al escuadrón | 0,5 s desde que uno lo ve hasta que lo saben todos |
| Fichas de ataque | 2 (el tirador va aparte: 1 tiro en curso como mucho) |
| Fusil | ráfagas de 3 a 5 · 0,095 s entre balas · 0,6–1,2 s entre ráfagas · daño 7 · dispersión 0,011 rad asentado, ×3,2 sin asentar · se asienta en 1 s · cargador 30 · recarga 2,4 s |
| Escopeta | 8 perdigones de 5 · dispersión 0,05 · 0,95 s entre tiros · útil hasta 16 m, nada a 28 m · 6 cartuchos · 0,55 s por cartucho |
| Fusil de tirador | daño 48 · láser 1,3 s + destello 0,25 s · ciclo de 3,2 s o más · el punto sigue al jugador con 0,22 s de atraso y adelanta el 60 %: corriendo de costado te erra |
| Culatazo | 15 de daño a menos de 1,8 m · aviso 0,35 s · cada 2,5 s |
| Supresión sobre un soldado | bala del jugador a menos de 1,2 m: +0,35 · baja 0,5 por segundo · con más de 0,6 se esconde 0,8–1,5 s y pierde la puntería |
| Tope de daño al jugador | 32 por segundo con balas de fusil y escopeta |
| Granada | mecha 3 s desde que sale de la mano · aviso 0,65 s antes · radio 7 m · daño 80 en el centro y 0 en el borde · ×0,3 detrás de cobertura · 11 s entre granadas del escuadrón · se lanza entre 8 y 30 m · el granadero lleva 3 y los demás 1 |
| Cuándo la tiran | jugador quieto o cubierto 3,5 s en un radio de 2,5 m, o 3 bichos juntos |
| Flanqueo | cada 14 s o más, si quedan 3 o más |
| Pérdida de contacto | 2,5 s: «lo perdí» y fuego sobre el último lugar · 7 s: granada o avance · 12 s: barrido de 30 s · después, de vuelta a los puestos |
| Jefe caído | 7 s de desorden: sin órdenes nuevas y una sola ficha |
| Refuerzo | con 2 o menos vivos, o a los 45 s de combate · 3 s para pedirlo · llega en 25 s · una sola vez |
| Daño de sus balas a un auto | 0,5 golpes por bala (el auto se prende a los 20 golpes) |

## 6. El retén: lugar y disposición provisoria

`mapa-reten.json` es un volcado del juego real: `{X0,Z0,W,H,B[],Hh[],G[],cars[],sub[],mh[]}` para la ventana `x∈[-640,-160)`, `z∈[500,720)`. `B` y `Hh` son `enB` y `enH`; `G` es el tipo de suelo (0 vereda, 1 calle, 2 edificio, 3 plaza, 4 bloqueado); índice `(z-Z0)*W+(x-X0)`. `cars` son los autos (`id,x,z,a,L,W,H`), `sub` las bocas de subte (de ahí salen los bichos), `mh` las tapas de alcantarilla. `mapa-reten.png` lo dibuja (4 px por metro; arriba es el norte).

Lugar: Av. de Mayo entre Santiago del Estero (`x≈-322`) y San José (`x≈-450`). La calzada va de `z≈597,5` a `z≈616,5` a la altura de la barricada. El arco del pasaje del Barolo está en la vereda sur, en `x≈-412…-407`, `z≈618`, y sale a Hipólito Yrigoyen (`z≈670`).

Disposición provisoria (W la ajusta sobre el mapa real y entrega la definitiva en `RETEN.datos`; A la usa tal cual en el simulador):

- **Barricada** cruzando la avenida en `x≈-438`, mirando al este. Dos furgones negros atravesados: norte `x∈[-439,2 … -436,8] z∈[599,5 … 605,4]`, sur `x∈[-439,2 … -436,8] z∈[608,6 … 614,5]`. Entre los dos, un paso de 3 m cerrado con vallas de 1,1 m (`z∈[605,5 … 608,5]`). Vallas también en las puntas (`z∈[597,5 … 599,4]` y `[614,6 … 616,5]`).
- **Camioneta de mando** detrás, en `(-446, 609)`. Ya hay un taxi abandonado en `(-442,2 ; 610,9)`.
- **Reflectores** en las dos puntas de la barricada, apuntando al este. Zona iluminada: `x∈[-432,-392]`, `z∈[598,620]`.
- **Fila de autos detenidos** al este de la barricada, con las puertas abiertas y baleados: es la cobertura del jugador para acercarse y cuenta lo que hacen. Centros aproximados: `(-424,603)`, `(-417,612,5)`, `(-409,605,5)`, `(-398,610)`, `(-390,602)`, `(-381,613)`, alineados con la avenida. Ya existen un auto en `(-432,6 ; 608,7)` y otro en `(-401,8 ; 614,75)`.
- **Puestos**: jefe `(-441,606)` y granadero `(-441,612)`, los dos mirando al este. **Ronda** del asalto: `(-428,604) → (-395,604) → (-395,614) → (-428,614)`. **Nido** del tirador: techo del furgón norte. **Reunión**: `(-447,609)`. **Refuerzo**: sale de `(-540,607)` y viene corriendo por la avenida.
- El jugador arranca en `(-326, 606)`, a unos 110 m.

## 7. Cómo probar

El juego corre sin pantalla en Chromium con render por software. **Dibujar es lentísimo** (1 cuadro por segundo); **la lógica es rápida** si no se dibuja (10 s de juego en 1 s). Por eso el arnés apaga el render y avanza el juego a mano.

```js
const H=require('<ruta a ue>/harness.js');
const h=await H.open('mi-copia.html');     // carga (~15 s). Espera turno: solo 2 copias del juego corren a la vez en la máquina
await h.start();                            // arma la sección B y arranca la partida (~9 s)
await h.alReten();                          // jugador en Av. de Mayo y Santiago del Estero mirando al oeste, sin oleadas
await h.ev("P.hp");                         // evalúa código ADENTRO del juego: ve todas sus variables. Devuelve algo serializable
await h.step(5);                            // simula 5 s a 60 cuadros por segundo, sin dibujar
await h.step(2,1/60,"keys.KeyW=true");      // con código que corre antes de cada cuadro
await h.shot('captura.png');                // dibuja UN cuadro y saca captura. La primera tarda ~45 s; las siguientes ~10–15 s
console.log(h.errors);                      // errores de página y de consola
await h.close();                            // siempre: libera el turno
```

- Juntá muchas pruebas en una sola corrida. Cada apertura cuesta ~25 s y hay cola.
- Las capturas son caras: usalas para lo visual, no para la lógica. Para ver algo de cerca y rápido, ocultá el mapa (`SECG.A.visible=SECG.B.visible=false`) antes de la captura.
- Para páginas sueltas y livianas (visor de modelos, prueba de efectos) usá `H.openPage('pagina.html')` → `h.page` (Playwright) y `h.shotPage('x.png')`. No hacen cola.
- Mirá tus capturas con la herramienta de lectura de imágenes antes de dar algo visual por bueno.
- No hay red: no cargues nada de afuera en las pruebas (usá `three.r128.min.js` local).

## 8. Qué entregar y cómo informar

Todo adentro de tu carpeta. Tu mensaje final lo lee el integrador, no Facu: que sea concreto.

1. **Archivos** entregados, con ruta.
2. **Contrato real**: qué implementaste de la sección 4 y en qué te apartaste (con el porqué).
3. **Anclas delicadas** de tu parche: las que caen en líneas que otro puede tocar.
4. **Pruebas**: qué corriste y qué dio. Números, no adjetivos. Capturas que conviene mirar.
5. **Pendientes y dudas**: lo que no entró, lo que no pudiste verificar, lo que harías distinto.

No digas que algo anda si no lo corriste. Si algo quedó a medias, decilo así.

## 9. Frases de radio

La IA las emite con `ENV.radio(s, clave, texto)`. Se ven como subtítulos de «radio interceptada» y suenan como voz distorsionada (Facu graba después las reales: la lista sale en la página de concepto). Varias opciones por clave; elegir al azar sin repetir la última. `{N}` se reemplaza por el número del soldado.

| Clave | Cuándo | Frases |
|---|---|---|
| `ocioso` | en guardia, cada tanto | «Central, retén Mayo sin novedad.» · «¿Cuántos van?» / «Once.» · «Media hora para el relevo.» · «Nadie sale de la zona. Nadie.» |
| `sospecha` | vio u oyó algo | «Vi algo. Voy a mirar.» · «¿Escucharon eso?» · «Movimiento al este.» |
| `nada` | no encontró nada | «Nada. Falsa alarma.» · «Sin novedad.» |
| `contacto` | lo ve por primera vez | «Contacto. Testigo al frente.» · «Lo veo. Detrás del auto.» · «Testigo a la vista.» |
| `fijar` | empieza el fuego de cobertura | «Fuego de cobertura.» · «Lo tengo fijado.» |
| `muevo` | cambia de cobertura | «Me muevo.» · «Cambio de posición.» · «Cubrime.» |
| `tecubro` | el que cubre | «Te cubro.» · «Dale, andá.» |
| `orden_flanco` | el jefe ordena rodear | «Ceniza {N}, rodealo.» |
| `flanco_izq` / `flanco_der` | el que flanquea, al salir | «Voy por izquierda.» / «Voy por derecha.» |
| `granada` | 0,65 s antes de soltarla | «¡Granada va!» |
| `granada_enemiga` | granada del jugador cerca | «¡Granada! ¡Al piso!» |
| `recarga` | recarga | «Recargando.» · «Cambio cargador.» |
| `recarga_jugador` | el jugador recarga y el asalto empuja | «Está recargando. ¡Voy!» |
| `herido` | queda con poca vida | «Me dieron.» · «Estoy herido.» |
| `suprimido` | clavado por el fuego del jugador | «¡Me tiene clavado!» |
| `flanqueado` | el jugador aparece por un costado | «¡Nos rodeó!» · «¡Por el costado!» |
| `baja` | cae un compañero | «Hombre caído.» · «Cayó Ceniza {N}.» |
| `jefe_caido` | cae el jefe | «Cayó el jefe. Tomo el mando.» |
| `perdido` | lo perdieron de vista | «Lo perdí.» · «Sin visual.» |
| `tirador_listo` | el tirador llega a su puesto | «Tirador en posición.» |
| `tirador_mira` | empieza a apuntar con el láser | «Lo tengo en la mira.» |
| `tirador_fallo` | erró o se le cortó la línea | «Se me movió.» |
| `bichos` | aparecen mutantes | «¡Bichos!» · «Bichos por atrás.» · «Contacto hostil, no humano.» |
| `auto_fuego` | un auto cercano se prende fuego | «¡Ese auto va a volar! ¡Salgan!» |
| `busqueda` | empiezan a barrer | «Barriendo el sector.» · «Revisen los autos.» |
| `limpio` | termina la búsqueda | «Sector limpio. Volvemos al retén.» |
| `refuerzo_pide` | pide apoyo (3 s) | «Central, contacto en el retén Mayo. Pedimos apoyo.» |
| `refuerzo_va` | respuesta | «Tizón en camino. Treinta segundos.» |
| `refuerzo_llega` | llega el segundo escuadrón | «Tizón en posición.» |
| `muerto_jugador` | muere el jugador | «Testigo eliminado.» · «Central, uno menos.» |
