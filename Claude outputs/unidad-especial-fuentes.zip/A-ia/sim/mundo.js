/* =====================================================================================================
   sim/mundo.js — el retén de Av. de Mayo simulado, para probar la IA de la Unidad Especial (ue_ia.js)
   -----------------------------------------------------------------------------------------------------
   JS puro: sirve en Node y en el navegador (no usa require ni DOM). El mapa entra ya cargado
   (el objeto de mapa-reten.json: {X0,Z0,W,H,B,Hh,G,cars,sub,mh}).

   USO
     const M  = crearMundo(mapa, { semilla: 1 });       // mundo + ENV completo (SPEC 4.7) + retén provisorio (SPEC 6)
     const UE = crearUE(M.ENV, UE_TUNE);                // la IA
     M.conectar(UE);                                    // el mundo le avisa a la IA (ruidos, balas cerca, explosiones)
     M.armarReten();                                    // escuadrón «Ceniza» en guardia + refuerzo «Tizón» listo
     cada cuadro:
       M.moverJugador(vx, vz, dt, {agach, correr});     // (si no se llama en un cuadro, el jugador queda quieto)
       M.dispararJugador(x, y, z);                      // opcional
       M.paso(dt);                                      // tiempo, IA (UE.update), granadas, bichos
       for (const ev of M.sacarEventos()) …            // dibujar y hacer sonar

   API
     M.ENV                       el ENV de la SPEC 4.7 (lo usa crearUE)
     M.UE                        la IA conectada (o null)
     M.t                         reloj del mundo (s)
     M.jugador                   {x,y,z,vx,vz,agach,ojoY,alto,hp,vivo,linterna,recargando,corriendo,arma,cargador,granadas,dano:{fuente:total}}
     M.ponerJugador(x, z)
     M.moverJugador(vx, vz, dt, {agach, correr})
                                 velocidad deseada (m/s). Tope 3,0 agachado · 6,2 caminando · 9,6 corriendo.
                                 Choca y se desliza contra la grilla (no pasa autos, vallas ni paredes).
     M.armaJugador(n)            'pistola' (26, 0,17 s) · 'escopeta' (10×15, a quemarropa) · 'uzi' (10, 0,072 s) · 'fusil' (22, 0,09 s)
     M.dispararJugador(x, y, z)  dispara el arma actual hacia ese punto, con su dispersión y su cadencia. Resuelve contra
                                 el mundo (ENV.rayo + piso), los soldados (UE.rayo → UE.herir) y los bichos; avisa UE.balaCerca
                                 y UE.ruido. Devuelve null si el arma no estaba lista, o [{pega, s, parte, hx,hy,hz}] (una por perdigón)
     M.recargarJugador()
     M.lanzarGranadaJugador(x,z) granada del jugador (mecha 3 s), con arco. Devuelve true si salió.
     M.linterna(on)
     M.soltarBichos(n, {cada})   n bichos desde las bocas del subte (detrás del retén), uno cada `cada` s (0,35)
     M.paso(dt)
     M.sacarEventos()            vacía y devuelve la cola de eventos (abajo)
     M.foto()                    instantánea para dibujar: {t, jugador, soldados (UE.debug), escuadrones, bichos, granadas, laseres}
     M.rayo(ox,oy,oz,dx,dy,dz,max) → t   ·   M.lv(ax,ay,az,bx,by,bz) → bool (rayo real, para jugadores automáticos)
     M.camino(x0,z0,x1,z1,{costo(k), maxIt}) → [{x,z}] | null      A* propio del simulador (jugadores automáticos, bichos)
     M.libre(x,z) → bool (el jugador puede estar ahí) · M.celda(x,z) → k · M.grilla = {B,H,HR,G,EW,EH,EX0,EZ0}
     M.reten                     lo que se le sumó a la grilla (para dibujar): [{tipo,x0,x1,z0,z1,alto}]
     M.zonaLuz                   {x0,x1,z0,z1}: lo que alumbran los reflectores

   EVENTOS (M.sacarEventos)
     {tipo:'bala', t, de:'soldado'|'jugador', s, arma, modo, ox,oy,oz, hx,hy,hz, px,py,pz, pega:'jugador'|'soldado'|'bicho'|'mundo'|'nada'}
     {tipo:'radio', t, s, clave, texto}
     {tipo:'herida', t, a:'jugador'|'soldado'|'bicho', dano, fuente:'fusil'|'escopeta'|'tirador'|'granada'|'culata'|'bicho'|'jugador', s?}
     {tipo:'granada', t, de, x,y,z, vx,vy,vz, mecha}        sale una granada (de: el soldado, o 'jugador')
     {tipo:'explosion', t, x,y,z, r, de}
     {tipo:'laser', t, s, on}                                 el tirador prende o apaga el láser (el punto, en M.foto().laseres)
     {tipo:'evento', t, nombre, datos}                        ENV.evento de la IA: 'contacto','combate','perdido','baja','refuerzo',
                                                              'granada_aviso','granada_orden','flanco','flanco_llego','busqueda','limpio'…
     {tipo:'muerte', t, a:'jugador'|'bicho', quien?}
   ===================================================================================================== */
function crearMundo(mapa, op) {
  op = op || {};
  const PI = Math.PI, hyp = Math.hypot;
  const EX0 = mapa.X0, EZ0 = mapa.Z0, EW = mapa.W, EH = mapa.H, N = EW * EH;
  const B = new Uint8Array(mapa.B), H = new Uint8Array(mapa.Hh), G = new Uint8Array(mapa.G);
  const HR = new Float32Array(N);                       // altura real de cada casillero para las balas (m)
  for (let k = 0; k < N; k++) HR[k] = B[k] === 2 ? 40 : B[k] === 1 ? H[k] * 0.1 : 0;

  /* ---------- azar con semilla (mulberry32) ---------- */
  let sem = (op.semilla === undefined ? 1 : op.semilla) * 2654435761 >>> 0;
  function azar() { sem = (sem + 0x6D2B79F5) >>> 0; let t = sem; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  const campana = () => azar() + azar() - 1;

  const M = { t: 0, UE: null, eventos: [], reten: [], zonaLuz: { x0: -432, x1: -392, z0: 598, z1: 620 } };
  const celda = (x, z) => { const i = Math.floor(x - EX0), j = Math.floor(z - EZ0); return (i < 0 || j < 0 || i >= EW || j >= EH) ? -1 : j * EW + i; };
  const cX = k => EX0 + (k % EW) + 0.5, cZ = k => EZ0 + ((k / EW) | 0) + 0.5;
  /* el jugador y los bichos no pasan por paredes, autos, vallas ni bancos (lo de menos de 0,5 m se pisa) */
  const pasable = k => k >= 0 && (B[k] === 0 || (B[k] === 1 && H[k] < 5));
  const libre = (x, z) => pasable(celda(x, z));

  /* ====================================================================================================
     EL RETÉN PROVISORIO (SPEC 6), sumado a la grilla. Los obstáculos entran inflados 0,3 m (como en el juego).
     ==================================================================================================== */
  function marcar(x0, x1, z0, z1, b, altoM, tipo) {
    const a = 0.3; M.reten.push({ tipo, x0, x1, z0, z1, alto: altoM });
    for (let z = Math.floor(z0 - a); z <= Math.floor(z1 + a); z++) for (let x = Math.floor(x0 - a); x <= Math.floor(x1 + a); x++) {
      const cx = x + 0.5, cz = z + 0.5; if (cx < x0 - a || cx > x1 + a || cz < z0 - a || cz > z1 + a) continue;
      const k = celda(cx, cz); if (k < 0) continue;
      if (b === 2) { const edif = B[k] === 2; B[k] = 2; H[k] = 0; HR[k] = edif ? Math.max(HR[k], altoM) : altoM; }
      else if (B[k] !== 2) { B[k] = 1; H[k] = Math.max(H[k], Math.round(altoM * 10)); HR[k] = Math.max(HR[k], altoM); }
    }
  }
  /* una valla fina: al menos una fila de casilleros sobre su eje */
  function valla(x, z0, z1) {
    M.reten.push({ tipo: 'valla', x0: x - 0.1, x1: x + 0.1, z0, z1, alto: 1.1 });
    for (let z = Math.floor(z0); z <= Math.floor(z1 - 0.01); z++) { const k = celda(x, z + 0.5); if (k >= 0 && B[k] !== 2) { B[k] = 1; H[k] = 11; HR[k] = 1.1; } }
  }
  function autoX(cx, cz) { marcar(cx - 2.2, cx + 2.2, cz - 0.9, cz + 0.9, 1, 1.5, 'auto'); }
  if (op.reten !== false) {
    marcar(-439.2, -436.8, 599.5, 605.4, 2, 2.4, 'furgon');          // furgón norte (techo: nido del tirador)
    marcar(-439.2, -436.8, 608.6, 614.5, 2, 2.4, 'furgon');          // furgón sur
    valla(-438, 605.5, 608.5); valla(-438, 597.5, 599.4); valla(-438, 614.6, 616.5);
    marcar(-448.4, -443.6, 608.0, 610.0, 2, 2.1, 'mando');           // camioneta de mando
    const fila = [[-424, 603], [-417, 612.5], [-409, 605.5], [-398, 610], [-390, 602], [-381, 613]];
    for (const p of fila) autoX(p[0], p[1]);
  }

  /* ====================================================================================================
     RAYOS: la grilla como campo de alturas (HR). DDA casillero por casillero.
     ==================================================================================================== */
  function rayo(ox, oy, oz, dx, dy, dz, max) {
    if (!(max > 0)) max = 1e4;
    let i = Math.floor(ox - EX0), j = Math.floor(oz - EZ0);
    const si = dx > 0 ? 1 : -1, sj = dz > 0 ? 1 : -1;
    const tdx = Math.abs(dx) > 1e-12 ? Math.abs(1 / dx) : Infinity, tdz = Math.abs(dz) > 1e-12 ? Math.abs(1 / dz) : Infinity;
    let tmx = Math.abs(dx) > 1e-12 ? ((dx > 0 ? (EX0 + i + 1 - ox) : (ox - (EX0 + i))) * tdx) : Infinity;
    let tmz = Math.abs(dz) > 1e-12 ? ((dz > 0 ? (EZ0 + j + 1 - oz) : (oz - (EZ0 + j))) * tdz) : Infinity;
    let t0 = 0;
    for (let it = 0; it < 4000; it++) {
      if (i < 0 || j < 0 || i >= EW || j >= EH) return Infinity;
      const h = HR[j * EW + i], t1 = Math.min(tmx, tmz, max);
      if (h > 0) {
        const y0 = oy + dy * t0, y1 = oy + dy * t1;
        if (y0 < h) return t0;
        if (y1 < h) return t0 + (y0 - h) / (y0 - y1) * (t1 - t0);
      }
      if (t1 >= max) return Infinity;
      if (tmx < tmz) { i += si; t0 = tmx; tmx += tdx; } else { j += sj; t0 = tmz; tmz += tdz; }
    }
    return Infinity;
  }
  function lv(ax, ay, az, bx, by, bz) {
    const dx = bx - ax, dy = by - ay, dz = bz - az, d = Math.sqrt(dx * dx + dy * dy + dz * dz); if (d < 0.05) return true;
    return rayo(ax, ay, az, dx / d, dy / d, dz / d, d) >= d - 0.02;
  }

  /* ---------- luz: reflectores del retén; el resto, noche ---------- */
  function luz(x, z) {
    const L = M.zonaLuz, dx = Math.max(L.x0 - x, 0, x - L.x1), dz = Math.max(L.z0 - z, 0, z - L.z1), d = Math.sqrt(dx * dx + dz * dz);
    return d <= 0 ? 1 : d < 4 ? 1 - 0.22 * d : 0.12;
  }

  /* ====================================================================================================
     A* DEL SIMULADOR (para jugadores automáticos y bichos)
     ==================================================================================================== */
  const aG = new Float32Array(N), aDe = new Int32Array(N), aSel = new Uint32Array(N), aCer = new Uint32Array(N);
  let aSello = 0; const hF = [], hK = [];
  function hPush(f, k) { let a = hF.length; hF.push(f); hK.push(k); while (a > 0) { const p = (a - 1) >> 1; if (hF[p] <= hF[a]) break; [hF[p], hF[a]] = [hF[a], hF[p]]; [hK[p], hK[a]] = [hK[a], hK[p]]; a = p; } }
  function hPop() { const k = hK[0], fl = hF.pop(), kl = hK.pop(); if (hF.length) { hF[0] = fl; hK[0] = kl; let a = 0; for (;;) { const l = 2 * a + 1, r = l + 1; let m = a; if (l < hF.length && hF[l] < hF[m]) m = l; if (r < hF.length && hF[r] < hF[m]) m = r; if (m === a) break; [hF[m], hF[a]] = [hF[a], hF[m]]; [hK[m], hK[a]] = [hK[a], hK[m]]; a = m; } } return k; }
  const DI = [1, -1, 0, 0, 1, -1, 1, -1], DJ = [0, 0, 1, -1, 1, 1, -1, -1];
  function libreCerca(x, z, r) {
    const k0 = celda(x, z); if (pasable(k0)) return k0;
    let m = -1, md = 1e9; const i0 = Math.floor(x - EX0), j0 = Math.floor(z - EZ0);
    for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) { const i = i0 + di, j = j0 + dj; if (i < 0 || j < 0 || i >= EW || j >= EH) continue; const k = j * EW + i; if (!pasable(k)) continue; const d = di * di + dj * dj; if (d < md) { md = d; m = k; } }
    return m;
  }
  function camino(x0, z0, x1, z1, o) {
    o = o || {};
    const s = libreCerca(x0, z0, 3), t = libreCerca(x1, z1, 4); if (s < 0 || t < 0) return null;
    const ti = t % EW, tj = (t / EW) | 0, costo = o.costo || null, maxIt = o.maxIt || 40000;
    const heur = k => { const dx = Math.abs((k % EW) - ti), dz = Math.abs(((k / EW) | 0) - tj); return dx + dz - 0.586 * Math.min(dx, dz); };
    aSello++; hF.length = 0; hK.length = 0; aG[s] = 0; aDe[s] = -1; aSel[s] = aSello; hPush(heur(s), s);
    let it = 0, ok = false;
    while (hF.length && it++ < maxIt) {
      const k = hPop(); if (aCer[k] === aSello) continue; aCer[k] = aSello; if (k === t) { ok = true; break; }
      const i = k % EW, j = (k / EW) | 0;
      for (let q = 0; q < 8; q++) {
        const ni = i + DI[q], nj = j + DJ[q]; if (ni < 0 || nj < 0 || ni >= EW || nj >= EH) continue;
        const n = nj * EW + ni; if (aCer[n] === aSello || !pasable(n)) continue;
        if (q >= 4 && (!pasable(j * EW + ni) || !pasable(nj * EW + i))) continue;
        let c = q >= 4 ? 1.4142 : 1; if (costo) c += costo(n) * c;
        const g = aG[k] + c; if (aSel[n] !== aSello || g < aG[n]) { aSel[n] = aSello; aG[n] = g; aDe[n] = k; hPush(g + heur(n), n); }
      }
    }
    if (!ok) return null;
    const pts = []; for (let k = t; k !== -1; k = aDe[k]) pts.push({ x: cX(k), z: cZ(k) }); pts.reverse();
    /* suavizado: atajos rectos por casilleros pasables (sin costo extra en el medio) */
    const out = [pts[0]]; let a = 0;
    while (a < pts.length - 1) {
      let b = Math.min(pts.length - 1, a + 14);
      for (; b > a + 1; b--) if (tramoLibre(pts[a].x, pts[a].z, pts[b].x, pts[b].z, costo)) break;
      out.push(pts[b]); a = b;
    }
    out.costo = aG[t];
    return out;
  }
  function tramoLibre(ax, az, bx, bz, costo) {
    const d = hyp(bx - ax, bz - az), n = Math.max(1, Math.ceil(d / 0.35));
    for (let q = 1; q < n; q++) { const k = celda(ax + (bx - ax) * q / n, az + (bz - az) * q / n); if (!pasable(k) || (costo && costo(k) > 0)) return false; }
    return true;
  }

  /* ====================================================================================================
     EL JUGADOR
     ==================================================================================================== */
  const ARMAS = {
    pistola: { dano: 26, cad: 0.17, n: 1, disp: 0.011, cargador: 12, recarga: 1.3, alcance: 120 },
    escopeta: { dano: 15, cad: 0.8, n: 10, disp: 0.075, cargador: 6, recarga: 0.5, cartucho: true, alcance: 60, lleno: 7, nada: 24 },
    uzi: { dano: 10, cad: 0.072, n: 1, disp: 0.032, cargador: 32, recarga: 1.8, alcance: 100 },
    fusil: { dano: 22, cad: 0.09, n: 1, disp: 0.0075, cargador: 30, recarga: 2.2, alcance: 160 }
  };
  const J = M.jugador = {
    x: -326, y: 0, z: 606, vx: 0, vz: 0, agach: 0, ojoY: 1.62, alto: 1.8, hp: 100, vivo: true, linterna: false, recargando: false, corriendo: false,
    arma: 'pistola', cargador: {}, recT: 0, tTiro: -99, granadas: 2, dano: {}, movido: false, tMuerte: -1
  };
  for (const a in ARMAS) J.cargador[a] = ARMAS[a].cargador;
  M.armas = ARMAS;
  M.ponerJugador = (x, z) => { const k = libreCerca(x, z, 4); J.x = k >= 0 ? cX(k) : x; J.z = k >= 0 ? cZ(k) : z; J.vx = J.vz = 0; };
  M.moverJugador = function (vx, vz, dt, o) {
    o = o || {};
    if (!J.vivo) { J.vx = J.vz = 0; return; }
    J.agach = o.agach ? 1 : 0; J.alto = o.agach ? 1.15 : 1.8; J.ojoY = J.y + (o.agach ? 1.05 : 1.62);
    const tope = o.agach ? 3.0 : o.correr ? 9.6 : 6.2, v = hyp(vx, vz);
    if (v > tope) { vx *= tope / v; vz *= tope / v; }
    let nx = J.x + vx * dt, nz = J.z + vz * dt;
    if (!libre(nx, nz)) { if (libre(nx, J.z)) { nz = J.z; vz = 0; } else if (libre(J.x, nz)) { nx = J.x; vx = 0; } else { nx = J.x; nz = J.z; vx = vz = 0; } }
    J.x = nx; J.z = nz; J.vx = vx; J.vz = vz; J.corriendo = !o.agach && hyp(vx, vz) > 6.5; J.movido = true;
  };
  M.armaJugador = n => { if (ARMAS[n]) { J.arma = n; J.recT = 0; J.recargando = false; } };
  M.linterna = on => { J.linterna = !!on; };
  M.recargarJugador = () => { const A = ARMAS[J.arma]; if (J.recT > 0 || J.cargador[J.arma] >= A.cargador) return false; J.recT = A.recarga; J.recargando = true; return true; };
  function rayoBichos(ox, oy, oz, dx, dy, dz, max) {
    let m = null, mt = max;
    for (const b of bichos) {
      if (!b.vivo) continue;
      const t = capsulaV(ox, oy, oz, dx, dy, dz, b.x, b.y + 0.25, b.z, b.y + 1.35, b.r); if (t >= 0 && t < mt) { mt = t; m = b; }
    }
    return m ? { ref: m, t: mt } : null;
  }
  function capsulaV(ox, oy, oz, dx, dy, dz, cx, y0, cz, y1, r) {               // cilindro vertical (aprox. de cápsula)
    const fx = ox - cx, fz = oz - cz, a = dx * dx + dz * dz; if (a < 1e-9) return -1;
    const b = fx * dx + fz * dz, c = fx * fx + fz * fz - r * r, h = b * b - a * c; if (h < 0) return -1;
    const t = (-b - Math.sqrt(h)) / a; if (t < 0) return -1;
    const y = oy + dy * t; return (y >= y0 && y <= y1) ? t : -1;
  }
  M.dispararJugador = function (px, py, pz) {
    if (!J.vivo || J.recT > 0 || M.t < J.tTiro) return null;
    const A = ARMAS[J.arma];
    if (J.cargador[J.arma] <= 0) { M.recargarJugador(); return null; }
    J.cargador[J.arma]--; J.tTiro = M.t + A.cad;
    const ox = J.x, oy = J.y + (J.agach ? 1.0 : 1.55), oz = J.z;
    let dx = px - ox, dy = py - oy, dz = pz - oz; const d0 = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1; dx /= d0; dy /= d0; dz /= d0;
    const mueve = 1 + hyp(J.vx, J.vz) / 5, res = [];
    for (let q = 0; q < A.n; q++) {
      const da = campana() * A.disp * mueve * 1.6, dv = campana() * A.disp * mueve;
      const hl = Math.sqrt(dx * dx + dz * dz) || 1, lx = -dz / hl, lz = dx / hl;
      let ex = dx + lx * da, ey = dy + dv, ez = dz + lz * da; const el = Math.sqrt(ex * ex + ey * ey + ez * ez); ex /= el; ey /= el; ez /= el;
      let t = rayo(ox, oy, oz, ex, ey, ez, A.alcance), pega = t < A.alcance ? 'mundo' : 'nada'; if (!(t < A.alcance)) t = A.alcance;
      if (ey < -1e-4) { const tp = oy / -ey; if (tp < t) { t = tp; pega = 'mundo'; } }
      let s = null, parte = null, bicho = null;
      const o = { x: ox, y: oy, z: oz }, dd = { x: ex, y: ey, z: ez };
      if (M.UE) { const r = M.UE.rayo(o, dd, t); if (r) { t = r.t; s = r.s; parte = r.parte; pega = 'soldado'; } }
      const rb = rayoBichos(ox, oy, oz, ex, ey, ez, t); if (rb) { t = rb.t; bicho = rb.ref; s = null; pega = 'bicho'; }
      let dano = A.dano; if (A.lleno) { const dist = t; dano *= dist <= A.lleno ? 1 : dist >= A.nada ? 0 : 1 - (dist - A.lleno) / (A.nada - A.lleno); }
      if (s && dano > 0) { M.UE.herir(s, dano, dd, parte, 'jugador'); }
      if (bicho && dano > 0) herirBicho(bicho, dano, ex, ez, 'jugador');
      const hx = ox + ex * t, hy = oy + ey * t, hz = oz + ez * t;
      emitir({ tipo: 'bala', de: 'jugador', arma: J.arma, ox, oy, oz, hx, hy, hz, px, py, pz, pega, s, parte });
      if (M.UE && (q === 0 || A.n === 1)) M.UE.balaCerca(o, dd, t);
      res.push({ pega, s, parte, hx, hy, hz });
    }
    if (M.UE) M.UE.ruido({ x: J.x, y: J.y, z: J.z }, 'disparo', 1);
    if (J.cargador[J.arma] <= 0) M.recargarJugador();
    return res;
  };

  /* ====================================================================================================
     GRANADAS: física simple (gravedad, rebote, rozamiento, paredes), mecha, explosión
     ==================================================================================================== */
  const granadas = [];
  const GRAV = 9.8;
  function arco(ox, oy, oz, hx, hy, hz) {
    const dx = hx - ox, dz = hz - oz, dh = hyp(dx, dz);
    for (let T = Math.max(0.7, dh / 16); T <= 2.8; T += 0.1) {
      const vx = dx / T, vz = dz / T, vy = (hy - oy + 0.5 * GRAV * T * T) / T;
      if (Math.sqrt(vx * vx + vy * vy + vz * vz) > 19) continue;
      let ok = true;
      for (let q = 1; q <= 24 && ok; q++) {                                        // la trayectoria no choca antes de llegar
        const t = T * q / 25, x = ox + vx * t, y = oy + vy * t - 0.5 * GRAV * t * t, z = oz + vz * t;
        if (hyp(x - hx, z - hz) < 0.6) break;
        const k = celda(x, z); if (k < 0 || HR[k] > y - 0.08) ok = false;
      }
      if (ok) return { vx, vy, vz, t: T };
    }
    return null;
  }
  function crearGranada(de, ox, oy, oz, vx, vy, vz, mecha, tipo) {
    const g = { de, x: ox, y: oy, z: oz, vx, vy, vz, t: mecha, mecha, tipo: tipo || 'frag', r: 7, dano: 80, vivo: true, t0: M.t };
    granadas.push(g);
    emitir({ tipo: 'granada', de, x: ox, y: oy, z: oz, vx, vy, vz, mecha });
    return g;
  }
  M.lanzarGranadaJugador = function (x, z) {
    if (!J.vivo || J.granadas <= 0) return false;
    const a = arco(J.x, J.y + 1.6, J.z, x, 0, z); if (!a) return false;
    J.granadas--; crearGranada('jugador', J.x, J.y + 1.6, J.z, a.vx, a.vy, a.vz, 3.0, 'frag');
    return true;
  };
  function pasoGranada(g, dt) {
    const n = Math.max(1, Math.ceil(dt / 0.01)), h = dt / n;
    for (let q = 0; q < n; q++) {
      g.vy -= GRAV * h;
      let nx = g.x + g.vx * h, ny = g.y + g.vy * h, nz = g.z + g.vz * h;
      const k = celda(nx, nz);
      if (k < 0 || HR[k] > ny) {                                                    // pega contra algo: rebota en el eje que cruzó
        const kx = celda(nx, g.z), kz = celda(g.x, nz);
        if (kx < 0 || HR[kx] > ny) { g.vx = -g.vx * 0.35; nx = g.x; }
        if (kz < 0 || HR[kz] > ny) { g.vz = -g.vz * 0.35; nz = g.z; }
        if (nx !== g.x && nz !== g.z) { g.vx = -g.vx * 0.35; g.vz = -g.vz * 0.35; nx = g.x; nz = g.z; }
      }
      if (ny <= 0.06) { ny = 0.06; if (g.vy < 0) { g.vy = -g.vy * 0.28; if (g.vy < 0.6) g.vy = 0; g.vx *= 0.45; g.vz *= 0.45; } }
      if (ny <= 0.07 && g.vy === 0) { const v = hyp(g.vx, g.vz), f = Math.max(0, v - 4 * h); if (v > 0) { g.vx *= f / v; g.vz *= f / v; } }
      g.x = nx; g.y = ny; g.z = nz;
    }
    g.t -= dt;
    if (g.t <= 0) explotar(g);
  }
  function explotar(g) {
    g.vivo = false;
    const deJ = g.de === 'jugador';
    emitir({ tipo: 'explosion', x: g.x, y: g.y, z: g.z, r: g.r, de: g.de });
    if (J.vivo) {
      const d = hyp(J.x - g.x, J.z - g.z);
      if (d < g.r) { let dn = g.dano * (1 - d / g.r); if (!lv(g.x, g.y + 0.3, g.z, J.x, J.y + J.alto * 0.6, J.z)) dn *= 0.3; if (dn > 0.5) herirJugador(dn, g.x, g.z, 'granada'); }
    }
    for (const b of bichos) if (b.vivo) { const d = hyp(b.x - g.x, b.z - g.z); if (d < g.r) herirBicho(b, g.dano * (1 - d / g.r) * 1.3, b.x - g.x, b.z - g.z, deJ ? 'jugador' : 'soldado'); }
    if (M.UE) M.UE.explosion({ x: g.x, y: g.y, z: g.z }, g.r, g.dano, deJ ? 'jugador' : 'granada');
  }

  /* ====================================================================================================
     BICHOS: corren al blanco más cercano (el jugador o un soldado) y muerden
     ==================================================================================================== */
  const bichos = [], porSalir = [];
  let bichoId = 0;
  M.soltarBichos = function (n, o) {
    o = o || {}; const cada = o.cada || 0.35, bocas = mapa.sub && mapa.sub.length ? mapa.sub : [{ x: -514, z: 623 }];
    for (let i = 0; i < n; i++) { const b = bocas[i % bocas.length]; porSalir.push({ t: M.t + (o.desde || 0) + i * cada, x: b.x + campana(), z: b.z + campana() }); }
  };
  function nacerBicho(x, z) {
    const k = libreCerca(x, z, 4);
    const b = { id: bichoId++, ref: null, x: k >= 0 ? cX(k) : x, y: 0, z: k >= 0 ? cZ(k) : z, r: 0.45, tipo: 'corredor', hp: 70, vivo: true, vel: 6.4,
      cam: null, ci: 0, tCam: 0, blanco: null, tBlanco: 0, tMord: 0, vx: 0, vz: 0, mataPor: null };
    b.ref = b; bichos.push(b);
  }
  function herirBicho(b, dano, dx, dz, de) {
    if (!b || !b.vivo) return;
    b.hp -= dano; emitir({ tipo: 'herida', a: 'bicho', dano, fuente: de || 'soldado', quien: b.id });
    if (b.hp <= 0) { b.vivo = false; b.mataPor = de || 'soldado'; emitir({ tipo: 'muerte', a: 'bicho', quien: b.id, por: b.mataPor }); }
  }
  function pasoBichos(dt) {
    for (let i = porSalir.length - 1; i >= 0; i--) if (M.t >= porSalir[i].t) { nacerBicho(porSalir[i].x, porSalir[i].z); porSalir.splice(i, 1); }
    const obj = M.UE ? M.UE.objetivos() : [];
    for (const b of bichos) {
      if (!b.vivo) continue;
      if (b.tMord > 0) b.tMord -= dt;
      if (M.t >= b.tBlanco) {                                                         // elige el blanco más cercano
        b.tBlanco = M.t + 0.5; let m = null, md = 1e9;
        if (J.vivo) { md = hyp(J.x - b.x, J.z - b.z); m = J; }
        for (const s of obj) { const d = hyp(s.x - b.x, s.z - b.z) + (s.y > 1 ? 40 : 0); if (d < md) { md = d; m = s; } }   // a uno subido (el tirador en el techo) no lo alcanzan: va último
        if (m !== b.blanco) { b.blanco = m; b.cam = null; }
      }
      const o = b.blanco; if (!o) continue;
      const d = hyp(o.x - b.x, o.z - b.z);
      if (d < 1.25) {                                                                 // muerde
        if (b.tMord <= 0) {
          b.tMord = 0.85;
          if (o === J) herirJugador(9, b.x, b.z, 'bicho'); else if (o.herir) { o.herir(9, b); emitir({ tipo: 'herida', a: 'soldado', dano: 9, fuente: 'bicho', s: o }); }
        }
        continue;
      }
      if (!b.cam || M.t >= b.tCam) {
        b.tCam = M.t + 0.7;
        b.cam = (d < 3 && tramoLibre(b.x, b.z, o.x, o.z, null)) ? [{ x: o.x, z: o.z }] : camino(b.x, b.z, o.x, o.z, { maxIt: 9000 }); b.ci = b.cam && b.cam.length > 1 ? 1 : 0;
      }
      let tx = o.x, tz = o.z;
      if (b.cam && b.ci < b.cam.length) { tx = b.cam[b.ci].x; tz = b.cam[b.ci].z; if (hyp(tx - b.x, tz - b.z) < 0.6 && b.ci < b.cam.length - 1) { b.ci++; tx = b.cam[b.ci].x; tz = b.cam[b.ci].z; } }
      const l = hyp(tx - b.x, tz - b.z) || 1, vx = (tx - b.x) / l * b.vel, vz = (tz - b.z) / l * b.vel;
      let nx = b.x + vx * dt, nz = b.z + vz * dt;
      if (!libre(nx, nz)) { if (libre(nx, b.z)) nz = b.z; else if (libre(b.x, nz)) nx = b.x; else { nx = b.x; nz = b.z; b.cam = null; } }
      b.vx = (nx - b.x) / dt; b.vz = (nz - b.z) / dt; b.x = nx; b.z = nz;
    }
  }

  /* ====================================================================================================
     ENV (SPEC 4.7)
     ==================================================================================================== */
  function emitir(ev) { ev.t = M.t; M.eventos.push(ev); }
  function herirJugador(dano, desdeX, desdeZ, tipo) {
    if (!J.vivo || !(dano > 0)) return;
    J.hp -= dano; J.dano[tipo] = (J.dano[tipo] || 0) + dano;
    emitir({ tipo: 'herida', a: 'jugador', dano, fuente: tipo, desdeX, desdeZ });
    if (J.hp <= 0) { J.hp = 0; J.vivo = false; J.tMuerte = M.t; J.vx = J.vz = 0; emitir({ tipo: 'muerte', a: 'jugador', por: tipo }); }
  }
  const pel = [];
  const ENV = {
    B, H, EW, EH, EX0, EZ0,
    jugador: () => J,
    piso: () => 0,
    rayo,
    luz,
    bichos: () => { const v = []; for (const b of bichos) if (b.vivo) v.push(b); return v; },
    rayoBichos,
    herirBicho: (ref, dano, dx, dz) => herirBicho(ref, dano, dx, dz, 'soldado'),
    peligros: () => { pel.length = 0; for (const g of granadas) if (g.vivo) pel.push({ x: g.x, z: g.z, r: g.r, t: g.t, de: g.de, tipo: 'granada' }); return pel; },
    herirJugador,
    bala: e => emitir({ tipo: 'bala', de: 'soldado', s: e.s, arma: e.tipo, modo: e.modo, raf: e.raf, ficha: e.ficha, ox: e.ox, oy: e.oy, oz: e.oz, hx: e.hx, hy: e.hy, hz: e.hz, px: e.px, py: e.py, pz: e.pz, pega: e.pega }),
    granada: (s, ox, oy, oz, vx, vy, vz, mecha, tipo) => crearGranada(s, ox, oy, oz, vx, vy, vz, mecha, tipo),
    arco,
    radio: (s, clave, texto) => emitir({ tipo: 'radio', s, clave, texto }),
    evento: (nombre, datos) => emitir({ tipo: 'evento', nombre, datos }),
    vista: () => null,
    azar,
    ahora: () => M.t
  };
  M.ENV = ENV;

  /* ====================================================================================================
     PASO, EVENTOS, FOTO
     ==================================================================================================== */
  M.conectar = UE => { M.UE = UE; };
  M.armarReten = function (o) {
    o = o || {};
    const E = PI / 2;                                                               // rumbo «al este»
    const c = M.UE.escuadron({
      nombre: 'Ceniza', roles: o.roles || ['jefe', 'asalto', 'granadero', 'tirador'],
      puestos: { jefe: { x: -441, z: 606, rumbo: E }, granadero: { x: -441, z: 612, rumbo: E } },
      ronda: [{ x: -428, z: 604 }, { x: -395, z: 604 }, { x: -395, z: 614 }, { x: -428, z: 614 }],
      nido: { x: -437.6, z: 602.6, y: 2.4, rumbo: E, r: 4 },
      reunion: { x: -447, z: 609 }
    });
    let r = null;
    if (o.refuerzo !== false) r = M.UE.refuerzo({ nombre: 'Tizón', roles: o.rolesRefuerzo || ['jefe', 'asalto', 'granadero', 'asalto'], sale: { x: -540, z: 607 }, camino: [{ x: -505, z: 607 }, { x: -470, z: 607 }, { x: -452, z: 604 }] });
    return { ceniza: c, tizon: r };
  };
  const laserOn = new Map();
  M.paso = function (dt) {
    M.t += dt;
    if (J.recT > 0) { J.recT -= dt; if (J.recT <= 0) { const A = ARMAS[J.arma]; if (A.cartucho) { J.cargador[J.arma]++; if (J.cargador[J.arma] < A.cargador) J.recT = A.recarga; else J.recargando = false; } else { J.cargador[J.arma] = A.cargador; J.recargando = false; } } }
    J.recargando = J.recT > 0;
    if (M.UE) {
      M.UE.update(dt);
      for (const s of M.UE.soldados) if (s.rol === 'tirador') { const on = !!(s.vivo && s.laser); if (on !== !!laserOn.get(s)) { laserOn.set(s, on); emitir({ tipo: 'laser', s, on }); } }
    }
    for (const g of granadas) if (g.vivo) pasoGranada(g, dt);
    for (let i = granadas.length - 1; i >= 0; i--) if (!granadas[i].vivo) granadas.splice(i, 1);
    pasoBichos(dt);
    if (!J.movido) { J.vx = J.vz = 0; J.corriendo = false; }
    J.movido = false;
  };
  M.sacarEventos = () => { const v = M.eventos; M.eventos = []; return v; };
  M.foto = function () {
    const d = M.UE ? M.UE.debug() : { soldados: [], escuadrones: [], granadas: [] };
    const las = [];
    if (M.UE) for (const s of M.UE.soldados) if (s.vivo && s.laser) las.push({ ox: s.x, oy: s.y + 0.3, oz: s.z, x: s.laser.x, y: s.laser.y, z: s.laser.z });
    return {
      t: M.t, jugador: { x: J.x, z: J.z, hp: J.hp, vivo: J.vivo, agach: J.agach, linterna: J.linterna, arma: J.arma },
      soldados: d.soldados, escuadrones: d.escuadrones,
      bichos: bichos.filter(b => b.vivo).map(b => ({ x: b.x, z: b.z, hp: b.hp })),
      granadas: granadas.filter(g => g.vivo).map(g => ({ x: g.x, z: g.z, t: g.t, de: g.de === 'jugador' ? 'jugador' : 'soldado' })),
      laseres: las
    };
  };
  M.bichos = bichos; M.granadas = granadas;
  M.rayo = rayo; M.lv = lv; M.camino = camino; M.libre = libre; M.celda = celda; M.libreCerca = libreCerca; M.cX = cX; M.cZ = cZ; M.azar = azar;
  M.grilla = { B, H, HR, G, EW, EH, EX0, EZ0 };
  return M;
}
if (typeof module !== 'undefined') module.exports = { crearMundo };
