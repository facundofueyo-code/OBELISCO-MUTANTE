  /* ====================================================================================================
     PENSAR: unas 8 veces por segundo por soldado, escalonado. Decide; actuar() ejecuta.
     ==================================================================================================== */
  function pensar(s) {
    if (s.aturdido > 0 || s.salto >= 0) return;
    if (s.estado === 'esquivar') { pensarEsquivar(s); return; }
    if (empezarEsquivar(s)) return;
    elegirBlanco(s);
    if (s.estado === 'lanzar' || s.estado === 'culata') return;
    if (intentarCulata(s)) return;
    if (s.blanco === 'bicho') { pensarBicho(s); return; }
    if (s.estado === 'bicho') { ponerEstado(s, 'alerta'); s.enTiro = false; }
    const nivel = nivelDe(s);
    if (red.muerto || nivel === 0) pensarGuardia(s);
    else if (nivel === 2) pensarCombate(s);
    else if (s.esc.estado === 'busqueda') pensarBusqueda(s);
    else pensarSospecha(s);
  }

  /* ---------- blanco: el jugador o un bicho ---------- */
  function elegirBlanco(s) {
    const b = s.bicho, nivel = nivelDe(s);
    if (b && b.d < T.bichoManda) s.blanco = 'bicho';                                  // un bicho encima manda
    else if (nivel >= 2 && red.uc && !red.muerto && (!b || s.ve || (!s.esc.prioBichos && ahora - red.tSenal < 4))) s.blanco = 'jugador';
    else if (b) s.blanco = 'bicho';
    else s.blanco = (nivel >= 2 && !red.muerto) ? 'jugador' : null;
  }
  function mirarA(s, x, y, z) {
    s.miraObj = Math.atan2(x - s.x, z - s.z);
    const d = hyp(x - s.x, z - s.z); s.mPitch = Math.atan2(y - (s.y + 1.4 - 0.5 * s.agach), d || 1);
  }

  /* ---------- peligros: granadas y autos por explotar ---------- */
  function puntoDeEscape(s, p) {
    const base = Math.atan2(s.x - p.x, s.z - p.z); let mejor = null, mp = -1e9;
    for (let q = 0; q < 12; q++) {
      const a = base + q * PI / 6, x = p.x + Math.sin(a) * (p.r + 2.8), z = p.z + Math.cos(a) * (p.r + 2.8), k = libreCerca(x, z, 1);
      if (k < 0) continue; const fx = cX(k), fz = cZ(k);
      if (enPeligro(fx, fz, 0.5)) continue;
      let pt = -hyp(fx - s.x, fz - s.z);
      if (!lineaVista(p.x, 0.5, p.z, fx, 0.6, fz)) pt += 4;                           // mejor si queda algo entre la explosión y él
      if (pt > mp) { mp = pt; mejor = k; }
    }
    return mejor;
  }
  function empezarEsquivar(s) {
    const p = enPeligro(s.x, s.z, 0.8); if (!p || p.t > 6) return false;
    if (s.pelVisto !== p.x + p.z) { s.pelVisto = p.x + p.z; s.pelT = ahora; }           // tarda un instante en darse cuenta
    if (ahora - s.pelT < 0.2) return false;
    const propia = p.de && typeof p.de === 'object';                                    // una granada nuestra: se corren sin gritar
    if (!propia) decir(s, (p.tipo === 'auto' || p.r > 8) ? 'auto_fuego' : 'granada_enemiga');
    s.raf = 0; s.enTiro = false; if (s.rol === 'tirador') soltarLaser(s, false);
    if (s.lanzaT >= 0 && s.lanza && !s.lanza.salio) { s.lanzaT = -1; s.lanza = null; }
    if (s.elev) { bajarDelNido(s); ponerEstado(s, 'esquivar'); s.escK = -1; return true; }
    ponerEstado(s, 'esquivar'); s.post = 0; s.apObj = false; s.miraObj = null; s.miraFija = false;
    const k = puntoDeEscape(s, p); s.escK = k;
    if (k >= 0) irA(s, cX(k), cZ(k), T.velEscapar, { evita: [{ x: p.x, z: p.z, r: p.r, c: 5 }] }); else { parar(s); s.post = 2; }
    if (s.esc.mueve === s) s.esc.mueve = null;
    return true;
  }
  function pensarEsquivar(s) {
    const p = enPeligro(s.x, s.z, 3.5);
    if (!p) {                                                                           // pasó el peligro: a pelear de nuevo
      if (ahora - s.tEst < 0.4) return;
      s.post = 0; s.cob = null; parar(s); ponerEstado(s, 'alerta'); return;
    }
    if (s.escK === -1 && s.salto < 0 && !s.elev) { const k = puntoDeEscape(s, p); s.escK = k; if (k >= 0) irA(s, cX(k), cZ(k), T.velEscapar, null); }
    const dentro = hyp(p.x - s.x, p.z - s.z) < p.r + 0.5;
    if (p.t < 0.5 || (s.llego && !s.esperaCamino)) {
      if (dentro && p.t > 1.2 && s.llego) { const k = puntoDeEscape(s, p); if (k >= 0) { irA(s, cX(k), cZ(k), T.velEscapar, null); return; } }
      parar(s); s.post = 2;                                                             // al piso
    }
  }

  /* ---------- culatazo ---------- */
  function intentarCulata(s) {
    if (s.culCd > 0 || s.culT >= 0 || s.elev || s.tierra > 0.3 || s.recT >= 0 && false) return false;
    const C = T.culata;
    if (s.ve && s.blanco === 'jugador') {
      const h = s.hist[(s.hI + 9) % 10];
      if (ahora - h.t < 0.25 && hyp(h.x - s.x, h.z - s.z) < C.dist) {
        s.culT = 0; s.culPego = false; s.culBicho = false; s.raf = 0; s.dvx = s.dvz = 0; s.miraObj = rumboA(s, h.x, h.z); s.miraFija = true; ponerEstado(s, 'culata'); return true;
      }
    }
    const b = s.bicho;
    if (b && b.d < 1.7 && (s.balas <= 0 || s.recT >= 0)) { s.culT = 0; s.culPego = false; s.culBicho = true; s.raf = 0; s.miraObj = rumboA(s, b.x, b.z); s.miraFija = true; ponerEstado(s, 'culata'); return true; }
    return false;
  }

  /* ---------- contra los bichos: sin ficha, con buena puntería, retrocediendo si se le vienen encima ---------- */
  function pensarBicho(s) {
    const b = s.bicho; if (!b) return;
    if (s.elev) { s.post = 2; s.enTiro = false; return; }                               // el tirador en el nido no se distrae
    if (s.estado !== 'bicho') { ponerEstado(s, 'bicho'); parar(s); if (s.esc.mueve === s) s.esc.mueve = null; }
    s.apObj = true; s.luz = true; s.miraFija = true; s.enTiro = true; s.post = s.tierra > 0 ? 0 : (b.d > 12 ? 1 : 0);
    mirarA(s, b.x, b.y, b.z);
    if (s.balas <= 0 && s.recT < 0) { s.recT = 0; decir(s, 'recarga'); }
    if (b.d < T.bichoRetro) {
      /* retrocede de frente al bicho, despacio (así puede seguir tirando), hacia un casillero libre */
      const ux = (s.x - b.x) / (b.d || 1), uz = (s.z - b.z) / (b.d || 1);
      let vx = ux, vz = uz;
      if (!libreEn(s.x + ux * 1.2, s.z + uz * 1.2)) { if (libreEn(s.x - uz * 1.2, s.z + ux * 1.2)) { vx = -uz; vz = ux; } else if (libreEn(s.x + uz * 1.2, s.z - ux * 1.2)) { vx = uz; vz = -ux; } else { vx = vz = 0; } }
      s.dvx = vx * 1.55; s.dvz = vz * 1.55; s.retro = 0.3;
    } else { s.dvx = s.dvz = 0; }
  }

  /* ====================================================================================================
     GUARDIA: puestos y ronda. No saben nada.
     ==================================================================================================== */
  function pensarGuardia(s) {
    const e = s.esc;
    s.apObj = false; s.enTiro = false; s.miraFija = false; s.cob = null;
    if (s.sosp >= T.sospechaMira && !red.muerto) { entrarSospecha(e, s, s.estX, s.estZ); return; }
    if (s.rol === 'tirador' && e.nido) {
      ponerEstado(s, 'puesto'); s.luz = false;
      if (!s.elev) { subirAlNido(s); return; }
      s.post = 2; s.miraObj = e.nido.rumbo + Math.sin(ahora * 0.33 + s.escaneo) * 0.45; return;
    }
    if (s.rol === 'asalto' && e.ronda && e.ronda.length) {
      ponerEstado(s, 'ronda'); s.post = 0; s.luz = true;
      if (s.espera > ahora) { s.miraObj = s.rondaYaw + Math.sin((ahora - s.tEsp0) * 1.3) * 1.1; s.miraFija = true; return; }   // parado, alumbrando los autos
      if (s.llego && !s.esperaCamino) {
        if (s.rondaYendo) { s.rondaYendo = false; s.espera = ahora + entre(1.5, 3); s.tEsp0 = ahora; s.rondaYaw = s.miraYaw; s.ri = (s.ri + 1) % e.ronda.length; return; }
        const p = e.ronda[s.ri % e.ronda.length]; irA(s, p.x, p.z, T.velRonda, null); s.rondaYendo = true;
      }
      s.miraObj = null; return;
    }
    ponerEstado(s, 'puesto'); s.post = s.rol === 'tirador' ? 1 : 0; s.luz = false;
    const p = s.puesto;
    if (hyp(p.x - s.x, p.z - s.z) > 0.8) { if (s.llego && !s.esperaCamino) irA(s, p.x, p.z, 2.4, null); s.miraObj = null; return; }
    s.miraObj = p.rumbo + Math.sin(ahora * 0.3 + s.escaneo) * 0.6;
    if (ahora > s.tOcio) { s.tOcio = ahora + entre(25, 50); if (e.estado === 'guardia') decir(s, 'ocioso'); }
  }
  /* el tirador vuelve a su nido: camina hasta el pie del furgón y sube */
  function subirAlNido(s) {
    const n = s.esc.nido, k = libreCerca(n.x, n.z, 5); if (k < 0) return;
    const d = hyp(cX(k) - s.x, cZ(k) - s.z); s.post = 0; s.miraObj = null;
    if (d > 0.7) { if (s.llego && !s.esperaCamino) irA(s, cX(k), cZ(k), 2.4, null); return; }
    parar(s); s.salto = 0; s.sx0 = s.x; s.sz0 = s.z; s.sx1 = n.x; s.sz1 = n.z; s.sDur = 1.6; s.subeA = n.y; s.bajaDe = 0;
  }
  function bajarDelNido(s) {
    if (!s.elev) return;
    const u = red.uc; let k = -1;
    if (u) { const l = hyp(s.x - u.x, s.z - u.z) || 1; k = libreCerca(s.x + (s.x - u.x) / l * 3, s.z + (s.z - u.z) / l * 3, 3); }   // baja del lado contrario al jugador
    if (k < 0) k = libreCerca(s.x, s.z, 5); if (k < 0) return;
    soltarLaser(s, false); s.enTiro = false;
    s.bajaDe = s.elev.y; s.elev = null; s.post = 0; s.tierra = 0; s.agach = 1;
    s.salto = 0; s.sx0 = s.x; s.sz0 = s.z; s.sx1 = cX(k); s.sz1 = cZ(k); s.sDur = T.tDeTierra + 0.5; s.cob = null;
  }

  /* ====================================================================================================
     SOSPECHA: vieron u oyeron algo. Miran, alumbran, uno va a revisar.
     ==================================================================================================== */
  function pensarSospecha(s) {
    const e = s.esc, q = e.sosp; if (!q) { pensarGuardia(s); return; }
    s.apObj = true; s.luz = s.rol !== 'tirador'; s.enTiro = false; s.cob = null; s.miraFija = true;
    if (s.sosp >= T.sospechaMira && ahora - s.estT < 0.3) { q.x = s.estX; q.z = s.estZ; q.t = ahora; }      // sigue viendo algo: actualiza adónde mirar
    if (q.quien === s && !s.elev) {
      ponerEstado(s, 'revisar'); s.post = 0;
      const d = hyp(q.x - s.x, q.z - s.z);
      if (d > 5) {
        if ((s.llego && !s.esperaCamino) || (s.dest && hyp(s.dest.x - q.x, s.dest.z - q.z) > 4 && !s.esperaCamino)) irA(s, q.x, q.z, 2.6, null);
        mirarA(s, q.x, 1.2, q.z); q.llegoT = 0;
      } else {
        parar(s); if (!q.llegoT) q.llegoT = ahora;
        s.miraObj = rumboA(s, q.x, q.z) + Math.sin((ahora - q.llegoT) * 1.6) * 1.2;
      }
    } else {
      ponerEstado(s, 'alerta'); if (s.camino) parar(s);
      s.post = s.rol === 'tirador' ? (s.elev ? 2 : 1) : 0; mirarA(s, q.x, 1.2, q.z);
    }
  }

  /* ====================================================================================================
     COMBATE
     ==================================================================================================== */
  const enMovimiento = s => s.estado === 'a_cubierto' || s.estado === 'avanzar' || s.estado === 'flanquear' || s.estado === 'replegar' || s.estado === 'llegando';
  function pensarCombate(s) {
    const e = s.esc, u = conocido(s);
    s.apObj = true;
    if (!u) { ponerEstado(s, 'alerta'); s.enTiro = false; s.post = s.elev ? 2 : 1; return; }       // combate sin saber dónde: rodilla en tierra y a mirar
    /* mirar: al jugador si lo ve; si no, al último lugar conocido */
    if (s.ve && puntoMira(s, T.miraAtraso, T.miraAdelanto)) mirarA(s, s.miraX, s.miraY, s.miraZ); else mirarA(s, u.x, u.y + 1.1, u.z);
    if (s.estado === 'radio') { pensarRadio(s); return; }
    if (s.orden) tomarOrden(s, u);
    if (s.estado === 'lanzar' || s.estado === 'radio') return;
    if (s.rol === 'tirador') { pensarTirador(s, u); return; }
    s.luz = s.tarea !== 'flanquear';
    /* clavado en descampado, lejos de su cobertura: cuerpo a tierra hasta que afloje */
    if (enMovimiento(s) && s.supr > T.suprEsconde && s.cob && hyp(s.cob.x - s.x, s.cob.z - s.z) > 6 && s.tarea !== 'replegar') {
      ponerEstado(s, 'tierra'); s.pinned = true; parar(s); if (ahora - s.tSuprDijo > 6) { decir(s, 'suprimido'); s.tSuprDijo = ahora; } return;
    }
    switch (s.estado) {
      case 'a_cubierto': case 'avanzar': case 'flanquear': case 'replegar': case 'llegando': enCamino(s, u); break;
      case 'cubierto': enCubierto(s, u); break;
      case 'asomado': enAsomado(s, u); break;
      case 'volver': enVolver(s); break;
      case 'tierra': enTierra(s, u); break;
      default: reaccionar(s); break;
    }
  }
  /* primer momento del combate (o quedó sin cobertura): arma arriba y a buscar dónde cubrirse */
  function reaccionar(s) {
    if (s.rol === 'tirador') s.tarea = 'tirador'; else if (s.tarea === 'guardia' || s.tarea === 'buscar') s.tarea = 'fijar';
    s.enTiro = false; s.miraFija = true;
    if (s.estado !== 'alerta') ponerEstado(s, 'alerta');
    if (s.camino && !s.cob) parar(s);
    if (!s.esperaCob) pedirCobertura(s);
  }
  /* qué cobertura busca según su tarea y su rol */
  function opcionesCob(s, u) {
    const e = s.esc, dA = hyp(s.x - u.x, s.z - u.z), herido = s.hp < T.vida * T.heridoBajo;
    let ideal = s.rol === 'jefe' ? T.distJefe : s.rol === 'asalto' ? T.distAsalto + 6 : T.distGranadero; if (herido) ideal += 10;
    if (s.tarea === 'replegar') { const r = e.reunion || s.puesto; return { cx: (s.x + r.x) / 2, cz: (s.z + r.z) / 2, radio: 26, dMin: 10, dMax: 120, dIdeal: dA + 14, atras: dA < 45, reunion: r }; }
    if (s.tarea === 'avanzar') { const f = Math.min(1, 12 / (dA || 1)); return { cx: s.x + (u.x - s.x) * f, cz: s.z + (u.z - s.z) * f, radio: 14, dMin: 6, dMax: Math.max(9, dA - 3), dIdeal: Math.max(9, dA - 14) }; }
    if (s.tarea === 'empujar') { const f = Math.min(1, 8 / (dA || 1)); return { cx: u.x + (s.x - u.x) * f, cz: u.z + (s.z - u.z) * f, radio: 11, dMin: 4, dMax: 14, dIdeal: 8, tiro: true, pesoCamino: 0.05 }; }
    return { radio: 22, dMin: s.rol === 'asalto' ? 6 : 9, dMax: 75, dIdeal: ideal };
  }
  function pedirCobertura(s) {
    if (s.esperaCob) return; s.esperaCob = true;
    encolar(s, 'cob', () => {
      s.esperaCob = false; const u = conocido(s); if (!u) return;
      let c = null;
      if (s.rol === 'tirador') c = buscarPuestoTirador(s, u.x, u.z);
      if (!c) c = buscarCobertura(s, u.x, u.z, opcionesCob(s, u));
      if (!c && s.tarea !== 'fijar' && s.rol !== 'tirador') { s.tarea = 'fijar'; c = buscarCobertura(s, u.x, u.z, opcionesCob(s, u)); }
      if (!c) {                                                                         // no hay dónde: pelea desde donde está, cuerpo a tierra
        if (s.cob && s.estado === 'cubierto') return;                                   // se queda con la que tenía
        s.cob = null; s.sinCob = ahora; parar(s); ponerEstado(s, 'tierra'); s.pinned = false; if (s.esc.mueve === s) s.esc.mueve = null; return;
      }
      tomarCobertura(s, c);
    });
  }
  function tomarCobertura(s, c) {
    s.cob = c; s.enTiro = false; s.tCob = ahora; s.tSinTiro = 0; s.fallo = false;
    if (hyp(c.x - s.x, c.z - s.z) < 0.5) { ponerEstado(s, 'cubierto'); s.tSal = ahora + entre(0.2, 0.6); if (s.esc.mueve === s) s.esc.mueve = null; return; }
    const sig = s.tarea === 'flanquear';
    ponerEstado(s, sig ? 'flanquear' : s.tarea === 'replegar' ? 'replegar' : (s.tarea === 'avanzar' || s.tarea === 'empujar') ? 'avanzar' : 'a_cubierto');
    s.caminoOp = { expo: s.tarea !== 'empujar', agach: sig, evita: peligros.length ? peligros.map(p => ({ x: p.x, z: p.z, r: p.r + 1, c: 8 })) : null };
    irA(s, c.x, c.z, sig ? T.velAgach : T.velCorrer, s.caminoOp);
    s.post = sig ? 1 : 0;
  }
  /* corriendo hacia su cobertura */
  function enCamino(s, u) {
    const e = s.esc;
    s.enTiro = false; s.miraFija = false; s.post = s.estado === 'flanquear' ? 1 : 0;
    if (!s.cob) { reaccionar(s); return; }
    if (s.llego && !s.esperaCamino) {
      const d = hyp(s.cob.x - s.x, s.cob.z - s.z);
      if (d < 0.9) {
        if (e.mueve === s) e.mueve = null;
        if (s.rol === 'tirador') { ponerEstado(s, 'tierra'); s.pinned = false; if (ahora - s.tirDijo > 5) { decir(s, 'tirador_listo'); s.tirDijo = ahora; } return; }
        ponerEstado(s, 'cubierto'); s.tSal = ahora + ((s.tarea === 'flanquear' || s.tarea === 'empujar') ? 0.25 : entre(0.3, 0.9));
        if (e.flanco && e.flanco.s === s && !e.flanco.tLlego) { e.flanco.tLlego = ahora; ENV.evento('flanco_llego', { s, t: ahora - e.flanco.t0 }); }
        return;
      }
      if (s.fallo || (s.sinCamino || 0) > 2) { s.cob = null; s.sinCamino = 0; reaccionar(s); return; }  // no se puede llegar: otra
      irA(s, s.cob.x, s.cob.z, s.vel || T.velCorrer, s.caminoOp);                       // camino parcial: sigue desde donde quedó
      return;
    }
    /* si el lugar conocido se movió y la cobertura a la que va ya no tapa, elige otra sin frenar */
    if (ahora - (s.tReval || 0) > 0.7) {
      s.tReval = ahora;
      if (hyp(u.x - s.cob.ax, u.z - s.cob.az) > 3 && !tapa(s.cob, u.x, u.z) && !s.esperaCob) pedirCobertura(s);
    }
  }
  /* a cubierto: escondido en su casillero. Recarga, decide si cambia de posición, y se asoma cada tanto */
  function enCubierto(s, u) {
    const e = s.esc, c = s.cob; if (!c) { reaccionar(s); return; }
    const A = T[s.arma];
    s.enTiro = false; s.miraFija = true; s.post = c.tipo === 'alta' ? 0 : 1;
    if (hyp(c.x - s.x, c.z - s.z) > 0.4 && s.llego && !s.esperaCamino) irA(s, c.x, c.z, 2.4, null);
    /* ¿me flanqueó? El lugar conocido ya ve mi cobertura: cambio urgente, sin pedir permiso */
    if ((c.tipo !== 'nada' || ahora - s.tCob > 7) && !s.esperaCob && !tapa(c, u.x, u.z)) {
      if (Math.abs(angN(rumboA(s, u.x, u.z) - rumboA(s, c.ax, c.az))) > 0.8) decir(s, 'flanqueado');
      c.tipo = 'nada'; s.tCob = ahora - 4; pedirCobertura(s); return;
    }
    if (s.recT >= 0) { ponerEstado(s, 'recargar'); return; }
    if (s.estado === 'recargar') ponerEstado(s, 'cubierto');
    if (s.balas <= 0 || (s.balas <= A.cargador * 0.34 && !s.ve && ahora - s.tDisparo > 1)) { s.recT = 0; ponerEstado(s, 'recargar'); decir(s, 'recarga'); ENV.evento('recarga', { s }); return; }
    /* herido: se repliega una vez a una cobertura más atrás */
    if (s.hp < T.vida * T.heridoBajo && !s.replegado) {
      s.replegado = true; decir(s, 'herido'); s.tarea = 'replegar'; if (!s.esperaCob) pedirCobertura(s); return;
    }
    /* cambio de posición no urgente: pide permiso (fuego y movimiento) */
    if (!s.esperaCob && quiereMoverse(s, u, c) && pedirPermiso(s)) { pedirCobertura(s); return; }
    /* asomarse: es también su manera de mirar */
    if (ahora >= s.tSal && s.escondeT <= 0 && c.tiro) {
      ponerEstado(s, 'asomado'); s.tVentana = entre(T.ventanaMin, T.ventanaMax); s.post = c.tiro.post;
      if (c.tiro.lado !== 0) irA(s, c.tiro.x, c.tiro.z, 2.6, null);
    }
  }
  function quiereMoverse(s, u, c) {
    const e = s.esc; if (e.desorden > ahora) return false;                              // sin jefe: cada uno aguanta donde está
    if (ahora - s.tCob < 4) return false;
    if (s.moverPor) return true;                                                        // se lo ordenaron (avanzar, empujar, fin del flanqueo)
    const dA = hyp(c.x - u.x, c.z - u.z);
    if (!c.tiro) return true;
    if (s.tarea === 'fijar') {
      const ideal = s.rol === 'jefe' ? T.distJefe : s.rol === 'asalto' ? T.distAsalto + 6 : T.distGranadero;
      if (dA > ideal + 20 || dA < (s.rol === 'asalto' ? 4 : 7)) return true;
      if (s.tSinTiro > 4.5) return true;                                                // desde acá no hay tiro al lugar conocido
    }
    return false;
  }
  /* Fuego y movimiento: uno se mueve si otro está tirando (o si hace rato que nadie ve al jugador).
     No se mueven todos a la vez. */
  function pedirPermiso(s) {
    const e = s.esc;
    if (e.mueve && e.mueve !== s) { if (e.mueve.vivo && enMovimiento(e.mueve) && ahora - e.tMueve < 9) return false; e.mueve = null; }
    let cubre = null;
    for (let i = 0; i < e.soldados.length; i++) { const m = e.soldados[i]; if (m !== s && m.vivo && m.activo && ahora - m.tDisparo < 1) { cubre = m; break; } }
    if (!cubre && ahora - red.tVisto < T.moverSinVer) {
      if (!s.pidioT || ahora - s.pidioT > 6) s.pidioT = ahora;
      if (ahora - s.pidioT < 3) {                                                       // pide fuego de cobertura y espera
        for (let i = 0; i < e.soldados.length; i++) { const m = e.soldados[i]; if (m !== s && m.vivo && m.activo && m.estado === 'cubierto' && m.cob && m.cob.tiro && m.balas > 3 && m.rol !== 'tirador') { m.tSal = 0; m.cubreHasta = ahora + 4; break; } }
        return false;
      }
    }
    e.mueve = s; e.tMueve = ahora; s.pidioT = 0; s.moverPor = null;
    if (cubre) { cubre.cubreHasta = ahora + 3.5; if (decir(s, 'muevo')) dialogos.push({ t: ahora + 1.25, e, quien: cubre, clave: 'tecubro', f: null }); }
    return true;
  }
  /* asomado en su puesto de tiro: gatillo() tira; acá se decide cuándo volver */
  function enAsomado(s, u) {
    const c = s.cob; if (!c || !c.tiro) { ponerEstado(s, 'cubierto'); return; }
    const t = c.tiro; s.post = t.post; s.miraFija = true;
    const enLugar = hyp(t.x - s.x, t.z - s.z) < 0.35;
    s.enTiro = enLugar && Math.abs(s.agach - (t.post === 1 ? 1 : 0)) < 0.25;
    if (!enLugar && s.llego && !s.esperaCamino) irA(s, t.x, t.z, 2.6, null);
    if (s.supr > T.suprEsconde) {                                                       // lo tienen clavado: se esconde y pierde la puntería
      s.escondeT = entre(T.suprTMin, T.suprTMax); s.raf = 0; if (ahora - s.tSuprDijo > 6) { decir(s, 'suprimido'); s.tSuprDijo = ahora; }
      volverACubierto(s); return;
    }
    /* ¿desde acá hay tiro al lugar conocido? (para decidir si conviene cambiar de posición) */
    if (s.enTiro && ahora - (s.tChkTiro || 0) > 0.5) {
      s.tChkTiro = ahora; const o = origenLibre(u.x, u.z);
      if (s.ve || lineaVista(s.x, s.y + ojoDe(s), s.z, o.x, 1.1, o.z)) s.tSinTiro = 0; else s.tSinTiro += 0.5;
    }
    if (s.raf > 0) return;                                                              // no corta una ráfaga
    if (s.balas <= 0 || ahora - s.tEst > s.tVentana) { volverACubierto(s); return; }
    if (!s.ve && !debeSuprimir(s) && ahora - s.tEst > 0.9) { volverACubierto(s); s.tSal += 0.6; }
  }
  function volverACubierto(s) {
    const c = s.cob; s.enTiro = false; ponerEstado(s, 'volver');
    if (c) irA(s, c.x, c.z, 2.8, null);
  }
  function enVolver(s) {
    const c = s.cob; if (!c) { reaccionar(s); return; }
    s.enTiro = false; s.miraFija = true; s.post = c.tipo === 'alta' ? 0 : 1;
    if ((s.llego && !s.esperaCamino) || hyp(c.x - s.x, c.z - s.z) < 0.3) { ponerEstado(s, 'cubierto'); s.tSal = ahora + entre(T.cubiertoMin, T.cubiertoMax) + Math.max(0, s.escondeT); }
  }
  /* cuerpo a tierra en descampado: o no hay cobertura, o lo clavaron corriendo */
  function enTierra(s, u) {
    s.post = 2; s.miraFija = true; s.enTiro = true;
    if (s.pinned) {
      if (s.supr < 0.3 && ahora - s.tEst > 0.8) { s.pinned = false; if (s.cob) { ponerEstado(s, 'a_cubierto'); s.post = 0; irA(s, s.cob.x, s.cob.z, T.velCorrer, s.caminoOp); } else reaccionar(s); }
      return;
    }
    if (ahora - (s.sinCob || 0) > 3 && !s.esperaCob) { s.sinCob = ahora; pedirCobertura(s); }
  }
  /* órdenes del cerebro: se toman cuando el soldado está en condiciones */
  function tomarOrden(s, u) {
    const o = s.orden, e = s.esc;
    if (ahora - o.t > 4) { s.orden = null; return; }
    const quieto = s.estado === 'cubierto' || s.estado === 'asomado' || s.estado === 'volver' || s.estado === 'tierra' || s.estado === 'alerta';
    if (o.tipo === 'lanzar') {
      if (!quieto || s.raf > 0 || s.granadas <= 0 || s.recT >= 0) return;
      s.orden = null; parar(s); ponerEstado(s, 'lanzar'); s.enTiro = false; s.post = 0;
      s.lanza = { x: o.x, y: o.y, z: o.z, motivo: o.motivo, salio: false }; s.lanzaT = 0; s.gritoT = ahora;
      mirarA(s, o.x, o.y + 1, o.z); s.miraFija = true;
      decir(s, 'granada'); ENV.evento('granada_aviso', { s, x: o.x, z: o.z, motivo: o.motivo });
    } else if (o.tipo === 'radio') {
      if (s.estado !== 'cubierto' && !(s.estado === 'tierra' && !s.pinned)) return;
      s.orden = null; ponerEstado(s, 'radio'); s.tRadio0 = ahora; s.enTiro = false; s.post = 1;
      e.tRadio = -99; decir(s, 'refuerzo_pide'); s.radioT = T.refuerzoPedir; ENV.evento('refuerzo', { fase: 'pide', s });
    } else if (o.tipo === 'flanquear') {
      if (!quieto || s.raf > 0) return;
      s.orden = null; s.tarea = 'flanquear'; s.cob = o.cob; s.tCob = ahora; s.enTiro = false; s.luz = false; s.post = 1;
      ponerEstado(s, 'flanquear'); s.camino = o.camino; s.ci = 0; s.llego = false; s.esperaCamino = false; s.vel = T.velAgach; s.dest = { x: o.cob.x, z: o.cob.z };
      s.caminoOp = { expo: true, agach: true }; e.mueve = null;
    } else if (o.tipo === 'empujar' || o.tipo === 'avanzar' || o.tipo === 'replegar') {
      if (!quieto || s.raf > 0) return;
      s.orden = null; s.tarea = o.tipo; if (o.tipo === 'replegar') s.replegado = true;
      if (!s.esperaCob) pedirCobertura(s);
    } else s.orden = null;
  }
  /* pidiendo refuerzo: 3 s a cubierto con la mano en la radio. Si lo hieren, se interrumpe (ver herir) */
  function pensarRadio(s) {
    s.enTiro = false; s.post = 1; s.radioT = 1;
    if (ahora - s.tRadio0 >= T.refuerzoPedir) {
      red.refPedido = true; red.refEn = ahora + T.refuerzoLlega; ENV.evento('refuerzo', { fase: 'pedido', s, llega: red.refEn });
      const r = red.refuerzo; if (r) dialogos.push({ t: ahora + 1.3, e: r, quien: r.soldados[0], clave: 'refuerzo_va', f: null, forzar: true });
      ponerEstado(s, s.cob ? 'cubierto' : 'alerta'); s.tSal = ahora + 0.5;
    }
  }
  /* el tirador: en su puesto, cuerpo a tierra. El ciclo del láser está en tickTirador() */
  function pensarTirador(s, u) {
    const e = s.esc; s.luz = false; s.miraFija = true; s.tarea = 'tirador';
    const d = hyp(u.x - s.x, u.z - s.z), fresco = ahora - red.tSenal < 3 && u.err < 4;
    if (s.elev) {
      s.post = 2; s.enTiro = true; ponerEstado(s, 'tierra'); s.pinned = false;
      if (!s.dijoListo) { s.dijoListo = true; if (decir(s, 'tirador_listo')) s.tirDijo = ahora; }
      /* lo flanquearon: el jugador está casi debajo o detrás de su sector. Se levanta (tarda) y se reubica */
      const fuera = Math.abs(angN(rumboA(s, u.x, u.z) - e.nido.rumbo)) > 1.9;
      if (fresco && (d < 9 || (fuera && d < 35))) { decir(s, 'flanqueado'); bajarDelNido(s); ponerEstado(s, 'alerta'); }
      return;
    }
    if (enMovimiento(s)) { enCamino(s, u); return; }
    if (s.estado !== 'tierra') { reaccionar(s); return; }
    const c = s.cob; s.post = c ? c.tiro.post : 2; s.enTiro = true;
    if (s.recT >= 0) return;
    if (s.pinned) { if (s.supr < 0.3) s.pinned = false; return; }
    /* reubicarse: sin puesto, con el jugador encima, o sin línea al lugar conocido hace rato */
    if (ahora - (s.tChkTiro || 0) > 0.5) { s.tChkTiro = ahora; const o = origenLibre(u.x, u.z); if (s.ve || lineaVista(s.x, s.y + ojoDe(s), s.z, o.x, 1.1, o.z)) s.tSinTiro = 0; else s.tSinTiro += 0.5; }
    const mal = !c ? ahora - (s.sinCob || 0) > 3 : ((fresco && d < 10) || s.tSinTiro > 6) && ahora - s.tCob > 5;
    if (mal && !s.esperaCob && s.tir === 'espera') { s.sinCob = ahora; s.tSinTiro = 0; pedirCobertura(s); }
  }

  /* ====================================================================================================
     BÚSQUEDA: perdieron al jugador. Barren el último lugar conocido y las coberturas de alrededor.
     ==================================================================================================== */
  function pensarBusqueda(s) {
    const e = s.esc, q = e.busq;
    s.apObj = true; s.enTiro = false; s.cob = null; s.miraFija = false;
    if (s.rol === 'tirador') {                                                          // el tirador cubre desde su puesto
      ponerEstado(s, 'alerta'); s.luz = false; s.post = (s.elev || s.tierra > 0.5) ? 2 : 1; s.miraFija = true;
      if (red.uc) s.miraObj = rumboA(s, red.uc.x, red.uc.z) + Math.sin(ahora * 0.5 + s.escaneo) * 0.5; return;
    }
    ponerEstado(s, 'buscar'); s.luz = true; s.post = 0;
    if (!q || !q.puntos) { if (s.camino) parar(s); return; }
    if (s.espera > ahora) { s.miraObj = s.rondaYaw + Math.sin((ahora - s.tEsp0) * 2.2) * 1.4; s.miraFija = true; return; }
    if (s.bi >= 0 && s.llego && !s.esperaCamino) { q.puntos[s.bi].visto = true; s.bi = -1; s.espera = ahora + 1.5; s.tEsp0 = ahora; s.rondaYaw = s.miraYaw; return; }
    if (s.bi < 0) {
      let b = -1, bd = 1e9;
      for (let i = 0; i < q.puntos.length; i++) { const p = q.puntos[i]; if (p.visto || p.n >= 2) continue; const d = hyp(p.x - s.x, p.z - s.z) + (p.n ? 6 : 0); if (d < bd) { bd = d; b = i; } }
      if (b < 0) { q.listo = true; if (s.camino) parar(s); s.miraObj = red.uc ? rumboA(s, red.uc.x, red.uc.z) + Math.sin(ahora + s.escaneo) : s.miraObj; return; }
      const p = q.puntos[b]; s.bi = b; p.n++;
      let x = p.x, z = p.z;
      if (p.n > 1) { const l = hyp(s.x - x, s.z - z) || 1, k = libreCerca(x + (s.x - x) / l * 3.5, z + (s.z - z) / l * 3.5, 2); if (k >= 0) { x = cX(k); z = cZ(k); } }   // el segundo se queda 3,5 m atrás, cubriendo
      irA(s, x, z, T.velAgach, null); s.miraObj = null;
    }
  }

