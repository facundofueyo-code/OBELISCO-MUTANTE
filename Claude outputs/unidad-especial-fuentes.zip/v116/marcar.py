#!/usr/bin/env python3
"""marcar.py entrada.html salida.html [vista.txt]

Pone en el juego los cambios de la base de trabajo de la unidad especial: los 17
marcadores /*UE:…*/ y <!--UE:…-->, el objeto `const UEB={…}` y la llamada
UEB.ruido(…) en fire(). Son exactamente los cambios entre game-1.14.0.html y
base.html (sacados con difflib por líneas, mirando solo el tramo que cambia).

Cada cambio es (nombre, antes, nuevo, después): `antes+después` tiene que aparecer
UNA sola vez en la entrada y queda `antes+nuevo+después`. Si no aparece, aparece más
de una vez o `nuevo` ya está en el archivo, el script corta con error y no escribe nada.

Comprobado: marcar.py game-1.14.0.html → idéntico byte a byte a base.html (1.14.0),
y aplica sin adaptar ninguna ancla sobre la 1.16.0 (ver INDICE.md).
Con un tercer argumento escribe también la vista (líneas de más de 5000 caracteres
recortadas a 200, mismos números de línea).
"""
import sys

UEB_BLOCK = (
    "/* UE · enlace entre los módulos de la unidad especial. Cada módulo pisa lo que implementa; por defecto no hacen nada. */\n"
    "const UEB={\n"
    "  objetivos:()=>[],                 /* soldados vivos como blancos de los bichos: [{x,z,y,r,vivo,herir(daño,bicho)}] */\n"
    "  explosion:(pos,radio,dano,de)=>{},/* avisar toda explosión (granada, auto): la IA le aplica daño a los soldados y la escucha */\n"
    "  ruido:(pos,tipo,fuerza)=>{},      /* ruidos del jugador: 'disparo' | 'pasos' | 'recarga' | 'impacto' */\n"
    "  botin:(x,z,rol)=>{},              /* al morir un soldado: soltar fusil, munición, granadas o botiquín */\n"
    "  estado:()=>({alerta:0,ang:0,combate:false,vivos:0}), /* para el HUD: cuánto te están viendo y desde dónde */\n"
    "  debug:()=>null                    /* para la vista táctica (F2) */\n"
    "};\n"
)

# (nombre, antes, nuevo, después) — en el orden del archivo
CAMBIOS = [
    ('css',      "\n",                                                        "/*UE:css*/\n",            "</style>"),
    ('hud',      "  </div>\n",                                                "  <!--UE:hud-->\n",       "</div>\n<div id=\"cross\""),
    ('capas',    "</div>\n",                                                  "<!--UE:capas-->\n",       "<div id=\"cross\""),
    ('ayuda',    "juntá las cajas que tiran los bichos</dd>\n",               "      <!--UE:ayuda-->\n", "    </dl>"),
    ('inicio',   "id=\"btnStart\" type=\"button\">Bajar a la 9 de Julio</button>\n", "    <!--UE:inicio-->\n", "    <p class=\"best\" id=\"bestTxt\">"),
    ('UEB',      "\nconst V3=THREE.Vector3;\n",                               UEB_BLOCK,                 "/* registro de materiales"),
    ('ruido',    "camAxes();camera.getWorldPosition(ray.o);SHJ.notice(ray.o,fwdV);", "UEB.ruido(ray.o,'disparo',w.id==='escopeta'?1.3:1);", "\n"),
    ('rayo-jugador', "\n",                                                    "    /*UE:rayo-jugador*/\n", "    {const ch=rayCars(ray.o,d,Math.min(wall,range));"),
    ('reset',    "  $('#bossbar').hidden=true;hudAmmo();hudHP();hudScore();hudWave();", "/*UE:reset*/", "\n"),
    ('warm-on',  "  try{SHJ.warm(true);}catch(e){}",                         "/*UE:warm-on*/",          "\n"),
    ('warm-off', "  try{SHJ.warm(false);}catch(e){}",                        "/*UE:warm-off*/",         "vm.visible=vmv;"),
    ('start',    ";$('#cross').hidden=false;$('#touch').hidden=!isTouch;vm.visible=true;", "/*UE:start*/", "\n"),
    ('fin',      "function gameOver(){",                                      "/*UE:fin*/",              "\n"),
    ('pausa',    "function setPaused(v){paused=v;",                           "/*UE:pausa*/",            "MOV.quiet();"),
    ('teclas',   "  if(e.code==='KeyF'&&running&&!e.repeat)toggleTorch();\n", "  /*UE:teclas*/\n",       "  if((e.code==='ShiftLeft'"),
    ('modulos',  "\n",                                                        "/*UE:modulos*/\n",        "/* ---------- loop ---------- */"),
    ('brujula',  "\n",                                                        "  /*UE:brujula*/\n",      "  return L;}"),
    ('update',   "SHJ.update(dt);updateProjs(dt);updatePickups(dt);",        "/*UE:update*/",           "}"),
    ('fx',       "updateDecals(dt);updateDebris(dt);updateSmoke(dt);updateSparks(dt);", "/*UE:fx*/",   "}"),
]

MARCADORES = ['/*UE:css*/', '<!--UE:hud-->', '<!--UE:capas-->', '<!--UE:ayuda-->', '<!--UE:inicio-->',
              '/*UE:modulos*/', '/*UE:update*/', '/*UE:fx*/', '/*UE:reset*/', '/*UE:start*/', '/*UE:fin*/',
              '/*UE:pausa*/', '/*UE:teclas*/', '/*UE:warm-on*/', '/*UE:warm-off*/', '/*UE:brujula*/',
              '/*UE:rayo-jugador*/']


def marcar(src):
    for nombre, antes, nuevo, despues in CAMBIOS:
        clave = nuevo.strip()
        if clave in src:
            raise SystemExit(f'ERROR [{nombre}]: el archivo ya tiene {clave[:60]!r}')
        ancla = antes + despues
        n = src.count(ancla)
        if n != 1:
            raise SystemExit(f'ERROR [{nombre}]: el ancla aparece {n} veces (tiene que ser 1): {ancla[:120]!r}')
        src = src.replace(ancla, antes + nuevo + despues)
    # control final: cada marcador, UEB y la llamada a UEB.ruido, una sola vez
    for m in MARCADORES + ['const UEB={', 'UEB.ruido(ray.o,']:
        if src.count(m) != 1:
            raise SystemExit(f'ERROR: {m!r} quedó {src.count(m)} veces')
    return src


def vista(src, largo=5000, corte=200):
    return '\n'.join(l if len(l) <= largo else l[:corte] + ' /*…línea larga recortada…*/' for l in src.split('\n'))


if __name__ == '__main__':
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    ent = open(sys.argv[1], encoding='utf8', newline='').read()
    sal = marcar(ent)
    open(sys.argv[2], 'w', encoding='utf8', newline='').write(sal)
    if len(sys.argv) > 3:
        open(sys.argv[3], 'w', encoding='utf8', newline='').write(vista(sal))
    print(f'ok: {len(CAMBIOS)} cambios, {len(MARCADORES)} marcadores; {len(ent)} → {len(sal)} caracteres')
