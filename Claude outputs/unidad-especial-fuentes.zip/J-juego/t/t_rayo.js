// Micro-medición de ENV.rayo por partes (paredes, cajas, autos) en el retén.
const H=require('../../harness.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
(async()=>{const h=await H.open(F);
  try{await h.start();await h.ev("RETEN.ir({bichos:false});1");await h.step(.5);
    console.log(JSON.stringify(await h.ev(`(()=>{const o=new V3(),d=new V3();let s=12345;const r=()=>{s=(s*16807)%2147483647;return s/2147483647;};
      const N=2000,P=[];for(let i=0;i<N;i++){const ox=-445+r()*60,oz=598+r()*20,a=r()*6.283,dx=Math.sin(a),dz=Math.cos(a),dy=(r()-.5)*.1,l=Math.hypot(dx,dy,dz);P.push([ox,1+r(),oz,dx/l,dy/l,dz/l,5+r()*60]);}
      const t=f=>{const t0=performance.now();for(const p of P)f(p);return +((performance.now()-t0)/N*1000).toFixed(1);};
      const res={obst:obstacles.length,cars:VCARS.length};
      res.paredes=t(p=>{o.set(p[0],p[1],p[2]);d.set(p[3],p[4],p[5]);rayWalls(o,d,p[6]);});
      res.autos=t(p=>{o.set(p[0],p[1],p[2]);d.set(p[3],p[4],p[5]);rayCars(o,d,p[6]);});
      res.cajasViejo=t(p=>{o.set(p[0],p[1],p[2]);d.set(p[3],p[4],p[5]);let w=Infinity;for(const b of obstacles){if(b.glass)continue;const tt=rayBox(o,d,b);if(tt<w)w=tt;}});
      res.envRayo=t(p=>UEG.ENV.rayo(p[0],p[1],p[2],p[3],p[4],p[5],p[6]));
      res.autosNuevo=t(p=>{UEG.ENV.rayo(p[0],p[1],p[2],p[3],p[4],p[5],p[6]);});res.cmp=(()=>{let dif=0;for(const p of P){o.set(p[0],p[1],p[2]);d.set(p[3],p[4],p[5]);const a=rayCars(o,d,p[6]);const t1=UEG.ENV.rayo(p[0],p[1],p[2],p[3],p[4],p[5],p[6]);const R=UEG.RZ;const b=R.que==="auto"?R.car:null;if(a&&R.que!=="auto"&&a.t<R.t-1e-6)dif++;if(a&&b&&a.car!==b)dif++;}return dif;})();res.envRayoLargo=t(p=>UEG.ENV.rayo(p[0],p[1],p[2],p[3],p[4],p[5],400));
      return res;})()`)));
  }catch(e){console.log('EXC',e.message.slice(0,400));}
  console.log('errores',JSON.stringify(h.errors.slice(0,5)));await h.close();})();
