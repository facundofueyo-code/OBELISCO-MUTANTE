/* ====================================================================================
   UEM · UNIDAD ESPECIAL · modelo, armas y animación de los soldados (Three.js r128)
   ------------------------------------------------------------------------------------
   Todo hecho por código: una SkinnedMesh por soldado (cuerpo + equipo + arma, color por
   vértice, un solo material) y una segunda malla aditiva para lo que brilla (linterna,
   láser, fogonazo, luz de la nuca). Ninguna luz real de Three.js.
   Modelo mirando a +Z, pies en y=0. El lado izquierdo del soldado es +X.
   Contrato: UEM.ROLES · UEM.crear(rol,{semilla}) · UEM.granada() · UEM.calentar(scene,on)
   ==================================================================================== */
const UEM=(()=>{
const V3=THREE.Vector3,Q4=THREE.Quaternion,M4=THREE.Matrix4;
const PI=Math.PI,TAU=PI*2,RAD=PI/180;
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
const sat=x=>x<0?0:x>1?1:x;
const sst=(a,b,x)=>{const t=sat((x-a)/(b-a));return t*t*(3-2*t);};   /* escalón suave */
const ease=t=>t*t*(3-2*t);
const envol=a=>{a=(a+PI)%TAU;if(a<0)a+=TAU;return a-PI;};              /* ángulo a -PI…PI */
/* azar con semilla (el modelo se arma igual en cada carga; cada soldado varía según su semilla) */
function azarDe(s){s=(s>>>0)||1;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}

/* ---------- roles ---------- */
const ROLES={
  jefe:     {nombre:'Jefe',     arma:'fusil',   desc:'Antena larga de radio en la espalda y micrófono. Se queda atrás de la base de fuego y da las órdenes con señas.'},
  asalto:   {nombre:'Asalto',   arma:'escopeta',desc:'Más liviano: sin mochila, canana de cartuchos cruzada y hombreras. Flanquea y empuja de cerca.'},
  granadero:{nombre:'Granadero',arma:'fusil',   desc:'Portagranadas en el pecho y morral al costado. Te saca de la cobertura con granadas.'},
  tirador:  {nombre:'Tirador',  arma:'tirador', desc:'Velo de tela sobre el casco y los hombros, fusil largo con mira, bípode y supresor. Láser rojo antes de cada tiro.'}
};

/* ---------- paleta: color (lineal, como el resto del juego) + aspereza + metal + emisión ----------
   La tela es negra mate; el equipo, gris carbón apenas más claro para que el volumen se lea de noche. */
const PAL={
  tela:   [0x16171b,.96,0,0],   /* uniforme */
  tela2:  [0x1b1c21,.94,0,0],   /* refuerzos, bolsillos */
  equipo: [0x2a2c31,.86,0,0],   /* chaleco, portacargadores, correaje */
  equipo2:[0x34363b,.84,0,0],   /* tapas, hebillas de plástico, bordes */
  velcro: [0x43454a,.98,0,0],   /* velcro vacío: donde iría un parche */
  casco:  [0x1d1e22,.72,.05,0],
  goma:   [0x101114,.48,.0,0],  /* máscara */
  goma2:  [0x191a1e,.55,.0,0],
  metal:  [0x26272a,.42,.75,0], /* hebillas, rieles, filtro */
  arma:   [0x17181a,.50,.55,0], /* acero pavonado */
  poli:   [0x1a1b1d,.66,.05,0], /* polímero del arma */
  cuero:  [0x121214,.58,0,0],   /* borcegos */
  suela:  [0x0b0b0c,.9,0,0],
  guante: [0x18191c,.8,0,0],
  rodilla:[0x232428,.6,.05,0],  /* rodilleras y coderas: plástico duro */
  lente:  [0x16283a,.04,.0,1.1],/* lentes de la máscara: vidrio oscuro con brillo frío tenue (emisivo, no ilumina nada) */
  lente2: [0x30404c,.10,.0,.25],
  vidrio: [0x1a2630,.08,.2,.10],/* ópticas del arma */
  led:    [0xff2010,.4,0,3.2],  /* luz roja de la nuca */
  laton:  [0x8a6a2c,.38,.85,0], /* vainas y culotes */
  cart:   [0x3a1210,.6,0,0],    /* cartuchos de escopeta */
  foco:   [0xd8e4f0,.2,0,.9],   /* lente de la linterna */
  velo:   [0x1e1e20,.98,0,0],   /* velo del tirador: tela opaca, apenas más clara */
  granada:[0x1c1f17,.6,.1,0],   /* granada: verde oliva casi negro */
  /* efectos (malla aditiva): [color, modo, exponente, -]. modo 0 plano, 1 volumen de borde suave, 2 resplandor de frente */
  fxHaz:  [0xfff1d6,1,1.6,0],
  fxNucleo:[0xfff4e0,1,2.4,0],
  fxDeslumbre:[0xfff6ea,2,7,0],
  fxHalo: [0xfff1d6,2,2.5,0],
  fxFogonazo:[0xffc070,0,1,0],
  fxFogoFrente:[0xffd890,2,1.5,0],
  fxLaser:[0xff1a0a,1,1,0],
  fxLaserHalo:[0xff2010,1,2.5,0],
  fxPunto:[0xff3020,0,1,0],
  fxLed:  [0xff2a10,0,1,0],
  fxLente:[0x9fc4ff,2,2.2,0]
};
