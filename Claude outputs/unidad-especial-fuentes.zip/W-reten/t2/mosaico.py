# Junta varias capturas en una sola imagen con su nombre. Uso: python3 mosaico.py salida.png columnas a.png b.png ...
import sys
from PIL import Image, ImageDraw
out, cols, fs = sys.argv[1], int(sys.argv[2]), sys.argv[3:]
ims = [Image.open(f).convert('RGB') for f in fs]
w, h = ims[0].size
rows = (len(ims) + cols - 1) // cols
M = Image.new('RGB', (w * cols, h * rows), (20, 20, 20))
for i, (im, f) in enumerate(zip(ims, fs)):
    x, y = (i % cols) * w, (i // cols) * h
    M.paste(im, (x, y))
    d = ImageDraw.Draw(M)
    d.rectangle([x, y, x + 260, y + 22], fill=(0, 0, 0))
    d.text((x + 6, y + 5), f.split('/')[-1], fill=(255, 255, 0))
M.save(out)
