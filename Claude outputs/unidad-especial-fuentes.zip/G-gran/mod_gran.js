/* ====================================================================================
   GRAN · granadas de mano (v1.17.0)
   Las tiran los soldados (que avisan antes) y, más adelante, el jugador.
   La física corre con paso fijo de 1/60 s y es la misma que usa arco() para calcular el tiro:
   lo que arco() dice que queda en un lugar al explotar, queda ahí (mientras el mundo no cambie
   en el medio: un auto que explota, un vidrio que se rompe).
   Contrato:
     GRAN.lanzar({pos,vel,mecha,de,tipo}) → g, o null si ya hay 8 vivas (pos y vel se copian)
     GRAN.lista   granadas vivas: [{p,v,t,de,tipo}] (siempre el mismo arreglo; t = segundos que faltan)
     GRAN.arco(desde,hasta,{vmax,mecha,tol}) → {vel,ok,t,err,fin,ang}
     GRAN.update(dt) en el marcador UE:update · GRAN.fx(dt) en UE:fx (la explosión se sigue viendo si el jugador muere)
     GRAN.reset() en UE:reset · GRAN.G (gravedad) · GRAN.TUNE (los números de abajo)
   Sin luces reales: la luz que parpadea y el fogonazo son sprites aditivos. Todo se crea al cargar.
   ==================================================================================== */
const GRAN=(()=>{
  /* ---------- números para ajustar: todos juntos ---------- */
  const TUNE={
    /* física */
    G:9.8,           // gravedad (m/s²): la real. Con la mano a 17 m/s llega a unos 30 m tirando a 45°, y el vuelo (1,5–2,5 s) se alcanza a ver
    R:.036,          // radio de choque (m): el cuerpo de la granada mide unos 7 cm
    eSuelo:.3,       // rebote contra el piso (0 nada · 1 todo)
    frSuelo:.55,     // parte de la velocidad horizontal que le queda en cada pique
    vReb:1.2,        // con menos velocidad de caída que esta (m/s) ya no pica: rueda
    rodar:5,         // freno al rodar (m/s²)
    eMuro:.35,       // rebote contra paredes, autos, cordones, postes y obstáculos
    frMuro:.7,       // parte de la velocidad de costado que conserva al pegar contra algo
    escalon:.06,     // si el terreno sube de golpe más que esto por encima de la base de la granada, es un escalón (el cordón mide 15 cm): rebota como en una pared
    altoPoste:4,     // altura (m) que se les da a postes, árboles y columnas que no la tienen cargada (los árboles no tienen copa)
    mecha:3,         // mecha por omisión (s)
    /* explosión */
    radio:7,         // radio (m)
    dano:80,         // daño en el centro; baja en línea recta hasta 0 en el borde
    cobertura:.3,    // parte del daño (y del empujón) que pasa si hay algo sólido entre la granada y el blanco
    xBichos:1,       // los bichos reciben el daño multiplicado por esto (la explosión de un auto les hace 160 en el centro)
    empuje:7,        // empujón horizontal al jugador en el centro (m/s); baja con la distancia igual que el daño
    empujeY:2.5,     // y hacia arriba (m/s), si está parado en el piso
    sacudida:.75,    // sacudida de cámara al lado (la de un auto llega a 1); se apaga a los 30 m
    autoR:4.5,       // los autos con la carrocería a menos de esto (m) reciben golpes…
    autoGolpes:20,   // …hasta esta cantidad si está pegada (carDamage: a los 12 humean, a los 20 se prenden y explotan)
    /* arco() */
    vmax:17,         // velocidad máxima de la mano (m/s)
    tol:1,           // error máximo (m) entre donde queda al explotar y el blanco para dar el tiro por bueno
    /* sonido: volumen (0…1) y distancia (m) a la que deja de oírse */
    volBip:.9, oirBip:35,
    volBoom:1, oirBoom:140,
    volPique:.8, oirPique:25,
    /* pitido y luz: intervalo entre pitidos (s) recién lanzada y al final de la mecha */
    bipLento:1, bipRapido:.1,
    luz:.25, luzPico:.8,   // tamaño (m) de la luz roja entre pitidos y en cada pitido
    luzPiso:1.5            // tamaño (m) de su reflejo en el piso en cada pitido
  };
  const H=1/60,R=TUNE.R,NMAX=8,LOC=12;   // paso fijo de la física · radio · fondo común · medio lado (m) de la zona de cosas cercanas de cada granada
  const lista=[],todas=[];
  const N={x:0,y:1,z:0,m:0};              // normal del último choque y material (0 piedra · 1 chapa · 2 vidrio)
  const D2R=Math.PI/180,cl=(v,a,b)=>v<a?a:v>b?b:v;

  /* ================= el mundo: qué frena a una granada =================
     Paredes de los edificios (WALLS_ALL, con su altura), postes y árboles (círculos), obstáculos (cajas),
     autos (la planta como rectángulo y el perfil de la carrocería como techo) y el piso (floorAt, con el cordón).
     Para no recorrer los ~1300 autos y todos los obstáculos en cada paso, cada granada lleva la lista de los que
     tiene cerca (y el coseno y seno del giro de cada auto). */
  const mkLoc=()=>({ob:[],ca:[],cc:[],cs:[]});
  function locArmar(L,x0,z0,x1,z1){L.ob.length=0;L.ca.length=0;L.cc.length=0;L.cs.length=0;
    for(const b of obstacles){if(b.x1<x0||b.x0>x1||b.z1<z0||b.z0>z1)continue;L.ob.push(b);}
    for(const c of VCARS){if(c.st>=3)continue;const r=c.L*.5+.5;if(c.x+r<x0||c.x-r>x1||c.z+r<z0||c.z-r>z1)continue;
      L.ca.push(c);L.cc.push(Math.cos(c.a));L.cs.push(Math.sin(c.a));}}
  /* techo de un auto a lo largo (X hacia la trompa): el mismo perfil por el que camina el jugador; camiones y aplastados, una caja */
  const techo=(c,X)=>c.crushed?(c.by||0)+c.H*.4:(MOV.carOK(c)?MOV.carTop(c,X):(c.by||0)+c.H*.97);

  /* Primer choque del tramo o→o+d contra algo vertical (o el fondo de algo). La granada es una esfera de radio R:
     cada cosa se engorda R. Devuelve la fracción 0…1 del tramo (1 = nada) y deja la normal en N. */
  function choque(ox,oy,oz,dx,dy,dz,L){let best=1;const x1=ox+dx,z1=oz+dz;
    /* paredes: segmento engordado R; las que arrancan en el piso siguen hacia abajo (la calzada está a −0,15) */
    {const i0=Math.floor((Math.min(ox,x1)-R)/HC),i1=Math.floor((Math.max(ox,x1)+R)/HC),j0=Math.floor((Math.min(oz,z1)-R)/HC),j1=Math.floor((Math.max(oz,z1)+R)/HC);
     for(let i=i0;i<=i1;i++)for(let j=j0;j<=j1;j++){const a=allHash.get(hk(i,j));if(!a)continue;
       for(const idx of a){const w=WALLS_ALL[idx],ex=w[2]-w[0],ez=w[3]-w[1],l=Math.sqrt(ex*ex+ez*ez);if(l<1e-6)continue;
         const ux=ex/l,uz=ez/l;let nx=uz,nz=-ux,s0=(ox-w[0])*nx+(oz-w[1])*nz;if(s0<0){s0=-s0;nx=-nx;nz=-nz;}
         const ds=dx*nx+dz*nz;if(ds>=0||s0+ds>=R)continue;           // se aleja, va paralela o no llega
         let t=(s0-R)/-ds;if(t<0)t=0;if(t>=best)continue;
         const al=(ox+dx*t-w[0])*ux+(oz+dz*t-w[1])*uz;if(al<-R||al>l+R)continue;
         const y=oy+dy*t,yb=w[4]<=.01?-50:w[4];if(y+R<yb||y-R>w[5])continue;
         best=t;N.x=nx;N.y=0;N.z=nz;N.m=0;}}}
    /* postes, árboles, columnas y bolsas (los círculos de los autos no: el auto va como caja) */
    {const A=dx*dx+dz*dz;if(A>1e-12){const i0=Math.floor((Math.min(ox,x1)-1.5)/HC),i1=Math.floor((Math.max(ox,x1)+1.5)/HC),j0=Math.floor((Math.min(oz,z1)-1.5)/HC),j1=Math.floor((Math.max(oz,z1)+1.5)/HC);
     for(let i=i0;i<=i1;i++)for(let j=j0;j<=j1;j++){const cs=circHash.get(hk(i,j));if(!cs)continue;
       for(const c of cs){if(c.dead||(c.brk&&c.brk.k==='car'))continue;
         const rr=c.r+R,fx=ox-c.x,fz=oz-c.z,B=fx*dx+fz*dz;if(B>=0)continue;
         const C=fx*fx+fz*fz-rr*rr;let t;if(C<=0)t=0;else{const q=B*B-A*C;if(q<0)continue;t=(-B-Math.sqrt(q))/A;}
         if(t>=best)continue;
         const h=c.h===undefined?TUNE.altoPoste:c.low?Math.min(c.h,.7):c.h;if(oy+dy*t-R>=h)continue;
         const qx=fx+dx*t,qz=fz+dz*t,ql=Math.sqrt(qx*qx+qz*qz)||1;best=t;N.x=qx/ql;N.y=0;N.z=qz/ql;N.m=0;}}}}
    /* obstáculos: cajas. Entrar por la tapa no cuenta acá: eso lo resuelve el piso */
    for(const b of L.ob){if(b.gl&&b.gl.dead)continue;let t0=0,t1=best,ax=-1,sg=0;
      if(dx>-1e-12&&dx<1e-12){if(ox<b.x0-R||ox>b.x1+R)continue;}else{let ta=(b.x0-R-ox)/dx,tb=(b.x1+R-ox)/dx,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=0;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}
      {const y0=(b.y0||0)-R,y1=b.y1+R;if(dy>-1e-12&&dy<1e-12){if(oy<y0||oy>y1)continue;}else{let ta=(y0-oy)/dy,tb=(y1-oy)/dy,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=1;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}}
      if(dz>-1e-12&&dz<1e-12){if(oz<b.z0-R||oz>b.z1+R)continue;}else{let ta=(b.z0-R-oz)/dz,tb=(b.z1+R-oz)/dz,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=2;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}
      if(ax<0||(ax===1&&sg>0))continue;
      best=t0;N.x=ax===0?sg:0;N.y=ax===1?sg:0;N.z=ax===2?sg:0;N.m=b.gl?2:0;}
    /* autos: la planta como rectángulo (en el sistema del auto); si pasa más alto que la carrocería en ese punto, sigue de largo */
    for(let k=0;k<L.ca.length;k++){const c=L.ca[k];if(c.st>=3)continue;
      const ca=L.cc[k],sa=L.cs[k],rx=ox-c.x,rz=oz-c.z,lx=rx*ca-rz*sa,lz=rx*sa+rz*ca,ldx=dx*ca-dz*sa,ldz=dx*sa+dz*ca,hw=c.W/2+R,hl=c.L/2+R;
      let t0=0,t1=best,ax=-1,sg=0;
      if(ldx>-1e-12&&ldx<1e-12){if(lx<-hw||lx>hw)continue;}else{let ta=(-hw-lx)/ldx,tb=(hw-lx)/ldx,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=0;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}
      if(ldz>-1e-12&&ldz<1e-12){if(lz<-hl||lz>hl)continue;}else{let ta=(-hl-lz)/ldz,tb=(hl-lz)/ldz,s=-1;if(ta>tb){const q=ta;ta=tb;tb=q;s=1;}if(ta>t0){t0=ta;ax=1;sg=s;}if(tb<t1)t1=tb;if(t0>t1)continue;}
      if(ax<0)continue;
      const y=oy+dy*t0;if(y-R>=techo(c,cl(-(lz+ldz*t0),-c.L/2,c.L/2))-.02)continue;
      best=t0;const nlx=ax===0?sg:0,nlz=ax===1?sg:0;N.x=nlx*ca+nlz*sa;N.y=0;N.z=-nlx*sa+nlz*ca;N.m=1;}
    return best;}

  /* ---------- atajos exactos para arco() ----------
     arco() simula varios tiros por llamada y tiene que ser barata. Dos atajos que no cambian el resultado:
     · una grilla de 1 m de la zona del tiro marca dónde hay algo contra qué chocar (cada cosa engordada R+5 cm):
       si un paso no toca ninguna celda marcada, choque() no puede encontrar nada y no hace falta llamarlo;
     · la altura máxima a la que puede haber piso en la zona (terreno, andenes, tapas de obstáculos, techos de autos):
       mientras la granada va por encima, y no está sobre un edificio ni una escalinata, no puede tocar el piso.
     terreno() es floorAt() con la lista de andenes ya filtrada para la zona; si alguien cambia floorAt, se usa floorAt. */
  const FLOOR_SRC='function floorAt(x,z){let y=PISO.y(x,z);for(const f of floors)if(x>f.x0&&x<f.x1&&z>f.z0&&z<f.z1&&f.y>y)y=f.y;for(const fn of FLOORFN){const v=fn(x,z);if(v>0&&v>y)y=v;}return y;}';
  let floorIgual=null;
  function terreno(x,z,Z){
    if(floorIgual===null)floorIgual=String(floorAt)===FLOOR_SRC;
    if(!Z||!floorIgual||x<Z.x0||z<Z.z0||x>=Z.x0+Z.nx||z>=Z.z0+Z.nz)return floorAt(x,z);
    let y=PISO.y(x,z);for(const f of Z.fl)if(x>f.x0&&x<f.x1&&z>f.z0&&z<f.z1&&f.y>y)y=f.y;
    for(const fn of FLOORFN){const v=fn(x,z);if(v>0&&v>y)y=v;}return y;}
  /* zona: grilla de celdas de 1 m. c: 1 si hay algo contra qué chocar · top: altura máxima a la que puede haber piso en la celda */
  const mkZona=()=>({x0:0,z0:0,nx:0,nz:0,c:new Uint8Array(4096),top:new Float32Array(4096),fl:[],T:-1e9,X0:0,Z0:0,X1:0,Z1:0});
  const _vistas=new Set();
  function zonaArmar(Z,L,x0,z0,x1,z1){Z.x0=Math.floor(x0);Z.z0=Math.floor(z0);Z.nx=Math.ceil(x1)-Z.x0;Z.nz=Math.ceil(z1)-Z.z0;
    const n=Z.nx*Z.nz;if(Z.c.length<n){Z.c=new Uint8Array(n*2);Z.top=new Float32Array(n*2);}
    const c=Z.c,tp=Z.top,m=R+.05;c.fill(0,0,n);tp.fill(.1,0,n);   // PISO.y: vereda 0, calzada −0,15 y vados en el medio (nunca más de 0)
    /* marca las celdas que toca la caja (engordada m); con alto, sube el techo de esas celdas */
    const marca=(ax,az,bx,bz,alto)=>{let i0=Math.floor(ax-m)-Z.x0,i1=Math.floor(bx+m)-Z.x0,j0=Math.floor(az-m)-Z.z0,j1=Math.floor(bz+m)-Z.z0;
      if(i1<0||j1<0||i0>=Z.nx||j0>=Z.nz)return;if(i0<0)i0=0;if(j0<0)j0=0;if(i1>=Z.nx)i1=Z.nx-1;if(j1>=Z.nz)j1=Z.nz-1;
      for(let j=j0;j<=j1;j++){const o=j*Z.nx;for(let i=i0;i<=i1;i++){if(alto!==undefined){if(alto>tp[o+i])tp[o+i]=alto;}else c[o+i]=1;}}};
    /* paredes: solo el pedazo que cae en la zona, de a tramos de 0,5 m (una fachada en diagonal no marca toda su caja) */
    const ex0=x0-1,ez0=z0-1,ex1=x1+1,ez1=z1+1;_vistas.clear();
    for(let i=Math.floor(ex0/HC);i<=Math.floor(ex1/HC);i++)for(let j=Math.floor(ez0/HC);j<=Math.floor(ez1/HC);j++){const a=allHash.get(hk(i,j));if(!a)continue;
      for(const idx of a){if(_vistas.has(idx))continue;_vistas.add(idx);const w=WALLS_ALL[idx],dx=w[2]-w[0],dz=w[3]-w[1];let ta=0,tb=1;
        if(Math.abs(dx)<1e-9){if(w[0]<ex0||w[0]>ex1)continue;}else{let u=(ex0-w[0])/dx,v=(ex1-w[0])/dx;if(u>v){const q=u;u=v;v=q;}if(u>ta)ta=u;if(v<tb)tb=v;}
        if(Math.abs(dz)<1e-9){if(w[1]<ez0||w[1]>ez1)continue;}else{let u=(ez0-w[1])/dz,v=(ez1-w[1])/dz;if(u>v){const q=u;u=v;v=q;}if(u>ta)ta=u;if(v<tb)tb=v;}
        if(ta>tb)continue;const k=Math.max(1,Math.ceil(Math.sqrt(dx*dx+dz*dz)*(tb-ta)/.5));
        for(let q=0;q<k;q++){const t0=ta+(tb-ta)*q/k,t1=ta+(tb-ta)*(q+1)/k,ax=w[0]+dx*t0,az=w[1]+dz*t0,bx=w[0]+dx*t1,bz=w[1]+dz*t1;
          marca(ax<bx?ax:bx,az<bz?az:bz,ax<bx?bx:ax,az<bz?bz:az);}}}
    /* postes, árboles, columnas y bolsas */
    for(let i=Math.floor((x0-2)/HC);i<=Math.floor((x1+2)/HC);i++)for(let j=Math.floor((z0-2)/HC);j<=Math.floor((z1+2)/HC);j++){const cs=circHash.get(hk(i,j));if(!cs)continue;
      for(const q of cs){if(q.dead||(q.brk&&q.brk.k==='car'))continue;marca(q.x-q.r,q.z-q.r,q.x+q.r,q.z+q.r);}}
    /* obstáculos y autos: chocan y además pueden ser piso (tapa, carrocería) */
    for(const b of L.ob){marca(b.x0,b.z0,b.x1,b.z1);if(!b.gl)marca(b.x0,b.z0,b.x1,b.z1,b.y1);}
    for(let k=0;k<L.ca.length;k++){const q=L.ca[k],ca=Math.abs(L.cc[k]),sa=Math.abs(L.cs[k]),hx=ca*q.W/2+sa*q.L/2,hz=sa*q.W/2+ca*q.L/2;
      marca(q.x-hx,q.z-hz,q.x+hx,q.z+hz);marca(q.x-hx,q.z-hz,q.x+hx,q.z+hz,(q.by||0)+q.H+.3);}
    /* andenes y escalinatas de floors: los que tocan la zona (terreno() usa esta lista) */
    Z.fl.length=0;for(const f of floors){if(f.x1<Z.x0||f.x0>Z.x0+Z.nx||f.z1<Z.z0||f.z0>Z.z0+Z.nz)continue;Z.fl.push(f);marca(f.x0,f.z0,f.x1,f.z1,f.y);}
    Z.X0=x0;Z.Z0=z0;Z.X1=x1;Z.Z1=z1;}
  /* ¿el tramo (x0,z0)→(x1,z1) no toca ninguna celda marcada? (afuera de la zona no se sabe: se revisa) */
  function zonaLibre(Z,x0,z0,x1,z1){let i0=Math.floor(Math.min(x0,x1))-Z.x0,i1=Math.floor(Math.max(x0,x1))-Z.x0,j0=Math.floor(Math.min(z0,z1))-Z.z0,j1=Math.floor(Math.max(z0,z1))-Z.z0;
    if(i0<0||j0<0||i1>=Z.nx||j1>=Z.nz)return false;
    for(let j=j0;j<=j1;j++){const o=j*Z.nx;for(let i=i0;i<=i1;i++)if(Z.c[o+i])return false;}return true;}
  /* ¿seguro que en (x,z) no hay piso a la altura y o más arriba? Edificios (terrazas) y escalinatas (FLOORFN) se miran en el punto */
  function zonaAlta(Z,x,z,y){const i=Math.floor(x)-Z.x0,j=Math.floor(z)-Z.z0;if(i<0||j<0||i>=Z.nx||j>=Z.nz||y<=Z.top[j*Z.nx+i]||isSolid(x,z))return false;
    for(const fn of FLOORFN){const v=fn(x,z);if(v>0&&v>=y)return false;}return true;}

  /* Altura de lo que hay debajo de (x,z) para algo que está a la altura y: el terreno (floorAt, con cordón y escalinatas),
     la tapa de un obstáculo, la carrocería de un auto o una terraza baja, si no quedan más de 30 cm por encima.
     Deja en pisoT el terreno solo y en pisoM el material (1 si es un auto). */
  let pisoM=0,pisoT=0;
  function suelo(x,z,y,L,Z){const lim=y+.3;let g=terreno(x,z,Z);pisoT=g;pisoM=0;
    for(const b of L.ob){if(b.gl)continue;if(x>b.x0&&x<b.x1&&z>b.z0&&z<b.z1&&b.y1>g&&b.y1<=lim)g=b.y1;}
    for(let k=0;k<L.ca.length;k++){const c=L.ca[k];if(c.st>=3)continue;const rx=x-c.x,rz=z-c.z;if(rx*rx+rz*rz>c.L*c.L*.3)continue;
      const ca=L.cc[k],sa=L.cs[k],lx=rx*ca-rz*sa,lz=rx*sa+rz*ca;if(lx>c.W/2||lx<-c.W/2||lz>c.L/2||lz<-c.L/2)continue;
      const h=techo(c,-lz);if(h>g&&h<=lim){g=h;pisoM=1;}}
    if(isSolid(x,z)){const bh=bldH(x,z);if(bh>g&&bh<=lim){g=bh;pisoM=0;}}
    return g;}
  /* normal de un escalón del terreno entre (x0,z0) y (x1,z1): busca dónde sube y mira la pendiente ahí */
  function normalEscalon(x0,z0,x1,z1,lim){let a=0,b=1;const mx=x1-x0,mz=z1-z0;
    for(let i=0;i<6;i++){const m=(a+b)/2;if(floorAt(x0+mx*m,z0+mz*m)>lim)b=m;else a=m;}
    const cx=x0+mx*(a+b)/2,cz=z0+mz*(a+b)/2,e=.05;
    let nx=floorAt(cx-e,cz)-floorAt(cx+e,cz),nz=floorAt(cx,cz-e)-floorAt(cx,cz+e);   // hacia abajo de la pendiente
    const l=Math.sqrt(nx*nx+nz*nz),ml=Math.sqrt(mx*mx+mz*mz)||1;
    if(l<1e-6||(nx*mx+nz*mz)/(l*ml)>-.2){nx=-mx/ml;nz=-mz/ml;}else{nx/=l;nz/=l;}
    N.x=nx;N.y=0;N.z=nz;N.m=0;}
  /* rebote contra una superficie de normal n: la parte normal se invierte por e, la de costado se queda con fr */
  function rebote(v,nx,ny,nz,e,fr){const vn=v.x*nx+v.y*ny+v.z*nz;if(vn>=0)return;
    const tx=v.x-vn*nx,ty=v.y-vn*ny,tz=v.z-vn*nz;v.x=tx*fr-e*vn*nx;v.y=ty*fr-e*vn*ny;v.z=tz*fr-e*vn*nz;}

  /* ================= un paso de física (H segundos) =================
     Lo usan igual las granadas de verdad y las de prueba de arco(): por eso lo que arco() dice, pasa.
     Devuelve 0 nada · 1 pegó contra algo de costado · 2 picó contra el piso */
  function paso(g,L,Z){const p=g.p,v=g.v;g.k++;
    if(g.quieta){/* quieta: cada 16 pasos se fija si le sacaron el piso (un auto que explotó debajo) */
      if((g.k&15)||suelo(p.x,p.z,p.y,L,Z)>=p.y-R-.03)return 0;g.quieta=false;g.enPiso=false;}
    v.y-=TUNE.G*H;
    const x0=p.x,y0=p.y,z0=p.z,dx=v.x*H,dy=v.y*H,dz=v.z*H;let ev=0;
    const t=Z&&zonaLibre(Z,(dx<0?x0+dx:x0)-R,(dz<0?z0+dz:z0)-R,(dx<0?x0:x0+dx)+R,(dz<0?z0:z0+dz)+R)?1:choque(x0,y0,z0,dx,dy,dz,L);
    if(t<1){p.set(x0+dx*t+N.x*.002,y0+dy*t+N.y*.002,z0+dz*t+N.z*.002);rebote(v,N.x,N.y,N.z,TUNE.eMuro,TUNE.frMuro);ev=1;g.mat=N.m;}
    else p.set(x0+dx,y0+dy,z0+dz);
    /* atajo de arco(): bien por encima de todo lo que puede ser piso, no toca piso ni escalón (es lo mismo que daría suelo) */
    if(Z&&zonaAlta(Z,p.x,p.z,(y0<p.y?y0:p.y)-R)){g.enPiso=false;return ev;}
    let yr=y0>p.y?y0:p.y,gy=suelo(p.x,p.z,yr,L,Z),sm=pisoM;
    /* escalón del terreno (cordón, andén, escalinata): si adelante el terreno queda más alto que la base de la granada, es una pared */
    if(pisoT>y0-R+TUNE.escalon&&(p.x!==x0||p.z!==z0)){
      normalEscalon(x0,z0,p.x,p.z,y0-R+TUNE.escalon);p.x=x0;p.z=z0;rebote(v,N.x,0,N.z,TUNE.eMuro,TUNE.frMuro);ev=1;g.mat=0;
      gy=suelo(p.x,p.z,yr,L,Z);sm=pisoM;}
    if(p.y-R<=gy){
      if(v.y<-TUNE.vReb){/* llega con fuerza: pica. Sobre un auto, según la inclinación de la carrocería (capó, parabrisas) */
        let nx=0,ny=1,nz=0;
        if(sm===1){const e=.06;let sx=(suelo(p.x+e,p.z,yr,L,Z)-suelo(p.x-e,p.z,yr,L,Z))/(2*e),sz=(suelo(p.x,p.z+e,yr,L,Z)-suelo(p.x,p.z-e,yr,L,Z))/(2*e);
          if(sx>2||sx<-2||sz>2||sz<-2){sx=0;sz=0;}                       // borde de la carrocería: como plano
          const il=1/Math.sqrt(1+sx*sx+sz*sz);nx=-sx*il;ny=il;nz=-sz*il;}
        rebote(v,nx,ny,nz,TUNE.eSuelo,TUNE.frSuelo);ev=2;g.mat=sm;}
      else{/* rueda y se va frenando */
        v.y=0;const sp=Math.sqrt(v.x*v.x+v.z*v.z);
        if(sp<.12){v.x=0;v.z=0;g.quieta=true;}else{const k=(sp-TUNE.rodar*H)/sp;v.x*=k>0?k:0;v.z*=k>0?k:0;}}
      p.y=gy+R;g.enPiso=true;}
    else g.enPiso=false;
    return ev;}

  /* ================= arco: solución de lanzamiento por elevación =================
     Prueba ángulos de 20° a 60° (primero 45°). Para cada uno calcula la velocidad que pone la granada sobre el blanco,
     simula el tiro con la física de arriba hasta que se acaba la mecha (o se queda quieta) y corre el punto de mira por
     lo que pica y rueda, hasta que quede sobre el blanco. Si choca con algo en el aire, ese ángulo no sirve.
     Devuelve {vel, ok, t, err, fin, ang}: velocidad inicial · si queda a menos de tol del blanco sin chocar en el aire ·
     tiempo de vuelo hasta el primer toque · error previsto (m) · dónde va a quedar al explotar · ángulo (rad).
     Si no hay tiro bueno, vel es el mejor intento. Guarda las últimas respuestas un segundo (el gesto de lanzar dura 1,3 s). */
  const ANG=[45,35,55,25,60,20].map(a=>a*D2R),MAXSIM=7;
  const GS={p:new V3(),v:new V3(),k:0,quieta:false,enPiso:false,mat:0},LA=mkLoc(),ZA=mkZona(),SIM={fin:new V3(),choca:false,t:0},_av=new V3();
  let atajos=true;   // para comparar en las pruebas: con y sin atajos tiene que dar lo mismo
  const CACHE=[];for(let i=0;i<8;i++)CACHE.push({a:new V3(),b:new V3(),T:-1e9,vmax:0,mecha:0,tol:0,r:{vel:new V3(),ok:false,t:0,err:0,fin:new V3(),ang:0}});
  let cacheI=0;
  const MEM=[];for(let i=0;i<8;i++)MEM.push({T:-1e9,ax:0,az:0,bx:0,bz:0,vmax:0,mecha:0,ang:0,D:1,al:0,ac:0});let memI=0;   // tiros resueltos hace poco
  const copiaRes=(r,o)=>{o=o||{vel:new V3(),ok:false,t:0,err:0,fin:new V3(),ang:0};o.vel.copy(r.vel);o.ok=r.ok;o.t=r.t;o.err=r.err;o.fin.copy(r.fin);o.ang=r.ang;return o;};
  /* si la mano quedó por debajo del terreno (no debería), la granada arranca apoyada encima */
  const arreglarInicio=p=>{const f=floorAt(p.x,p.z);if(p.y-R<f)p.y=f+R;};
  function simular(desde,vel,n,L,Z){const g=GS;g.p.copy(desde);arreglarInicio(g.p);g.v.copy(vel);g.k=0;g.quieta=false;g.enPiso=false;g.mat=0;
    let t1=-1;SIM.choca=false;
    for(let i=0;i<n;i++){const ev=paso(g,L,Z);
      if(t1<0){if(ev===1){SIM.choca=true;t1=(i+1)*H;break;}if(ev===2||g.enPiso)t1=(i+1)*H;}
      if(g.quieta)break;}
    SIM.fin.copy(g.p);SIM.t=t1<0?n*H:t1;return SIM;}
  function arco(desde,hasta,opt){
    const vmax=(opt&&opt.vmax)||TUNE.vmax,mecha=(opt&&opt.mecha)||TUNE.mecha,tol=(opt&&opt.tol)||TUNE.tol;
    for(const c of CACHE){if(T<c.T||T-c.T>=1||c.vmax!==vmax||c.mecha!==mecha||c.tol!==tol)continue;
      if(Math.abs(c.a.x-desde.x)+Math.abs(c.a.y-desde.y)+Math.abs(c.a.z-desde.z)>.2||Math.abs(c.b.x-hasta.x)+Math.abs(c.b.y-hasta.y)+Math.abs(c.b.z-hasta.z)>.2)continue;
      return copiaRes(c.r);}
    const res={vel:new V3(),ok:false,t:0,err:Infinity,fin:new V3(),ang:0};
    /* la zona (cosas cercanas y grilla) se arma con 8 m de margen y se reusa 1 s si el tiro nuevo cae adentro con 6 m de margen */
    const ax0=Math.min(desde.x,hasta.x),az0=Math.min(desde.z,hasta.z),ax1=Math.max(desde.x,hasta.x),az1=Math.max(desde.z,hasta.z);
    const Z=atajos?ZA:null;
    if(!Z||T<ZA.T||T-ZA.T>1||ax0-6<ZA.X0||az0-6<ZA.Z0||ax1+6>ZA.X1||az1+6>ZA.Z1){
      locArmar(LA,ax0-8,az0-8,ax1+8,az1+8);if(Z){zonaArmar(Z,LA,ax0-8,az0-8,ax1+8,az1+8);Z.T=T;}}
    const ty=suelo(hasta.x,hasta.z,hasta.y,LA,Z),h=ty+R-desde.y,n=Math.max(1,Math.round(mecha/H));let sims=0;
    /* arranque en caliente: si hace poco se resolvió un tiro parecido (mismo lanzador y blanco a pocos metros), se empieza
       por su ángulo y corriendo el punto de mira lo mismo que corrió aquel (lo que pica y rueda), en la dirección del tiro nuevo */
    const bx=hasta.x-desde.x,bz=hasta.z-desde.z,Db=Math.sqrt(bx*bx+bz*bz)||1,ux=bx/Db,uz=bz/Db;
    let m0=null;for(const m of MEM){if(T<m.T||T-m.T>3||m.vmax!==vmax||m.mecha!==mecha)continue;
      if(Math.abs(m.ax-desde.x)+Math.abs(m.az-desde.z)>3||Math.abs(m.bx-hasta.x)+Math.abs(m.bz-hasta.z)>4)continue;if(!m0||m.T>m0.T)m0=m;}
    let mx=0,mz=0;
    for(let ai=-1;ai<ANG.length;ai++){const a=ai<0?(m0?m0.ang:-1):ANG[ai];if(a<0||(ai>=0&&m0&&a===m0.ang))continue;
      let ax=hasta.x,az=hasta.z;if(ai<0){const al=m0.al*Db/m0.D;ax+=ux*al-uz*m0.ac;az+=uz*al+ux*m0.ac;}
      const ca=Math.cos(a),sa=Math.sin(a),ta=sa/ca;let pax=0,paz=0,pfx=0,pfz=0;
      for(let it=0;it<3&&sims<MAXSIM;it++){
        const dx=ax-desde.x,dz=az-desde.z,D=Math.sqrt(dx*dx+dz*dz),den=D*ta-h;if(D<.3||den<.05)break;
        const v=Math.sqrt(TUNE.G*D*D/(2*ca*ca*den));if(v>vmax)break;
        _av.set(dx/D*v*ca,v*sa,dz/D*v*ca);simular(desde,_av,n,LA,Z);sims++;
        const ex=hasta.x-SIM.fin.x,ez=hasta.z-SIM.fin.z,err=Math.sqrt(ex*ex+ez*ez);
        const ok=!SIM.choca&&err<=tol&&Math.abs(SIM.fin.y-R-ty)<1;
        if((ok&&!res.ok)||(ok===res.ok&&err<res.err)){res.vel.copy(_av);res.ok=ok;res.t=SIM.t;res.err=err;res.fin.copy(SIM.fin);res.ang=a;mx=ax;mz=az;}
        if(SIM.choca||err<.25)break;   // ese ángulo no sirve, o ya está
        /* corrección: lo que le faltó; desde la segunda, escalada por cuánto movió el final la corrección anterior (secante) */
        let k=1;if(it>0){const da=(ax-pax)*ux+(az-paz)*uz,df=(SIM.fin.x-pfx)*ux+(SIM.fin.z-pfz)*uz;if(Math.abs(df)>.05)k=cl(da/df,.5,2);}
        pax=ax;paz=az;pfx=SIM.fin.x;pfz=SIM.fin.z;ax+=ex*k;az+=ez*k;}
      if(res.ok)break;}                 // el primer ángulo que sirve (más bombeado solo si el de 45° choca o no llega)
    if(!sims){/* ningún ángulo llega (o el blanco está pegado): el mejor intento es tirarla a 45° con toda la fuerza hacia allá */
      const c45=Math.SQRT1_2*vmax;_av.set(ux*c45,c45,uz*c45);simular(desde,_av,n,LA,Z);
      res.vel.copy(_av);res.t=SIM.t;res.fin.copy(SIM.fin);res.err=Math.hypot(hasta.x-SIM.fin.x,hasta.z-SIM.fin.z);res.ang=45*D2R;}
    if(res.ok){const m=MEM[memI];memI=(memI+1)%MEM.length;const ox=mx-hasta.x,oz=mz-hasta.z;
      m.T=T;m.ax=desde.x;m.az=desde.z;m.bx=hasta.x;m.bz=hasta.z;m.vmax=vmax;m.mecha=mecha;m.ang=res.ang;m.D=Db;m.al=ox*ux+oz*uz;m.ac=-ox*uz+oz*ux;}
    const c=CACHE[cacheI];cacheI=(cacheI+1)%CACHE.length;c.a.copy(desde);c.b.copy(hasta);c.T=T;c.vmax=vmax;c.mecha=mecha;c.tol=tol;copiaRes(res,c.r);
    return res;}

  /* ================= mallas y efectos (todo se crea al cargar) ================= */
  const GEO_PLANO=new THREE.PlaneGeometry(1,1);
  /* granada propia, por si no está UEM: cuerpo ovalado verde oliva y espoleta de metal, en una sola malla (una llamada de dibujo) */
  const GEO_PROPIA=(()=>{const pts=[];
    for(let i=0;i<=9;i++){const a=-Math.PI/2+(Math.PI/2+56*D2R)*i/9;pts.push(new THREE.Vector2(Math.max(.0008,Math.cos(a)*.031),Math.sin(a)*.036));}
    pts.push(new THREE.Vector2(.0105,.03),new THREE.Vector2(.0105,.052),new THREE.Vector2(.0008,.054));
    const g=new THREE.LatheGeometry(pts,10),pos=g.attributes.position,col=new Float32Array(pos.count*3);
    for(let i=0;i<pos.count;i++){const m=pos.getY(i)>.029;col[i*3]=m?.42:.12;col[i*3+1]=m?.41:.14;col[i*3+2]=m?.38:.09;}
    g.setAttribute('color',new THREE.BufferAttribute(col,3));g.computeVertexNormals();return g;})();
  const MAT_PROPIA=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.55,metalness:.35});
  const sprite=(map,color,aditivo)=>{const s=new THREE.Sprite(new THREE.SpriteMaterial({map,color,transparent:true,opacity:0,depthWrite:false,blending:aditivo?THREE.AdditiveBlending:THREE.NormalBlending}));s.visible=false;_sceneAdd(s);return s;};
  const plano=(map,color)=>{const m=new THREE.Mesh(GEO_PLANO,new THREE.MeshBasicMaterial({map,color,transparent:true,opacity:0,depthWrite:false,blending:THREE.AdditiveBlending,polygonOffset:true,polygonOffsetFactor:-2}));m.rotation.x=-Math.PI/2;m.visible=false;_sceneAdd(m);return m;};
  for(let i=0;i<NMAX;i++){const m=new THREE.Mesh(GEO_PROPIA,MAT_PROPIA);m.visible=false;_sceneAdd(m);
    todas.push({p:new V3(),v:new V3(),t:0,de:null,tipo:'frag',          // lo público (GRAN.lista)
      i,viva:false,k:0,quieta:false,enPiso:false,mat:0,L:mkLoc(),Lx:0,Lz:0,pa:new V3(),pe:new V3(),
      bip:0,luz:0,tic:0,wx:0,wz:0,malla:m,
      luzS:sprite(glowTex,0xff2a12,true),          // la lucecita roja que parpadea
      luzP:plano(glowTex,0xff2010)});}             // su reflejo en el piso
  /* con UEM (el modelo de los soldados) se usa su granada. UEM puede estar declarado más abajo en el script:
     se busca recién al armar la partida (reset) o al primer lanzamiento, nunca al cargar este módulo */
  let mallaUEM=false;
  function armarMallas(){if(mallaUEM)return;let fab=null;
    try{if(typeof UEM!=='undefined'&&UEM&&typeof UEM.granada==='function')fab=UEM.granada;}catch(e){fab=null;}
    if(!fab)return;mallaUEM=true;
    try{for(const g of todas){const m=fab();m.castShadow=false;m.visible=false;if(g.malla.parent)g.malla.parent.remove(g.malla);g.malla=m;_sceneAdd(m);}}catch(e){}}

  /* explosión: fogonazo, bolas de fuego, humo y onda en el piso. 3 a la vez como mucho (la cuarta pisa la más vieja) */
  const FXN=3,FX=[];let fxI=0;
  for(let i=0;i<FXN;i++){const f={on:false,t:0,flash:sprite(glowTex,0xffe2a8,true),fuego:[],humo:[],anillo:plano(VFXT.ring,0xffc890)};
    for(let k=0;k<5;k++)f.fuego.push({s:sprite(VFXT.fire,0xffe0a0,true),v:new V3(),vida:1,s0:1,s1:2});
    for(let k=0;k<6;k++)f.humo.push({s:sprite(VFXT.smoke,0x3a342e,false),v:new V3(),vida:1,s0:1,s1:3,ret:0});
    FX.push(f);}
  const _q=new V3(),_w2=new V3(),_c=new THREE.Color();
  function efecto(p,piso,cerca){const f=FX[fxI];fxI=(fxI+1)%FXN;f.on=true;f.t=0;
    f.flash.position.set(p.x,p.y+.35,p.z);f.flash.scale.setScalar(3);f.flash.material.opacity=1;f.flash.visible=true;
    for(const q of f.fuego){q.s.position.set(p.x+rand(-.3,.3),p.y+rand(.1,.5),p.z+rand(-.3,.3));
      q.v.set(rand(-1,1),rand(.3,1.2),rand(-1,1)).normalize().multiplyScalar(rand(2,5));
      q.vida=rand(.35,.6);q.s0=rand(.6,1);q.s1=rand(2.2,3.2);q.s.material.rotation=rand(0,6.28);q.s.material.opacity=0;q.s.scale.setScalar(q.s0);q.s.visible=true;}
    for(const q of f.humo){const a=rand(0,6.28),r=rand(.2,1);q.s.position.set(p.x+Math.cos(a)*r,Math.max(p.y,piso+.3)+rand(0,.6),p.z+Math.sin(a)*r);
      q.v.set(Math.cos(a)*rand(1,2.5),rand(.6,1.6),Math.sin(a)*rand(1,2.5));
      q.vida=rand(2,3.4);q.ret=rand(0,.12);q.s0=rand(.8,1.3);q.s1=rand(3,4.5);q.s.material.rotation=rand(0,6.28);q.s.material.opacity=0;q.s.scale.setScalar(q.s0);q.s.visible=true;}
    if(cerca){f.anillo.position.set(p.x,piso+.06,p.z);f.anillo.scale.setScalar(1);f.anillo.material.opacity=.8;f.anillo.visible=true;}else f.anillo.visible=false;
    /* pedazos de asfalto y tierra: las partículas del juego (un solo InstancedMesh, ya existe) */
    for(let k=0;k<14;k++)spawnPart(_q.set(p.x,p.y+.1,p.z),_w2.set(rand(-1,1),rand(.4,1.5),rand(-1,1)).normalize().multiplyScalar(rand(3,9)),rand(.025,.06),k%3?'#2a2622':'#4a4038',rand(1.2,2.4));}
  function fx(dt){for(const f of FX){if(!f.on)continue;f.t+=dt;const t=f.t;let vivo=false;
    if(f.flash.visible){const k=t/.14;if(k>=1)f.flash.visible=false;else{vivo=true;f.flash.scale.setScalar(3+5*k);f.flash.material.opacity=1-k;}}
    const amort=Math.exp(-3*dt),amortH=Math.exp(-1.2*dt);
    for(const q of f.fuego){if(!q.s.visible)continue;const k=t/q.vida;if(k>=1){q.s.visible=false;continue;}vivo=true;
      q.v.multiplyScalar(amort);q.v.y+=1.5*dt;q.s.position.addScaledVector(q.v,dt);
      q.s.scale.setScalar(q.s0+(q.s1-q.s0)*Math.sqrt(k));q.s.material.opacity=.95*(1-k*k);
      q.s.material.color.setHex(0xffe0a0).lerp(_c.setHex(0x8a2a08),Math.min(1,k*1.5));}
    for(const q of f.humo){if(!q.s.visible)continue;vivo=true;const tt=t-q.ret;if(tt<0)continue;const k=tt/q.vida;if(k>=1){q.s.visible=false;continue;}
      q.v.x*=amortH;q.v.z*=amortH;q.v.y*=amortH;q.s.position.addScaledVector(q.v,dt);
      q.s.scale.setScalar(q.s0+(q.s1-q.s0)*Math.sqrt(k));q.s.material.opacity=.7*Math.min(1,k*5)*(1-k);
      q.s.material.color.setHex(0x4a423a).lerp(_c.setHex(0x1c1a18),Math.min(1,k*1.3));}
    if(f.anillo.visible){const k=t/.35;if(k>=1)f.anillo.visible=false;else{vivo=true;f.anillo.scale.setScalar(1+8*Math.sqrt(k));f.anillo.material.opacity=.8*(1-k);}}
    if(!vivo)f.on=false;}}

  /* ================= sonido =================
     Todo sintetizado con noise() y tone() del juego, cada sonido envuelto en auOneShot y pasando por auGate.
     Para que se oiga de qué lado viene, mientras suena se pone un paneo estéreo como salida (se cambia master
     un instante: noise() y tone() se conectan a master). Los nodos los libera auOneShot. */
  function conPaneo(x,z,fn){const m0=master;let pn=null;
    if(AC.createStereoPanner){const dx=x-P.pos.x,dz=z-P.pos.z,d=Math.sqrt(dx*dx+dz*dz);pn=AC.createStereoPanner();
      pn.pan.value=d>.5?cl((dx*Math.cos(P.yaw)-dz*Math.sin(P.yaw))/d,-1,1)*.8:0;pn.connect(m0);master=pn;}
    try{fn();}finally{master=m0;}}
  const volDist=(x,z,oir)=>{const d=Math.hypot(x-P.pos.x,z-P.pos.z),k=1-d/oir;return k>0?k*k:0;};
  const sBip=auOneShot((x,z,v)=>conPaneo(x,z,()=>{tone('square',3150,0,.04,.03*v);tone('sine',3150,0,.07,.07*v);}));
  const sPique=auOneShot((x,z,v,mat)=>conPaneo(x,z,()=>{
    if(mat===1){tone('square',rand(520,700),rand(300,380),.09,.045*v);noise(.06,'bandpass',rand(1800,2600),0,.12*v,4);}        // chapa
    else if(mat===2){tone('sine',rand(2600,3400),0,.12,.05*v);noise(.04,'highpass',5000,0,.1*v);}                               // vidrio
    else{noise(.035,'bandpass',rand(2600,4200),0,.16*v,3);tone('triangle',rand(1500,2200),rand(900,1200),.04,.04*v);}}));      // piedra
  const sBoom=auOneShot((x,z,v)=>conPaneo(x,z,()=>{
    noise(1.3,'lowpass',2400,50,.95*v);                  // cuerpo
    noise(.15,'highpass',2600,0,.6*v);                   // chasquido
    tone('sine',110,30,.8,.6*v);                          // golpe grave
    tone('triangle',62,32,.35,.18*v);
    for(let k=0;k<5;k++)noise(.04,'highpass',rand(3000,7000),0,.1*v,1,.08+k*rand(.06,.12));   // esquirlas que caen
    noise(.7,'bandpass',200,60,.25*v,1,.1);}));          // retumbe
  function bip(g){if(!AC)return;const v=volDist(g.p.x,g.p.z,TUNE.oirBip);if(v<.01||!auGate('gran_bip',2,8,250))return;sBip(g.p.x,g.p.z,v*TUNE.volBip);}
  function pique(g,ev){if(!AC||T-g.tic<.07)return;
    const sp=ev===2?Math.abs(g.v.y)/TUNE.eSuelo:Math.hypot(g.v.x,g.v.z)/TUNE.eMuro,f=cl(sp/9,0,1);if(f<.08)return;
    const v=volDist(g.p.x,g.p.z,TUNE.oirPique)*f;if(v<.01||!auGate('gran_tic',1,4,150))return;g.tic=T;sPique(g.p.x,g.p.z,v*TUNE.volPique,g.mat);}
  function boom(p){if(!AC)return;const d=Math.hypot(p.x-P.pos.x,p.z-P.pos.z),v=cl(1.15-d/TUNE.oirBoom*1.15,.06,1);if(!auGate('gran_boom',3,3,250))return;sBoom(p.x,p.z,v*TUNE.volBoom);}

  /* ================= explosión: daño ================= */
  const LX=mkLoc(),_o=new V3(),_b=new V3(),_dr=new V3(),_es=[];
  /* ¿hay algo sólido entre o y b? Paredes y autos con los rayos de las balas (rayWalls, rayCars) y los obstáculos.
     Vidrios, postes, árboles y bichos no cubren */
  function tapado(o,b){_dr.subVectors(b,o);const len=_dr.length();if(len<.05)return false;_dr.multiplyScalar(1/len);
    if(rayWalls(o,_dr,len)<len)return true;
    const rc=rayCars(o,_dr,len);if(rc&&rc.t<len)return true;
    for(const q of LX.ob){if(q.gl)continue;let t0=0,t1=len,dentro=true;
      for(let ax=0;ax<3&&dentro;ax++){const p0=ax===0?o.x:ax===1?o.y:o.z,d=ax===0?_dr.x:ax===1?_dr.y:_dr.z,a=ax===0?q.x0:ax===1?(q.y0||0):q.z0,bb=ax===0?q.x1:ax===1?q.y1:q.z1;
        if(d>-1e-9&&d<1e-9){if(p0<a||p0>bb)dentro=false;}else{let ta=(a-p0)/d,tb=(bb-p0)/d;if(ta>tb){const s=ta;ta=tb;tb=s;}if(ta>t0)t0=ta;if(tb<t1)t1=tb;if(t0>t1)dentro=false;}}
      if(dentro)return true;}
    return false;}
  /* distancia de la explosión a un cuerpo vertical (pies en y0, cabeza en y1) a dh metros en horizontal */
  const distCuerpo=(dh,py,y0,y1)=>{const dv=py<y0?y0-py:py>y1?py-y1:0;return Math.sqrt(dh*dh+dv*dv);};
  function danos(g,p){const Rr=TUNE.radio;_o.set(p.x,p.y+.3,p.z);
    locArmar(LX,p.x-Rr-3,p.z-Rr-3,p.x+Rr+3,p.z+Rr+3);
    /* autos cercanos: golpes según lo cerca que quede la carrocería (pueden prenderse) */
    for(let k=0;k<LX.ca.length;k++){const c=LX.ca[k];if(c.st>=3)continue;const rx=p.x-c.x,rz=p.z-c.z,ca=LX.cc[k],sa=LX.cs[k],lx=rx*ca-rz*sa,lz=rx*sa+rz*ca;
      const ex=Math.max(0,Math.abs(lx)-c.W/2),ez=Math.max(0,Math.abs(lz)-c.L/2),ey=Math.max(0,p.y-((c.by||0)+c.H)),d=Math.sqrt(ex*ex+ez*ez+ey*ey);
      if(d<TUNE.autoR){const n=Math.ceil(TUNE.autoGolpes*(1-d/TUNE.autoR));if(n>0)carDamage(c,n);}}
    /* bichos: distancia al borde del cuerpo, descuento por cobertura, empujón (damageEnemy lo hace) */
    _es.length=0;for(const e of enemies)_es.push(e);
    for(const e of _es){if(e.hp<=0)continue;const ep=e.obj.position,r=e.c.r||.5,hb=e.c.height||1,dx=ep.x-p.x,dz=ep.z-p.z,dh=Math.sqrt(dx*dx+dz*dz);
      const d=distCuerpo(Math.max(0,dh-r),p.y,ep.y,ep.y+hb);if(d>=Rr)continue;
      let dm=TUNE.dano*TUNE.xBichos*(1-d/Rr);if(tapado(_o,_b.set(ep.x,ep.y+hb*.5,ep.z)))dm*=TUNE.cobertura;
      if(dh>.05)_dr.set(dx/dh,0,dz/dh);else _dr.set(1,0,0);damageEnemy(e,dm,_dr);}
    _es.length=0;}
  function danoJugador(p){const Rr=TUNE.radio,eye=1.7-.68*P.ch,dx=P.pos.x-p.x,dz=P.pos.z-p.z,dh=Math.sqrt(dx*dx+dz*dz);
    const d=distCuerpo(dh,p.y,P.pos.y,P.pos.y+eye);
    shake=Math.max(shake,TUNE.sacudida*cl(1-d/30,0,1));
    if(d>=Rr||P.hp<=0)return;
    const f=tapado(_o.set(p.x,p.y+.3,p.z),_b.set(P.pos.x,P.pos.y+eye-.45,P.pos.z))?TUNE.cobertura:1,k=(1-d/Rr)*f;
    /* empujón: hacia afuera de la explosión y un poco hacia arriba */
    const nx=dh>.05?dx/dh:1,nz=dh>.05?dz/dh:0;P.vel.x+=nx*TUNE.empuje*k;P.vel.z+=nz*TUNE.empuje*k;if(P.onGround)P.vel.y=Math.max(P.vel.y,TUNE.empujeY*k);
    const dm=Math.round(TUNE.dano*k);if(dm>0)hurtPlayer(dm,false);}
  function explotar(g){const i=lista.indexOf(g);if(i>=0){lista[i]=lista[lista.length-1];lista.pop();}
    g.viva=false;g.malla.visible=false;g.luzS.visible=false;g.luzP.visible=false;
    const p=g.pe.copy(g.p),piso=suelo(p.x,p.z,p.y,g.L),cerca=p.y-piso<1.2;
    efecto(p,piso,cerca);boom(p);
    if(cerca){addDecal(p.x,p.z,2.4,'#0d0b09');addDecal(p.x+rand(-.3,.3),p.z+rand(-.3,.3),1.3,'#050404');}
    danos(g,p);
    UEB.explosion(p,TUNE.radio,TUNE.dano,g.de);
    danoJugador(p);}

  /* ================= vida de cada granada ================= */
  function lanzar(o){let g=null;for(const q of todas)if(!q.viva){g=q;break;}if(!g)return null;
    armarMallas();
    g.p.copy(o.pos);arreglarInicio(g.p);if(o.vel)g.v.copy(o.vel);else g.v.set(0,0,0);
    g.t=o.mecha>0?o.mecha:TUNE.mecha;g.de=o.de===undefined?null:o.de;g.tipo=o.tipo||'frag';
    g.viva=true;g.k=0;g.quieta=false;g.enPiso=false;g.mat=0;g.pa.copy(g.p);g.bip=0;g.luz=0;g.tic=-9;
    g.wx=rand(-14,14);g.wz=rand(-14,14);g.malla.rotation.set(rand(0,6.28),rand(0,6.28),0);
    locArmar(g.L,g.p.x-LOC,g.p.z-LOC,g.p.x+LOC,g.p.z+LOC);g.Lx=g.p.x;g.Lz=g.p.z;
    g.malla.position.copy(g.p);g.malla.visible=true;g.luzS.visible=true;g.luzP.visible=false;
    lista.push(g);
    if(g.de==='jugador')UEB.ruido(g.p,'granada',.5);
    return g;}
  const intervalo=t=>{const k=cl(t/3,0,1);return TUNE.bipRapido+(TUNE.bipLento-TUNE.bipRapido)*k*Math.sqrt(k);};
  let acc=0;
  function update(dt){if(!lista.length){acc=0;return;}
    acc+=dt;if(acc>.1)acc=.1;
    while(acc>=H){acc-=H;
      for(let i=lista.length-1;i>=0;i--){const g=lista[i];g.pa.copy(g.p);
        /* la lista de cosas cercanas se rehace al alejarse 6 m o cada medio segundo (escalonado entre granadas) */
        if(Math.abs(g.p.x-g.Lx)>LOC*.5||Math.abs(g.p.z-g.Lz)>LOC*.5||(g.k+g.i*4)%30===29){locArmar(g.L,g.p.x-LOC,g.p.z-LOC,g.p.x+LOC,g.p.z+LOC);g.Lx=g.p.x;g.Lz=g.p.z;}
        const ev=paso(g,g.L);if(ev){pique(g,ev);if(ev===2){g.wx*=.6;g.wz*=.6;}}
        g.t-=H;if(g.t<H*.5)explotar(g);}}
    /* dibujo: entre el paso anterior y el actual, para que se vea suave a cualquier cuadro por segundo */
    const f=acc/H;
    for(const g of lista){const m=g.malla,x=g.pa.x+(g.p.x-g.pa.x)*f,y=g.pa.y+(g.p.y-g.pa.y)*f,z=g.pa.z+(g.p.z-g.pa.z)*f;m.position.set(x,y,z);
      if(!g.enPiso){m.rotation.x+=g.wx*dt;m.rotation.z+=g.wz*dt;}
      else if(!g.quieta){m.rotation.x+=g.v.z/R*dt;m.rotation.z-=g.v.x/R*dt;}
      g.bip-=dt;if(g.bip<=0){g.bip=intervalo(g.t);g.luz=1;bip(g);}
      g.luz=Math.max(0,g.luz-dt*9);const l=g.luz;
      g.luzS.position.set(x,y+.05,z);g.luzS.scale.setScalar(TUNE.luz+(TUNE.luzPico-TUNE.luz)*l);g.luzS.material.opacity=.55+.45*l;
      if(g.enPiso){g.luzP.visible=true;g.luzP.position.set(x,y-R+.012,z);g.luzP.scale.setScalar(.6+(TUNE.luzPiso-.6)*l);g.luzP.material.opacity=.1+.45*l;}else g.luzP.visible=false;}}
  function reset(){armarMallas();
    for(const g of todas){g.viva=false;g.malla.visible=false;g.luzS.visible=false;g.luzP.visible=false;}
    lista.length=0;acc=0;
    for(const f of FX){f.on=false;f.flash.visible=false;for(const q of f.fuego)q.s.visible=false;for(const q of f.humo)q.s.visible=false;f.anillo.visible=false;}
    for(const c of CACHE)c.T=-1e9;for(const m of MEM)m.T=-1e9;ZA.T=-1e9;}
  /* para pruebas y para la vista táctica: cuántas hay vivas, cuántas piezas propias se están dibujando y cuántas explosiones siguen */
  function estado(){let vis=0;for(const g of todas)vis+=(g.malla.visible?1:0)+(g.luzS.visible?1:0)+(g.luzP.visible?1:0);let fxOn=0;
    for(const f of FX){if(f.on)fxOn++;vis+=(f.flash.visible?1:0)+(f.anillo.visible?1:0);for(const q of f.fuego)vis+=q.s.visible?1:0;for(const q of f.humo)vis+=q.s.visible?1:0;}
    return {vivas:lista.length,visibles:vis,explosiones:fxOn,mallaUEM:mallaUEM};}
  return {lanzar,lista,arco,update,fx,reset,estado,get G(){return TUNE.G;},TUNE};
})();
