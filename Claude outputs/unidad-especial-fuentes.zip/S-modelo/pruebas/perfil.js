/* perfil en el tiempo: minY y error de manos para una capa o muerte. node perfil.js <rol> <campo> <dur> '<e0 json>' [tipoMuerte] */
const THREE=require('../../three.r128.min.js');global.THREE=THREE;const fs=require('fs');
const UEM=new Function('THREE',fs.readFileSync(__dirname+'/../ue_modelo.js','utf8')+'\nreturn UEM;')(THREE);
const V3=THREE.Vector3,H=UEM._interno.H;
const [,,rol,campo,dur,e0j,tipo]=process.argv;
function piel(u){u.root.updateMatrixWorld(true);const g=u.malla.geometry,pos=g.attributes.position,si=g.attributes.skinIndex,sw=g.attributes.skinWeight,
  bones=u.malla.skeleton.bones,inv=u.malla.skeleton.boneInverses,M=bones.map((b,i)=>new THREE.Matrix4().multiplyMatrices(b.matrixWorld,inv[i]));
  const r={};let v=new V3(),a=new V3();
  for(let i=0;i<pos.count;i++){const b0=si.getX(i);if(bones[b0].scale.x<1e-3)continue;v.fromBufferAttribute(pos,i);let y=0;
    for(let j=0;j<2;j++){const w=j?sw.getY(i):sw.getX(i);if(w<=0)continue;a.copy(v).applyMatrix4(M[j?si.getY(i):si.getX(i)]);y+=a.y*w;}
    const n=bones[b0].name;if(r[n]===undefined||y<r[n])r[n]=y;}
  return Object.entries(r).filter(([n,y])=>y<-.01).sort((a,b)=>a[1]-b[1]).slice(0,4).map(([n,y])=>n+' '+y.toFixed(3)).join(', ');}
const u=UEM.crear(rol,{semilla:9});Object.assign(u.e,JSON.parse(e0j||'{}'));for(let i=0;i<60;i++)u.update(1/60);const st=u._st;
const N=Math.round(dur*60);
for(let i=0;i<=N;i++){const t=i/N;if(tipo){u.e.muerte=u.e.muerte||{tipo,t:0,dir:.3};u.e.muerte.t=t;}else u.e[campo]=t;u.update(1/60);
  if(i%Math.max(1,Math.round(N/14))===0){const eI=st.P[H.manoI].distanceTo(st.sp.mano[0].p),eD=st.P[H.manoD].distanceTo(st.sp.mano[1].p);
    console.log(t.toFixed(2),'eI',(eI*100).toFixed(0),'eD',(eD*100).toFixed(0),'pel',st.P[H.cadera].x.toFixed(2),st.P[H.cadera].y.toFixed(2),st.P[H.cadera].z.toFixed(2),'|',piel(u));}}
