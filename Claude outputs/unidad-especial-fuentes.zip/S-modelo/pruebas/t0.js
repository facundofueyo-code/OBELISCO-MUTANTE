const H=require('../../harness.js');
(async()=>{const t0=Date.now();const h=await H.openPage(__dirname+'/t0.html',{width:1280,height:720});
console.log('abierto',Date.now()-t0,'ms');console.log(await h.page.evaluate(()=>({ms:window.__ms,caps:window.__caps})));
await h.shotPage(__dirname+'/t0.png');console.log('errores',h.errors);await h.close();})().catch(e=>{console.error('FAIL',e);process.exit(1);});
