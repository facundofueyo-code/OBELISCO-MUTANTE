/* =====================================================================================================
   LOS CUATRO ROLES — el visor 3D de S-modelo (crearVisorUE) con botones de rol, pose e interruptores.
   Se crea recién cuando entra en pantalla y se pausa cuando sale o la pestaña está oculta.
   ===================================================================================================== */
(function () {
'use strict';
const stage = document.getElementById('vStage'), cv = document.getElementById('vc'), aviso = document.getElementById('vAviso');
if (!stage || !cv) return;
const tactil = !!(window.matchMedia && matchMedia('(hover: none) and (pointer: coarse)').matches);
const reduce = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
const E = { rol: 'jefe', pose: 'Apunta', linterna: true, laser: true, girar: false, plena: false, ronda: false };
let V = null, visible = false, fallo = false;
function hayModelo() { try { return typeof THREE !== 'undefined' && typeof crearVisorUE === 'function' && !!UEM; } catch (e) { return false; } }
function avisar(t) { aviso.textContent = t; aviso.hidden = false; }
function crear() {
  if (V || fallo) return;
  if (!hayModelo()) { fallo = true; avisar('El visor 3D necesita Three.js, que se baja de internet al abrir la página. Sin conexión no se puede mostrar.'); return; }
  try {
    V = crearVisorUE(cv, { rol: E.rol, pose: E.pose, sombras: !tactil, girar: false });
    V.linterna(E.linterna); V.laser(E.laser); V.girar(E.girar); V.luzPlena(E.plena); V.ronda(E.ronda);
    V.pausa(!visible || document.hidden);
    if (tactil) cv.style.touchAction = 'pan-y';                                  // en el celular, deslizar para arriba sigue moviendo la página
  } catch (e) { fallo = true; V = null; console.error('visor: ' + (e && e.message)); avisar('Este navegador no pudo armar el visor 3D (WebGL).'); }
}
if (typeof IntersectionObserver !== 'undefined') {
  new IntersectionObserver(en => { visible = en[0].isIntersecting; if (visible) crear(); if (V) V.pausa(!visible || document.hidden); }, { rootMargin: '250px 0px' }).observe(stage);
} else { visible = true; crear(); }
document.addEventListener('visibilitychange', () => { if (V) V.pausa(!visible || document.hidden); });
if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => { if (V) V.tam(); }).observe(stage);
/* botones */
function grupo(id, alElegir) {
  const caja = document.getElementById(id); if (!caja) return;
  caja.addEventListener('click', ev => {
    const b = ev.target.closest('button'); if (!b) return;
    for (const x of caja.querySelectorAll('button')) x.setAttribute('aria-pressed', String(x === b));
    alElegir(b.dataset.v, b);
  });
}
grupo('vRoles', v => { E.rol = v; if (V) V.rol(v); });
grupo('vPoses', v => {
  E.pose = v; if (E.ronda) { E.ronda = false; marcar('ronda', false); if (V) V.ronda(false); }
  if (V) V.pose(v);
});
function marcar(k, b) { const el = document.querySelector('#vLlaves [data-k="' + k + '"]'); if (el) el.setAttribute('aria-pressed', String(b)); }
document.getElementById('vLlaves').addEventListener('click', ev => {
  const b = ev.target.closest('button'); if (!b) return;
  const k = b.dataset.k; E[k] = !E[k]; marcar(k, E[k]);
  if (k === 'ronda' && E.ronda) for (const x of document.querySelectorAll('#vPoses button')) x.setAttribute('aria-pressed', 'false');
  if (!V) return;
  if (k === 'linterna') V.linterna(E.linterna); else if (k === 'laser') V.laser(E.laser); else if (k === 'girar') V.girar(E.girar);
  else if (k === 'plena') V.luzPlena(E.plena); else if (k === 'ronda') V.ronda(E.ronda);
});
if (reduce.matches) marcar('girar', false);
window.UEVISOR = { get V() { return V; }, crear, get fallo() { return fallo; } };
})();
