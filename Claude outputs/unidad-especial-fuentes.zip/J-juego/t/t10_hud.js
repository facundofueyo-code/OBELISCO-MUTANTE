// HUD: peleando solo contra bichos no dice «TE VIERON»; en combate con el jugador, sí.
const H=require('../../harness.js');const INST=require('./inst.js');
(async()=>{const h=await H.open(__dirname+'/../obelisco-mutante.html');const ev=c=>h.ev(c);
  try{await h.start();await ev("RETEN.ir({bichos:true});1");await ev(INST);await ev("window.__inmortal=true;1");
    const r=[];for(let k=0;k<9;k++){await h.step(10);r.push(await ev("(()=>{const e=UEB.estado(),u=UE.estado();return [+T.toFixed(0),+e.alerta.toFixed(2),e.combate,u.combate,!!UE.red.uc,UE.soldados.filter(s=>s.vivo).length,$('#ueVisto')?$('#ueVisto').style.display:'?']})()"));}
    console.log('bichos',JSON.stringify(r));
    await ev("RETEN.ir({bichos:false});1");await h.step(.5);await ev("window.__inmortal=true;P.pos.set(-404,floorAt(-404,607),607);P.vel.set(0,0,0);1");
    const q=[];for(let k=0;k<4;k++){await h.step(2);q.push(await ev("(()=>{const e=UEB.estado();return [+T.toFixed(0),+e.alerta.toFixed(2),e.combate,e.ang===null?null:+e.ang.toFixed(2),!!UE.red.uc,$('#ueVisto')?$('#ueVisto').style.display:'?']})()"));}
    console.log('jugador',JSON.stringify(q));
  }catch(e){console.log('EXC',e.message.slice(0,300));}
  console.log('err',JSON.stringify(h.errors.slice(0,4)));await h.close();})();
