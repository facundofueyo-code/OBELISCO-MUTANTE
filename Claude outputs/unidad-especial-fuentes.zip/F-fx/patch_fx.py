#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Parche F (efectos, sonido, avisos y vista táctica) sobre base.html.

Uso:  python3 patch_fx.py entrada.html salida.html

Inserta todo delante de los marcadores /*UE:…*/ y <!--UE:…--> y los deja, así se compone con los
parches de los demás en cualquier orden. No edita ninguna línea existente del juego: solo agrega.
Necesita mod_fx.js en la misma carpeta.
"""
import sys, os

AQUI = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------------------------
# CSS (va delante de /*UE:css*/). Usa las variables del HUD del juego: --bone, --sodium, --bile, --murk, --hud.
# ---------------------------------------------------------------------------------------------
CSS = r"""
/* UE·F — radio interceptada, detección, dirección del daño, aviso de granada y vista táctica */
#ueRadio{position:absolute;left:16px;bottom:calc(98px + env(safe-area-inset-bottom,0px));width:min(440px,46vw);display:flex;flex-direction:column;align-items:flex-start;gap:3px}
#ueRadio .lbl{opacity:0;transition:opacity .25s;margin-bottom:1px}
#ueRadio.on .lbl{opacity:1}
#ueRadio .lbl i{font-style:normal;color:#ff5a4a;margin-right:6px}
.ue-rl{max-width:100%;box-sizing:border-box;background:rgba(0,0,0,.5);border-left:3px solid var(--sodium);padding:3px 10px 3px 8px;font-size:14px;line-height:1.3;opacity:0;transform:translateX(-10px);transition:opacity .16s,transform .16s}
.ue-rl.in{opacity:1;transform:none}
.ue-rl.out{opacity:0;transition:opacity .35s}
.ue-rl b{font-size:11px;letter-spacing:.14em;color:var(--sodium);margin-right:8px;white-space:nowrap}
.ue-rl.pel{border-left-color:#ff3b3b;background:rgba(118,8,18,.74);color:#fff;font-weight:700}
.ue-rl.pel b{color:#ffc2b8}
#ueRet{position:absolute;left:50%;top:50%;width:clamp(320px,40vmin,520px);height:clamp(320px,40vmin,520px);transform:translate(-50%,-50%);overflow:visible;text-shadow:none}
#ueRet path,#ueRet circle{fill:none;stroke-linecap:round}
#ueRet .b{stroke:#000;stroke-opacity:.55}
#ueDet .pista{stroke:currentColor;stroke-opacity:.34}
#ueDet .rell{stroke:currentColor}
#ueDet path.punta{fill:currentColor;stroke:#000;stroke-opacity:.6;stroke-width:.7}
#ueVisto{font:700 7.4px var(--hud);letter-spacing:1.6px;text-anchor:middle;fill:#ff4a3a;stroke:#000;stroke-width:1.6px;stroke-opacity:.8;paint-order:stroke}
#ueGolpes path.cuna{fill:#ff2f2f;fill-opacity:.9;stroke:#3a0006;stroke-opacity:.75;stroke-width:1}
#ueGranadas .gr{color:var(--sodium)}
#ueGranadas .gr.letal{color:#ff4a3a}
#ueGranadas path.fl{fill:currentColor;stroke:#000;stroke-opacity:.7;stroke-width:1}
#ueGranadas circle.fondo{fill:rgba(0,0,0,.62);stroke:currentColor;stroke-width:1.4}
#ueGranadas path.ic{fill:currentColor;stroke:currentColor;stroke-width:1.5;stroke-linejoin:round}
#ueGranadas text{font:700 8.6px var(--hud);letter-spacing:.3px;text-anchor:middle;fill:currentColor;stroke:#000;stroke-width:1.8px;stroke-opacity:.8;paint-order:stroke}
@media (max-width:640px){#ueRadio{width:min(300px,62vw)}.ue-rl{font-size:12px}}
/* vista táctica (F2): chica arriba a la derecha; con Shift+F2, grande y centrada */
#ueTac{position:fixed;z-index:40;right:16px;top:calc(84px + env(safe-area-inset-top,0px));width:min(420px,46vh,40vw);pointer-events:none;box-sizing:border-box;
  background:var(--murk);border:1px solid rgba(239,230,210,.28);font:600 11px/1.4 var(--hud);color:var(--bone);text-shadow:none}
#ueTac .ue-cab{display:flex;justify-content:space-between;align-items:baseline;gap:10px;padding:4px 8px;border-bottom:1px solid rgba(239,230,210,.18)}
#ueTac .ue-cab b{font-size:10px;letter-spacing:.2em;color:var(--sodium);white-space:nowrap}
#ueTac .ue-cab span{font-size:10px;opacity:.65;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#ueTac canvas{display:block;width:100%;aspect-ratio:1}
#ueTac .ue-tx{padding:5px 8px 7px;border-top:1px solid rgba(239,230,210,.18)}
#ueTac p{margin:0 0 3px}
#ueTac .es{margin-top:2px}
#ueTac .es b{color:var(--sodium);letter-spacing:.14em}
#ueTac em{font-style:normal;font-weight:700;letter-spacing:.08em}
#ueTac .ro{color:#ff5a4a}
#ueTac .am{color:var(--sodium)}
#ueTac .ve{color:var(--bile)}
#ueTac .uc{color:#ffe14a}
#ueTac .al{color:#ff5a4a}
#ueTac .ley{margin:5px 0 0;padding-top:4px;border-top:1px solid rgba(239,230,210,.14);font-size:10px;line-height:1.6;opacity:.9;word-spacing:1px}
#ueTac i{display:inline-block;font-style:normal;width:9px;height:9px;border-radius:50%;margin:0 4px 0 0;vertical-align:-1px;box-sizing:border-box}
#ueTac .ley i{margin-left:9px}
#ueTac .ley i:first-child,#ueTac .ley br+i{margin-left:0}
#ueTac .ley i.an{border:2px solid #ff4a3a}
#ueTac .ley i.cr{width:auto;height:auto;border-radius:0;color:#ffe14a;font-weight:700;vertical-align:0}
#ueTac .ley i.li{width:14px;height:0;border-radius:0;border-top:1px solid var(--bone);vertical-align:3px}
#ueTac .ley i.ca{width:14px;height:0;border-radius:0;border-top:2px dashed var(--bone);vertical-align:3px;opacity:.7}
#ueTac .ley i.cu{border-radius:0;border:1.5px solid var(--bone)}
#ueTac .ley i.la{width:14px;height:0;border-radius:0;border-top:1.5px solid #ff2828;vertical-align:3px}
#ueTac .ley i.tr{width:0;height:0;border-radius:0;border:5px solid transparent;border-left:9px solid #fff;border-right:0;vertical-align:-1px}
#ueTac .ley i.co{border-radius:0;background:#966c2c}
#ueTac table{border-collapse:collapse;margin:3px 0 9px;width:100%}
#ueTac td{padding:1px 7px 1px 0;vertical-align:top}
#ueTac td:nth-child(-n+3){white-space:nowrap}
#ueTac td u{text-decoration:none;opacity:.6}
#ueTac .nw{white-space:nowrap}
#ueTac tr.mu{opacity:.45}
#ueTac .vb{display:inline-block;width:32px;height:5px;background:rgba(0,0,0,.6);border:1px solid rgba(239,230,210,.3);vertical-align:1px}
#ueTac .vb span{display:block;height:100%;background:#c0182f}
#ueTac.gr{--l:min(calc(92vh - 28px),calc(96vw - 424px));right:auto;left:50%;top:50%;transform:translate(-50%,-50%);width:calc(var(--l) + 424px);display:grid;grid-template-columns:var(--l) 422px;grid-template-rows:auto var(--l);font-size:12px}
#ueTac.gr .ue-cab{grid-column:1/-1}
#ueTac.gr .ue-tx{border-top:0;border-left:1px solid rgba(239,230,210,.18);overflow:hidden;padding:9px 10px}
#ueTac.gr .ley{font-size:11px;line-height:1.75}
/* con la vista táctica chica prendida, los mensajes de la derecha se corren para no quedar tapados */
body.ue-tac #feed{right:calc(32px + min(420px,46vh,40vw))}
"""

# ---------------------------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------------------------
# adentro de #hud (se oculta con el HUD). Todo con position:absolute para no mover el HUD existente (que es flex).
HUD = ('<div id="ueRadio" aria-live="off"><span class="lbl"><i>&#9673;</i>RADIO INTERCEPTADA</span></div>'
       '<svg id="ueRet" viewBox="-100 -100 200 200" aria-hidden="true"></svg>\n  ')
# fuera del HUD: la vista táctica se ve siempre (también en pausa y al morir)
CAPAS = ('<div id="ueTac" hidden><div class="ue-cab"><b>VISTA T&Aacute;CTICA</b><span></span></div>'
         '<canvas></canvas><div class="ue-tx"></div></div>\n')
AYUDA = ('<dt><kbd>F2</kbd></dt><dd>Vista táctica: ver qué sabe y qué decide el escuadrón '
         '(<kbd>Shift</kbd>+<kbd>F2</kbd>: grande)</dd>\n      ')

# ---------------------------------------------------------------------------------------------
# enganches en el código del juego (todos delante de un marcador)
# ---------------------------------------------------------------------------------------------
ENGANCHES = [
    ('/*UE:fx*/',     'UEFX.update(dt);UEHUD.update(dt);UEDBG.update(dt);'),   # frame(): siguen aunque no haya partida
    ('/*UE:reset*/',  'UEFX.reset();UEHUD.reset();UESND.reset();'),            # resetGame()
    ('/*UE:pausa*/',  'UESND.pausa(v);'),                                      # setPaused(v): corta la radio que esté sonando
    ('/*UE:teclas*/', 'UEDBG.tecla(e);'),                                      # keydown: F2 y Shift+F2
]


def aplicar(s):
    """Devuelve el HTML con el parche F aplicado. Falla fuerte si un marcador no aparece exactamente una vez."""
    def rep(viejo, nuevo, n=1):
        nonlocal s
        c = s.count(viejo)
        assert c == n, f'ancla: esperaba {n}, hay {c}: {viejo[:80]!r}'
        s = s.replace(viejo, nuevo)

    def antes(marca, codigo):            # inserta delante de un marcador y lo deja
        rep(marca, codigo + marca)

    mod = open(os.path.join(AQUI, 'mod_fx.js'), encoding='utf-8').read()
    antes('/*UE:css*/', CSS.strip('\n') + '\n')
    antes('<!--UE:hud-->', HUD)
    antes('<!--UE:capas-->', CAPAS)
    antes('<!--UE:ayuda-->', AYUDA)
    antes('/*UE:modulos*/', mod.rstrip('\n') + '\n')
    for marca, codigo in ENGANCHES:
        antes(marca, codigo)
    return s


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    src, dst = sys.argv[1], sys.argv[2]
    html = aplicar(open(src, encoding='utf-8').read())
    open(dst, 'w', encoding='utf-8').write(html)
    print(f'patch_fx: {src} -> {dst} ({len(html)} bytes)')
