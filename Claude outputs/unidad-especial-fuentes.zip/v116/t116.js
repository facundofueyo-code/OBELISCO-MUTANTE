/* Prueba de v116/base.html con el arnés + volcado de la zona del retén (dump.js adaptado a la 1.16.0).
   Uso: node t116.js [ruta del arnés]   (por defecto ../harness.js) */
const fs = require('fs'), path = require('path');
const HP = path.resolve(process.argv[2] || path.join(__dirname, '..', 'harness.js'));
const H = require(HP);
const t0 = Date.now(); const log = (...a) => console.log(((Date.now() - t0) / 1000).toFixed(1) + 's', ...a);

/* volcado: mismo formato que dump.js ({X0,Z0,W,H,B,Hh,G,cars,obs,sub,mh,carIds}) y además P (enP), circ, piso, canteros, arboles */
const DUMP = `(()=>{
  const X0=-640,X1=-160,Z0=500,Z1=720,W=X1-X0,H=Z1-Z0;const B=[],Hh=[],G=[],P=[];
  for(let z=Z0;z<Z1;z++)for(let x=X0;x<X1;x++){const k=eCell(x+.5,z+.5);B.push(k<0?2:enB[k]);Hh.push(k<0?0:enH[k]);P.push(k<0?0:enP[k]);G.push(cellAt(x+.5,z+.5));}
  const inW=(x,z)=>x>X0&&x<X1&&z>Z0&&z<Z1,r2=v=>+(+v).toFixed(2),r3=v=>+(+v).toFixed(3);
  const cars=[];VCARS.forEach((c,vi)=>{if(!inW(c.x,c.z))return;cars.push({id:c.S.id,mi:c.mi,x:r2(c.x),z:r2(c.z),a:r3(c.a),L:r2(c.L),W:r2(c.W),H:r2(c.H),lit:c.lit||null,
    vi,malla:c.grp?'propia':'instanciada',kind:c.kind||null,by:r3(c.by),tx:r3(c.tx||0),tz:r3(c.tz||0),st:c.st,cs:(c.cs||[]).map(q=>[r2(q.x),r2(q.z),r2(q.r),r2(q.h)])});});
  const obs=obstacles.filter(b=>b.x1>X0&&b.x0<X1&&b.z1>Z0&&b.z0<Z1).map(b=>({x0:r2(b.x0),x1:r2(b.x1),z0:r2(b.z0),z1:r2(b.z1),y0:r2(b.y0||0),y1:r2(b.y1),glass:b.glass?1:0}));
  const sub=SUBTE.filter(s=>inW(s.x,s.z)).map(s=>({x:+s.x.toFixed(1),z:+s.z.toFixed(1)}));
  const mh=(typeof MH!=='undefined'?MH:[]).filter(s=>inW(s.x,s.z)).map(s=>({x:+s.x.toFixed(1),z:+s.z.toFixed(1)}));
  /* círculos de choque que no son de autos en x∈[-470,-300], z∈[590,622] */
  const circ=circles.filter(q=>!q.dead&&!(q.brk&&q.brk.k==='car')&&q.x>=-470&&q.x<=-300&&q.z>=590&&q.z<=622).map(q=>{const o={x:r2(q.x),z:r2(q.z),r:r2(q.r)};if(q.h!==undefined)o.h=r2(q.h);if(q.low)o.low=1;if(q.brk)o.k=q.brk.k;return o;});
  /* árboles (círculos 'tree') y canteros de árbol de la sección B en toda la ventana */
  const arboles=circles.filter(q=>!q.dead&&q.brk&&q.brk.k==='tree'&&inW(q.x,q.z)).map(q=>({x:r2(q.x),z:r2(q.z),r:r2(q.r),road:q.brk.t.road?1:0,k:q.brk.t.k}));
  const canteros=((PISO.GS.B&&PISO.GS.B.pits)||[]).filter(p=>inW(p.x,p.z)).map(p=>({x:r2(p.x),z:r2(p.z),size:p.size,nx:r3(p.nx),nz:r3(p.nz),tree:p.tree}));
  /* corte de alturas del piso a lo ancho de Av. de Mayo */
  const piso=[-438,-400].map(x=>{const zs=[],y=[],py=[],g=[];for(let z=590;z<=622.001;z+=.5){zs.push(z);y.push(r3(floorAt(x,z)));py.push(r3(PISO.y(x,z)));g.push(cellAt(x,z));}return {x,z:zs,y,py,g};});
  return {X0,Z0,W,H,B,Hh,G,cars,obs,sub,mh,carIds:CARS.map(c=>c.id),P,circ,arboles,canteros,piso,nVCARS:VCARS.length};})()`;

(async () => {
  const UE = path.join(__dirname, '..');
  log('arnés', HP, '· turnos ocupados antes de abrir:', ['.turno0', '.turno1'].filter(f => fs.existsSync(path.join(UE, f))).join(',') || 'ninguno');
  let t = Date.now(); const h = await H.open(path.join(__dirname, 'base.html')); const tOpen = Date.now() - t;
  log('open', (tOpen / 1000).toFixed(1) + ' s');
  try {
    t = Date.now(); const st = await h.start(); const tStart = Date.now() - t;
    log('start', (tStart / 1000).toFixed(1) + ' s', JSON.stringify(st), 'errores:', h.errors.length);
    t = Date.now(); const d = await h.ev(DUMP);
    fs.writeFileSync(path.join(__dirname, 'mapa-reten.json'), JSON.stringify(d));
    log('volcado', ((Date.now() - t) / 1000).toFixed(1) + ' s', `autos ${d.cars.length} (VCARS ${d.nVCARS}) obs ${d.obs.length} subte ${d.sub.length} mh ${d.mh.length} circ ${d.circ.length} árboles ${d.arboles.length} canteros ${d.canteros.length}`);
    const S = "JSON.stringify({T:+T.toFixed(1),STAGE,wave,en:enemies.length,toSpawn,hp:+P.hp.toFixed(0),running,over,x:+P.pos.x.toFixed(1),y:+P.pos.y.toFixed(2),z:+P.pos.z.toFixed(1)})";
    await h.ev('intermission=.1;1');
    for (let i = 0; i < 5; i++) { const r = await h.step(5, 1 / 60, 'P.hp=100'); log('oleada +5 s', JSON.stringify(r), await h.ev(S), 'errores:', h.errors.length); }
    const ar = await h.alReten();
    log('alReten', JSON.stringify(ar), await h.ev("JSON.stringify({piso:+floorAt(P.pos.x,P.pos.z).toFixed(3),cel:cellAt(P.pos.x,P.pos.z),autoCerca:Math.min(...circles.filter(q=>q.brk&&q.brk.k==='car'&&!q.dead).map(q=>+(Math.hypot(q.x-P.pos.x,q.z-P.pos.z)-q.r).toFixed(2)))})"));
    const r = await h.step(5); log('+5 s en el retén', JSON.stringify(r), await h.ev(S));
    log('errores:', h.errors.length ? '\n' + h.errors.join('\n').slice(0, 3000) : 'ninguno');
  } finally { await h.close(); log('cerrado'); }
})().catch(e => { log('FALLA', e.message.slice(0, 1500)); process.exit(1); });
