// sim/prueba_modelo.js — prueba los caminos que solo corren en el juego: modelo (ENV.vista), THREE presente, debug/estado/reset.
// node sim/prueba_modelo.js
global.THREE = { Vector3: class { constructor() { this.x = 0; this.y = 0; this.z = 0; } } };
const P = require('path').join(__dirname, '..') + '/';
const { crearUE, UE_TUNE } = require(P + 'ue_ia.js'); const { crearMundo } = require(P + 'sim/mundo.js'); const { crearJugadores } = require(P + 'sim/jugadores.js');
const mapa = require(P + '../mapa-reten.json');
const M = crearMundo(mapa, { semilla: 5 });
let nUpd = 0, nDisp = 0, nRayo = 0, nDispose = 0, malE = 0;
M.ENV.vista = s => ({
  root: { position: { set(x, y, z) { if (![x, y, z].every(Number.isFinite)) malE++; } }, rotation: { y: 0 } }, e: {},
  update(dt) { nUpd++; for (const k of ['agach', 'tierra', 'apunta', 'mYaw', 'mPitch', 'asoma', 'recarga', 'salto', 'lanza', 'senal', 'radio', 'aturdido']) if (!Number.isFinite(this.e[k])) malE++; },
  boca(v) { v.x = s.x; v.y = s.y + 1.5; v.z = s.z; return v; }, disparo() { nDisp++; },
  rayo(o, d) { nRayo++; return null; }, dispose() { nDispose++; }
});
const UE = crearUE(M.ENV, UE_TUNE); M.conectar(UE); M.armarReten();
const bot = crearJugadores(M, UE).decente({ inicio: { x: -326, z: 606 } }); let evs = [];
while (M.t < 120 && M.jugador.vivo) { bot.paso(1 / 30, evs); M.paso(1 / 30); evs = M.sacarEventos(); }
const d = UE.debug(), e = UE.estado();
console.log('vista: update', nUpd, 'disparo', nDisp, 'rayo', nRayo, 'entradas raras', malE, '| debug soldados', d.soldados.length, 'escuadrones', d.escuadrones.length, 'claves', Object.keys(d.soldados[0]).join(','));
console.log('estado', JSON.stringify(e), '| objetivos', UE.objetivos().length);
UE.reset(); console.log('reset: dispose', nDispose, 'soldados', UE.soldados.length, 'escuadrones', UE.escuadrones.length);
for (let i = 0; i < 60; i++) { M.paso(1 / 30); } console.log('después del reset corre:', UE.soldados.filter(s => s.vivo).length, 'vivos');
