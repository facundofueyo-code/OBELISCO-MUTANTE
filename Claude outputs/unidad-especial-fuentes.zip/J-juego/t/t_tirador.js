const H=require('../../harness.js');const INST=require('./inst.js');
const F=__dirname+'/../obelisco-mutante.html';
(async()=>{const h=await H.open(F);const ev=c=>h.ev(c);
  try{await h.start();await ev("RETEN.ir({bichos:false});1");await ev(INST);await h.step(.5);
    await ev("window.__inmortal=true;P.pos.set(-410,floorAt(-410,607),607);P.vel.set(0,0,0);P.yaw=Math.PI/2;1");
    const out=[];for(let k=0;k<50;k++){await h.step(.5);out.push(await ev("(()=>{const s=UE.soldados.find(q=>q.rol==='tirador');return [+T.toFixed(1),s.estado,s.tarea,s.tir,s.ve?1:0,s.blanco,s.enTiro?1:0,+s.supr.toFixed(2),s.elev?1:0,+s.x.toFixed(1),+s.z.toFixed(1),+s.y.toFixed(2),s.laser?1:0,s.tierra.toFixed(1)]})()"));}
    console.log(out.map(o=>o.join(' ')).join('\n'));
    console.log(JSON.stringify(await ev("({ev:__L.ev,bala:__L.bala})")));
  }catch(e){console.log('EXC',e.message.slice(0,300));}
  console.log('err',JSON.stringify(h.errors.slice(0,3)));await h.close();})();
