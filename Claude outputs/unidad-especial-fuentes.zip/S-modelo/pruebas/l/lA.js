/* cada rol de pie apuntando: tres cuartos de frente, perfil y espalda */
const roles=['jefe','asalto','granadero','tirador'],vis=[];
for(const r of roles)for(const [az,n] of [[.75,'3/4'],[1.57,'perfil'],[3.5,'espalda']])vis.push({rol:r,pose:'Apunta',t:1.6,az,el:.06,dist:3.25,obj:[0,.92,0],txt:r+' · '+n,
  fn2:I=>{const s=I.soldados[0];s.u.e.mYaw=0;}});
/* orden por columnas: un rol por columna */
const orden=[];for(let f=0;f<3;f++)for(let c=0;c<4;c++)orden.push(vis[c*3+f]);
module.exports={cols:4,vistas:orden};
