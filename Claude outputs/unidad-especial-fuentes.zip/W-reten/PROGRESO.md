# W-reten · progreso (base 1.16.0)

`recon/` y `pruebas/` son de la base vieja (1.14.0): no se usan. Las pruebas nuevas están en `t2/`.

## Hecho (todo corrido con el arnés, sin errores)
- `mod_reten.js` + `patch_reten.py` (aplican sobre `v116/base.html`; compuestos con F en los dos órdenes).
- Lugar: furgones, vallas, camioneta, reflectores (haz, mancha horneada con sombras, lente, destello), balizas, grupo electrógeno,
  fila de autos (6 movidos, 2 que quedan), puertas abiertas, balazos, sangre, bolsas, tacho con fuego y humo, casquillos, papeles, pintada.
- `RETEN.datos` verificado contra la grilla (`RETEN.verificar()`), `RETEN.luz`, `RETEN.ir` + botones, `reset`, «Otra vuelta».
- Pruebas 1–6 de TAREA.md (`t2/tfinal.log`, `t2/t3final*.log`, `t2/t7.js`), capturas finales en `capturas/final-*`.
- `INFORME.md`.

## Falta / ideas
- Chispas y sonido al pegarle a un furgón; reflectores que se puedan romper; compuerta baja en la camioneta.

## Decisiones
- Barricada en x=−438 (como la SPEC). Furgones = `ambulancia` negra sin ploteo ni patente, geometría unida, blindados (cajas de `obstacles`).
- Vallas, camioneta y bolsas = cajas de `obstacles` (salto del jugador como en la 9 de Julio). Veredas abiertas: flanqueo.
- Fila: autos existentes movidos (siguen instanciados); lo agregado a cada auto va en `c.rg` (carBoom lo esconde, UNDO lo vuelve).
- Pintada sobre una persiana propia: los frentes de FRENTES cambian entre sesiones.
- `armar()` después de `FRENTES.build('B')` (antes de `navInit`, para que la grilla del Shajar también tome las cajas).
