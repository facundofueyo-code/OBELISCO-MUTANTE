# Parche J (pegamento de la unidad especial) para Obelisco Mutante con marcadores UE.
# Uso: python3 patch_pegamento.py entrada.html salida.html
# Pega el modelo (UEM, ue_modelo.js), la IA (crearUE, ue_ia.js) y el pegamento (UEG, mod_pegamento.js) en el
# marcador de módulos, y engancha: update, reset, precalentado, fin de partida, bala del jugador y el título
# de la pantalla de fin. Se aplica DESPUÉS de los parches de F, G, M y W (los usa si están).
# Si hay una copia corregida de ue_ia.js o ue_modelo.js en piezas/ (esta carpeta), usa esa.
import sys, os
src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()
AQUI = os.path.dirname(os.path.abspath(__file__))
UE = os.path.dirname(AQUI)

def rep(viejo, nuevo, n=1):
    global s
    c = s.count(viejo)
    assert c == n, f'ancla: esperaba {n}, hay {c}: {viejo[:80]!r}'
    s = s.replace(viejo, nuevo)

def antes(marca, codigo):            # inserta delante de un marcador y lo deja
    rep(marca, codigo + marca)

def pieza(*partes):                  # la copia corregida de piezas/ si existe; si no, la original
    p = os.path.join(AQUI, 'piezas', partes[-1])
    if not os.path.exists(p):
        p = os.path.join(UE, *partes)
    t = open(p, encoding='utf-8').read()
    for m in ('/*UE:', '<!--UE:'):
        assert m not in t, f'{p}: el código no puede contener texto de marcadores ({m})'
    return t

modelo = pieza('S-modelo', 'ue_modelo.js')
ia = pieza('A-ia', 'ue_ia.js')
pega = pieza('J-juego', 'mod_pegamento.js')
assert 'const UEM=' in modelo and 'function crearUE' in ia and 'const UEG=' in pega

antes('/*UE:modulos*/', modelo.rstrip('\n') + '\n' + ia.rstrip('\n') + '\n' + pega.rstrip('\n') + '\n')
antes('/*UE:update*/', 'UEG.update(dt);')
antes('/*UE:reset*/', 'UEG.reset();')
antes('/*UE:warm-on*/', 'UEG.warm(true);')
antes('/*UE:warm-off*/', 'UEG.warm(false);')
antes('/*UE:fin*/', 'UEG.fin();')
# bala del jugador: si el primero que encuentra es un soldado, la bala termina ahí (continue del for de fire())
antes('/*UE:rayo-jugador*/', 'if(UEG.balaJugador(ray.o,d,w,hitE?best:Infinity,wall,range,i)){anyHit=true;continue;}')
# pantalla de fin: «Testigo eliminado» si lo mataron ellos
rep("$('#over-title').textContent=pick(", "$('#over-title').textContent=UEG.titulo()||/*UE:J*/pick(")
open(dst, 'w', encoding='utf-8').write(s)
