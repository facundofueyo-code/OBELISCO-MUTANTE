const L4=require('./l4.js');const solo=L4.vistas[6].fn2;
const v=(rol,pose,t,az,el,txt,o={})=>Object.assign({rol,pose,t,az,el,dist:.8,obj:[0,1.62,0],txt},o);
module.exports={cols:4,vistas:[
  v('todos','Apunta',2,.45,.12,'los cuatro, linternas (noche)',{luz:true,obj:[-.3,.9,-.4],dist:8}),
  v('todos','Apunta',2,.2,.02,'desde el jugador (1,6 m, 9 m)',{luz:true,obj:[-.3,1.3,-.4],dist:9}),
  v('jefe','De pie',1.5,0,.03,'cabeza de frente (luz plena)',{plena:true}),
  v('jefe','Apunta',1.5,.5,.05,'cabeza 3/4 (noche)',{fn2:I=>{I.soldados[0].u.root.rotation.y=.35;}}),
  v('jefe','De pie',.5,1.57,.0,'fusil y granada',{plena:true,obj:[0,1.0,0],dist:1.35,fn2:solo}),
  v('asalto','De pie',.5,1.57,.0,'escopeta',{plena:true,obj:[0,1.0,0],dist:1.35,fn2:solo}),
  v('tirador','De pie',.5,1.57,.0,'fusil de tirador',{plena:true,obj:[0,1.0,0],dist:1.55,fn2:solo}),
  v('todos','De pie',2,0,.05,'siluetas (luz plena)',{plena:true,obj:[-.3,.9,-.4],dist:8})]};
