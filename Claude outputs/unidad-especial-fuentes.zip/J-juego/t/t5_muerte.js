// Prueba 5: al jugador lo matan los soldados → «Testigo eliminado»; «Otra vuelta» vuelve al retén con todo de nuevo.
// Y al revés: si lo matan los bichos, el título de siempre.
const H=require('../../harness.js'),fs=require('fs');
const INST=require('./inst.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
const OUT=process.argv[3]||__dirname+'/t5.json';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto');const R={};const ev=c=>h.ev(c);
  try{
    await h.start();await ev("RETEN.ir({bichos:false});1");await ev(INST);await h.step(.5);
    /* parado en la luz frente al retén, sin cubrirse */
    await ev("P.pos.set(-404,floorAt(-404,607),607);P.vel.set(0,0,0);P.yaw=Math.PI/2;1");
    let k=0;for(;k<60;k++){await h.step(1);if(await ev("over"))break;}
    R.muerte1=await ev("({T:+T.toFixed(1),over,running,hp:Math.round(P.hp),titulo:$('#over-title').textContent,ultimo:__L.hp.slice(-3),danos:__L.danos.length})");
    lg('muerte por soldados',JSON.stringify(R.muerte1));
    await new Promise(r=>setTimeout(r,1500));
    R.pantalla=await ev("({visible:!$('#scr-over').hidden,boton:$('#btnAgain').textContent.trim()})");lg('pantalla',JSON.stringify(R.pantalla));
    /* «Otra vuelta» */
    await ev("$('#btnAgain').click();1");await h.step(1);
    R.otra=await ev("({running,over,stage:STAGE,pos:[+P.pos.x.toFixed(0),+P.pos.z.toFixed(0)],hp:P.hp,sold:UE.soldados.map(s=>[s.nombre,s.vivo,s.estado,Math.round(s.hp)]),est:UE.estado(),cajas:pickups.length,gran:GRAN.lista.length,titulo:UEG.titulo()})");
    lg('otra vuelta',JSON.stringify(R.otra));
    /* muerte por bichos en la partida de siempre: el título no cambia */
    await ev("RETEN.ir({bichos:true});1");await h.step(.2);
    await ev("P.pos.set(-470,floorAt(-470,606),606);1");      // detrás del retén, junto a las bocas de subte: lejos de la vista de los soldados
    for(k=0;k<90;k++){await h.step(1);if(await ev("over"))break;}
    R.muerte2=await ev("({T:+T.toFixed(1),over,titulo:$('#over-title').textContent,bichos:enemies.length})");lg('muerte 2',JSON.stringify(R.muerte2));
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(OUT,JSON.stringify(R));
  await h.close();lg('cerrado');
})();
