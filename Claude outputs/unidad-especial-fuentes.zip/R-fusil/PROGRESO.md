# R-fusil — progreso

(Se actualiza seguido. Si el trabajo se corta, quien siga lee esto primero.)

## Estado
- [x] Leída la SPEC, la TAREA y el código de armas, MOV, cajas, autos, audio, bucle.
- [ ] Datos del mundo en ejecución (cantidad de obstáculos, autos, costo de floorAt).
- [ ] `mod_fusil.js` + `patch_fusil.py`
- [ ] GRAN (física, arco, explosión)
- [ ] Fusil (modelo, manos, recarga, ráfaga, sonido, HUD)
- [ ] Botín (cajas, UEB.botin)
- [ ] Granada del jugador (tecla G, gesto)
- [ ] Pruebas con arnés + capturas
- [ ] INFORME.md

## Decisiones (ver INFORME.md al final)
