#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Arma prueba_fx.html: una página suelta y liviana para iterar lo visual sin abrir el juego.

Toma del juego (../base-view.txt) el CSS y el HTML del HUD, las partículas y el audio TAL CUAL, les aplica
el mismo CSS/HTML del parche (patch_fx.py) y pega mod_fx.js sin tocar. Así lo que se ve acá es lo que va al juego.
También genera prueba_mapa.js con la grilla real del retén (../mapa-reten.json) para el fondo de la vista táctica.

Uso:  python3 armar_prueba.py
"""
import os, json, base64
import patch_fx

AQUI = os.path.dirname(os.path.abspath(__file__))
UE = os.path.dirname(AQUI)
L = open(os.path.join(UE, 'base-view.txt'), encoding='utf-8').read().split('\n')


def lineas(a, b):
    """líneas a…b de base-view.txt (numeradas desde 1, las dos incluidas)"""
    return '\n'.join(L[a - 1:b])


def entre(ini, fin):
    """texto del juego desde la línea que contiene `ini` hasta la anterior a la que contiene `fin`"""
    i = next(k for k, l in enumerate(L) if ini in l)
    j = next(k for k, l in enumerate(L) if fin in l and k > i)
    return '\n'.join(L[i:j])


# --- CSS y HUD del juego, con mis agregados delante de los marcadores ---
css = entre(':root{', '</style>')
assert css.count('/*UE:css*/') == 1
css = css.replace('/*UE:css*/', patch_fx.CSS + '/*UE:css*/')
hud = entre('<div id="game"></div>', '<div id="touch" hidden>')
for marca, cod in (('<!--UE:hud-->', patch_fx.HUD), ('<!--UE:capas-->', patch_fx.CAPAS)):
    assert hud.count(marca) == 1
    hud = hud.replace(marca, cod + marca)
hud = hud.replace('<div id="hud" hidden>', '<div id="hud">').replace('<div id="cross" hidden>', '<div id="cross">')

# --- código del juego que la página usa tal cual ---
particulas = entre('const PMAX=800;', '/* ---------- decals')
audio = entre('let AC=null,master=null,noiseBuf=null;', '/* una voz humana rota')
for must in ('function spawnPart(', 'function updateParticles(', 'function auGate(', 'function auOneShot(', 'function noise(', 'function shCurve(', 'function initVox('):
    assert must in particulas + audio, must

mod = open(os.path.join(AQUI, 'mod_fx.js'), encoding='utf-8').read()
tpl = open(os.path.join(AQUI, 'prueba_plantilla.html'), encoding='utf-8').read()
for clave, txt in (('/*__CSS__*/', css), ('<!--__HUD__-->', hud), ('/*__PARTICULAS__*/', particulas), ('/*__AUDIO__*/', audio), ('/*__MOD__*/', mod)):
    assert tpl.count(clave) == 1, clave
    tpl = tpl.replace(clave, txt)
open(os.path.join(AQUI, 'prueba_fx.html'), 'w', encoding='utf-8').write(tpl)

# --- grilla real del retén, compacta ---
dst = os.path.join(AQUI, 'prueba_mapa.js')
if not os.path.exists(dst):
    d = json.load(open(os.path.join(UE, 'mapa-reten.json')))
    b64 = lambda a: base64.b64encode(bytes(a)).decode()
    open(dst, 'w').write('window.MAPA=' + json.dumps({'X0': d['X0'], 'Z0': d['Z0'], 'W': d['W'], 'H': d['H'], 'B': b64(d['B']), 'Hh': b64(d['Hh']),
                                                    'cars': d['cars']}) + ';\n')
print('prueba_fx.html armada:', len(tpl), 'bytes')
