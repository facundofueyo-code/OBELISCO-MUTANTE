// Instrumentación que se mete en la página (h.ev(INST)): cuenta radio, balas, daño, eventos, fichas y explosiones.
module.exports=`(()=>{if(window.__L)return 'ya';
window.__L={radio:[],bala:{n:0},danos:[],ev:{},fichMax:0,log:[],expl:[],fichas:0,cuadros:0,pegaJ:[]};
const E=UEG.ENV,L=window.__L,r1=v=>+(+v).toFixed(2);
const r0=E.radio;E.radio=(s,c,t)=>{L.radio.push([r1(T),s&&s.nombre,c,t]);r0(s,c,t);};
const b0=E.bala;E.bala=ev=>{const B=L.bala;B.n++;B['p_'+ev.pega]=(B['p_'+ev.pega]||0)+1;B['m_'+ev.modo]=(B['m_'+ev.modo]||0)+1;B['t_'+ev.tipo]=(B['t_'+ev.tipo]||0)+1;
  if(ev.pega==='jugador')L.pegaJ.push([r1(T),ev.s.nombre,ev.tipo,ev.modo]);b0(ev);};
const h0=E.herirJugador;E.herirJugador=(d,x,z,t)=>{L.danos.push([+T.toFixed(3),+d.toFixed(2),t]);h0(d,x,z,t);};
L.hp=[];const hp0=hurtPlayer;hurtPlayer=function(n,g){L.hp.push([+T.toFixed(2),Math.round(n)]);if(window.__inmortal&&P.hp-n<=5)P.hp=100;return hp0(n,g);};
const e0=E.evento;E.evento=(n,d)=>{L.ev[n]=(L.ev[n]||0)+1;
  if(/granada|baja|refuerzo|contacto|combate|perdido|busqueda|limpio|guardia|flanco$|jefe_caido|jugador_muerto/.test(n))L.log.push([r1(T),n,d&&d.s?d.s.nombre:(d&&d.esc?d.esc.nombre:''),d&&d.fase||d&&d.de&&(typeof d.de==='string'?d.de:'obj')||'']);e0(n,d);};
const x0=UEB.explosion;UEB.explosion=(p,r,dn,de)=>{L.expl.push([r1(T),r1(p.x),r1(p.z),de&&typeof de==='object'?'soldado:'+de.nombre:de]);x0(p,r,dn,de);};
window.__fich=()=>{let f=0;for(const s of UE.soldados)if(s.vivo&&s.ficha&&s.rol!=='tirador')f++;if(f>L.fichMax)L.fichMax=f;L.cuadros++;};
/* apunta la cámara al pecho de s (desde los ojos del jugador) */
window.__apuntar=(s,dy)=>{const ey=P.pos.y+1.7-.68*P.ch,ty=s.y+(dy===undefined?(s.tierra>.5?.25:s.agach>.5?.8:1.2):dy),dx=s.x-P.pos.x,dz=s.z-P.pos.z;
  P.yaw=Math.atan2(-dx,-dz);P.pitch=Math.atan2(ty-ey,Math.hypot(dx,dz));};
/* ¿se ve el pecho de s desde los ojos del jugador? (mundo fijo, sin bichos) */
window.__ve=(s)=>{const ey=P.pos.y+1.7-.68*P.ch,ty=s.y+(s.tierra>.5?.25:s.agach>.5?.8:1.2),dx=s.x-P.pos.x,dy=ty-ey,dz=s.z-P.pos.z,d=Math.hypot(dx,dy,dz);
  return UEG.ENV.rayo(P.pos.x,ey,P.pos.z,dx/d,dy/d,dz/d,d)>=d-.5;};
return 'ok';})()`;
