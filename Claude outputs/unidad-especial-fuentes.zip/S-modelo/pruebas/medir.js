/* mide en Chromium: llamadas de dibujo y triángulos por soldado con todo prendido; costo de update con 8 */
const H=require('../../harness.js'),path=require('path');
(async()=>{const h=await H.openPage(path.join(__dirname,'..','prueba.html'),{width:640,height:360});
  await h.page.waitForFunction(()=>window.V);
  const r=await h.page.evaluate(()=>{
    V.pausa(true);const I=V.interno(),R=I.renderer;
    const escena=new THREE.Scene();escena.fog=new THREE.FogExp2(0x1b1822,.045);
    const luz=new THREE.SpotLight(0xffffff,2,30,.6,.5,1);luz.castShadow=true;luz.position.set(-4,6,3);escena.add(luz,luz.target,new THREE.HemisphereLight(0x8899bb,0x221111,.5));
    const cam=new THREE.PerspectiveCamera(40,16/9,.1,100);cam.position.set(2,1.5,6);cam.lookAt(0,1,0);
    const roles=['jefe','asalto','granadero','tirador'],us=[];
    const medir=(n,sombras)=>{R.shadowMap.enabled=sombras;
      while(us.length<n){const u=UEM.crear(roles[us.length%4],{semilla:us.length});u.root.position.set((us.length%4)*1.2-1.8,0,-Math.floor(us.length/4)*2);escena.add(u.root);us.push(u);}
      us.forEach(u=>{u.e.apunta=1;u.e.luz=true;u.e.laser=new THREE.Vector3(0,1,20);u.update(1/60);u.disparo();u.update(1/60);});
      R.render(escena,cam);R.render(escena,cam);return {calls:R.info.render.calls,tris:R.info.render.triangles};};
    const base=(()=>{R.shadowMap.enabled=false;R.render(escena,cam);return R.info.render.calls;})();
    const a=medir(1,false),b=medir(1,true),c=medir(8,false),d=medir(8,true);
    /* costo de update: 8 soldados animándose, sin dibujar */
    const prog=[(u,t)=>{u.e.apunta=1;u.e.mYaw=.4*Math.sin(t);},(u,t)=>{u.root.position.z=1.4*t;u.e.apunta=.4;},(u,t)=>{u.e.recarga=(t%2.6)/2.6;},(u,t)=>{u.e.tierra=1;},
      (u,t)=>{u.root.position.z=5*t;},(u,t)=>{u.e.agach=1;},(u,t)=>{u.e.lanza=(t%1.5)/1.5;},(u,t)=>{u.e.senal=(t%1.6)/1.6;}];
    let t=0;for(let i=0;i<120;i++){t+=1/60;us.forEach((u,k)=>{prog[k](u,t);u.update(1/60);});}
    const N=1200,t0=performance.now();for(let i=0;i<N;i++){t+=1/60;us.forEach((u,k)=>{prog[k](u,t);u.update(1/60);});}
    const ms=(performance.now()-t0)/N;
    return {base,uno:a,unoSombra:b,ocho:c,ochoSombra:d,msUpdate8:ms,info:UEM.info('jefe')};});
  console.log(JSON.stringify(r,null,1));console.log('errores',JSON.stringify(h.errors));await h.close();})().catch(e=>{console.error(e);process.exit(1);});
