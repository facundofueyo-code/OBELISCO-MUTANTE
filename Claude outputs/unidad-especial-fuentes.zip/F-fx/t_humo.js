/* prueba de humo de la página suelta: carga, errores, una captura */
const H=require('../harness.js');
(async()=>{const h=await H.openPage(__dirname+'/prueba_fx.html',{width:1280,height:720});
  await h.page.waitForFunction('window.__listo===true',{timeout:60000}).catch(e=>console.log('no listo',e.message));
  const ev=c=>h.page.evaluate(c=>window.__ev(c),c);
  console.log('errores al cargar:',JSON.stringify(h.errors));
  console.log(await ev("JSON.stringify({pm:typeof UEFX,snd:typeof UESND,hud:typeof UEHUD,dbg:typeof UEDBG,modo:UEDBG.modo})"));
  await new Promise(r=>setTimeout(r,1500));
  await h.shotPage(__dirname+'/capturas/p00_humo.png');
  console.log('errores:',JSON.stringify(h.errors));
  await h.close();})().catch(e=>{console.error('FAIL',e);process.exit(1);});
