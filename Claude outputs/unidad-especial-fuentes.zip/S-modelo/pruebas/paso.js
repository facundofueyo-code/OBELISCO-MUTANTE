/* paso: ¿patinan los pies apoyados? (distancia que se mueve en el mundo la base de los dedos de un pie apoyado) */
const THREE=require('../../three.r128.min.js');global.THREE=THREE;const fs=require('fs');
const UEM=new Function('THREE',fs.readFileSync(__dirname+'/../ue_modelo.js','utf8')+'\nreturn UEM;')(THREE);
const V3=THREE.Vector3;const H=UEM._interno.H;
function corrida(nombre,fn,seg=4,e0={}){
  const u=UEM.crear('jefe',{semilla:5});Object.assign(u.e,e0);const st=u._st;const prev=[null,null];let maxDesl=0,pasos=0,vuelo=[false,false],minPel=9,maxPel=0,cab=0;
  for(let i=0;i<seg*60;i++){const t=i/60;fn(u,t,1/60);u.update(1/60);
    for(let k=0;k<2;k++){const f=st.pie[k];const P=st.P[k?H.punteraD:H.punteraI];
      const w=new V3(P.x*st.k,P.y*st.k,P.z*st.k).applyAxisAngle(new V3(0,1,0),u.root.rotation.y).add(u.root.position);
      if(!f.vuelo&&prev[k]&&!vuelo[k]&&i>30)maxDesl=Math.max(maxDesl,w.distanceTo(prev[k]));
      if(f.vuelo&&!vuelo[k])pasos++;vuelo[k]=f.vuelo;prev[k]=w;}
    if(i>60){minPel=Math.min(minPel,st.P[H.cadera].y);maxPel=Math.max(maxPel,st.P[H.cadera].y);}}
  console.log(nombre.padEnd(18),'patina máx',(maxDesl*1000).toFixed(1),'mm/cuadro · pasos',pasos,'· cadera',minPel.toFixed(3),'…',maxPel.toFixed(3));
}
corrida('camina',(u,t)=>{u.root.position.z=1.4*t;});
corrida('trota',(u,t)=>{u.root.position.z=3.2*t;});
corrida('corre',(u,t)=>{u.root.position.z=5.4*t;});
corrida('de costado',(u,t)=>{u.root.position.x=1.5*t;},4,{apunta:1});
corrida('atrás',(u,t)=>{u.root.position.z=-1.2*t;},4,{apunta:1});
corrida('gira quieto',(u,t)=>{u.root.rotation.y=Math.min(1,t/1.2)*Math.PI/2;});
corrida('agachado camina',(u,t)=>{u.root.position.z=1.2*t;},4,{agach:1,apunta:1});
corrida('frena',(u,t)=>{u.root.position.z=1.4*Math.min(t,1.53);});
corrida('curva',(u,t)=>{const a=t*1.4/2.2;u.root.position.set(Math.sin(a)*2.2,0,Math.cos(a)*2.2);u.root.rotation.y=a+Math.PI/2;});
