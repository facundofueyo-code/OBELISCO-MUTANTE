/* =====================================================================
   UE · M — LOS BICHOS CONTRA LA UNIDAD ESPECIAL (combate de a tres)
   Hasta acá los mutantes solo conocían al jugador. Con esto cada bicho común (rata, bagayo, baboso,
   escupidor, mole) elige blanco entre el jugador y los soldados vivos que entrega UEB.objetivos():
     e.tg = null (el jugador, como siempre) o uno de esos objetos {x,z,y,r,vivo,herir(daño,bicho)}.
   El Engendro sigue yendo siempre por el jugador, pero sus golpes de área también agarran a los soldados.
   Además deja lo que necesita la IA de los soldados: rayoBichos (sus balas contra los bichos) y bichosVivos.

   Regla de oro: si UEB.objetivos() devuelve vacío (no hay unidad especial cerca), nada de esto corre y los
   bichos se comportan exactamente igual que antes, cuadro por cuadro. Por eso acá adentro no se usa
   Math.random: no hay que correrle el azar al resto del juego.

   Los enganches en el código viejo (updateEnemies, enSteer, atkTick, spit, updateProjs, damageEnemy,
   killEnemy, carBoom, carHitsDynamic) están marcados con UE:M.
   ===================================================================== */
const BCH_TUNE={
  radio:24,     // m · un soldado es candidato a blanco si está a menos de esto del bicho
  suelta:30,    // m · el bicho suelta a su soldado si se le aleja más que esto
  sesgo:1.15,   // leve preferencia por el jugador: la distancia a un soldado cuenta multiplicada por esto
  hist:.75,     // histéresis: solo cambia de blanco si el otro le queda a menos de esta fracción de lo que le falta al suyo
  cada:.5,      // s · cada cuánto revisa su blanco cada bicho (escalonado entre bichos)
  veto:4,       // s · si no pudo llegar a un soldado (sin camino, o se trabó yendo), no lo vuelve a elegir por este tiempo
  nodos:420,    // tope de casilleros que abre cada búsqueda de camino corto
  costo:520     // tope de costo del camino corto (10 = 1 m llano; trepar un auto suma unos 50)
};
const BCH={
  t:-1,L:[],n:0,vacio:[],       // los soldados de este cuadro (se piden una sola vez por cuadro)
  turno:0,                      // reparte las revisiones de blanco entre cuadros
  rej:new Uint8Array(64),       // candidatos descartados en la revisión en curso
  tmp:{x:0,z:0},
  esf:-1,c:new V3(),hit:{e:null,t:0,p:null,ojo:false},   // rayoBichos
  bv:[],pool:[],bvN:0           // bichosVivos
};

/* la lista de soldados se le pide a la IA una sola vez por cuadro (T, el reloj del juego, avanza en cada cuadro) */
function bchObjs(){
  if(BCH.t!==T){BCH.t=T;const L=UEB.objetivos();BCH.L=L&&L.length?L:BCH.vacio;BCH.n=BCH.L.length;}
  return BCH.L;
}

/* ---------- elección de blanco ---------- */
/* Blanco del bicho en este cuadro: null = el jugador. Lo llama updateEnemies una vez por bicho y por cuadro.
   Usa en el bicho: tg (blanco), tgT (reloj de la próxima revisión), tgL (la próxima elección es libre, sin histéresis),
   tgX/tgV (soldado vetado y hasta cuándo). */
function bchBlanco(e,dt){
  bchObjs();
  if(!BCH.n){if(e.tg)e.tg=null;return null;}       // sin soldados (la partida de siempre): no cambia nada
  if(e.type==='boss')return null;                   // el Engendro va siempre por el jugador
  const K=BCH_TUNE;let g=e.tg||null;
  if(g){
    if(g.vivo===false){if(e.atkS)return g;g=null;e.tgL=1;e.tgT=0;}   // se lo mataron: termina el golpe en el lugar (bchPega ya no
                                                                    // daña a un muerto) y después elige de nuevo ya mismo, sin histéresis
    else if(e.stk>=2&&!bchATiro(e,g)){e.tgX=g;e.tgV=T+K.veto;g=null;}   // se trabó yendo hacia él: dos revisiones seguidas de
                                                                    // updateEnemies sin avanzar (la primera suele ser el golpe que recién terminó)
    else if(e.tgX===g&&T<e.tgV)g=null;                           // bchSteer no le encontró camino: lo deja
  }
  if(e.tgT===undefined){e.tgT=(BCH.turno++%8)*K.cada/8;e.tgL=1;} // primera vez: escalonado, y la primera elección es libre
  e.tgT-=dt;
  /* no cambia de idea en medio de un golpe o de un salto, ni mientras está trabado */
  if(e.tgT<=0&&!e.atkS&&!(e.leapT>0)&&!(e.stk>0)){e.tgT=K.cada;g=bchElegir(e,g);}
  e.tg=g;return g;
}
/* ¿le llega con el golpe? Misma cuenta vertical que usa updateEnemies para empezar a pegar (hacia arriba). Todo se mide desde
   los pies del bicho (e.gy) y del soldado (s.y): desde la 1.15 la calzada está en -0,15 y no se supone piso en 0 */
function bchAlto(e,s){return s.y-e.gy<e.c.height+1;}
/* El escupidor no necesita llegar a su soldado: escupe de 5 a 42 m, y a menos de 24 m se aleja o lo rodea (como con el jugador).
   Mientras lo tenga a menos de BCH_TUNE.suelta (30 m; más lejos lo suelta igual), que se trabe contra una pared o un auto
   o que no haya camino corto no es razón para soltarlo: va con el rumbo directo y sigue escupiendo. */
function bchATiro(e,g){const o=e.obj.position;return !!e.c.spit&&Math.hypot(g.x-o.x,g.z-o.z)<BCH_TUNE.suelta;}
/* ¿puede llegar caminando? Línea recta libre o, si se pide, un camino corto */
function bchLlega(e,s,cls,conCamino){const o=e.obj.position;
  if(enLine(o.x,o.z,s.x,s.z,cls,.8))return true;
  return conCamino&&bchCamino(o.x,o.z,s,cls,BCH.tmp);
}
/* Elige entre el jugador y los soldados a menos de BCH_TUNE.radio: gana el más cercano, con la distancia a los soldados
   pesada por el sesgo. Si ya tiene blanco, otro solo se lo saca si está bastante más cerca (histéresis).
   A un soldado lo elige solo si puede llegar; para no gastar, hace como mucho una búsqueda de camino por revisión. */
function bchElegir(e,cur){
  const K=BCH_TUNE,L=BCH.L,o=e.obj.position,cls=isBig(e)?1:0,n=Math.min(L.length,64),rej=BCH.rej;
  const dJ=Math.hypot(P.pos.x-o.x,P.pos.z-o.z);       // el jugador siempre es candidato
  let libre=!!e.tgL;e.tgL=0;
  let pC=dJ;                                          // «puntaje» del blanco actual: su distancia (pesada, si es un soldado)
  if(cur){const d=Math.hypot(cur.x-o.x,cur.z-o.z);
    if(L.indexOf(cur)<0||d>K.suelta||!bchAlto(e,cur)){cur=null;libre=true;}   // ya no figura, se fue lejos o quedó fuera de alcance
    else pC=d*K.sesgo;}
  /* un soldado candidato tiene que ganarle al jugador y, si ya había blanco, también al actual por el margen de histéresis */
  const umbral=libre?dJ:Math.min(pC*K.hist,dJ);
  for(let i=0;i<n;i++)rej[i]=0;
  for(let intento=0;intento<3;intento++){
    let b=-1,bp=umbral;
    for(let i=0;i<n;i++){const s=L[i];
      if(rej[i]||!s||s===cur||s.vivo===false||(s===e.tgX&&T<e.tgV))continue;
      const d=Math.hypot(s.x-o.x,s.z-o.z);if(d>K.radio)continue;
      const p=d*K.sesgo;if(p<bp&&bchAlto(e,s)){bp=p;b=i;}}
    if(b<0)break;
    if(bchLlega(e,L[b],cls,intento===0))return L[b];
    rej[b]=1;
  }
  if(cur&&!(dJ<pC*K.hist))return cur;   // ni otro soldado ni el jugador le ganan: sigue con el suyo
  return null;                          // el jugador
}

/* ---------- caminar hacia un soldado ---------- */
/* El campo de navegación del juego apunta al jugador, así que hacia un soldado el bicho va derecho si enLine da libre
   y, si no, por un camino corto propio. Lo llama enSteer cuando el bicho tiene e.tg. Devuelve 1 (derecho al blanco),
   2 (al punto que deja en out) o 0: no hay cómo llegar; entonces veta a ese soldado y enSteer sigue hacia el jugador. */
function bchSteer(e,x,z,out,cls){const g=e.tg;
  if(enLine(x,z,g.x,g.z,cls,.8))return 1;
  if(bchATiro(e,g))return 1;       // el escupidor a tiro solo necesita el rumbo hacia el blanco (para acercarse, alejarse o rodearlo)
  if(bchCamino(x,z,g,cls,out))return 2;
  e.tgX=g;e.tgV=T+BCH_TUNE.veto;return 0;
}
/* Camino corto hasta un soldado: A* sobre la grilla de los bichos (enB/enH), dentro de una ventana de 64×64 m centrada
   entre los dos. Se busca desde el soldado hacia el bicho, así el costo de trepar se cuenta en el sentido en que camina
   el bicho, con las mismas reglas y costos que enBuild (el campo hacia el jugador). Deja en out el punto del camino más
   lejano que el bicho ve en línea recta, igual que enSteer. No arma un campo por soldado: es una búsqueda acotada
   (BCH_TUNE.nodos y BCH_TUNE.costo) que corta en cuanto llega. */
const BCW=64;
const bchG=new Uint16Array(BCW*BCW),    // costo acumulado desde el soldado
      bchPa=new Int16Array(BCW*BCW),    // siguiente casillero del camino hacia el soldado (índice en la ventana; -1 = es el final)
      bchSe=new Uint16Array(BCW*BCW),   // marca «visitado en esta búsqueda» (así no hay que limpiar los arreglos cada vez)
      bchHp=new Int32Array(4096);       // montículo de (costo estimado total · 4096 + índice)
let bchId=0,bchHn=0;
function bchPush(v){if(bchHn>=4096)return;let i=bchHn++;const H=bchHp;while(i>0){const p=(i-1)>>1;if(H[p]<=v)break;H[i]=H[p];i=p;}H[i]=v;}
function bchPop(){const H=bchHp,top=H[0],v=H[--bchHn];let i=0;
  for(;;){let c=2*i+1;if(c>=bchHn)break;if(c+1<bchHn&&H[c+1]<H[c])c++;if(H[c]>=v)break;H[i]=H[c];i=c;}
  H[i]=v;return top;}
/* costo que falta, estimado: distancia en casilleros con diagonales (10 y 14, como los pasos) */
function bchF(g,di,dj){const a=di<0?-di:di,b=dj<0?-dj:dj;return g+(a>b?10*a+4*b:10*b+4*a);}
function bchCamino(x,z,s,cls,out){
  const ks=eCell(x,z),kg=eCell(s.x,s.z);if(ks<0||kg<0)return false;
  const K=BCH_TUNE,si=ks%EW,sj=(ks/EW)|0,gi=kg%EW,gj=(kg/EW)|0;
  const i0=((si+gi)>>1)-(BCW>>1),j0=((sj+gj)>>1)-(BCW>>1);          // esquina de la ventana
  const sli=si-i0,slj=sj-j0,gli=gi-i0,glj=gj-j0;                    // el bicho y el soldado, en la ventana
  if(sli<1||slj<1||sli>BCW-2||slj>BCW-2||gli<1||glj<1||gli>BCW-2||glj>BCW-2)return false;   // demasiado lejos para un camino corto
  if(++bchId>65000){bchSe.fill(0);bchId=1;}
  const id=bchId,sOK=enEnter(cls,ks);bchHn=0;
  /* arranca en el casillero del soldado o, si está pegado a algo (los obstáculos entran inflados 0,3 m), en los libres de alrededor */
  if(enEnter(cls,kg)){const q=glj*BCW+gli;bchSe[q]=id;bchG[q]=0;bchPa[q]=-1;bchPush(bchF(0,gli-sli,glj-slj)*4096+q);}
  else for(let d=0;d<8;d++){const di=EN8[d][0],dj=EN8[d][1];if(!enEnter(cls,kg+dj*EW+di))continue;
    const q=(glj+dj)*BCW+gli+di,c=di&&dj?14:10;bchSe[q]=id;bchG[q]=c;bchPa[q]=-1;bchPush(bchF(c,gli+di-sli,glj+dj-slj)*4096+q);}
  let fin=-1,abiertos=0;
  while(bchHn>0){
    const v=bchPop(),idx=v&4095,li=idx%BCW,lj=(idx/BCW)|0,gk=bchG[idx];
    if((v>>12)>bchF(gk,li-sli,lj-slj))continue;                     // entrada vieja: ya se llegó más barato
    /* ¿llegó al bicho? Si el bicho está parado en un casillero que no es transitable (pegado a una pared), alcanza con un vecino */
    {const a=li-sli,b=lj-slj;if((a===0&&b===0)||(!sOK&&a>=-1&&a<=1&&b>=-1&&b<=1)){fin=idx;break;}}
    if(++abiertos>K.nodos)break;
    const i=i0+li,j=j0+lj;if(i<1||j<1||i>=EW-1||j>=EH-1)continue;
    const k=j*EW+i,bk=enB[k],hk2=enH[k];
    for(let d=0;d<8;d++){const di=EN8[d][0],dj=EN8[d][1],nli=li+di,nlj=lj+dj;
      if(nli<0||nlj<0||nli>=BCW||nlj>=BCW)continue;
      const n=k+dj*EW+di;if(!enEnter(cls,n))continue;
      if(cls&&enC[n]<15&&Math.max(Math.abs(i+di-gi),Math.abs(j+dj-gj))>6)continue;        // los grandes necesitan espacio, salvo al lado del blanco
      if(di&&dj&&(!enEnter(cls,k+di)||!enEnter(cls,k+dj*EW)))continue;                    // no corta esquinas
      let c=di&&dj?14:10;
      if(cls&&enP[k])c+=enP[n]?6:30;                                                      // el mole empuja autos, pero le cuesta
      else if(bk===1){c+=4;if(enB[n]!==1||hk2>enH[n]+4)c+=cls?12+hk2:22+2*hk2;}           // subirse a algo (el bicho va de n a k)
      const nd=gk+c;if(nd>K.costo)continue;
      const q=nlj*BCW+nli;if(bchSe[q]===id&&bchG[q]<=nd)continue;
      bchSe[q]=id;bchG[q]=nd;bchPa[q]=idx;bchPush(bchF(nd,nli-sli,nlj-slj)*4096+q);}
  }
  if(fin<0)return false;
  /* los próximos casilleros del camino (hasta 14, o hasta el borde de algo que hay que trepar) y, de esos, el más lejano que ve */
  let np=0,a=fin,kc=ks;
  if((j0+((a/BCW)|0))*EW+i0+a%BCW===ks)a=bchPa[a];
  for(let q=0;q<14&&a>=0;q++){const kn=(j0+((a/BCW)|0))*EW+i0+a%BCW;_ep[np++]=kn;if(enB[kn]===1&&enB[kc]!==1)break;kc=kn;a=bchPa[a];}
  if(!np){out.x=s.x;out.z=s.z;return true;}
  for(let q=np-1;q>=0;q--){const c=_ep[q],cx=EX0+c%EW+.5,cz=EZ0+((c/EW)|0)+.5;if(!q||enLine(x,z,cx,cz,cls,.8)){out.x=cx;out.z=cz;return true;}}
  return true;
}

/* ---------- pegarle a un soldado ---------- */
/* Golpe cuerpo a cuerpo (mordida, zarpazo, caída del salto): si el soldado está al alcance, le aplica el daño.
   alcance: desde el centro del bicho, como contra el jugador (se corrige por el radio del soldado; el del jugador es 0,45).
   alto: hasta qué altura sobre los pies del bicho llega el golpe. Devuelve true si le pegó. */
function bchPega(e,g,alcance,alto,dano){
  if(g.vivo===false)return false;const o=e.obj.position;
  if(Math.hypot(g.x-o.x,g.z-o.z)>=alcance+(g.r||.4)-.45||g.y-e.gy>=alto)return false;
  g.herir(dano,e);return true;
}
/* Golpe de área (el pisotón del Engendro): daña a todos los soldados vivos a menos de radio del punto y con los pies por debajo de yTope */
function bchArea(x,z,radio,yTope,dano,e){const L=bchObjs();if(!BCH.n)return 0;let n=0;
  for(let i=0;i<L.length;i++){const s=L[i];if(!s||s.vivo===false||s.y>=yTope)continue;
    if(Math.hypot(s.x-x,s.z-z)<radio+(s.r||.4)-.45){s.herir(dano,e);n++;}}
  return n;
}
/* Escupitajo en vuelo contra los soldados (updateProjs): misma esfera que contra el jugador, a la altura del pecho.
   p.de es el bicho que escupió (lo anota spit). Devuelve true si le pegó a alguno. */
function bchProy(p){const L=bchObjs();if(!BCH.n)return false;const q=p.m.position,k=p.m.scale.x;
  for(let i=0;i<L.length;i++){const s=L[i];if(!s||s.vivo===false)continue;
    const dx=q.x-s.x,dy=q.y-(s.y+1),dz=q.z-s.z,R=1.05+(s.r||.4)-.45;
    if(dx*dx+dy*dy+dz*dz<R*R*k){s.herir(p.dmg,p.de||null);return true;}}
  return false;
}
/* Auto que viene deslizando (lo barrió el Engendro o lo empujó el mole): golpea a los soldados que agarra, con el mismo daño
   que al jugador. No se sabe qué bicho lo empujó: herir recibe null. Mismo enfriamiento por auto que usan los bichos (p.hitE).
   Altura: la misma cuenta que para el jugador (desde la 1.15 el techo se mide desde c.by, el piso del auto). */
function bchAuto(c,sp){const L=bchObjs();if(!BCH.n)return;const p=c.ph,dano=Math.round(6+sp*3),techo=c.H+p.y+(c.by||0);
  for(let i=0;i<L.length;i++){const s=L[i];if(!s||s.vivo===false||(p.hitE.get(s)||0)>T||s.y>=techo)continue;
    for(const q of c.cs)if(Math.hypot(q.x-s.x,q.z-s.z)<q.r+.05+(s.r||.4)){s.herir(dano,null);p.hitE.set(s,T+.7);break;}}
}

/* ---------- lo que usa la IA de los soldados ---------- */
/* Bala de un soldado contra los bichos: la misma cuenta que hace fire() con las balas del jugador (esfera del cuerpo y
   esferas de las partes vivas; una parte gana si está hasta 0,2 m detrás de lo mejor encontrado).
   o, d: Vector3 (origen y dirección unitaria). Devuelve null o {e,t,p,ojo}: el bicho, la distancia, la parte (null = cuerpo)
   y si es un ojo. OJO: el objeto devuelto se reutiliza en cada llamada. t puede ser apenas negativo si el origen está
   adentro del bicho. El daño lo aplica quien llama con damageEnemy(e,daño,dir,'soldado') (fire() multiplica ×2,5 en un
   ojo y ×0,75 en otra parte). */
function rayoBichos(o,d,maxT){
  if(BCH.esf!==T){BCH.esf=T;updatePartSpheres();}     // las esferas de las partes se calculan una vez por cuadro como mucho
  let best=Infinity,hitE=null,hitP=null;const cen=BCH.c;
  for(const e of enemies){const t=raySphere(o,d,enemyCenter(e,cen),e.c.r*(e.c.hit||1.08));if(t<best){best=t;hitE=e;hitP=null;}
    for(const p of e.parts){if(!p.alive||!p.rad)continue;const tp=raySphere(o,d,p.c,p.rad);if(tp<best+.2&&tp<Infinity){best=Math.min(best,tp);hitE=e;hitP=p;}}}
  if(!hitE||!(best<maxT))return null;
  const r=BCH.hit;r.e=hitE;r.t=best;r.p=hitP;r.ojo=!!hitP&&hitP.kind==='eye';return r;
}
/* Los mutantes vivos como los necesita la IA: centro del cuerpo, radio, tipo y vida. Además tg (a quién persigue: null = al
   jugador) y est ('climb' y 'rise' = todavía está saliendo). Devuelve siempre el mismo arreglo, con los mismos objetos. */
function bichosVivos(){const L=BCH.bv,pool=BCH.pool;let n=0;
  for(let i=0;i<enemies.length;i++){const e=enemies[i];if(e.hp<=0)continue;
    const b=pool[n]||(pool[n]={ref:null,x:0,y:0,z:0,r:0,tipo:'',hp:0,tg:null,est:''}),p=e.obj.position;
    b.ref=e;b.x=p.x;b.y=p.y+e.m.bodyY;b.z=p.z;b.r=e.c.r;b.tipo=e.type;b.hp=e.hp;b.tg=e.tg||null;b.est=e.state;L[n++]=b;}
  for(let i=n;i<BCH.bvN;i++){pool[i].ref=null;pool[i].tg=null;}   // no retener bichos muertos
  BCH.bvN=n;L.length=n;return L;
}
