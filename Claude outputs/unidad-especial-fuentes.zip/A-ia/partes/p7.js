
  /* ====================================================================================================
     ESTADOS DEL ESCUADRÓN: guardia → sospecha → combate → búsqueda → guardia (más alertas)
     ==================================================================================================== */
  function jefeDe(e) {                                                                  // quién manda: el jefe; si cayó, granadero, asalto, tirador
    if (e.jefe && e.jefe.vivo) return e.jefe;
    const orden = ['jefe', 'granadero', 'asalto', 'tirador'];
    for (let r = 0; r < orden.length; r++) for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.rol === orden[r]) return s; }
    for (let i = 0; i < e.soldados.length; i++) if (e.soldados[i].vivo && e.soldados[i].activo) return e.soldados[i];
    return null;
  }
  function senal(s, tipo) { if (s && s.vivo) { s.senalT = 0; s.senalTipo = tipo; } }
  function elegirRevisor(e, x, z) {
    let mejor = null, md = 1e9;
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.activo || s.rol === 'tirador' || s.rol === 'jefe') continue;
      const d = hyp(s.x - x, s.z - z) - (s.rol === 'asalto' ? 15 : 0); if (d < md) { md = d; mejor = s; }
    }
    return mejor;
  }
  function entrarSospecha(e, s, x, z) {
    if (!e.activo || red.muerto || e.estado === 'combate') return;
    if (e.estado === 'busqueda') { if (e.busq && hyp(x - e.busq.x, z - e.busq.z) > 6) e.busq.mover = { x, z }; return; }   // corre el centro del barrido
    if (!e.sosp) {
      e.sosp = { x, z, t: ahora, t0: ahora, quien: elegirRevisor(e, x, z), llegoT: 0 };
      e.estado = 'sospecha'; e.tEst = ahora;
      if (s) decir(s, 'sospecha'); ENV.evento('sospecha', { s, x, z });
    } else { e.sosp.x = x; e.sosp.z = z; e.sosp.t = ahora; }
  }
  function entrarCombate(e, quien) {
    if (!e.activo || red.muerto || e.estado === 'combate') return;
    const antes = e.estado;
    let otro = false; for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i] !== e && escuadrones[i].activo && escuadrones[i].estado === 'combate') otro = true;
    if (!otro) red.tContacto = ahora;
    e.estado = 'combate'; e.tEst = ahora; e.fase = 0; e.sosp = null; e.busq = null; e.fijarDicho = false; e.replegados = false;
    if (e.tFlanco < ahora - T.flancoCada) e.tFlanco = ahora - T.flancoCada + 6;     // el primer flanqueo, no antes de 6 s de combate
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.activo) continue;
      if (s.alerta < 2) s.alerta = 2;
      if (s.tConoce < -90) s.tConoce = ahora;                                          // el reloj de reacción corre desde que se entera
      s.tarea = s.rol === 'tirador' ? 'tirador' : 'fijar'; s.espera = 0; s.bi = -1; s.orden = null; s.rondaYendo = false;
      if (s.estado === 'ronda' || s.estado === 'puesto' || s.estado === 'revisar' || s.estado === 'buscar' || s.estado === 'alerta') { ponerEstado(s, 'alerta'); if (!s.elev && s.salto < 0) parar(s); }
    }
    e.orden = 'combate'; ENV.evento('combate', { esc: e, antes, s: quien });
  }
  function volverAGuardia(e, alertado, motivo) {
    e.estado = 'guardia'; e.tEst = ahora; e.sosp = null; e.busq = null; e.fase = 0; e.flanco = null; e.mueve = null; e.prioBichos = false;
    e.replegados = false; e.radioQuien = null; e.orden = '';
    if (alertado) e.alertado = true;
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.activo) continue;
      s.alerta = 0; s.sosp = 0; s.tarea = 'guardia'; s.orden = null; s.cob = null; s.enTiro = false; s.raf = 0; s.ficha = false;
      s.avisoHecho = false; s.tConoce = -99; s.veDesde = -99; s.bi = -1; s.espera = 0; s.pinned = false; s.cubreHasta = 0; s.ve = false;
      if (s.lanzaT >= 0 && s.lanza && !s.lanza.salio) { s.lanzaT = -1; s.lanza = null; }
      if (s.rol === 'tirador') soltarLaser(s, false);
      ponerEstado(s, 'puesto'); if (!s.elev && s.salto < 0) parar(s);
      for (let q = 0; q < 10; q++) s.hist[q].t = -99;                                   // olvida lo que vio
    }
    for (let i = red.fichas.length - 1; i >= 0; i--) if (red.fichas[i].esc === e) { red.fichas[i].ficha = false; red.fichas.splice(i, 1); }
    let alguno = false; for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo && escuadrones[i].estado !== 'guardia') alguno = true;
    if (!alguno) { red.uc = null; red.tVisto = -99; red.tSenal = -99; red.ancla = null; red.tContacto = -99; red.tirador = null; red.fichas.length = 0; xOk = false; partes.length = 0; }
    ENV.evento(motivo || (alertado ? 'limpio' : 'guardia'), { esc: e });
  }
  function empezarBusqueda(e) {
    const u = red.uc; if (!u) { volverAGuardia(e, true, 'nada'); return; }
    e.estado = 'busqueda'; e.tEst = ahora; e.fase = 3; e.flanco = null; e.mueve = null; e.orden = 'barrido';
    e.busq = { x: u.x, z: u.z, t0: ahora, puntos: null, listo: false, mover: null };
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.activo) continue;
      s.alerta = 1; s.tarea = 'buscar'; s.orden = null; s.bi = -1; s.espera = 0; s.cob = null; s.enTiro = false; s.raf = 0; s.pinned = false;
      if (s.ficha) { s.ficha = false; const k = red.fichas.indexOf(s); if (k >= 0) red.fichas.splice(k, 1); }
      if (s.rol === 'tirador') soltarLaser(s, false);
    }
    decir(jefeDe(e), 'busqueda'); ENV.evento('busqueda', { esc: e, x: u.x, z: u.z });
    planearBarrido(e);
  }
  /* puntos del barrido: el último lugar conocido y las coberturas de alrededor que no se ven desde donde están */
  function planearBarrido(e) {
    const b = e.busq, pts = [{ x: b.x, z: b.z, visto: false, n: 0 }];
    const i0 = Math.floor(b.x - EX0), j0 = Math.floor(b.z - EZ0), R = 12, cand = [];
    for (let dj = -R; dj <= R; dj += 2) for (let di = -R; di <= R; di += 2) {
      const i = i0 + di, j = j0 + dj; if (i < 1 || j < 1 || i >= EW - 1 || j >= EH - 1) continue;
      const k = j * EW + i; if (B[k] !== 0 || vecinoAlto(k) < 1) continue;
      const x = cX(k), z = cZ(k), d = hyp(x - b.x, z - b.z); if (d > R || d < 3) continue;
      let visto = false;
      for (let q = 0; q < e.soldados.length && !visto; q++) { const s = e.soldados[q]; if (s.vivo && s.activo && lineaVista(s.x, s.y + ojoDe(s), s.z, x, 0.9, z, s.elev)) visto = true; }
      if (!visto) cand.push({ x, z, d });
    }
    cand.sort((a, c) => a.d - c.d);
    for (let i = 0; i < cand.length && pts.length < 7; i++) { const c = cand[i]; let cerca = false; for (let q = 0; q < pts.length; q++) if (hyp(pts[q].x - c.x, pts[q].z - c.z) < 4) cerca = true; if (!cerca) pts.push({ x: c.x, z: c.z, visto: false, n: 0 }); }
    b.puntos = pts;
  }

  /* ====================================================================================================
     HERIDAS Y BAJAS
     ==================================================================================================== */
  function herir(s, dano, dir, parte, de, bicho) {
    if (!s || !s.vivo || !s.activo || !(dano > 0)) return;
    const m = parte === 'cabeza' ? T.multCabeza : parte === 'torso' ? T.multTorso : (parte === 'brazo' || parte === 'pierna' || parte === 'miembro') ? T.multMiembro : 1;
    const d = dano * m; s.hp -= d; s.herT = ahora;
    if (dir) { const dx = dir.x || 0, dz = dir.z || 0; if (dx || dz) s.herDir = Math.atan2(dx, dz); }
    ENV.evento('herido', { s, dano: d, parte, de });
    if (s.hp <= 0) { morir(s, de, parte); return; }
    s.asiento = 0; s.supr = Math.min(1, s.supr + 0.4);
    if (d >= T.aturdeDano && s.salto < 0 && !s.elev) { s.aturdido = T.aturdeT; s.raf = 0; if (s.estado !== 'lanzar' && s.estado !== 'radio') ponerEstado(s, 'aturdido'); }
    if (s.estado === 'radio') { ponerEstado(s, s.cob ? 'cubierto' : 'alerta'); s.radioT = 0; ENV.evento('refuerzo', { fase: 'interrumpido', s }); }
    if (s.lanzaT >= 0 && s.lanza && !s.lanza.salio && d >= 10) { s.lanzaT = -1; s.lanza = null; if (s.estado === 'lanzar') ponerEstado(s, s.cob ? 'volver' : 'alerta'); }
    if (s.rol === 'tirador' && s.tir !== 'espera') soltarLaser(s, true);
    if (de === 'jugador' || de === 'granada') {
      /* sabe que le tiran y de qué lado (no a qué distancia): mira hacia allá y el escuadrón entra en combate */
      if (s.herDir !== undefined && dir) { const a = s.herDir + PI; s.estX = s.x + Math.sin(a) * 15; s.estZ = s.z + Math.cos(a) * 15; s.estT = ahora; }
      if (s.alerta < 2) { s.alerta = 2; if (s.tConoce < -90) s.tConoce = ahora; }
      if (s.esc.estado !== 'combate') entrarCombate(s.esc, null);
    } else if (de === 'bicho' && bicho) {
      if (!s.bicho) s.bicho = { ref: null, x: 0, y: 0, z: 0, r: 0.5, d: 0 };
      const o = s.bicho; o.ref = bicho.ref || bicho; o.x = bicho.x; o.y = bicho.y || 0; o.z = bicho.z; o.r = bicho.r || 0.5; o.d = hyp(bicho.x - s.x, bicho.z - s.z); s.bichoT = ahora;
      if (s.alerta < 1) s.alerta = 1;
    }
  }
  function morir(s, de, parte) {
    const e = s.esc;
    s.vivo = false; s.hp = 0; ponerEstado(s, 'muerto'); s.tMuerte = ahora; s.raf = 0; s.enTiro = false; s.laser = null; s.camino = null; s.esperaCamino = false;
    s.vx = s.vz = s.dvx = s.dvz = 0; s.luz = false; s.orden = null; s.lanzaT = -1; s.lanza = null; s.culT = -1; s.radioT = 0; s.cob = null; s.ve = false;
    if (s.ficha) { s.ficha = false; const i = red.fichas.indexOf(s); if (i >= 0) red.fichas.splice(i, 1); }
    if (red.tirador === s) red.tirador = null;
    if (e.mueve === s) e.mueve = null;
    if (e.flanco && e.flanco.s === s) { e.flanco = null; e.tFlanco = ahora; }
    const tipo = (de === 'granada' || de === 'auto') ? 'derrumbe' : s.tierra > 0.5 ? 'tierra' : parte === 'cabeza' ? 'atras' : (azar() < 0.5 ? 'adelante' : 'derrumbe');
    s.muerte = { tipo, t: 0, dir: s.herDir || 0 };
    ENV.evento('baja', { s, de, parte });
    let otro = null, od = 1e9;
    for (let i = 0; i < e.soldados.length; i++) { const o = e.soldados[i]; if (!o.vivo || !o.activo) continue; const d = hyp(o.x - s.x, o.z - s.z); if (d < od) { od = d; otro = o; } }
    if (otro) dialogos.push({ t: ahora + 0.7, e, quien: otro, clave: 'baja', n: s.num });
    if (e.jefe === s) {
      e.jefe = jefeDe(e); e.desorden = ahora + T.jefeCaidoT; e.orden = 'desorden';
      ENV.evento('jefe_caido', { s, nuevo: e.jefe, hasta: e.desorden });
      if (e.jefe) dialogos.push({ t: ahora + 1.7, e, quien: e.jefe, clave: 'jefe_caido' });
      for (let i = 0; i < e.soldados.length; i++) { const o = e.soldados[i]; if (o.vivo && o.orden && o.orden.tipo !== 'lanzar') o.orden = null; }
      if (e.flanco) { e.flanco.s.tarea = 'fijar'; e.flanco = null; }
    }
    /* los compañeros que lo ven caer se dan cuenta aunque no sepan de dónde vino */
    if (e.estado !== 'combate' && !red.muerto && otro && od < 30 && lineaVista(otro.x, otro.y + ojoDe(otro), otro.z, s.x, 0.8, s.z)) entrarCombate(e, null);
  }

  /* ====================================================================================================
     EL CEREBRO DEL ESCUADRÓN (cada T.tCerebro s): pérdida de contacto, roles y órdenes, granada,
     flanqueo, empuje, repliegue, refuerzo, prioridad de bichos. Lo que «sabe» es red.uc, nunca el jugador.
     ==================================================================================================== */
  function cerebro(e) {
    let vivos = 0; for (let i = 0; i < e.soldados.length; i++) if (e.soldados[i].vivo && e.soldados[i].activo) vivos++;
    e.vivos = vivos; if (!vivos) { e.orden = 'sin gente'; return; }
    if (!e.jefe || !e.jefe.vivo) e.jefe = jefeDe(e);
    if (e.estado === 'sospecha') cerebroSospecha(e);
    else if (e.estado === 'combate') cerebroCombate(e, vivos);
    else if (e.estado === 'busqueda') cerebroBusqueda(e);
  }
  function cerebroSospecha(e) {
    const q = e.sosp; if (!q) { e.estado = 'guardia'; return; }
    if (!q.quien || !q.quien.vivo) q.quien = elegirRevisor(e, q.x, q.z);
    const sinNada = ahora - q.t, revisado = q.llegoT && ahora - q.llegoT > 4;
    if ((sinNada > 6 && (revisado || !q.quien)) || sinNada > 14 || ahora - q.t0 > 30) {
      decir(q.quien || jefeDe(e), 'nada'); volverAGuardia(e, true, 'nada');
    }
  }
  function cerebroBusqueda(e) {
    const b = e.busq; if (!b) { volverAGuardia(e, true); return; }
    if (b.mover) { b.x = b.mover.x; b.z = b.mover.z; b.mover = null; b.listo = false; planearBarrido(e); for (let i = 0; i < e.soldados.length; i++) e.soldados[i].bi = -1; }
    if (ahora - b.t0 > T.barridoT || (b.listo && ahora - b.t0 > 10)) { decir(jefeDe(e), 'limpio'); volverAGuardia(e, true, 'limpio'); }
  }
  function quienHabla(e) {
    let m = null, mt = -1e9;
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.tVisto > mt) { mt = s.tVisto; m = s; } }
    return m || jefeDe(e);
  }
  const quietoParaOrden = s => s.estado === 'cubierto' || s.estado === 'asomado' || s.estado === 'volver' || s.estado === 'alerta' || s.estado === 'recargar' || (s.estado === 'tierra' && !s.pinned);
  function cerebroCombate(e, vivos) {
    const u = red.uc, jefe = jefeDe(e);
    e.prioBichos = bichosCerca(e) >= 3;
    if (!u) { e.orden = 'sin lugar conocido'; return; }
    const sinSenal = ahora - red.tSenal;
    /* 1. pérdida de contacto (SPEC 5): 2,5 s «lo perdí» y fuego al lugar viejo · 7 s granada o avance · 12 s barrido */
    if (sinSenal < T.perdidoT) e.fase = 0;
    else {
      if (e.fase < 1) { e.fase = 1; decir(quienHabla(e), 'perdido'); ENV.evento('perdido', { esc: e, x: u.x, z: u.z }); e.orden = 'perdido: fuego al lugar viejo'; }
      if (sinSenal >= T.perdidoAccion && e.fase < 2 && e.desorden <= ahora) { e.fase = 2; if (!ordenarGranada(e, u, 'perdido')) ordenarAvance(e, u); }
      if (sinSenal >= T.perdidoBarrido && e.fase < 3) { empezarBusqueda(e); return; }
    }
    if (e.desorden > ahora) { e.orden = 'desorden'; return; }                              // sin jefe: nadie da órdenes nuevas
    /* 2. refuerzo */
    pedirRefuerzo(e, vivos, jefe);
    /* 3. quedan pocos: se repliegan hacia la reunión y aguantan */
    if (vivos <= T.refuerzoVivos && !e.replegados) {
      e.replegados = true; e.orden = 'repliegue'; senal(jefe, 'alto');
      for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.rol !== 'tirador' && s.estado !== 'radio' && !(s.orden && s.orden.tipo === 'radio')) s.orden = { tipo: 'replegar', t: ahora }; }
    }
    /* 4. granada: lo tienen ubicado y no se mueve (quieto o escondido) */
    if (e.fase === 0 && red.ancla && ahora - red.ancla.t0 >= T.granada.quieto) ordenarGranada(e, u, 'quieto');
    ordenarGranadaBichos(e);
    /* 5. flanqueo */
    seguirFlanco(e);
    if (!e.flanco && !e.replegados && vivos >= T.flancoMinVivos && ahora - e.tFlanco >= T.flancoCada && sinSenal < 3 && u.err <= 4) planearFlanco(e, u);
    /* 6. el jugador recarga: el asalto empuja */
    if (red.recJug > ahora - 0.9 && ahora - e.tEmpuje > 10 && !e.replegados) ordenarEmpuje(e, u);
    if (!e.flanco && e.orden !== 'granada') e.orden = e.replegados ? 'repliegue' : 'base de fuego';
  }
  function bichosCerca(e) {
    if (!bichos.length) return 0;
    let n = 0;
    for (let i = 0; i < bichos.length; i++) {
      const b = bichos[i];
      for (let q = 0; q < e.soldados.length; q++) { const s = e.soldados[q]; if (s.vivo && s.activo && hyp(b.x - s.x, b.z - s.z) < 16) { n++; break; } }
    }
    return n;
  }
  /* granada al último lugar conocido. Devuelve true si la ordenó. */
  function ordenarGranada(e, u, motivo) {
    const G = T.granada;
    if (ahora - red.tGranada < G.cada || red.muerto || u.err > 3) return false;
    for (let i = 0; i < soldados.length; i++) { const o = soldados[i]; if (o.vivo && o.activo && hyp(o.x - u.x, o.z - u.z) < G.amigos) return false; }
    return ordenarLanzar(e, u.x, u.y, u.z, motivo);
  }
  function ordenarLanzar(e, x, y, z, motivo) {
    const G = T.granada; let mejor = null, mp = -1e9;
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i];
      if (!s.vivo || !s.activo || s.granadas <= 0 || s.elev || s.orden || s.lanzaT >= 0 || !quietoParaOrden(s)) continue;
      if (e.flanco && e.flanco.s === s && !e.flanco.tLlego) continue;
      const d = hyp(s.x - x, s.z - z); if (d < G.distMin || d > G.distMax) continue;
      const p = (s.rol === 'granadero' ? 10 : s.rol === 'tirador' ? -5 : 0) - Math.abs(d - 18) * 0.1;
      if (p <= mp) continue;
      if (!ENV.arco(s.x, s.y + 1.75, s.z, x, y, z)) continue;
      mp = p; mejor = s;
    }
    if (!mejor) return false;
    mejor.orden = { tipo: 'lanzar', t: ahora, x, y, z, motivo };
    red.tGranada = ahora; e.orden = 'granada (' + motivo + ')';
    ENV.evento('granada_orden', { s: mejor, x, z, motivo });
    return true;
  }
  function ordenarGranadaBichos(e) {
    const G = T.granada; if (bichos.length < G.bichos || ahora - red.tGranada < G.cada) return;
    for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i]; if (!s.vivo || !s.bicho || ahora - s.bichoT > 0.5) continue;
      const c = s.bicho; let n = 0, cx = 0, cz = 0;
      for (let q = 0; q < bichos.length; q++) { const b = bichos[q]; if (hyp(b.x - c.x, b.z - c.z) < G.bichosRadio) { n++; cx += b.x; cz += b.z; } }
      if (n < G.bichos) continue;
      cx /= n; cz /= n;
      let amigo = false; for (let q = 0; q < soldados.length; q++) { const o = soldados[q]; if (o.vivo && o.activo && hyp(o.x - cx, o.z - cz) < G.amigos) amigo = true; }
      if (amigo) continue;
      if (ordenarLanzar(e, cx, 0, cz, 'bichos')) return;
    }
  }
  /* sin señal hace rato y sin granada: uno o dos avanzan a una cobertura más cerca; los demás cubren */
  function ordenarAvance(e, u) {
    const c = [];
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.rol !== 'tirador' && !s.orden && quietoParaOrden(s)) c.push(s); }
    if (!c.length) return;
    c.sort((a, b) => hyp(a.x - u.x, a.z - u.z) - hyp(b.x - u.x, b.z - u.z));
    const n = c.length >= 3 ? 2 : 1;
    for (let i = 0; i < n; i++) c[i].orden = { tipo: 'avanzar', t: ahora };
    for (let i = n; i < c.length; i++) c[i].cubreHasta = ahora + 5;
    senal(jefeDe(e), 'avanzar'); e.orden = 'avance sobre el lugar viejo'; ENV.evento('avance', { esc: e, n });
  }
  function ordenarEmpuje(e, u) {
    let a = null;
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s.vivo && s.activo && s.rol === 'asalto' && !s.orden && s.hp >= T.vida * T.heridoBajo && quietoParaOrden(s)) { a = s; break; } }
    if (!a || (e.flanco && e.flanco.s === a && !e.flanco.tLlego)) return;
    const d = hyp(a.x - u.x, a.z - u.z); if (d > 28 || d < 6) return;
    e.tEmpuje = ahora; a.orden = { tipo: 'empujar', t: ahora };
    decir(a, 'recarga_jugador'); e.orden = 'empuje'; ENV.evento('empuje', { s: a });
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s !== a && s.vivo && s.activo && s.rol !== 'tirador') s.cubreHasta = ahora + 4; }
  }
  /* ---------- flanqueo: el asalto (o el granadero si no hay asalto) rodea por el lado con el camino más tapado ---------- */
  function planearFlanco(e, u) {
    let f = null;
    for (let r = 0; r < 2 && !f; r++) for (let i = 0; i < e.soldados.length; i++) {
      const s = e.soldados[i];
      if (s.vivo && s.activo && s.rol === (r ? 'granadero' : 'asalto') && !s.orden && s.hp >= T.vida * T.heridoBajo && s.recT < 0 && (s.estado === 'cubierto' || s.estado === 'asomado' || s.estado === 'volver')) { f = s; break; }
    }
    if (!f) return;
    let bx = 0, bz = 0, n = 0;
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s !== f && s.vivo && s.activo && s.rol !== 'tirador') { bx += s.x; bz += s.z; n++; } }
    if (n) { bx /= n; bz /= n; } else { bx = f.x; bz = f.z; }
    e.tFlanco = ahora;
    const plan = { f, ux: u.x, uz: u.z, bx, bz, lados: [] };
    encolar(f, 'flanco1', () => ladoFlanco(plan, -1));
    encolar(f, 'flanco2', () => { ladoFlanco(plan, 1); decidirFlanco(e, plan); });
  }
  function ladoFlanco(plan, lado) {
    const f = plan.f; if (!f.vivo) return;
    const dA = hyp(plan.bx - plan.ux, plan.bz - plan.uz) || 1, bux = (plan.bx - plan.ux) / dA, buz = (plan.bz - plan.uz) / dA;
    const fi = -lado * 1.75, vx = bux * Math.cos(fi) - buz * Math.sin(fi), vz = bux * Math.sin(fi) + buz * Math.cos(fi);
    const cx = plan.ux + vx * T.flancoDist, cz = plan.uz + vz * T.flancoDist;
    const cob = buscarCobertura(f, plan.ux, plan.uz, { cx, cz, radio: 13, dMin: 6, dMax: 24, dIdeal: T.flancoDist, angMin: 1.05, bx: plan.bx, bz: plan.bz, lado, tiro: true, pesoCamino: 0.03 });
    if (!cob) return;
    const cam = aEstrella(f.x, f.z, cob.x, cob.z, { expo: true, agach: true, maxIt: 6000 });
    if (!cam || cam.parcial) return;
    plan.lados.push({ lado, cob, camino: cam, costo: cam.costo + cam.expuestos * 2 });
  }
  function decidirFlanco(e, plan) {
    const f = plan.f; if (!f.vivo || f.orden || e.flanco || e.desorden > ahora) return;
    let m = null; for (let i = 0; i < plan.lados.length; i++) if (!m || plan.lados[i].costo < m.costo) m = plan.lados[i];
    if (!m || m.costo > 110) { e.tFlanco = ahora - T.flancoCada + 5; ENV.evento('flanco_no', { s: f }); return; }
    f.orden = { tipo: 'flanquear', t: ahora, cob: m.cob, camino: m.camino, lado: m.lado };
    e.flanco = { s: f, t0: ahora, lado: m.lado, tLlego: 0, cob: m.cob }; e.orden = 'flanqueo ' + (m.lado > 0 ? 'der' : 'izq');
    const j = jefeDe(e); if (j && j !== f) { decir(j, 'orden_flanco', f.num); senal(j, m.lado > 0 ? 'der' : 'izq'); }
    for (let i = 0; i < e.soldados.length; i++) { const s = e.soldados[i]; if (s !== f && s.vivo && s.activo && s.rol !== 'tirador') s.cubreHasta = ahora + 6; }
    ENV.evento('flanco', { s: f, lado: m.lado > 0 ? 'der' : 'izq', costo: m.costo, x: m.cob.x, z: m.cob.z });
  }
  function seguirFlanco(e) {
    const F = e.flanco; if (!F) return;
    const f = F.s;
    if (!f.vivo || (f.tarea !== 'flanquear' && !(f.orden && f.orden.tipo === 'flanquear'))) { e.flanco = null; return; }
    if (!F.tLlego && ahora - F.t0 > 30) { e.flanco = null; f.tarea = 'fijar'; ENV.evento('flanco_fin', { s: f, llego: false }); return; }
    if (F.tLlego && ahora - F.tLlego > 10) { e.flanco = null; f.tarea = 'fijar'; ENV.evento('flanco_fin', { s: f, llego: true }); }
  }
  /* refuerzo: lo pide el jefe (o el que quede) desde una cobertura, 3 s con la radio. Una sola vez. */
  function pedirRefuerzo(e, vivos, jefe) {
    if (!red.refuerzo || red.refPedido || e.esRefuerzo) return;
    if (!(vivos <= T.refuerzoVivos || ahora - red.tContacto >= T.refuerzoCombate)) return;
    const q = e.radioQuien;
    if (q && q.vivo && (q.estado === 'radio' || (q.orden && q.orden.tipo === 'radio'))) return;
    let s = jefe;
    if (!s || s.elev || s.orden) { s = null; for (let i = 0; i < e.soldados.length; i++) { const o = e.soldados[i]; if (o.vivo && o.activo && !o.elev && !o.orden && o.rol !== 'tirador') { s = o; break; } } }
    if (!s) return;
    s.orden = { tipo: 'radio', t: ahora }; e.radioQuien = s;
  }
  /* el escuadrón de refuerzo entra por `sale` y viene por `camino`, ya en combate y sabiendo lo que sabe la red */
  const vozCentral = { id: -1, num: 1, nombre: 'Tizón 1', rol: 'jefe', voz: 7, vivo: true, activo: true, x: 0, y: 0, z: 0, esc: null, virtual: true };
  function llegadaRefuerzo() {
    const r = red.refuerzo;
    if (!r || !red.refPedido || red.refLlego || ahora < red.refEn) return;
    red.refLlego = true; r.activo = true; poblar(r);
    if (red.muerto) { volverAGuardia(r, true); return; }
    entrarCombate(r, null);
    if (red.tSenal < -90) { red.tSenal = ahora; }
    for (let i = 0; i < r.soldados.length; i++) { const s = r.soldados[i]; s.wi = 0; ponerEstado(s, 'llegando'); s.tarea = 'fijar'; }
    r.orden = 'llegando'; ENV.evento('refuerzo', { fase: 'entra', esc: r });
  }
  function pensarLlegando(s, u) {
    const e = s.esc, cam = e.camino || [];
    s.enTiro = false; s.post = 0; s.luz = true; s.miraFija = false; s.apObj = true;
    const fin = cam.length ? cam[cam.length - 1] : (e.reunion || s.puesto);
    const llego = s.wi >= cam.length || (s.llego && !s.esperaCamino && s.wi >= cam.length - 1 && hyp(fin.x - s.x, fin.z - s.z) < 3);
    if (s.ve || (u && hyp(u.x - s.x, u.z - s.z) < 38) || llego) {
      if (!e.llegoDicho) { e.llegoDicho = true; decir(s, 'refuerzo_llega'); ENV.evento('refuerzo', { fase: 'llega', esc: e, s }); }
      s.puesto = { x: s.x, z: s.z, rumbo: s.miraYaw };
      ponerEstado(s, 'alerta'); reaccionar(s); return;
    }
    if (s.llego && !s.esperaCamino) {
      if (s.dest && hyp(s.dest.x - s.x, s.dest.z - s.z) < 2.5) s.wi++;
      if (s.wi < cam.length) { const p = cam[s.wi], o = (s.num - 2.5) * 1.3; irA(s, p.x + o * 0.3, p.z + o, T.velCorrer, { expo: true }); }
    }
  }

  /* ====================================================================================================
     OÍDO Y SUPRESIÓN (los llama el juego)
     ==================================================================================================== */
  function ruido(pos, tipo, fuerza) {
    if (!pos || red.muerto) return;
    fuerza = fuerza || 1;
    const alc = (tipo === 'disparo' ? T.oidoDisparo : tipo === 'pasos' ? T.oidoPasos : tipo === 'impacto' ? T.oidoImpacto : tipo === 'explosion' ? T.oidoExplosion : 20) * fuerza;
    const delJugador = tipo === 'disparo' || tipo === 'pasos' || tipo === 'jugador';
    const px = pos.x, pz = pos.z, py = pos.y || 0;
    let mejor = null, me = 1e9;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      const d = hyp(px - s.x, pz - s.z); if (d > alc) continue;
      const err = tipo === 'impacto' ? 1 : 1 + d * 0.06;                              // de lejos se lo ubica peor
      s.estX = px + campana() * err; s.estZ = pz + campana() * err; s.estT = ahora;
      if (nivelDe(s) < 2) s.sosp = Math.max(s.sosp, (tipo === 'disparo' || tipo === 'explosion') ? 0.9 : 0.55);
      if (err < me) { me = err; mejor = s; }
    }
    if (!mejor) return;
    if (!delJugador) {                                                                  // explosión, impacto: se alarman y miran, pero eso no dice dónde está el testigo
      for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo && escuadrones[i].estado === 'guardia') entrarSospecha(escuadrones[i], mejor, mejor.estX, mejor.estZ);
      return;
    }
    if (ahora - red.tRuido < 0.3 && hyp(px - red.ruX, pz - red.ruZ) < 2) return;       // la misma ráfaga: no hace falta avisar cada tiro
    red.tRuido = ahora; red.ruX = px; red.ruZ = pz;
    partes.push({ t: ahora + T.aviso, t0: ahora, s: mejor, x: mejor.estX, y: py, z: mejor.estZ, err: me, fuerte: tipo === 'disparo' });
  }
  function balaCerca(o, d, t) {
    if (!o || !d) return;
    const ox = o.x, oy = o.y, oz = o.z, dx = d.x, dy = d.y, dz = d.z, L = t > 0 && t < 400 ? t : 400;
    const ex = ox + dx * L, ez = oz + dz * L;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      const cx = s.x - ox, cy = s.y + ojoDe(s) - 0.35 - oy, cz = s.z - oz;
      let u = cx * dx + cy * dy + cz * dz; if (u < 0) continue; if (u > L) u = L;
      const qx = cx - dx * u, qy = cy - dy * u, qz = cz - dz * u, dist = Math.sqrt(qx * qx + qy * qy + qz * qz);
      const cerca = dist < T.suprCerca, impacto = hyp(ex - s.x, ez - s.z) < T.oidoImpacto;
      if (!cerca && !impacto) continue;
      if (cerca) { s.supr = Math.min(1, s.supr + T.suprSuma); s.asiento *= 0.6; }
      if (nivelDe(s) < 2) { s.sosp = Math.max(s.sosp, 0.7); s.estX = ox + campana() * 4; s.estZ = oz + campana() * 4; s.estT = ahora; }
      if (s.supr > T.suprEsconde && ahora - s.tSuprDijo > 6 && s.esc.estado === 'combate' && s.rol !== 'tirador') { if (decir(s, 'suprimido')) s.tSuprDijo = ahora; }
    }
  }
  function explosion(pos, radio, dano, de) {
    if (!pos) return;
    const px = pos.x, py = pos.y || 0, pz = pos.z;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      const d = hyp(s.x - px, s.z - pz); if (d > radio) continue;
      let dn = dano * (1 - d / radio);
      if (!rayoLibre(px, py + 0.4, pz, s.x, s.y + ojoDe(s) * 0.6, s.z)) dn *= T.granada.cobertura;
      if (s.tierra > 0.8) dn *= 0.7;
      const l = d || 1;
      herir(s, dn, { x: (s.x - px) / l, y: 0, z: (s.z - pz) / l }, 'explosion', de === 'jugador' ? 'granada' : (typeof de === 'string' ? de : 'granada'));
    }
    ruido(pos, 'explosion', 1);
  }

  /* ====================================================================================================
     BALA DEL JUGADOR CONTRA LOS SOLDADOS: el modelo si hay; si no, cápsulas según la postura
     ==================================================================================================== */
  function capsula(ox, oy, oz, dx, dy, dz, ax, ay, az, bx, by, bz, r) {               // rayo contra cápsula (segmento a-b, radio r): t o -1
    const bax = bx - ax, bay = by - ay, baz = bz - az, oax = ox - ax, oay = oy - ay, oaz = oz - az;
    const baba = bax * bax + bay * bay + baz * baz, bard = bax * dx + bay * dy + baz * dz, baoa = bax * oax + bay * oay + baz * oaz;
    const rdoa = dx * oax + dy * oay + dz * oaz, oaoa = oax * oax + oay * oay + oaz * oaz, a = baba - bard * bard;
    if (a < 1e-9) { const t1 = esfera(ox, oy, oz, dx, dy, dz, ax, ay, az, r), t2 = esfera(ox, oy, oz, dx, dy, dz, bx, by, bz, r); return t1 < 0 ? t2 : t2 < 0 ? t1 : Math.min(t1, t2); }
    const b = baba * rdoa - baoa * bard, c = baba * oaoa - baoa * baoa - r * r * baba, h = b * b - a * c;
    if (h < 0) return -1;
    const t = (-b - Math.sqrt(h)) / a, y = baoa + t * bard;
    if (y > 0 && y < baba) return t;
    return y <= 0 ? esfera(ox, oy, oz, dx, dy, dz, ax, ay, az, r) : esfera(ox, oy, oz, dx, dy, dz, bx, by, bz, r);
  }
  function esfera(ox, oy, oz, dx, dy, dz, cx, cy, cz, r) {
    const ex = ox - cx, ey = oy - cy, ez = oz - cz, b = dx * ex + dy * ey + dz * ez, c = ex * ex + ey * ey + ez * ez - r * r, h = b * b - c;
    return h > 0 ? -b - Math.sqrt(h) : -1;
  }
  function rayoCuerpo(s, ox, oy, oz, dx, dy, dz, maxT) {
    /* descarte rápido: el rayo pasa lejos del soldado */
    const cx = s.x - ox, cz = s.z - oz, hl = Math.sqrt(dx * dx + dz * dz) || 1e-6, u = (cx * dx + cz * dz) / hl;
    if (u < -1.5 || u / hl > maxT + 2) return null;
    if (Math.abs(cx * dz - cz * dx) / hl > 1.3) return null;
    let mt = maxT, parte = null, t;
    const y = s.y, k = s.agach;
    if (s.tierra > 0.5) {
      const fx = Math.sin(s.rumbo), fz = Math.cos(s.rumbo);
      t = esfera(ox, oy, oz, dx, dy, dz, s.x + fx * 0.8, y + 0.32, s.z + fz * 0.8, 0.14); if (t >= 0 && t < mt) { mt = t; parte = 'cabeza'; }
      t = capsula(ox, oy, oz, dx, dy, dz, s.x - fx * 0.05, y + 0.22, s.z - fz * 0.05, s.x + fx * 0.6, y + 0.25, s.z + fz * 0.6, 0.23); if (t >= 0 && t < mt) { mt = t; parte = 'torso'; }
      t = capsula(ox, oy, oz, dx, dy, dz, s.x - fx * 0.95, y + 0.15, s.z - fz * 0.95, s.x - fx * 0.1, y + 0.18, s.z - fz * 0.1, 0.17); if (t >= 0 && t < mt) { mt = t; parte = 'pierna'; }
    } else {
      const hc = 1.66 - 0.54 * k, t0 = 0.98 - 0.4 * k, t1 = 1.48 - 0.5 * k, p1 = 0.92 - 0.37 * k;
      t = esfera(ox, oy, oz, dx, dy, dz, s.x, y + hc, s.z, 0.14); if (t >= 0 && t < mt) { mt = t; parte = 'cabeza'; }
      t = capsula(ox, oy, oz, dx, dy, dz, s.x, y + t0, s.z, s.x, y + t1, s.z, 0.25); if (t >= 0 && t < mt) { mt = t; parte = 'torso'; }
      t = capsula(ox, oy, oz, dx, dy, dz, s.x, y + 0.12, s.z, s.x, y + p1, s.z, 0.17 + 0.05 * k); if (t >= 0 && t < mt) { mt = t; parte = 'pierna'; }
    }
    return parte ? { s, t: mt, parte } : null;
  }
  function rayoJugador(o, d, maxT) {
    const ox = o.x, oy = o.y, oz = o.z, dx = d.x, dy = d.y, dz = d.z; let mt = (maxT > 0) ? maxT : Infinity, mejor = null;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue;
      if (s.vista && s.vista.rayo && _v3) {
        const r = s.vista.rayo(o, d);
        if (r) { const t = typeof r === 'number' ? r : r.t; if (t >= 0 && t < mt) { mt = t; mejor = { s, t, parte: r.parte || 'torso' }; } }
        continue;
      }
      const r = rayoCuerpo(s, ox, oy, oz, dx, dy, dz, mt); if (r) { mt = r.t; mejor = r; }
    }
    return mejor;
  }

  /* ====================================================================================================
     ESCUADRONES: crear, poblar, refuerzo
     ==================================================================================================== */
  function crearEscuadron(def, esRef) {
    const e = {
      nombre: def.nombre || (esRef ? 'Tizón' : 'Ceniza'), activo: !esRef, esRefuerzo: !!esRef, soldados: [],
      roles: (def.roles || ['jefe', 'asalto', 'granadero', 'tirador']).slice(),
      estado: 'guardia', tEst: ahora, puestos: def.puestos || null, ronda: def.ronda || null, nido: def.nido || null,
      reunion: def.reunion || null, sale: def.sale || null, camino: def.camino || null,
      sosp: null, busq: null, alertado: false, desorden: -99, jefe: null, tRadio: -99, ultFrase: {}, tFuego: -99,
      mueve: null, tMueve: 0, flanco: null, tFlanco: -99, tCerebro: ahora + azar() * T.tCerebro, orden: '', prioBichos: false,
      fase: 0, replegados: false, radioQuien: null, tEmpuje: -99, llegoDicho: false, fijarDicho: false, vivos: 0
    };
    escuadrones.push(e);
    if (!esRef) poblar(e);
    return e;
  }
  function puestoDe(e, rol, i) {
    const P = e.puestos; let p = null;
    if (Array.isArray(P)) p = P[i] || null; else if (P) p = P[rol] || null;
    return p;
  }
  function poblar(e) {
    const roles = e.roles, base = e.reunion || (e.sale) || { x: 0, z: 0 };
    let ang = 0;
    if (e.sale && e.camino && e.camino.length) ang = Math.atan2(e.camino[0].x - e.sale.x, e.camino[0].z - e.sale.z);
    for (let i = 0; i < roles.length; i++) {
      const rol = roles[i]; let p = null, nido = false;
      if (e.esRefuerzo && e.sale) {                                                     // el refuerzo aparece en fila, a la par del camino
        const o = (i - (roles.length - 1) / 2) * 1.6, x = e.sale.x + Math.cos(ang) * o - Math.sin(ang) * i * 0.8, z = e.sale.z - Math.sin(ang) * o - Math.cos(ang) * i * 0.8;
        const k = libreCerca(x, z, 4); p = { x: k >= 0 ? cX(k) : x, z: k >= 0 ? cZ(k) : z, rumbo: ang };
      } else {
        p = puestoDe(e, rol, i);
        if (!p && rol === 'tirador' && e.nido) { p = { x: e.nido.x, z: e.nido.z, rumbo: e.nido.rumbo || 0 }; nido = true; }
        if (!p && rol === 'asalto' && e.ronda && e.ronda.length) p = { x: e.ronda[0].x, z: e.ronda[0].z, rumbo: e.ronda[0].rumbo || 0 };
        if (!p) { const k = libreCerca(base.x + (i % 2 ? 1.5 : -1.5), base.z + i * 1.5 - 2, 4); p = { x: k >= 0 ? cX(k) : base.x, z: k >= 0 ? cZ(k) : base.z, rumbo: 0 }; }
        if (p.rumbo === undefined) p.rumbo = e.nido && e.nido.rumbo !== undefined ? e.nido.rumbo : 0;
        if (!nido && !libreEn(p.x, p.z)) { const k = libreCerca(p.x, p.z, 4); if (k >= 0) p = { x: cX(k), z: cZ(k), rumbo: p.rumbo }; }
      }
      const s = nuevoSoldado(e, rol, i + 1, p);
      if (nido) { s.elev = { r: e.nido.r || 1.5, y: e.nido.y || 2.4 }; s.y = s.elev.y; s.post = 2; s.agach = 1; s.tierra = 1; }
      else s.y = ENV.piso(s.x, s.z);
      if (e.esRefuerzo) { s.alerta = 2; s.tConoce = ahora; }
      e.soldados.push(s); soldados.push(s);
      if (rol === 'jefe' && !e.jefe) e.jefe = s;
      const v = ENV.vista ? ENV.vista(s) : null; if (v) { s.vista = v; escribirVista(s, 0); }
    }
    if (!e.jefe) e.jefe = jefeDe(e);
  }
  function escuadron(def) { defs.push({ tipo: 'escuadron', def }); return crearEscuadron(def || {}, false); }
  function refuerzo(def) { defs.push({ tipo: 'refuerzo', def }); const e = crearEscuadron(def || {}, true); red.refuerzo = e; return e; }

  /* ====================================================================================================
     UPDATE: un cuadro del juego
     ==================================================================================================== */
  let tLejosChk = -99, lejosTodos = false, tLentoPens = 0;
  const vivosObj = [];
  /* (percepción gruesa, solo para ahorrar: ¿está el jugador lejos de todos?) */
  function percibirLejos() {
    const j = ENV.jugador();
    for (let i = 0; i < soldados.length; i++) { const s = soldados[i]; if (s.vivo && s.activo && hyp(j.x - s.x, j.z - s.z) < T.lejos) return false; }
    return true;
  }
  function update(dt) {
    if (!(dt > 0)) return;
    if (dt > 0.1) dt = 0.1;
    ahora = ENV.ahora(); cuadro++; leerGrilla();
    let guardia = true; for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo && escuadrones[i].estado !== 'guardia') guardia = false;
    if (guardia && ahora - tLejosChk > 0.5) { tLejosChk = ahora; lejosTodos = percibirLejos(); }
    const lento = guardia && lejosTodos;
    peligros = ENV.peligros() || []; bichos = ENV.bichos() || [];
    tickDialogos(); entregarAvisos(); llegadaRefuerzo();
    for (let i = 0; i < escuadrones.length; i++) { const e = escuadrones[i]; if (e.activo && ahora >= e.tCerebro) { e.tCerebro = ahora + T.tCerebro; cerebro(e); } }
    repartirFichas();
    vivosObj.length = 0;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.activo) continue;
      if (!s.vivo) {
        if (s.muerte && s.muerte.t < 1) s.muerte.t = Math.min(1, (ahora - s.tMuerte) / 1.1);
        if (s.vista) escribirVista(s, dt);
        continue;
      }
      vivosObj.push(s);
      if (ahora >= s.tPerc) { s.tPerc = ahora + (lento ? 1 : T.tPercibir); percibir(s); }
      if (ahora >= s.tPens) { s.tPens = ahora + (lento ? 0.5 : T.tPensar); pensar(s); }
      actuar(s, dt);
    }
    for (let n = Math.max(1, Math.round(dt * 60)); n > 0; n--) if (!procesarTrabajo()) break;
  }
  function reset() {
    for (let i = 0; i < soldados.length; i++) { const s = soldados[i]; if (s.vista && s.vista.dispose) { try { s.vista.dispose(); } catch (err) { /* nada */ } } }
    soldados.length = 0; escuadrones.length = 0; trabajos.length = 0; dialogos.length = 0; partes.length = 0; idSig = 0; vivosObj.length = 0;
    red.uc = null; red.tVisto = -99; red.tSenal = -99; red.tContacto = -99; red.ancla = null; red.fichas.length = 0; red.tirador = null; red.dano.length = 0;
    red.tGranada = -99; red.muerto = false; red.refuerzo = null; red.refPedido = false; red.refEn = -1; red.refLlego = false; red.recJug = -99; red.bichosVistos = false;
    red.tRuido = -99; xOk = false; fichaLibreEn = -99; tLejosChk = -99; ahora = ENV.ahora();
    const d = defs.slice(); defs.length = 0;
    for (let i = 0; i < d.length; i++) { if (d[i].tipo === 'escuadron') escuadron(d[i].def); else refuerzo(d[i].def); }
  }

  /* ====================================================================================================
     CONSULTAS: objetivos (para los bichos), estado (HUD), debug (vista táctica)
     ==================================================================================================== */
  function objetivos() { return vivosObj; }
  function estado() {
    let m = null, ms = 0, combate = false, busqueda = false, quedan = 0;
    for (let i = 0; i < escuadrones.length; i++) { const e = escuadrones[i]; if (!e.activo) continue; if (e.estado === 'combate') combate = true; if (e.estado === 'busqueda') busqueda = true; }
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.vivo || !s.activo) continue; quedan++;
      const v = s.alerta >= 2 ? 1 : s.sosp; if (v > ms) { ms = v; m = s; }
    }
    return {
      sospecha: ms, x: m ? m.x : 0, z: m ? m.z : 0,
      angulo: m ? Math.atan2(m.x - m.estX, m.z - m.estZ) : 0,                          // rumbo desde donde lo percibió hacia el soldado (para el indicador del HUD)
      combate, busqueda, quedan, refuerzo: red.refLlego ? 'llego' : red.refPedido ? 'pedido' : 'no',
      refuerzoEn: red.refPedido && !red.refLlego ? Math.max(0, red.refEn - ahora) : null
    };
  }
  function debug() {
    const S = [], E = [];
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!s.activo) continue;
      const cam = []; if (s.camino) for (let q = s.ci; q < s.camino.length; q++) cam.push({ x: s.camino[q].x, z: s.camino[q].z });
      S.push({ id: s.id, nombre: s.nombre, rol: s.rol, esc: s.esc.nombre, x: s.x, z: s.z, y: s.y, rumbo: s.rumbo, estado: s.estado, tarea: s.tarea,
        postura: s.tierra > 0.5 ? 'tierra' : s.agach > 0.5 ? 'agachado' : 'pie', hp: Math.max(0, Math.round(s.hp)), vivo: s.vivo, ficha: !!s.ficha, ve: s.ve,
        sosp: s.sosp, suprimido: s.supr > T.suprEsconde || s.escondeT > 0, camino: cam, cob: s.cob ? { x: s.cob.x, z: s.cob.z } : null, blanco: s.blanco,
        laser: s.laser ? { x: s.laser.x, y: s.laser.y, z: s.laser.z } : null, luz: s.luz });
    }
    for (let i = 0; i < escuadrones.length; i++) {
      const e = escuadrones[i]; if (!e.activo) continue;
      E.push({ nombre: e.nombre, estado: e.estado, uc: red.uc ? { x: red.uc.x, z: red.uc.z, edad: ahora - red.uc.t, tipo: red.uc.tipo, err: red.uc.err } : null,
        fichas: red.fichas.filter(s => s.esc === e).length, orden: e.orden, sinJefe: e.desorden > ahora, refuerzoEn: red.refPedido && !red.refLlego ? red.refEn - ahora : null,
        fase: e.fase, flanco: e.flanco ? { nombre: e.flanco.s.nombre, lado: e.flanco.lado > 0 ? 'der' : 'izq' } : null });
    }
    const j = ENV.jugador();                                                            // solo para dibujar: ninguna decisión sale de acá
    const G = []; for (let i = 0; i < peligros.length; i++) G.push({ x: peligros[i].x, z: peligros[i].z, t: peligros[i].t });
    return { soldados: S, escuadrones: E, jugador: { x: j.x, z: j.z }, granadas: G };
  }

  return {
    escuadron, refuerzo, update, reset, soldados, rayo: rayoJugador, herir, balaCerca, ruido, explosion, objetivos, estado, debug,
    get escuadrones() { return escuadrones; }, get red() { return red; }, T,
    get astar() { return aCuenta; }, get exposCalc() { return xCalc; }
  };
}

if (typeof module !== 'undefined') module.exports = { crearUE, UE_TUNE };
