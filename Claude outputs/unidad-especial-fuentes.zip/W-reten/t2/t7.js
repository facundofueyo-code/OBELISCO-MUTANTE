const path=require('path');const H=require(path.resolve(__dirname,'..','..','harness.js'));
(async()=>{const h=await H.open(path.join(__dirname,process.argv[2]));try{await h.start();
 console.log('start errores',h.errors.length,'UEFX',await h.ev("typeof UEFX"),'RETEN',await h.ev("typeof RETEN"));
 console.log('luz',JSON.stringify(await h.ev("RETEN.datos.luz")));console.log('verificar',await h.ev("RETEN.verificar().ok"));
 await h.ev("RETEN.ir({bichos:true});1");await h.step(25,1/60,"P.hp=100");
 console.log('25 s con bichos',JSON.stringify(await h.ev("({wave,bichos:enemies.length,STAGE})")),'errores',h.errors.length);
 await h.ev("resetGame();1");console.log('reset ok',await h.ev("RETEN.verificar().ok"),'errores',h.errors.length?h.errors.join('\n').slice(0,1500):'ninguno');
}finally{await h.close();}})();
