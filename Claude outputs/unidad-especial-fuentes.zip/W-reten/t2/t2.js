/* Prueba 2 del retén (lógica): salto de valla, balas hasta que explote un auto de la fila, furgón, reinicio,
   RETEN.ir con y sin bichos (startGame de verdad), bichos que cruzan la barricada. Uso: node t2.js [juego.html] */
const path = require('path');
const UE = path.resolve(__dirname, '..', '..');
const H = require(path.join(UE, 'harness.js'));
const t0 = Date.now(); const log = (...a) => console.log(((Date.now() - t0) / 1000).toFixed(0) + 's', ...a);
const J = o => JSON.stringify(o);
const S = "JSON.stringify({x:+P.pos.x.toFixed(2),y:+P.pos.y.toFixed(2),z:+P.pos.z.toFixed(2)})";
(async () => {
  const h = await H.open(process.argv[2] || path.join(__dirname, 'juego.html'));
  try {
    await h.start(); log('start, errores', h.errors.length);
    /* --- 1. caminar desde el arranque hasta la valla del medio y saltarla --- */
    await h.alReten(-326, 606.8); await h.ev("P.pos.y=floorAt(P.pos.x,P.pos.z);1");
    await h.step(20, 1 / 60, "keys.KeyW=true;P.yaw=Math.PI/2;P.hp=100");
    log('20 s caminando al oeste por z=606,8 (valla en x=-437,7)', await h.ev(S));
    await h.step(.05, 1 / 60, "keys.KeyW=true;keys.Space=true;P.yaw=Math.PI/2;P.hp=100");
    await h.step(2, 1 / 60, "keys.KeyW=true;keys.Space=false;P.yaw=Math.PI/2;P.hp=100");
    log('después de Espacio contra la valla (pasó si x<-438,75)', await h.ev(S));
    await h.step(3, 1 / 60, "keys.KeyW=true;P.yaw=Math.PI/2;P.hp=100");
    log('sigue al oeste 3 s', await h.ev(S));
    /* valla norte de la punta, desde el este */
    await h.ev("P.pos.set(-433,floorAt(-433,598.7),598.7);P.vel.set(0,0,0);MOV.reset();1");
    await h.step(1.2, 1 / 60, "keys.KeyW=true;P.yaw=Math.PI/2;P.hp=100");
    log('contra la valla norte', await h.ev(S));
    await h.step(.05, 1 / 60, "keys.KeyW=true;keys.Space=true;P.yaw=Math.PI/2");
    await h.step(2, 1 / 60, "keys.KeyW=true;keys.Space=false;P.yaw=Math.PI/2");
    log('tras saltar la valla norte', await h.ev(S));
    /* auto 784 desde el este */
    await h.ev("P.pos.set(-388,floorAt(-388,611.4),611.4);P.vel.set(0,0,0);MOV.reset();1");
    await h.step(2.5, 1 / 60, "keys.KeyW=true;P.yaw=Math.PI/2;P.hp=100");
    log('contra el auto 784 (x=-399, cola en ~-396,8)', await h.ev(S));
    await h.ev("keys.KeyW=false;keys.Space=false;1");

    /* --- 2. balas: Uzi contra el furgón 782 de la fila hasta que se prende y explota --- */
    const tgt = await h.ev("(()=>{const c=RETEN.autos.find(c=>c.S.id==='furgon'&&c.x<-400);return {x:c.x,z:c.z,i:VCARS.indexOf(c)};})()");
    const aim = `{const dx=${tgt.x}-P.pos.x,dz=${tgt.z}-P.pos.z;P.yaw=Math.atan2(-dx,-dz);P.pitch=-.1;}`;
    await h.ev(`P.pos.set(-414,floorAt(-414,608.5),608.5);P.vel.set(0,0,0);MOV.reset();switchTo(2);1`);
    await h.step(1, 1 / 60, "P.hp=100;" + aim);
    let hist = [];
    for (let k = 0; k < 6; k++) {
      await h.step(3, 1 / 60, `P.hp=100;mouseDown=true;W[2].ammo=32;W[2].res=999;${aim}`);
      hist.push(await h.ev(`(()=>{const c=VCARS[${tgt.i}];return c.hits+'/'+c.st;})()`));
    }
    log('golpes/estado cada 3 s', hist.join(' '));
    await h.ev("mouseDown=false;P.pos.set(-370,floorAt(-370,607),607);1");
    await h.step(9, 1 / 60, "P.hp=100;mouseDown=false");
    const boom = await h.ev(`(()=>{const c=VCARS[${tgt.i}],e=RETEN.piezas.HD,m=e.mesh;const r=c.rg.find(r=>r[0]===e);return {st:c.st,muertos:c.cs.filter(q=>q.dead).length,restos:VWRECK.length,calcoY:r?+m.geometry.attributes.position.array[r[1]*3+1].toFixed(1):null};})()`);
    log('después de la explosión', J(boom));
    /* furgón del retén: tiros y explosión cerca no le hacen nada; la bala para en la caja */
    log('rayo al furgón norte desde x=-425', J(await h.ev(`(()=>{const o=new THREE.Vector3(-425,1.5,603.3),d=new THREE.Vector3(-1,0,0);let best=1e9,k=null;for(const b of obstacles){const t=rayBox(o,d,b);if(t<best){best=t;k=b.k||'?';}}const ch=rayCars(o,d,best);return {t:+best.toFixed(2),k,autoAntes:ch?VCARS.indexOf(ch.car):null};})()`)));

    /* --- 3. reinicio: todo vuelve --- */
    await h.ev("resetGame();1");
    log('tras resetGame', J(await h.ev(`(()=>{const c=VCARS[${tgt.i}],e=RETEN.piezas.HD,m=e.mesh,r=c.rg.find(r=>r[0]===e);return {st:c.st,hits:c.hits,muertos:c.cs.filter(q=>q.dead).length,x:c.x,z:c.z,restos:VWRECK.length,
      calcoY:r?+m.geometry.attributes.position.array[r[1]*3+1].toFixed(2):null,ok:RETEN.verificar().ok};})()`)));

    /* --- 4. RETEN.ir sin bichos (startGame real) --- */
    let t1 = Date.now();
    await h.ev("RETEN.ir({bichos:false});1");
    log('RETEN.ir({bichos:false}) ms', Date.now() - t1, J(await h.ev("({running,STAGE,gate:GATE.open,wave,intermission,esc:W[1].res,uzi:W[2].res,x:+P.pos.x.toFixed(1),y:+P.pos.y.toFixed(2),z:+P.pos.z.toFixed(1),yaw:+P.yaw.toFixed(2),left:$('#left').textContent})")));
    await h.step(15, 1 / 60, "P.hp=100");
    log('15 s sin bichos', J(await h.ev("({wave,en:enemies.length,toSpawn})")));
    /* --- 5. con bichos: arranque normal del botón (20 s) --- */
    t1 = Date.now();
    await h.ev("RETEN.ir({bichos:true});1");
    log('RETEN.ir({bichos:true}) ms', Date.now() - t1, J(await h.ev("({wave,intermission,bossCount,x:+P.pos.x.toFixed(1),z:+P.pos.z.toFixed(1)})")));
    await h.step(20, 1 / 60, "P.hp=100");
    log('20 s con bichos', J(await h.ev("({wave,en:enemies.length,toSpawn,cerca:enemies.filter(e=>Math.hypot(e.obj.position.x-P.pos.x,e.obj.position.z-P.pos.z)<4).length})")));
    /* jugador del lado este de la barricada: los bichos salen del subte de atrás (Sáenz Peña) y tienen que cruzarla */
    await h.ev("P.pos.set(-416,floorAt(-416,607.5),607.5);P.vel.set(0,0,0);1");
    const pos = [];
    for (let k = 0; k < 8; k++) {
      await h.step(5, 1 / 60, "P.hp=100");
      pos.push(await h.ev("enemies.map(e=>[e.id||e.type,+e.obj.position.x.toFixed(1),+e.obj.position.z.toFixed(1)])"));
    }
    /* trabados: cerca de la barricada (x∈[-452,-430]) y movieron menos de 1 m en 10 s */
    const ult = pos[pos.length - 1], ant = pos[pos.length - 3];
    const trab = ult.filter(([id, x, z], i) => x > -452 && x < -430 && ant[i] && Math.hypot(ant[i][1] - x, ant[i][2] - z) < 1);
    const cruz = ult.filter(([id, x]) => x > -436).length;
    log('40 s lado este', J({total: ult.length, alEsteDeLaBarricada: cruz, trabadosEnBarricada: trab, cercaJugador: await h.ev("enemies.filter(e=>Math.hypot(e.obj.position.x-P.pos.x,e.obj.position.z-P.pos.z)<4).length"), wave: await h.ev('wave')}));
    log('posiciones a los 40 s', J(ult.slice(0, 14)));
    /* --- 6. morir y «Otra vuelta»: vuelve al retén --- */
    await h.ev("gameOver();1");
    await h.ev("document.getElementById('btnAgain').click();1");
    log('otra vuelta', J(await h.ev("({running,STAGE,wave,x:+P.pos.x.toFixed(1),z:+P.pos.z.toFixed(1)})")));
    await h.ev("gameOver();document.getElementById('btnStart').click();1");
    log('botón normal después', J(await h.ev("({running,STAGE,wave,x:+P.pos.x.toFixed(1),z:+P.pos.z.toFixed(1)})")));
    log('errores', h.errors.length ? h.errors.join('\n').slice(0, 3000) : 'ninguno');
  } finally { await h.close(); log('cerrado'); }
})().catch(e => { log('FALLA', e.message.slice(0, 2000)); process.exit(1); });
