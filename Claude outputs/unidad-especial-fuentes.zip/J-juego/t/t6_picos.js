// Prueba 6b: de dónde salen los cuadros caros de UE.update (arco de granada, rayos, modelos).
const H=require('../../harness.js'),fs=require('fs');
const INST=require('./inst.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
const OUT=process.argv[3]||__dirname+'/t6.json';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto');const R={};const ev=c=>h.ev(c);
  try{
    await h.start();await ev("RETEN.ir({bichos:false});1");await ev(INST);await h.step(.5);
    await ev(`(()=>{const E=UEG.ENV;window.__P={arco:{n:0,ms:0,max:0},rayo:{n:0,ms:0,max:0},f:{arco:0,rayo:0,n:0},caros:[]};const Q=__P;
      const a0=E.arco;E.arco=function(...a){const t=performance.now();const r=a0(...a);const ms=performance.now()-t;Q.arco.n++;Q.arco.ms+=ms;if(ms>Q.arco.max)Q.arco.max=ms;Q.f.arco+=ms;return r;};
      const r0=E.rayo;E.rayo=function(...a){const t=performance.now();const r=r0(...a);const ms=performance.now()-t;Q.rayo.n++;Q.rayo.ms+=ms;if(ms>Q.rayo.max)Q.rayo.max=ms;Q.f.rayo+=ms;Q.f.n++;return r;};
      const u0=UEG.update;window.__u0=u0;return 1;})()`);
    /* envolver el update del pegamento desde afuera: se mide cada cuadro con su desglose */
    const cada=`{const t=performance.now();__P.f.arco=0;__P.f.rayo=0;__P.f.n=0;}`;
    await ev("window.__inmortal=true;P.pos.set(-410,floorAt(-410,607),607);P.vel.set(0,0,0);P.yaw=Math.PI/2;UE.T.refuerzoCombate=1;UE.T.refuerzoLlega=4;UEG.medirReset();1");
    for(let k=0;k<50;k++){
      await h.step(1,1/60,"__fich();{const Q=__P;const m0=UEG.MED.ia,mm0=UEG.MED.mod,n0=UEG.MED.n;Q.f.arco=0;Q.f.rayo=0;Q.f.n=0;window.__antes=[m0,mm0];}");
    }
    R.prof=await ev("(()=>{const o={};for(const [k,v] of Object.entries(UE.interno.prof||{}))o[k]={n:v.n,ms:+v.ms.toFixed(1),max:+v.max.toFixed(1),lentos:(v.lentos||[]).slice(0,3)};return o;})()");lg("prof",JSON.stringify(R.prof));R.P=await ev("({arco:__P.arco,rayo:__P.rayo,med:{n:UEG.MED.n,ia:+(UEG.MED.ia/UEG.MED.n).toFixed(3),mod:+(UEG.MED.mod/UEG.MED.n).toFixed(3),max:UEG.MED.max,peores:UEG.MED.peores.sort((a,b)=>b[1]-a[1]).slice(0,8)},astar:UE.astar,expos:UE.exposCalc,ev:__L.ev,vivos:UE.soldados.filter(s=>s.vivo).length})");
    lg('P',JSON.stringify(R.P));
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(OUT,JSON.stringify(R));
  await h.close();lg('cerrado');
})();
