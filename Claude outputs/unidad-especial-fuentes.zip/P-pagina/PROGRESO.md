# P-pagina · progreso

## Hecho
- `armar.py` arma `unidad-especial-concepto.html` (462 KB, Three.js r128 desde cdnjs) y `prueba.html` (igual, con `../three.r128.min.js`) desde `src/` más los 5 archivos del equipo pegados tal cual, cada uno en su `<script>`.
- Mapa recortado x∈[-570,-296) z∈[536,694): B/Hh/G en tramos + base64 (`src/mapa.py` lo arma, `src/mapa.js` lo desarma): 15,8 KB. `pruebas/recorte.js`: con el mapa entero y con el recortado el mundo da IGUAL, foto por foto cada segundo, en 5 casos (quieto 40 s, decente ×3 hasta 150 s, 6 bichos 60 s).
- Tablero (`src/tablero.js`): reposo con el retén en guardia bajo el velo; juego con teclado y mouse; «Mirar una pelea» con `JG.decente`; línea de visión con 180 rayos; luces siempre visibles (linternas con oclusión, láser, fogonazos, trazadoras, reflectores, bocas del subte); chispas, granadas con radio y cuenta a menos de 12 m, explosiones con marca; bichos; caídos con botín; «Ver lo que saben» (último lugar conocido, fichas, caminos, coberturas, estado en palabras, panel del escuadrón, trazadoras por modo); HUD en HTML (radio, detección, dirección del daño, salud, arma, granadas, posturas); perillas fichas/puntería/daño; finales; pausa; cámara lenta; pantalla completa; rueda.
- Reservas del juego en «juego» (pistola ∞, escopeta 2+10, Uzi 32+64); fusil y granadas solo de botín. En «mirar» el jugador automático usa las armas del simulador (como en lo medido).
- Sonido Web Audio (`src/sonido.js`), arranca con un clic.
- Visor 3D (`src/visor.js`): se crea al entrar en pantalla, se pausa fuera o con la pestaña oculta; sin Three.js avisa y el tablero sigue.
- Tarjetas; LA RADIO se arma con `UE_FRASES`.

## Pruebas (todas pasan, cero errores de consola)
- `p1.js` 90 s mirando una pelea · `p2.js` capturas · `p3.js` teclas, mouse, reservas, botín, pausa, finales · `p4.js` visor, costo, celular 400 px · `p5.js` avisos sin pisarse, botones, movimiento reducido · `p7.js` 400 px escritorio y publicada sin red · `p9.js` apuntar y pegar.

## Flojo o pendiente
- El indicador de detección usa `UE.estado().sospecha` (no existe `alerta`; `sospecha` ya vale 1 con alerta ≥ 2).
- En el celular la escala es 7 px/m (en la compu, 10).
- Con muchos soldados juntos, los rótulos de «Ver lo que saben» se acomodan en 6 lugares posibles; pueden quedar apretados.
- El sonido no se escuchó (Chromium sin pantalla): solo se comprobó que no rompe.
- Las capturas 2, 3, 4 y 7 se regeneraron con la versión final sin volver a mirarlas; 5, 6 y 8 se revisaron.
