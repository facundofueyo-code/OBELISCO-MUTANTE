// Prueba 9: después del combate, si el testigo se va lejos, barren y vuelven a los puestos (guardia alerta).
const H=require('../../harness.js'),fs=require('fs');
const INST=require('./inst.js');
const F=process.argv[2]||__dirname+'/../obelisco-mutante.html';
(async()=>{const t0=Date.now();const lg=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(0)+'s',...a);
  const h=await H.open(F);lg('abierto');const R={};const ev=c=>h.ev(c);
  try{
    await h.start();await ev("RETEN.ir({bichos:false});1");await ev(INST);await h.step(.5);
    await ev("window.__inmortal=true;P.pos.set(-404,floorAt(-404,607),607);P.vel.set(0,0,0);P.yaw=Math.PI/2;1");
    for(let k=0;k<20;k++){await h.step(.5);if(await ev("UE.estado().combate"))break;}
    await h.step(4);
    R.combate=await ev("({T:+T.toFixed(1),esc:UE.escuadrones.map(e=>[e.nombre,e.estado,e.activo])})");lg('combate',JSON.stringify(R.combate));
    await ev("P.pos.set(-150,floorAt(-150,606),606);P.vel.set(0,0,0);1");          // se va: 290 m al este, fuera de la vista
    const linea=[];for(let k=0;k<12;k++){await h.step(10);linea.push(await ev("[+T.toFixed(0),UE.escuadrones.filter(e=>e.activo).map(e=>e.estado).join('/'),UE.estado().refuerzo]"));}
    R.linea=linea;lg('linea',JSON.stringify(linea));
    R.fin=await ev(`(()=>{const D=RETEN.datos;return UE.soldados.filter(s=>s.vivo).map(s=>{const p=s.rol==='tirador'?D.nido:(UEG.ajustes[1]&&UEG.ajustes[1].rol===s.rol?UEG.ajustes[1].a:D.puestos.find(q=>q.rol===s.rol));
      return [s.nombre,s.estado,s.tarea,+s.x.toFixed(1),+s.z.toFixed(1),p?+Math.hypot(s.x-p.x,s.z-p.z).toFixed(1):null];});})()`);
    lg('fin',JSON.stringify(R.fin));
    R.radio=await ev("__L.radio.slice(-8).map(r=>r[0]+' '+r[1]+': '+r[3])");lg('radio',JSON.stringify(R.radio));
  }catch(e){lg('EXC',e.message.slice(0,600));R.exc=e.message;}
  R.errores=h.errors.slice(0,10);lg('errores',JSON.stringify(R.errores));
  fs.writeFileSync(__dirname+'/t9.json',JSON.stringify(R));
  await h.close();lg('cerrado');
})();
