/* Prueba 4: visor 3D (se crea al entrar en pantalla), costo por cuadro, y celular a 400 px (sin desborde, velo táctil, mirar una pelea con bichos). */
const path = require('path');
const H = require(path.join(__dirname, '../../harness.js'));
const PAG = path.join(__dirname, '../prueba.html');
const CAP = path.join(__dirname, '../cap/');
const quiero = process.argv.slice(2);
const ok = (c, m) => console.log((c ? 'OK   ' : 'FALLA') + ' ' + m);
(async () => {
  const h = await H.openPage(PAG, { width: 1280, height: 800 });
  const p = h.page;
  try {
    await p.waitForTimeout(600);
    const antes = await p.evaluate(() => !!(window.UEVISOR && UEVISOR.V));
    ok(!antes, 'el visor no existe antes de verlo');
    await p.evaluate(() => document.getElementById('vStage').scrollIntoView({ block: 'center' }));
    await p.waitForTimeout(2500);
    const v = await p.evaluate(() => { const V = UEVISOR.V; if (!V) return { fallo: UEVISOR.fallo }; return V.info(); });
    ok(v && v.soldados >= 1, 'visor creado al entrar en pantalla: ' + JSON.stringify(v));
    await p.click('#vRoles button[data-v="todos"]'); await p.click('#vPoses button[data-v="Agachado"]');
    await p.waitForTimeout(2500);
    const v2 = await p.evaluate(() => UEVISOR.V.info());
    ok(v2.soldados === 4, 'Los cuatro + Agachado: ' + v2.soldados + ' soldados, ' + v2.triangulos + ' triángulos');
    if (quiero.includes('visor')) { const r = await p.evaluate(() => { const b = document.getElementById('vStage').getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height }; }); await p.screenshot({ path: CAP + '6-visor.png', clip: { x: r.x, y: r.y, width: r.w, height: r.h + 120 } }); }
    await p.evaluate(() => window.scrollTo(0, 0)); await p.waitForTimeout(300);
    await p.click('#bMirarV'); await p.evaluate(() => UEPAG.congelar(true));
    await p.evaluate(() => UEPAG.avanzar(25));
    console.log('costo (cuadro de 1/60 s, SwiftShader):', JSON.stringify(await p.evaluate(() => UEPAG.costo(120))));
    console.log('errores escritorio:', h.errors.length ? h.errors.slice(0, 5).join('\n') : 0);
    // celular
    const ctx = await h.browser.newContext({ viewport: { width: 400, height: 860 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    const m = await ctx.newPage(); const errs = [];
    m.on('pageerror', e => errs.push('PAGEERR ' + e.message)); m.on('console', x => { if (x.type() === 'error' && !/Failed to load resource/.test(x.text())) errs.push('CONSOLE ' + x.text().slice(0, 300)); });
    await m.route('**/*', r => { const u = r.request().url(); if (u.startsWith('file:')) r.continue(); else r.abort(); });
    await m.goto('file://' + PAG, { waitUntil: 'load' }); await m.waitForTimeout(800);
    const c0 = await m.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: innerWidth, jugar: !document.getElementById('bJugar').hidden, tactil: !document.getElementById('veloTactil').hidden, ar: (() => { const r = document.getElementById('stage').getBoundingClientRect(); return +(r.width / r.height).toFixed(2); })() }));
    ok(c0.sw <= c0.iw && !c0.jugar && c0.tactil, 'celular en reposo: ' + JSON.stringify(c0));
    await m.tap('#bMirarV'); await m.evaluate(() => UEPAG.congelar(true));
    await m.tap('#bBichos');
    const r = await m.evaluate(() => UEPAG.avanzar(35));
    ok(r.cuentas.balasSold > 0 && r.cuentas.radio > 0, 'celular mirando una pelea con bichos 35 s: ' + JSON.stringify({ t: r.t, radio: r.cuentas.radio, balasSold: r.cuentas.balasSold, bajas: r.cuentas.bajas, fin: r.fin }));
    await m.tap('#bSaben'); await m.evaluate(() => UEPAG.dibujar());
    const anchos = await m.evaluate(() => { const malos = []; for (const el of document.querySelectorAll('.wrap *')) { const b = el.getBoundingClientRect(); if (b.right > innerWidth + 0.5 && b.width > 0) malos.push(el.tagName + '.' + el.className + ' ' + Math.round(b.right)); } return { sw: document.documentElement.scrollWidth, iw: innerWidth, malos: malos.slice(0, 6) }; });
    ok(anchos.sw <= anchos.iw && !anchos.malos.length, 'celular sin desborde lateral: ' + JSON.stringify(anchos));
    if (quiero.includes('celu')) { await m.evaluate(() => document.getElementById('stage').scrollIntoView({ block: 'start' })); await m.screenshot({ path: CAP + '7-celular.png' }); }
    console.log('errores celular:', errs.length ? errs.slice(0, 5).join('\n') : 0);
    await ctx.close();
  } finally { await h.close(); }
})();
