/* utilidades comunes de las pruebas de W-reten (se usan con ../../harness.js) */
const path=require('path');
const H=require(path.join(__dirname,'..','..','harness.js'));
const t0=Date.now();
const log=(...a)=>console.log(((Date.now()-t0)/1000).toFixed(1)+'s',...a);

/* cámara libre: saca al juego del modo partida para que no pise la cámara; la deja donde se le pide.
   look: [x,y,z] hacia donde mira. fog: densidad de niebla para esta captura (null = la del juego) */
async function libre(h,pos,look,out,opt={}){
  const fog=opt.fog===undefined?null:opt.fog;
  await h.ev(`(()=>{window.__fc={pos:${JSON.stringify(pos)},look:${JSON.stringify(look)},fog:${JSON.stringify(fog)}};
    if(!window.__r0){window.__r0=window.__render;}
    window.__render=(s,c)=>{const f=window.__fc;const sv={p:camera.position.clone(),q:camera.quaternion.clone(),fd:scene.fog.density};
      camera.position.set(f.pos[0],f.pos[1],f.pos[2]);camera.up.set(0,1,0);camera.lookAt(f.look[0],f.look[1],f.look[2]);camera.updateMatrixWorld(true);
      if(f.fog!==null)scene.fog.density=f.fog;
      const v=vm.visible;vm.visible=false;MOV.show(false);
      window.__r0(s,c);vm.visible=v;scene.fog.density=sv.fd;camera.position.copy(sv.p);camera.quaternion.copy(sv.q);camera.updateMatrixWorld(true);};
    return 1;})()`);
  await h.shot(out);
  await h.ev(`(()=>{window.__render=window.__r0;return 1;})()`);
  return out;
}
/* pone al jugador en un punto mirando con yaw/pitch y deja pasar un instante para que la cámara y los LOD se acomoden */
async function parado(h,x,z,yaw,pitch=0,t=.4){
  await h.ev(`(()=>{P.pos.set(${x},floorAt(${x},${z}),${z});P.vel.set(0,0,0);P.yaw=${yaw};P.pitch=${pitch};VLOD.t=0;TREE_LOD.t=0;return 1;})()`);
  await h.step(t);
}
const info=h=>h.ev(`({calls:renderer.info.render.calls,tris:renderer.info.render.triangles,geos:renderer.info.memory.geometries,tex:renderer.info.memory.textures,progs:renderer.info.programs.length})`);
module.exports={H,log,libre,parado,info};
