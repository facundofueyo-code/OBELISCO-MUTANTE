/* =====================================================================================================
   UEG · pegamento de la Unidad Especial (Obelisco Mutante v1.17.0)
   -----------------------------------------------------------------------------------------------------
   Une la IA de escuadrón (crearUE, de ue_ia.js) con el juego y con las otras piezas:
     · arma el ENV: todo lo que la IA sabe del mundo (grilla, jugador, piso, rayos, luz, bichos, peligros)
       y lo que pasa en el juego cuando ellos tiran, lanzan una granada, hablan por radio o se mueren;
     · crea el escuadrón «Ceniza» en el retén (RETEN.datos) y deja listo el refuerzo «Tizón»;
     · crea los modelos (UEM) y deja de dibujarlos y animarlos cuando están lejos o la sección B no se ve;
     · las balas del jugador contra ellos (fire(), en el marcador rayo-jugador), las explosiones, el ruido,
       el HUD (UEB.estado), la vista táctica (UEB.debug), los pasos y el botín;
     · si al jugador lo matan ellos, la pantalla de fin dice «Testigo eliminado».
   Va en el marcador de módulos después de ue_modelo.js y ue_ia.js (los pega el mismo parche) y de los
   módulos de F, G, M y W. Antes de usar un módulo ajeno pregunta si está (typeof): sin uno, lo demás anda.
   Nada de esto crea materiales ni luces: los únicos objetos 3D nuevos son los modelos de UEM.
   ===================================================================================================== */
const UEG=(()=>{
  /* ---------- números para ajustar ---------- */
  const TUNE={
    visDist:170,      // m: más lejos que esto (o con la sección B oculta) el soldado no se dibuja ni se anima
    pasosDist:24,     // m: hasta dónde se cuentan sus pasos (UESND igual los corta a 15 m)
    equipoDist:12,    // m: roce de correaje y hebillas de los que se mueven cerca
    radioDist:250,    // m: en guardia, la radio solo se «intercepta» a esta distancia del que habla
    puntos:250,       // puntos por soldado abatido (× combo, como los bichos)
    cajaMun:.9,       // probabilidad de que suelte munición (el asalto, de escopeta; los demás, la que más te falte)
    cajaSalud:.3,     // probabilidad de que suelte una empanada (+25 de salud)
    danoAuto:.5,      // golpes que le hace a un auto cada bala de ellos (el auto se prende a los 20)
    corrimiento:4,    // m: lo más que se corre el puesto del jefe o del granadero para que vea la avenida
    verMin:.5,        // parte de los puntos de la avenida que tiene que ver un puesto para decir que «tiene línea»
    nidoR:3.5         // m: el techo del furgón (5,9 × 2,5 m) entero cuenta como plataforma del tirador para su línea de visión
  };
  const _o=new V3(),_d=new V3(),_a=new V3(),_b=new V3(),_dir=new V3(),_hp=new V3();
  const _pos={x:0,y:0,z:0};
  const hay={
    reten:()=>typeof RETEN!=='undefined'&&!!RETEN&&!!RETEN.datos,
    fx:()=>typeof UEFX!=='undefined',
    snd:()=>typeof UESND!=='undefined',
    hud:()=>typeof UEHUD!=='undefined',
    gran:()=>typeof GRAN!=='undefined'&&!!GRAN
  };

  /* =================================================================================================
     EL MUNDO PARA LA IA
     ================================================================================================= */
  /* --- jugador: los pies (P.pos), no los ojos. Un solo objeto que se reescribe --- */
  const J={x:0,y:0,z:0,vx:0,vz:0,agach:0,ojoY:1.7,alto:1.8,hp:100,vivo:true,linterna:false,recargando:false,corriendo:false};
  function jugador(){
    const p=P.pos;J.x=p.x;J.y=p.y;J.z=p.z;J.vx=P.vel.x;J.vz=P.vel.z;J.agach=P.ch;
    J.ojoY=1.7-.68*P.ch;J.alto=1.8-.68*P.ch;J.hp=P.hp;J.vivo=running&&!over&&P.hp>0;J.linterna=!!torchOn;
    const w=W[wi];J.recargando=!!(w&&w.rT>=0);J.corriendo=!!P.sprint||(P.vel.x*P.vel.x+P.vel.z*P.vel.z)>49;
    return J;
  }

  /* --- cajas (obstacles) en una grilla de 8 m: la IA tira cientos de rayos y recorrer todas las cajas es caro.
         Se rehace sola si cambia la cantidad (el retén agrega las suyas, un vidrio roto se saca). Los vidrios no frenan. --- */
  const OC=8,OH=new Map();let ohN=-1,ohMarca=0;
  const ok=(i,j)=>i*4096+j;
  function ohArmar(){
    OH.clear();
    for(const b of obstacles){if(b.glass)continue;
      const i0=Math.floor(b.x0/OC),i1=Math.floor(b.x1/OC),j0=Math.floor(b.z0/OC),j1=Math.floor(b.z1/OC);
      if((i1-i0+1)*(j1-j0+1)>400)continue;           // nada del juego mide más de 160 m de lado; por las dudas
      for(let i=i0;i<=i1;i++)for(let j=j0;j<=j1;j++){const k=ok(i,j);let a=OH.get(k);if(!a)OH.set(k,a=[]);a.push(b);}}
    ohN=obstacles.length;
  }
  /* rayo contra una caja (AABB): distancia de entrada o Infinity. Si el origen está adentro, 0 */
  function cajaT(ox,oy,oz,dx,dy,dz,b,tm){
    let t0=0,t1=tm,a,c,q;
    if(dx>-1e-9&&dx<1e-9){if(ox<b.x0||ox>b.x1)return Infinity;}
    else{a=(b.x0-ox)/dx;c=(b.x1-ox)/dx;if(a>c){q=a;a=c;c=q;}if(a>t0)t0=a;if(c<t1)t1=c;if(t0>t1)return Infinity;}
    if(dy>-1e-9&&dy<1e-9){if(oy<b.y0||oy>b.y1)return Infinity;}
    else{a=(b.y0-oy)/dy;c=(b.y1-oy)/dy;if(a>c){q=a;a=c;c=q;}if(a>t0)t0=a;if(c<t1)t1=c;if(t0>t1)return Infinity;}
    if(dz>-1e-9&&dz<1e-9){if(oz<b.z0||oz>b.z1)return Infinity;}
    else{a=(b.z0-oz)/dz;c=(b.z1-oz)/dz;if(a>c){q=a;a=c;c=q;}if(a>t0)t0=a;if(c<t1)t1=c;if(t0>t1)return Infinity;}
    return t0;
  }
  let cajaHit=null;
  /* recorre los casilleros de 8 m que cruza el rayo (DDA) y prueba cada caja una sola vez */
  function rayoCajas(ox,oy,oz,dx,dy,dz,max){
    if(obstacles.length!==ohN)ohArmar();
    const marca=++ohMarca;let best=max;cajaHit=null;
    let i=Math.floor(ox/OC),j=Math.floor(oz/OC);
    const si=dx>0?1:-1,sj=dz>0?1:-1,ax=Math.abs(dx),az=Math.abs(dz);
    const tdx=ax>1e-9?OC/ax:Infinity,tdz=az>1e-9?OC/az:Infinity;
    let tx=ax>1e-9?((dx>0?(i+1)*OC:i*OC)-ox)/dx:Infinity,tz=az>1e-9?((dz>0?(j+1)*OC:j*OC)-oz)/dz:Infinity;
    for(let n=0;n<400;n++){
      const a=OH.get(ok(i,j));
      if(a)for(let q=0;q<a.length;q++){const b=a[q];if(b._ueM===marca)continue;b._ueM=marca;
        const t=cajaT(ox,oy,oz,dx,dy,dz,b,best);if(t<best){best=t;cajaHit=b;}}
      const tn=tx<tz?tx:tz;if(tn>=best)break;
      if(tx<tz){i+=si;tx+=tdx;}else{j+=sj;tz+=tdz;}
    }
    return best;
  }
  /* --- autos en una grilla de 16 m: rayCars recorre los 1263 autos en cada rayo (0,1 ms acá) y la IA tira cientos.
         Se rehace cada medio segundo (los autos casi no se mueven: los empuja un bicho grande o vuelan);
         cada auto entra con 3 m de margen por si se movió en el medio. La cuenta por auto es la de rayCars. --- */
  const AC_=16,AH=new Map();let ahT=-9,ahMarca=0,ahSuma=NaN;
  /* cada medio segundo se mira si algún auto se movió o voló (una suma de posiciones y estados); solo entonces se rehace */
  function ahRevisar(){ahT=T;let su=0;for(const c of VCARS)su+=c.x*1.31+c.z*.77+(c.st>=3||c.crushed?1e4:0);if(su!==ahSuma){ahSuma=su;ahArmar();}}
  function ahArmar(){AH.clear();
    for(const c of VCARS){if(c.st>=3||c.crushed)continue;const r=c.L*.6+.6+3;
      const i0=Math.floor((c.x-r)/AC_),i1=Math.floor((c.x+r)/AC_),j0=Math.floor((c.z-r)/AC_),j1=Math.floor((c.z+r)/AC_);
      for(let i=i0;i<=i1;i++)for(let j=j0;j<=j1;j++){const k=ok(i,j);let a=AH.get(k);if(!a)AH.set(k,a=[]);a.push(c);}}}
  const autoHit={car:null,t:0};
  function autoT(c,ox,oy,oz,dx,dy,dz,bt){
    if(c.st>=3||c.crushed)return Infinity;
    const ex=c.x-ox,ez=c.z-oz,along=ex*dx+ez*dz;if(along<-3||along>bt+3)return Infinity;
    const px=ex-dx*along,pz=ez-dz*along,rr=c.L*.6+.6;if(px*px+pz*pz>rr*rr)return Infinity;
    const ca=Math.cos(c.a),sa=Math.sin(c.a),lx=(ox-c.x)*ca-(oz-c.z)*sa,lz=(ox-c.x)*sa+(oz-c.z)*ca,ly=oy-(c.by||0),ldx=dx*ca-dz*sa,ldz=dx*sa+dz*ca;
    let t0=0,t1=bt,a,b,q;
    const W2=c.W/2,L2=c.L/2,yt=c.H*.97;
    if(ldx>-1e-8&&ldx<1e-8){if(lx<-W2||lx>W2)return Infinity;}else{a=(-W2-lx)/ldx;b=(W2-lx)/ldx;if(a>b){q=a;a=b;b=q;}if(a>t0)t0=a;if(b<t1)t1=b;if(t0>t1)return Infinity;}
    if(dy>-1e-8&&dy<1e-8){if(ly<.12||ly>yt)return Infinity;}else{a=(.12-ly)/dy;b=(yt-ly)/dy;if(a>b){q=a;a=b;b=q;}if(a>t0)t0=a;if(b<t1)t1=b;if(t0>t1)return Infinity;}
    if(ldz>-1e-8&&ldz<1e-8){if(lz<-L2||lz>L2)return Infinity;}else{a=(-L2-lz)/ldz;b=(L2-lz)/ldz;if(a>b){q=a;a=b;b=q;}if(a>t0)t0=a;if(b<t1)t1=b;if(t0>t1)return Infinity;}
    return t0<bt?t0:Infinity;
  }
  /* primer auto que cruza el rayo antes de max: {car,t} (el mismo objeto cada vez) o null */
  function rayoAutos(ox,oy,oz,dx,dy,dz,max){
    if(T-ahT>.5||T<ahT)ahRevisar();
    const marca=++ahMarca;let best=max,car=null;
    let i=Math.floor(ox/AC_),j=Math.floor(oz/AC_);
    const si=dx>0?1:-1,sj=dz>0?1:-1,ax=Math.abs(dx),az=Math.abs(dz);
    const tdx=ax>1e-9?AC_/ax:Infinity,tdz=az>1e-9?AC_/az:Infinity;
    let tx=ax>1e-9?((dx>0?(i+1)*AC_:i*AC_)-ox)/dx:Infinity,tz=az>1e-9?((dz>0?(j+1)*AC_:j*AC_)-oz)/dz:Infinity;
    for(let n=0;n<200;n++){
      const a=AH.get(ok(i,j));
      if(a)for(let q=0;q<a.length;q++){const c=a[q];if(c._ueM===marca)continue;c._ueM=marca;const t=autoT(c,ox,oy,oz,dx,dy,dz,best);if(t<best){best=t;car=c;}}
      const tn=tx<tz?tx:tz;if(tn>=best)break;
      if(tx<tz){i+=si;tx+=tdx;}else{j+=sj;tz+=tdz;}
    }
    if(!car)return null;autoHit.car=car;autoHit.t=best;return autoHit;
  }
  /* ENV.rayo: primer choque contra el mundo fijo (edificios, cajas y autos) o Infinity.
     Anota qué tocó (RZ): la bala de un soldado que termina ahí dice si fue un auto (lo daña) o chapa/pared (el efecto) */
  const RZ={t:Infinity,que:'',car:null,caja:null};
  function rayo(ox,oy,oz,dx,dy,dz,max){
    if(!(max>0))max=300;fRayos++;
    _o.set(ox,oy,oz);_d.set(dx,dy,dz);
    let t=rayWalls(_o,_d,max),que='pared',car=null,caja=null;
    if(!(t<max)){t=max;que='';}
    const tc=rayoCajas(ox,oy,oz,dx,dy,dz,t);if(tc<t){t=tc;que='caja';caja=cajaHit;}
    const ch=rayoAutos(ox,oy,oz,dx,dy,dz,t);if(ch&&ch.t<t){t=ch.t;que='auto';car=ch.car;caja=null;}
    RZ.t=que?t:Infinity;RZ.que=que;RZ.car=car;RZ.caja=caja;
    return que?t:Infinity;
  }
  const rayoLibre=(ax,ay,az,bx,by,bz)=>{const dx=bx-ax,dy=by-ay,dz=bz-az,d=Math.sqrt(dx*dx+dy*dy+dz*dz);if(d<.5)return true;
    return rayo(ax,ay,az,dx/d,dy/d,dz/d,d)>=d-.45;};

  /* --- bichos (módulo M) --- */
  const NADA=[];
  const bichos=()=>typeof bichosVivos==='function'?bichosVivos():NADA;
  const RB={ref:null,t:0};const _ob=new V3(),_db=new V3();
  function rayoB(ox,oy,oz,dx,dy,dz,max){
    if(typeof rayoBichos!=='function')return null;
    const r=rayoBichos(_ob.set(ox,oy,oz),_db.set(dx,dy,dz),max);
    if(!r||!(r.t<max))return null;RB.ref=r.e;RB.t=r.t>0?r.t:0;return RB;
  }
  function herirBicho(ref,dano,dx,dz){if(!ref||!(dano>0))return;
    const l=Math.hypot(dx,dz)||1;damageEnemy(ref,dano,_dir.set(dx/l,0,dz/l),'soldado');}

  /* --- peligros: granadas vivas y autos prendidos. Para una granada en vuelo se da el lugar donde va a caer
         (el que calculó GRAN.arco al lanzarla): así no «se mueve» y los que están ahí se corren a tiempo --- */
  const PEL=[],pelPool=[];let ardenT=-9;const arden=[];
  const pel=i=>{let o=pelPool[i];if(!o)o=pelPool[i]={x:0,z:0,r:0,t:0,de:null,tipo:''};PEL[i]=o;return o;};
  function peligros(){
    let n=0;
    if(hay.gran()&&GRAN.lista){const R=(GRAN.TUNE&&GRAN.TUNE.radio)||7;
      for(const g of GRAN.lista){if(!g||!g.p||g.tipo==='humo')continue;const o=pel(n++);
        const f=(!g.quieta&&g.ueFin&&g.ueDe===g.de)?g.ueFin:g.p;o.x=f.x;o.z=f.z;o.r=R;o.t=g.t;o.de=g.de;o.tipo='granada';}}
    if(T-ardenT>.25){ardenT=T;arden.length=0;for(const c of VCARS)if(c.st===2)arden.push(c);}
    for(const c of arden){if(c.st!==2)continue;const o=pel(n++);o.x=c.x;o.z=c.z;o.r=8;o.t=c.fuse>0?c.fuse:0;o.de=null;o.tipo='auto';}
    PEL.length=n;return PEL;
  }

  /* --- le pegan al jugador. «culpa» marca que el daño es de ellos, por si hurtPlayer termina la partida --- */
  let culpa=false,culpaGranT=-1,muerteUE=false;
  function herirJugador(dano,x,z,tipo){
    if(!running||!(dano>0))return;
    culpa=true;try{hurtPlayer(dano,false);}finally{culpa=false;}
    if(hay.hud()&&UEHUD.golpeDesde)UEHUD.golpeDesde(x,z);
  }

  /* --- una bala de ellos: trazadora, estampido con distancia, impacto y daño a los autos --- */
  let tiroS=null,tiroT=-1;
  function bala(ev){
    const fx=hay.fx(),snd=hay.snd();
    _a.set(ev.ox,ev.oy,ev.oz);_b.set(ev.hx,ev.hy,ev.hz);
    if(fx)UEFX.trazadora(_a,_b,ev.tipo);
    const mismo=ev.tipo==='escopeta'&&tiroS===ev.s&&tiroT===ev.t;            // ocho perdigones, un estampido
    if(snd&&!mismo)UESND.disparo(ev.tipo,_a);
    tiroS=ev.s;tiroT=ev.t;
    if(ev.pega==='mundo'){
      const L=Math.hypot(ev.hx-ev.ox,ev.hy-ev.oy,ev.hz-ev.oz);
      const fue=RZ.que&&Math.abs(RZ.t-L)<.06;                                 // terminó en lo que encontró el último rayo
      let mat='piso';
      if(fue)mat=RZ.que==='auto'?'metal':(RZ.que==='caja'&&RZ.caja&&esDelReten(RZ.caja))?'metal':'pared';
      if(fx)UEFX.impacto(_b,null,mat);
      if(fue&&RZ.que==='auto'&&RZ.car)carDamage(RZ.car,TUNE.danoAuto);
    }else if(ev.pega==='bicho'){if(fx)UEFX.impacto(_b,null,'carne');}
  }
  let cajasReten=null;
  function esDelReten(b){
    if(!cajasReten){cajasReten=new Set();try{if(typeof RETEN!=='undefined'&&RETEN.obs)for(const o of RETEN.obs)cajasReten.add(o);}catch(e){}}
    return cajasReten.has(b);
  }

  /* --- granadas: el sistema de GRAN. Se guarda dónde dijo arco() que cae, para peligros() --- */
  const AR={vx:0,vy:0,vz:0,t:0};const ULT={vx:NaN,vy:NaN,vz:NaN,fx:0,fz:0};
  const _ga=new V3(),_gb=new V3();
  /* GRAN.arco cuesta de 0,1 ms (repetido) a 7 ms (un tiro nuevo entre autos). La IA prueba hasta 6 lugares para decidir:
     si en este cuadro ya se gastaron 4 ms, contesta «no hay tiro» y la IA vuelve a probar en su próxima vuelta (0,4 s) */
  const ARCO_MS=4;
  function arco(ox,oy,oz,hx,hy,hz){
    if(!hay.gran()||!GRAN.arco||fArco>ARCO_MS)return null;
    const t0=performance.now();
    const r=GRAN.arco(_ga.set(ox,oy,oz),_gb.set(hx,hy,hz));
    fArco+=performance.now()-t0;
    if(!r||!r.ok)return null;
    AR.vx=r.vel.x;AR.vy=r.vel.y;AR.vz=r.vel.z;AR.t=r.t;
    ULT.vx=r.vel.x;ULT.vy=r.vel.y;ULT.vz=r.vel.z;ULT.fx=r.fin?r.fin.x:hx;ULT.fz=r.fin?r.fin.z:hz;
    return AR;
  }
  function granada(s,ox,oy,oz,vx,vy,vz,mecha,tipo){
    if(!hay.gran()||!GRAN.lanzar)return;
    const g=GRAN.lanzar({pos:_ga.set(ox,oy,oz),vel:_gb.set(vx,vy,vz),mecha,de:s,tipo:tipo||'frag'});
    if(!g)return;
    if(vx===ULT.vx&&vy===ULT.vy&&vz===ULT.vz){if(!g.ueFin)g.ueFin={x:0,z:0};g.ueFin.x=ULT.fx;g.ueFin.z=ULT.fz;g.ueDe=s;}
    else g.ueDe=null;
  }

  /* --- radio: subtítulo de «radio interceptada» y la voz. En guardia solo si el jugador está cerca --- */
  const voz=s=>s.virtual?4:((s.esc&&s.esc.esRefuerzo)?4:0)+(((s.num||1)-1)&3);
  function radio(s,clave,texto){
    if(!s||!texto)return;
    const guardia=s.virtual?false:!(s.esc&&s.esc.estado!=='guardia');
    if(guardia&&!s.virtual&&Math.hypot(P.pos.x-s.x,P.pos.z-s.z)>TUNE.radioDist)return;
    if(hay.hud())UEHUD.radio(s.nombre||'Central',texto,clave);
    if(hay.snd()){
      let p=null;if(!s.virtual){_pos.x=s.x;_pos.y=(s.y||0)+1.6;_pos.z=s.z;p=_pos;}
      UESND.radio(voz(s),UESND.durFrase?UESND.durFrase(texto):1.4,p);
    }
  }

  /* --- eventos de la IA: bajas y heridas (lo demás lo cuentan la radio y la vista táctica) --- */
  let explDe=null;   // quién causó la explosión que se está repartiendo ahora (para darle o no los puntos)
  function evento(tipo,d){
    if(tipo==='baja'&&d&&d.s)baja(d.s,d.de,d.parte);
    else if(tipo==='herido'&&d&&d.s&&d.de!=='jugador')sangre(d.s);
  }
  function sangre(s){if(!hay.fx())return;_hp.set(s.x,(s.y||0)+(s.tierra>.5?.3:s.agach>.5?.9:1.25),s.z);UEFX.sangre(_hp,null);}
  const QUIPS_UE=['Uno menos de negro','¿Quién te manda, eh?','Que lo venga a buscar Central','Sin insignia y sin aire',
    'Testigo uno, Ceniza cero','A ver si ahora me borrás'];
  function baja(s,de,parte){
    const x=s.x,z=s.z;
    if(hay.snd()){_pos.x=x;_pos.y=s.y||0;_pos.z=z;UESND.cuerpo(_pos);}
    const delJugador=de==='jugador'||(de==='granada'&&explDe==='jugador');
    if(delJugador){
      kills++;if(comboT>0)combo=Math.min(5,combo+1);else combo=1;comboT=3;
      const pts=TUNE.puntos*combo;score+=pts;hudScore();
      feed(`<b>${pick(QUIPS_UE)}</b> · ${s.nombre}${parte==='cabeza'?' (a la cabeza)':''} +${pts}`);
    }else{
      const como=de==='bicho'?'lo despedazaron los bichos':de==='auto'?'voló con el auto':de==='granada'?'lo voló una granada':'cayó';
      feed(`<b>${s.nombre}</b> · ${como}`);
    }
    botin(x,z,s.rol,s);
  }
  /* botín: el de R (UEB.botin) si alguien lo definió; si no, cajas de las que ya hay en el juego */
  const botinVacio=UEB.botin;
  function botin(x,z,rol,s){
    /* el tirador cae arriba del furgón: la caja va al piso libre más cercano */
    if(s&&s.elev||!libre(x,z)){const k=libreCerca(x,z,5);if(k){x=k.x;z=k.z;}}
    if(UEB.botin!==botinVacio){try{UEB.botin(x,z,rol);}catch(e){}return;}
    if(Math.random()<TUNE.cajaMun)addAmmo(x+rand(-.6,.6),z+rand(-.6,.6),rol==='asalto'?'escopeta':(typeof pickAmmoKind==='function'?pickAmmoKind():'uzi'));
    if(Math.random()<TUNE.cajaSalud)addPickup(x+rand(-.9,.9),z+rand(-.9,.9));
  }
  function libre(x,z){const k=eCell(x,z);return k>=0&&enB[k]===0;}
  const _lc={x:0,z:0};
  function libreCerca(x,z,r){
    for(let d=1;d<=r;d++)for(let a=0;a<16;a++){const t=a/16*Math.PI*2,px=x+Math.sin(t)*d,pz=z+Math.cos(t)*d;
      if(libre(px,pz)){_lc.x=px;_lc.z=pz;return _lc;}}
    return null;
  }

  /* --- modelos: UEM.crear por soldado. Lo que recibe la IA es un intermediario que no anima ni dibuja
         al soldado si no se ve (lejos o con la sección B oculta). La IA igual le pone posición y rumbo. --- */
  const VIS=[];
  const MED={ia:0,mod:0,n:0,max:0,maxMod:0,peores:[],reg:null};   // ms de todo UEG.update (IA, modelos, pasos) y de los modelos solos · reg: [] guarda cada cuadro (pruebas)   // costo medido (ms): IA + modelos, solo modelos, cuadros, peor cuadro
  let modAcc=0,cuadro=0,fArco=0,fRayos=0;
  /* animación por distancia: a menos de 15 m y en pantalla, cada cuadro; hasta 40 m, uno de cada dos; más lejos, uno
     de cada tres; fuera de pantalla, uno de cada seis
     (el modelo recibe el tiempo juntado, así el paso no patina). La IA igual mueve root en cada cuadro. */
  function cadaCuanto(v){
    if(!v.enPantalla)return 6;               // ~10 por segundo: la pose sigue al día para las balas y la boca del arma
    const d2=v.d2;return d2<15*15?1:d2<40*40?2:3;
  }
  function vista(s){
    if(typeof UEM==='undefined')return null;
    let u=null;try{u=UEM.crear(s.rol,{semilla:(s.id*7919+(s.esc&&s.esc.esRefuerzo?4001:13))|0});}catch(e){return null;}
    _sceneAdd(u.root);
    const v={u,s,root:u.root,e:u.e,vis:true,enPantalla:true,d2:0,acc:0,fase:VIS.length,quieto:0,px:s.x,pz:s.z,paso:0,eqT:rand(1,3),
      update(dt){
        if(!v.vis)return;
        if(!s.vivo&&s.muerte&&s.muerte.t>=1){v.quieto+=dt;if(v.quieto>3)return;}   // cadáver: ya quedó quieto
        v.acc+=dt;const k=cadaCuanto(v);if(k>1&&((cuadro+v.fase)%k)!==0&&v.acc<.1)return;
        const t0=performance.now();u.update(v.acc);v.acc=0;modAcc+=performance.now()-t0;},
      disparo(){if(v.vis)u.disparo();},
      golpe(dir,f){u.golpe(dir,f);},
      boca:q=>u.boca(q),ojos:q=>u.ojos(q),mano:q=>u.mano?u.mano(q):u.boca(q),
      rayo:(o,d)=>u.rayo(o,d),
      soltarArma(){u.soltarArma();},
      dispose(){try{u.dispose();}catch(e){}const i=VIS.indexOf(v);if(i>=0)VIS.splice(i,1);}};
    VIS.push(v);
    return v;
  }
  /* ¿en pantalla? Un cono horizontal alrededor de adonde mira el jugador (P.yaw), con margen por el sacudón y el
     ancho del cuerpo. No usa la matriz de la cámara: actualizarla recorre el arma en primera persona y sale caro. */
  function verModelos(){
    cuadro++;
    const secB=!SECG||SECG.B.visible,cx=camera.position.x,cz=camera.position.z,D2=TUNE.visDist*TUNE.visDist;
    const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),medio=Math.atan(Math.tan(camera.fov*Math.PI/360)*(camera.aspect||1.8))+.35,cosM=Math.cos(Math.min(3.1,medio));
    for(const v of VIS){const s=v.s,dx=s.x-cx,dz=s.z-cz;v.d2=dx*dx+dz*dz;const vis=secB&&s.activo!==false&&v.d2<D2;
      if(vis!==v.vis){v.vis=vis;v.root.visible=vis;}
      if(vis){const d=Math.sqrt(v.d2);v.enPantalla=d<4||(dx*fx+dz*fz)/d>cosM;}}
  }
  /* pasos y equipo de los que se mueven cerca (la IA no los avisa: salen de cuánto se movió cada uno) */
  function pasos(dt){
    if(!hay.snd()||!(dt>0))return;
    for(const v of VIS){const s=v.s;
      const dx=s.x-v.px,dz=s.z-v.pz;v.px=s.x;v.pz=s.z;
      if(!s.vivo)continue;
      const m=Math.sqrt(dx*dx+dz*dz);if(m>2)continue;                      // se teletransportó (reinicio)
      const dj=Math.hypot(s.x-P.pos.x,s.z-P.pos.z);if(dj>TUNE.pasosDist){v.paso=0;continue;}
      const vel=m/dt;if(vel<.3)continue;
      v.paso+=m;const zancada=vel>4?1.5:vel>2.2?1.1:.8;
      if(v.paso>=zancada){v.paso-=zancada;_pos.x=s.x;_pos.y=s.y||0;_pos.z=s.z;
        UESND.pasos(_pos,(vel>4?1.4:vel>2.2?1:.6)*(s.agach>.5?.6:1));}
      v.eqT-=dt;if(v.eqT<=0){v.eqT=rand(1.6,3.4);if(dj<TUNE.equipoDist){_pos.x=s.x;_pos.y=(s.y||0)+1;_pos.z=s.z;UESND.equipo(_pos);}}
    }
  }

  /* --- el ENV completo --- */
  const ENV={
    B:enB,H:enH,EW,EH,EX0,EZ0,
    jugador,piso:floorAt,rayo,
    luz:(x,z)=>typeof RETEN!=='undefined'&&RETEN.luz?RETEN.luz(x,z):0,
    bichos,rayoBichos:rayoB,herirBicho,peligros,herirJugador,bala,granada,arco,radio,evento,vista,
    azar:Math.random,ahora:()=>T
  };
  const UE=crearUE(ENV,UE_TUNE);

  /* =================================================================================================
     ESCUADRONES: Ceniza en el retén y Tizón de refuerzo
     ================================================================================================= */
  let creado=false;const AJUSTES=[];
  /* puntos sobre la avenida, delante del retén: se usan para ver si un puesto «tiene línea» */
  function muestraAvenida(D){
    const f=D.frente||{x:1,z:0},lx=-f.z,lz=f.x,out=[];
    for(const a of [18,32,48])for(const l of [-4.5,-.5,3.5])out.push({x:D.centro.x+f.x*a+lx*l,z:D.centro.z+f.z*a+lz*l});
    return out;
  }
  function veAvenida(x,z,M){
    const y0=floorAt(x,z)+1.62;let n=0;
    for(const p of M){const y1=floorAt(p.x,p.z)+1.1;let r=UE.interno.lv(x,y0,z,p.x,y1,p.z,null);
      if(r===2)r=rayoLibre(x,y0,z,p.x,y1,p.z)?1:0;if(r)n++;}
    return n/M.length;
  }
  /* jefe y granadero: si ninguno ve la avenida desde su puesto, se corre el que menos tenga que moverse */
  function puestosConLinea(D,pu){
    const M=muestraAvenida(D),info={};
    for(const rol of ['jefe','granadero'])if(pu[rol])info[rol]=veAvenida(pu[rol].x,pu[rol].z,M);
    AJUSTES.length=0;AJUSTES.push({antes:Object.assign({},info)});
    if(Object.values(info).some(v=>v>=TUNE.verMin))return;
    let mejor=null;
    for(const rol of ['jefe','granadero']){const p=pu[rol];if(!p)continue;
      for(let d=.5;d<=TUNE.corrimiento&&!(mejor&&mejor.d<=d);d+=.5)
        for(let a=0;a<16;a++){const t=a/16*Math.PI*2,x=p.x+Math.sin(t)*d,z=p.z+Math.cos(t)*d;
          if(!libre(x,z))continue;const v=veAvenida(x,z,M);
          if(v>=TUNE.verMin&&(!mejor||d<mejor.d||(d===mejor.d&&v>mejor.v)))mejor={rol,x,z,d,v};}}
    if(mejor){AJUSTES.push({rol:mejor.rol,de:{x:pu[mejor.rol].x,z:pu[mejor.rol].z},a:{x:+mejor.x.toFixed(2),z:+mejor.z.toFixed(2)},corrido:mejor.d,ve:mejor.v});
      pu[mejor.rol]={x:mejor.x,z:mejor.z,rumbo:pu[mejor.rol].rumbo};}
  }
  function crear(){
    const D=RETEN.datos,pu={};
    /* el tirador va solo con el nido: si tuviera puesto, la IA lo dejaría en el piso */
    for(const p of D.puestos||[])if(p.rol&&p.rol!=='tirador')pu[p.rol]={x:p.x,z:p.z,rumbo:p.rumbo};
    puestosConLinea(D,pu);
    /* nido.r: para W es dónde se lo puede poner; para la IA es hasta dónde el techo es «su plataforma» en la línea de
       visión (más allá, el mismo furgón lo tapa). Con 0,8 no veía nada: el borde este del techo está a 0,9 m. Se cubre el techo entero */
    const nido=D.nido?Object.assign({},D.nido,{r:Math.max(D.nido.r||0,TUNE.nidoR)}):null;
    UE.escuadron({nombre:'Ceniza',roles:['jefe','asalto','granadero','tirador'],puestos:pu,ronda:D.ronda,nido,reunion:D.reunion});
    if(D.refuerzo)UE.refuerzo({nombre:'Tizón',roles:['jefe','asalto','granadero','tirador'],sale:D.refuerzo.sale,camino:D.refuerzo.camino});
    creado=true;
  }

  /* =================================================================================================
     ENGANCHES DEL JUEGO
     ================================================================================================= */
  /* al reiniciar la partida (resetGame): escuadrones nuevos y todo como al principio */
  function reset(){
    PEND.length=0;muerteUE=false;culpa=false;culpaGranT=-1;tiroS=null;arden.length=0;ardenT=-9;cajasReten=null;
    if(!creado){if(hay.reten())crear();}else UE.reset();
    if(creado&&hay.gran()&&GRAN.arco&&hay.reten()){try{const D=RETEN.datos,c=D.centro,f=D.frente||{x:1,z:0};   // el primer GRAN.arco tarda ~25 ms: que sea ahora y no en la primera granada
      GRAN.arco(_ga.set(c.x-3*f.x,floorAt(c.x,c.z)+1.75,c.z),_gb.set(c.x+20*f.x,floorAt(c.x+20*f.x,c.z),c.z));}catch(e){}}
    for(const v of VIS){v.px=v.s.x;v.pz=v.s.z;v.vis=true;v.root.visible=true;}
  }
  /* cada cuadro de partida */
  function update(dt){
    if(!creado)return;
    const t0=performance.now();modAcc=0;fArco=0;fRayos=0;
    vaciar();                                   // los perdigones de este cuadro, juntos
    verModelos();
    UE.update(dt);
    pasos(dt);
    const ms=performance.now()-t0;MED.ia+=ms;MED.mod+=modAcc;MED.n++;if(ms>MED.max)MED.max=ms;if(modAcc>MED.maxMod)MED.maxMod=modAcc;
    if(MED.reg)MED.reg.push(ms,modAcc);
    if(ms>2){MED.peores.push([+T.toFixed(2),+ms.toFixed(2),+modAcc.toFixed(2),+fArco.toFixed(2),fRayos]);if(MED.peores.length>12){MED.peores.sort((a,b)=>b[1]-a[1]);MED.peores.length=8;}}
  }
  /* precalentado de shaders: una muestra de cada rol con todo prendido */
  function warm(on){try{if(typeof UEM!=='undefined')UEM.calentar(scene,on);}catch(e){}}

  /* --- balas del jugador (marcador rayo-jugador de fire(), una vez por bala o perdigón).
         Devuelve true si la bala terminó en un soldado: el que la llama hace «continue». --- */
  const PEND=[];   // daño de este disparo, junto por soldado y parte (los perdigones de la escopeta suman)
  function vaciar(){if(!PEND.length)return;
    for(const p of PEND){_dir.set(p.dx,p.dy,p.dz);UE.herir(p.s,p.dm,_dir,p.parte,'jugador');}PEND.length=0;}
  function balaJugador(o,d,w,tE,wall,range,i){
    if(!creado)return false;
    const ch=rayoAutos(o.x,o.y,o.z,d.x,d.y,d.z,Math.min(wall,range));
    let lim=Math.min(wall,range,tE);if(ch&&ch.t<lim)lim=ch.t;
    const h=UE.rayo(o,d,lim);
    if(!h||!(h.t<lim)){if(!i)UE.balaCerca(o,d,lim<range?lim:range);return false;}
    const s=h.s,t=h.t,fall=w.rays>1?(t<12?1:Math.max(.3,1-(t-12)/40)):(t<30?1:Math.max(.55,1-(t-30)/80)),dm=w.dmg*fall;
    let p=null;for(const q of PEND)if(q.s===s&&q.parte===h.parte){p=q;break;}
    if(p)p.dm+=dm;else PEND.push({s,dm,parte:h.parte,dx:d.x,dy:d.y,dz:d.z});
    _hp.copy(o).addScaledVector(d,t);
    if(hay.fx())UEFX.sangre(_hp,d);
    if(s.vista&&s.vista.golpe){const a=Math.atan2(o.x-s.x,o.z-s.z)-s.rumbo;s.vista.golpe(Math.atan2(Math.sin(a),Math.cos(a)),Math.min(1,dm/30));}
    return true;
  }

  /* --- UEB: lo que piden los demás módulos --- */
  UEB.objetivos=()=>UE.objetivos();
  UEB.explosion=(pos,radio,dano,de)=>{
    if(de&&typeof de==='object')culpaGranT=T;            // granada de un soldado: si mata al jugador, fueron ellos
    explDe=de;try{UE.explosion(pos,radio,dano,de);}finally{explDe=null;}
  };
  UEB.ruido=(pos,tipo,fuerza)=>{
    /* fire() avisa con la cámara; la IA quiere los pies del que hizo el ruido */
    const delJugador=tipo==='disparo'||tipo==='pasos'||tipo==='jugador'||tipo==='recarga';
    UE.ruido(delJugador?P.pos:pos,tipo,fuerza);
  };
  const EST={alerta:0,ang:null,combate:false,vivos:0,sospecha:0,x:0,z:0,quedan:0,busqueda:false,refuerzo:'no',refuerzoEn:null};
  /* Para el HUD. Si no saben nada del testigo (sin «último lugar conocido»: por ejemplo, pelean solo contra bichos o
     encontraron a un compañero muerto) no hay «TE VIERON»: el arco muestra solo la sospecha sobre el jugador. */
  UEB.estado=()=>{
    const e=UE.estado(),sabe=!!UE.red.uc;
    let niv=e.sospecha,x=e.x,z=e.z;
    if(!sabe){niv=0;for(const s of UE.soldados)if(s.vivo&&s.activo!==false&&s.sosp>niv){niv=s.sosp;x=s.x;z=s.z;}}
    EST.alerta=EST.sospecha=niv;EST.x=x;EST.z=z;EST.combate=e.combate&&sabe;EST.busqueda=e.busqueda;
    EST.vivos=EST.quedan=e.quedan;EST.refuerzo=e.refuerzo;EST.refuerzoEn=e.refuerzoEn;
    EST.ang=(niv>0&&hay.hud()&&UEHUD.angulo)?UEHUD.angulo(x,z):null;
    return EST;
  };
  UEB.debug=()=>creado?UE.debug():null;

  /* --- fin de partida: ¿lo mataron ellos? --- */
  function fin(){muerteUE=culpa||culpaGranT===T;}
  const titulo=()=>muerteUE?'Testigo eliminado':'';

  return {UE,ENV,TUNE,reset,update,warm,balaJugador,fin,titulo,
    get creado(){return creado;},get modelos(){return VIS;},get ajustes(){return AJUSTES;},MED,
    medirReset(){MED.ia=MED.mod=MED.n=MED.max=MED.maxMod=0;MED.peores.length=0;},RZ};
})();
const UE=UEG.UE;
