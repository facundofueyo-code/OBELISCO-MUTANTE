const path = require('path'); const H = require(path.join(__dirname, '../../harness.js'));
(async () => { const h = await H.openPage(path.join(__dirname, '../prueba.html'), { width: 1280, height: 800 });
  try { await h.page.waitForTimeout(500);
    const r = await h.page.evaluate(() => { const f = [...document.querySelectorAll('#frases > div')]; return { filas: f.length, primera: f[0] && f[0].textContent.slice(0, 120), conN: f.filter(d => d.querySelector('i')).length, titulo: document.title, h1: document.querySelector('h1').textContent, tarjetas: [...document.querySelectorAll('.card h3')].map(x => x.textContent).join(' | ') }; });
    console.log(JSON.stringify(r, null, 1)); console.log('errores:', h.errors.length);
  } finally { await h.close(); } })();
