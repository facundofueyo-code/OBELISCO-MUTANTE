  /* ====================================================================================================
     ARMAS Y BALAS
     ==================================================================================================== */
  const _boca = { x: 0, y: 0, z: 0 };
  const _v3 = (typeof THREE !== 'undefined' && THREE.Vector3) ? new THREE.Vector3() : null;   // solo para pedirle la boca del arma al modelo
  /* boca del arma: la del modelo si hay; si no, una aproximación según la postura */
  function boca(s) {
    if (s.vista && _v3 && s.vista.boca) { s.vista.boca(_v3); _boca.x = _v3.x; _boca.y = _v3.y; _boca.z = _v3.z; return _boca; }
    const h = s.tierra > 0 ? 0.95 + (0.25 - 0.95) * s.tierra : 1.42 + (0.95 - 1.42) * s.agach;
    _boca.x = s.x + Math.sin(s.miraYaw) * 0.45; _boca.y = s.y + h; _boca.z = s.z + Math.cos(s.miraYaw) * 0.45;
    return _boca;
  }
  /* Punto de mira de s sobre el jugador: su observación de hace `atraso` segundos más una parte del adelanto.
     Con el jugador quieto es exacto; corriendo de costado queda atrás (0,09·v con los números iniciales).
     Devuelve false si s no tiene observaciones propias recientes. */
  function puntoMira(s, atraso, adelanto) {
    const tq = ahora - atraso; let h0 = null, h1 = null, viejo = null;
    for (let q = 0; q < 10; q++) {
      const h = s.hist[q]; if (h.t < ahora - 1.2) continue;
      if (h.t <= tq) { if (!h0 || h.t > h0.t) h0 = h; } else if (!h1 || h.t < h1.t) h1 = h;
      if (!viejo || h.t < viejo.t) viejo = h;
    }
    if (!h0) h0 = viejo; if (!h0) return false;
    let x = h0.x, y = h0.y, z = h0.z;
    if (h1 && h1.t - h0.t < 0.4 && h1.t > h0.t && tq > h0.t) { const u = (tq - h0.t) / (h1.t - h0.t); x += (h1.x - x) * u; y += (h1.y - y) * u; z += (h1.z - z) * u; }
    x += h0.vx * atraso * adelanto; z += h0.vz * atraso * adelanto;
    const ult = s.hist[(s.hI + 9) % 10];
    s.miraX = x; s.miraZ = z; s.miraY = y + (ult.medio ? ult.alto - 0.12 : ult.alto * 0.62); s.miraPie = y; s.miraAlto = ult.alto;
    return true;
  }
  /* rayo contra la cápsula del jugador (radio 0,35, de y a y+alto). Devuelve la distancia o Infinity. */
  function rayoCapsula(ox, oy, oz, dx, dy, dz, cx, cy, cz, r, alto) {
    const fx = ox - cx, fz = oz - cz, a = dx * dx + dz * dz; if (a < 1e-9) return Infinity;
    const b = fx * dx + fz * dz, c = fx * fx + fz * fz - r * r, disc = b * b - a * c; if (disc < 0) return Infinity;
    const sq = Math.sqrt(disc), t0 = (-b - sq) / a, t1 = (-b + sq) / a; if (t1 < 0) return Infinity;
    const y0 = oy + dy * Math.max(t0, 0), y1 = oy + dy * t1, lo = cy, hi = cy + alto;
    if ((y0 < lo && y1 < lo) || (y0 > hi && y1 > hi)) return Infinity;
    if (y0 >= lo && y0 <= hi) return Math.max(t0, 0);
    /* entra por arriba o por abajo del cilindro */
    const yb = y0 > hi ? hi : lo; if (Math.abs(dy) < 1e-9) return Infinity; const t = (yb - oy) / dy; return (t >= 0 && t <= t1) ? t : Infinity;
  }
  /* tope de daño: cuánto le sacaron las balas de fusil y escopeta en el último segundo */
  function danoReciente() {
    const v = red.dano; let i = 0; while (i < v.length && v[i] <= ahora - 1) i += 2; if (i) v.splice(0, i);
    let n = 0; for (let q = 1; q < v.length; q += 2) n += v[q]; return n;
  }
  const _ev = { s: null, ox: 0, oy: 0, oz: 0, hx: 0, hy: 0, hz: 0, tipo: 'fusil', pega: 'nada', modo: 'pegar', raf: 0, t: 0, px: 0, py: 0, pz: 0 };
  const _res = { t: 0, pega: 'nada', ref: null };
  /* FÍSICA de una bala: contra el mundo, los bichos y el jugador, con rayo real. Es la única lectura de la
     posición real del jugador fuera de percibir(), y nada de lo que devuelve se usa para decidir dónde está. */
  function resolverBala(ox, oy, oz, dx, dy, dz, alc) {
    let tM = ENV.rayo(ox, oy, oz, dx, dy, dz, alc), pega = 'mundo';
    if (!(tM < alc)) { tM = alc; pega = 'nada'; }
    if (dy < -1e-4) {                                                // el piso también frena
      let tp = (oy - ENV.piso(ox, oz)) / -dy; tp = (oy - ENV.piso(ox + dx * tp, oz + dz * tp)) / -dy;
      if (tp > 0 && tp < tM) { tM = tp; pega = 'mundo'; }
    }
    let ref = null;
    const hb = bichos.length ? ENV.rayoBichos(ox, oy, oz, dx, dy, dz, tM) : null;
    if (hb && hb.t < tM) { tM = hb.t; pega = 'bicho'; ref = hb.ref; }
    const j = ENV.jugador();
    if (j.vivo) { const tj = rayoCapsula(ox, oy, oz, dx, dy, dz, j.x, j.y, j.z, 0.35, j.alto); if (tj < tM) { tM = tj; pega = 'jugador'; ref = null; } }
    _res.t = tM; _res.pega = pega; _res.ref = ref; return _res;
  }
  /* Dispara UNA bala (o perdigón) de s hacia el punto (px,py,pz).
     modo: 'pegar' · 'suprimir' (erra a propósito; si igual le iba a pegar, se sortea de nuevo una vez) ·
           'aviso' (primera ráfaga: no pega nunca) · 'bicho' · 'laser' (tirador).
     Devuelve qué tocó. */
  function tirarBala(s, px, py, pz, modo, tipo, disp, dano, alc, enTope) {
    const b = boca(s), ox = b.x, oy = b.y, oz = b.z;
    let dx = px - ox, dy = py - oy, dz = pz - oz, d = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1; dx /= d; dy /= d; dz /= d;
    const hl = Math.sqrt(dx * dx + dz * dz) || 1, lx = -dz / hl, lz = dx / hl;       // lateral horizontal
    const da = campana() * disp * 1.6, dv = campana() * disp * 1.1;
    let ex = dx + lx * da, ey = dy + dv, ez = dz + lz * da, el = Math.sqrt(ex * ex + ey * ey + ez * ez); ex /= el; ey /= el; ez /= el;
    let r = resolverBala(ox, oy, oz, ex, ey, ez, alc);
    if (r.pega === 'jugador') {
      let errar = false;
      if (modo === 'aviso') errar = true;
      else if (modo === 'suprimir' || modo === 'bicho') {
        /* segundo sorteo: el mismo desvío para el otro lado. Si igual le pega, le pega (cruzó una línea de fuego). */
        ex = dx - lx * da; ey = dy - dv; ez = dz - lz * da; el = Math.sqrt(ex * ex + ey * ey + ez * ez); ex /= el; ey /= el; ez /= el;
        r = resolverBala(ox, oy, oz, ex, ey, ez, alc);
      }
      if (r.pega === 'jugador' && !errar && enTope && danoReciente() + dano > T.topeDano) errar = true;   // tope de daño por segundo
      if (errar) {
        /* la bala se corre lo justo para pasarle al lado (0,6 m fuera del cuerpo), del lado hacia el que ya iba */
        const j = ENV.jugador(), jx = j.x - ox, jz = j.z - oz, jd = Math.sqrt(jx * jx + jz * jz) || 1;
        const lado = (ex * (-jz) + ez * jx) >= 0 ? 1 : -1, qx = -jz / jd * lado, qz = jx / jd * lado;
        for (let q = 0; q < 3 && r.pega === 'jugador'; q++) {
          const tx = j.x + qx * (0.95 + q * 0.5) - ox, ty = oy + ey * jd - oy, tz = j.z + qz * (0.95 + q * 0.5) - oz;
          el = Math.sqrt(tx * tx + ty * ty + tz * tz) || 1; ex = tx / el; ey = ty / el; ez = tz / el;
          r = resolverBala(ox, oy, oz, ex, ey, ez, alc);
        }
        if (r.pega === 'jugador') return 'nada';                     // no hubo forma: la bala no sale
      }
    }
    if (r.pega === 'jugador') {
      if (enTope) { red.dano.push(ahora, dano); }
      ENV.herirJugador(dano, s.x, s.z, tipo);
    } else if (r.pega === 'bicho') ENV.herirBicho(r.ref, (dano / (T.dano || 1)) * T.bichoDano, ex, ez);
    const e = _ev; e.s = s; e.ox = ox; e.oy = oy; e.oz = oz; e.hx = ox + ex * r.t; e.hy = oy + ey * r.t; e.hz = oz + ez * r.t;
    e.tipo = tipo; e.pega = r.pega; e.modo = modo; e.raf = s.nRaf; e.t = ahora; e.px = px; e.py = py; e.pz = pz;
    ENV.bala(e);
    return r.pega;
  }
  /* daño del perdigón según la distancia: entero hasta `lleno`, ~2/3 a `util`, nada desde `nada` */
  function caidaEscopeta(d) { const E = T.escopeta; return d <= E.lleno ? 1 : d >= E.nada ? 0 : 1 - (d - E.lleno) / (E.nada - E.lleno); }

  /* ¿la boca del arma tiene línea limpia (rayo real) hasta el punto de mira? */
  function lineaLimpia(s) {
    const b = boca(s); if (rayoLibre(b.x, b.y, b.z, s.miraX, s.miraY, s.miraZ)) return true;
    const yc = s.miraPie + s.miraAlto - 0.12;                        // si el pecho está tapado, prueba la cabeza
    if (rayoLibre(b.x, b.y, b.z, s.miraX, yc, s.miraZ)) { s.miraY = yc; return true; }
    return false;
  }
  /* ¿tiene sentido tirarle al último lugar conocido sin verlo? Solo si se sabe bien dónde es y hace poco
     (después se barre, no se gasta munición), o si le pidieron cubrir a uno que se mueve. */
  function debeSuprimir(s) {
    const u = red.uc; if (!u || u.err > 3) return false;
    if (s.rol === 'tirador') return false;
    if (s.cubreHasta > ahora) return true;
    if (s.tarea !== 'fijar') return false;
    const sinVer = ahora - red.tVisto;
    return sinVer < T.perdidoAccion + 1;
  }
  /* Empieza una ráfaga si corresponde. Decide el MODO una vez por ráfaga. */
  function empezarRafaga(s) {
    const A = T[s.arma]; let modo = null;
    if (s.blanco === 'bicho' && s.bicho) modo = 'bicho';
    else if (s.blanco === 'jugador') {
      if (ahora - s.tConoce < T.reaccion) return false;              // tiempo humano de reacción
      if (s.ve) {
        if (ahora - s.veDesde < T.reaccion) return false;
        if (!puntoMira(s, T.miraAtraso, T.miraAdelanto)) return false;
        if (!s.avisoHecho) modo = 'aviso';                           // la primera ráfaga de cada uno es de aviso
        else if (s.ficha && lineaLimpia(s) && (s.arma !== 'escopeta' || hyp(s.miraX - s.x, s.miraZ - s.z) < T.escopeta.nada)) modo = 'pegar';
        else modo = 'suprimir';
      } else {
        if (!debeSuprimir(s)) return false;
        modo = s.avisoHecho ? 'suprimir' : 'aviso';
      }
    }
    if (!modo) return false;
    if (s.arma === 'escopeta' && modo !== 'pegar' && modo !== 'bicho') {
      const u = conocido(s); if (!u || hyp(u.x - s.x, u.z - s.z) > T.escopeta.alcance) return false;       // de lejos la escopeta ni suprime
    }
    s.rafModo = modo; s.rafLado = azar() < 0.5 ? -1 : 1; s.rafOff = entre(T.supOffMin, T.supOffMax);
    s.raf = s.arma === 'fusil' ? Math.min(s.balas, Math.round(entre(A.rafMin, A.rafMax))) : 1;
    s.rafT = 0; s.nRaf++;
    if (modo === 'aviso') s.avisoHecho = true;
    return true;
  }
  /* una bala de la ráfaga en curso */
  function soltarBala(s) {
    const A = T[s.arma]; let modo = s.rafModo;
    if (modo === 'pegar' && (!s.ficha || !s.ve)) modo = 'suprimir';  // le sacaron la ficha o dejó de verlo en medio de la ráfaga
    let px, py, pz, disp, d;
    if (modo === 'bicho') {
      const b = s.bicho; if (!b) { s.raf = 0; return; }
      px = b.x; py = b.y; pz = b.z; disp = A.disp * 1.25 * (1 + s.supr);
    } else {
      if ((s.ve || ahora - s.tVisto < 0.6) && puntoMira(s, T.miraAtraso, T.miraAdelanto)) { px = s.miraX; py = s.miraY; pz = s.miraZ; }
      else { const u = red.uc; if (!u) { s.raf = 0; return; } px = u.x; py = u.y + 1.0; pz = u.z; if (modo === 'pegar') modo = 'suprimir'; }
      d = hyp(px - s.x, pz - s.z);
      if (modo === 'pegar') disp = A.disp * (1 + (A.suelto ? (A.suelto - 1) * (1 - s.asiento) : 0)) * T.punteria * (1 + s.supr);
      else {
        /* suprimir o avisar: apunta a propósito a un costado, con poca dispersión, para que se vean pasar y no peguen */
        disp = A.disp * 0.6;
        const off = s.rafOff + 1.7 * disp * 1.6 * d, ux = (px - s.x) / (d || 1), uz = (pz - s.z) / (d || 1);
        px += -uz * off * s.rafLado; pz += ux * off * s.rafLado; py += 0.15;
      }
    }
    s.balas--; s.tDisparo = ahora; s.esc.tFuego = ahora;
    if (s.vista && s.vista.disparo) s.vista.disparo();
    if (s.arma === 'escopeta') {
      d = hyp(px - s.x, pz - s.z); const dn = A.dano * caidaEscopeta(d) * (modo === 'bicho' ? 1 : T.dano);
      for (let q = 0; q < A.perdigones; q++) tirarBala(s, px, py, pz, modo, 'escopeta', modo === 'pegar' ? A.disp * T.punteria : A.disp, dn, A.alcance, true);
    } else tirarBala(s, px, py, pz, modo, 'fusil', disp, A.dano * (modo === 'bicho' ? 1 : T.dano), A.alcance, true);
  }
  /* cadencia de tiro: corre en cada cuadro mientras el soldado está en condiciones de tirar */
  function gatillo(s, dt) {
    const A = T[s.arma];
    if (s.raf > 0) {
      s.rafT -= dt;
      while (s.raf > 0 && s.rafT <= 0) {
        soltarBala(s); s.raf--; s.rafT += A.cadencia;
        if (s.raf <= 0 || s.balas <= 0) {
          s.raf = 0;
          s.pausaT = s.arma === 'fusil' ? entre(A.pausaMin, A.pausaMax) * (s.hp < T.vida * T.heridoBajo ? 1.7 : 1) * (s.rafModo === 'suprimir' && !s.ve ? 1.4 : 1) : A.cadencia;
        }
      }
      return;
    }
    s.pausaT -= dt;
    if (s.pausaT <= 0 && s.balas > 0) { if (!empezarRafaga(s)) s.pausaT = 0.12; }
  }
  /* ¿puede tirar ahora? (postura estable, arma arriba, mirando al blanco, sin correr) */
  function puedeTirar(s) {
    if (s.recT >= 0 || s.aturdido > 0 || s.salto >= 0 || s.lanzaT >= 0 || s.culT >= 0 || s.escondeT > 0) return false;
    if (s.apunta < 0.85) return false;
    if (s.tierra > 0.02 && s.tierra < 0.98) return false;            // a medio levantarse o tirarse
    if (s.vx * s.vx + s.vz * s.vz > 2.6) return false;               // corriendo no tira
    return true;
  }

  /* ---------------------------------------------------------------------------------------------------
     Fichas de ataque: como mucho TUNE.fichas soldados tiran a pegar a la vez (regla 4). Se la lleva el que
     mejor lo ve; rota. Una ficha que se suelta queda 0,4 s sin dueño (así nunca hay más de TUNE.fichas
     tirando a pegar ni siquiera durante el pase).
     --------------------------------------------------------------------------------------------------- */
  let fichaLibreEn = -99;
  function repartirFichas() {
    const F = red.fichas; let max = T.fichas;
    for (let i = 0; i < escuadrones.length; i++) if (escuadrones[i].activo && escuadrones[i].desorden > ahora) max = Math.min(max, 1);   // sin jefe: una sola
    if (red.muerto) max = 0;
    /* soltar las que ya no corresponden */
    for (let i = F.length - 1; i >= 0; i--) {
      const s = F[i];
      const vale = s.vivo && s.blanco === 'jugador' && (s.ve || ahora - s.tVisto < 0.7) && s.enTiro && s.recT < 0 && s.escondeT <= 0;
      if (!vale || F.length > max) { s.ficha = false; F.splice(i, 1); fichaLibreEn = ahora + 0.4; }
    }
    if (F.length >= max || ahora < fichaLibreEn) {
      /* rotación: si uno la tiene hace mucho y otro que lo ve la espera, la suelta */
      if (F.length >= max && max > 0) for (let i = 0; i < F.length; i++) { const s = F[i]; if (ahora - s.fichaT > T.fichaMax && hayEsperando()) { s.ficha = false; s.fichaCd = ahora + 2.5; F.splice(i, 1); fichaLibreEn = ahora + 0.4; break; } }
      return;
    }
    let mejor = null, mp = -1e9;
    for (let i = 0; i < soldados.length; i++) {
      const s = soldados[i]; if (!puedeFicha(s)) continue;
      const u = s.hist[(s.hI + 9) % 10], d = hyp(u.x - s.x, u.z - s.z);
      let p = s.asiento * 2 + (s.tarea === 'flanquear' || s.tarea === 'empujar' ? 3 : 0) - (s.veMedio ? 0.6 : 0);
      p += s.arma === 'escopeta' ? (d < 16 ? 2.5 : d < 28 ? 0.3 : -9) : 1 - d / 90;
      if (p > mp) { mp = p; mejor = s; }
    }
    if (mejor) { mejor.ficha = true; mejor.fichaT = ahora; F.push(mejor); }
  }
  function puedeFicha(s) {
    return s.vivo && s.activo && !s.ficha && s.rol !== 'tirador' && s.blanco === 'jugador' && s.ve && s.enTiro && s.recT < 0 && s.escondeT <= 0 && !(s.fichaCd > ahora) && ahora - s.veDesde >= T.reaccion * 0.5;
  }
  function hayEsperando() { for (let i = 0; i < soldados.length; i++) if (puedeFicha(soldados[i])) return true; return false; }

