/* Arnés de prueba sin pantalla para Obelisco Mutante (Chromium + SwiftShader).
   Uso:
     const H=require('<ruta>/harness.js');
     const h=await H.open('mi-copia-del-juego.html');        // carga (≈25 s) y deja el render apagado
     await h.start();                                          // arma la sección B y arranca la partida (sin precalentado ni mouse)
     await h.ev("P.pos.set(-330,0,603);STAGE='B';1");          // evalúa código ADENTRO del juego (ve todas sus variables)
     await h.step(5);                                          // simula 5 s de juego a 60 cuadros/s (rápido: no dibuja)
     await h.shot('captura.png');                              // dibuja UN cuadro y saca captura (lento: 10–60 s la primera vez)
     await h.close();                                          // SIEMPRE cerrar (libera el turno)
   h.errors = errores de página y de consola acumulados.
   Solo 2 copias del juego corren a la vez en la máquina: open() espera su turno. Juntá varias pruebas en una misma corrida.
   Para páginas sueltas y livianas (visor de modelos, prueba de efectos): H.openPage('pagina.html') → h.page (Playwright), h.shotPage('x.png'). */
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs=require('fs'),path=require('path');
const TAIL='requestAnimationFrame(frame);\n})();\n</script>';
/* como mucho 2 copias del juego abiertas a la vez en toda la máquina (cada una usa ~2 GB): las demás esperan su turno */
const SLOTS=[0,1].map(i=>path.join(__dirname,'.turno'+i));let mySlot=null;
const alive=pid=>{try{process.kill(pid,0);return true;}catch(e){return e.code==='EPERM';}};
async function tomarTurno(){for(;;){for(const f of SLOTS){try{const fd=fs.openSync(f,'wx');fs.writeSync(fd,String(process.pid));fs.closeSync(fd);mySlot=f;return;}catch(e){try{const pid=+fs.readFileSync(f,'utf8');const viejo=Date.now()-fs.statSync(f).mtimeMs>20*60*1000;if(!pid||!alive(pid)||viejo)fs.unlinkSync(f);}catch(e2){}}}await new Promise(r=>setTimeout(r,1500+Math.random()*1500));}}
function soltarTurno(){if(mySlot){try{fs.unlinkSync(mySlot);}catch(e){}mySlot=null;}}
process.on('exit',soltarTurno);process.on('SIGINT',()=>{soltarTurno();process.exit(130);});process.on('SIGTERM',()=>{soltarTurno();process.exit(143);});
async function open(file,{width=640,height=360,hook=true}={}){
  if(hook)await tomarTurno();
  let src=fs.readFileSync(file,'utf8');let f=path.resolve(file);
  if(hook&&!src.includes('window.__ev=')){
    if(src.split(TAIL).length!==2)throw new Error('no encuentro el final del script del juego para enganchar __ev');
    src=src.replace(TAIL,'requestAnimationFrame(frame);\nwindow.__ev=s=>eval(s);\n})();\n</script>');
    f=path.join(path.dirname(f),'.__test_'+path.basename(f));fs.writeFileSync(f,src);}
  const browser=await chromium.launch({headless:true,args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required','--disable-accelerated-2d-canvas','--disable-gpu-rasterization']});
  const page=await browser.newPage({viewport:{width,height}});page.setDefaultTimeout(900000);
  const errors=[];page.on('pageerror',e=>errors.push('PAGEERR '+e.message+'\n'+(e.stack||'').split('\n').slice(0,4).join('\n')));
  page.on('console',m=>{if(m.type()==='error'&&!/Failed to load resource/.test(m.text()))errors.push('CONSOLE '+m.text().slice(0,400));});
  await page.route('**/*',r=>{const u=r.request().url();if(u.startsWith('file:'))r.continue();else r.abort();});
  await page.goto('file://'+f,{waitUntil:'load',timeout:240000});
  const ev=code=>page.evaluate(c=>window.__ev(c),code);
  if(hook)await ev("window.__render=renderer.render.bind(renderer);renderer.render=()=>{};window.__raf=window.requestAnimationFrame;window.requestAnimationFrame=()=>0;window.__simT=performance.now();1");
  const h={browser,page,errors,ev,
    /* arranca la partida sin precalentar shaders ni capturar el mouse */
    start:()=>ev("(()=>{buildSectionB();resetGame();running=true;over=false;paused=false;fallback=true;document.body.classList.add('playing');$('#scr-start').hidden=true;$('#scr-over').hidden=true;$('#scr-pause').hidden=true;$('#hud').hidden=false;$('#cross').hidden=false;vm.visible=true;return {enReady,stage:STAGE};})()"),
    /* simula `seg` segundos de juego; opcionalmente ejecuta `each` (código) antes de cada cuadro */
    step:(seg,dt=1/60,each='')=>ev(`(()=>{let t=window.__simT;const n=Math.round(${seg}/${dt});const w0=performance.now();for(let i=0;i<n;i++){t+=${dt}*1000;${each};frame(t);}window.__simT=t;return {T:+T.toFixed(2),wallMs:Math.round(performance.now()-w0)};})()`),
    /* dibuja un cuadro de verdad y saca captura */
    shot:async(out)=>{await ev("(()=>{renderer.render=window.__render;let t=window.__simT+16;frame(t);window.__simT=t;renderer.render=()=>{};return 1;})()");await page.screenshot({path:out});return out;},
    /* deja al jugador en Av. de Mayo y Santiago del Estero, mirando al oeste (hacia el retén y el Congreso), sin oleadas */
    alReten:(x=-330,z=608)=>ev(`(()=>{GATE.open=true;STAGE='B';intermission=1e9;P.pos.set(${x},0,${z});P.vel.set(0,0,0);P.yaw=Math.PI/2;P.pitch=0;return [P.pos.x,P.pos.z];})()`),
    close:async()=>{try{await browser.close();}finally{if(hook)soltarTurno();}}};
  return h;}
/* página suelta y liviana (un visor, una prueba de efectos): sin enganche al juego y sin turno */
async function openPage(file,opt={}){const h=await open(file,{...opt,hook:false});h.shotPage=async out=>{await h.page.screenshot({path:out});return out;};return h;}
module.exports={open,openPage};
