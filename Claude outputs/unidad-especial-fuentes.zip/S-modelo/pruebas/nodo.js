/* Pruebas sin dibujar: carga ue_modelo.js en Node y revisa números (sin capturas). */
const THREE=require('../../three.r128.min.js');global.THREE=THREE;
const fs=require('fs');
const UEM=new Function('THREE',fs.readFileSync(__dirname+'/../ue_modelo.js','utf8')+'\nreturn UEM;')(THREE);
const V3=THREE.Vector3;
const escena=new THREE.Scene();
/* skinning en CPU: posiciones mundiales de todos los vértices del cuerpo */
function piel(u){
  u.root.updateMatrixWorld(true);const g=u.malla.geometry,pos=g.attributes.position,si=g.attributes.skinIndex,sw=g.attributes.skinWeight,
  bones=u.malla.skeleton.bones,inv=u.malla.skeleton.boneInverses,M=bones.map((b,i)=>new THREE.Matrix4().multiplyMatrices(b.matrixWorld,inv[i]));
  const out=new Float32Array(pos.count*3),v=new V3(),a=new V3();
  for(let i=0;i<pos.count;i++){v.fromBufferAttribute(pos,i);let x=0,y=0,z=0;
    for(let j=0;j<2;j++){const w=j?sw.getY(i):sw.getX(i);if(w<=0)continue;a.copy(v).applyMatrix4(M[j?si.getY(i):si.getX(i)]);x+=a.x*w;y+=a.y*w;z+=a.z*w;}
    out[i*3]=x;out[i*3+1]=y;out[i*3+2]=z;}
  return out;
}
function minY(u){const p=piel(u),g=u.malla.geometry,si=g.attributes.skinIndex,bones=u.malla.skeleton.bones,pos=g.attributes.position;let m=1e9,b='',k=0;
  for(let i=0;i<p.length/3;i++){const bb=bones[si.getX(i)];if(bb.scale.x<1e-3)continue;if(p[i*3+1]<m){m=p[i*3+1];b=bb.name;k=i;}}
  return [+m.toFixed(3),b+(m<-.005?'@'+[pos.getX(k),pos.getY(k),pos.getZ(k)].map(x=>x.toFixed(3)).join(','):'')];}
function nan(u){for(const b of u.malla.skeleton.bones){const e=b.matrixWorld.elements;for(const x of e)if(!isFinite(x))return b.name;}return null;}
const st=u=>u._st;
function errManos(u){const s=st(u),P=s.P,H=['manoI','manoD'].map(n=>u.malla.skeleton.bones.findIndex(b=>b.name===n));
  return H.map((h,i)=>+P[h].distanceTo(s.sp.mano[i].p).toFixed(3));}
const out=[];const log=(...a)=>{out.push(a.join(' '));};
/* 1. geometría */
for(const r of Object.keys(UEM.ROLES)){const i=UEM.info(r);log('rol',r,'tris',i.triangulos,'fx',i.triangulosEfectos,'total',i.triangulos+i.triangulosEfectos);}
{const I=UEM._interno,G=I.Constructor(I.H);let t0=0;const parte=(n,f)=>{f();log('  parte',n,G.tris()-t0);t0=G.tris();};
 parte('torso granadero',()=>I.torso(G,'granadero'));parte('torso jefe',()=>I.torso(G,'jefe'));parte('brazos',()=>{I.brazo(G,1,'jefe');I.brazo(G,-1,'jefe');});
 parte('mano izq',()=>I.mano(G,1));parte('mano der',()=>I.mano(G,-1));parte('piernas',()=>{I.pierna(G,1);I.pierna(G,-1);});parte('cabeza',()=>I.cabeza(G,'jefe'));
 parte('cabeza tirador',()=>I.cabeza(G,'tirador'));parte('fusil',()=>I.fusil(G));parte('escopeta',()=>I.escopeta(G));parte('tirador',()=>I.tirador(G));parte('granada',()=>I.granadaGeo(G,'granada'));}
/* 2. poses quietas: error de manos y piso */
const prueba=(nombre,rol,fn,seg=1.2)=>{const u=UEM.crear(rol,{semilla:3});escena.add(u.root);fn(u.e,u);
  for(let i=0;i<seg*60;i++)u.update(1/60);const n=nan(u);log(nombre.padEnd(22),rol.padEnd(9),'manos',errManos(u).join('/'),'minY',minY(u).join(' '),n?'NaN '+n:'');u.dispose();return u;};
for(const r of Object.keys(UEM.ROLES)){
  prueba('de pie',r,e=>{});
  prueba('apunta',r,e=>{e.apunta=1;});
  prueba('apunta izq arriba',r,e=>{e.apunta=1;e.mYaw=1.2;e.mPitch=.8;});
  prueba('apunta der abajo',r,e=>{e.apunta=1;e.mYaw=-1.2;e.mPitch=-.8;});
  prueba('agachado apunta',r,e=>{e.agach=1;e.apunta=1;});
  prueba('tierra apunta',r,e=>{e.tierra=1;e.apunta=1;});
  prueba('asoma der',r,e=>{e.apunta=1;e.asoma=1;});
}
log(out.length);
fs.writeFileSync(__dirname+'/nodo.txt',out.join('\n'));console.log(out.join('\n'));
